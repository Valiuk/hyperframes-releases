/*
    ExtractLayers.jsx — Hyperframes
    Витягує шари з виділених прекомпів у поточну композицію,
    зберігаючи їхнє положення, трансформації й таймінг.

    Як працює:
    1. Для кожного прекомпу створюється невидимий шар-контролер
       "[назва] [transform]" — копія трансформацій прекомп-шару (з ключами).
    2. Усі шари прекомпу копіюються над прекомп-шаром у тому ж порядку.
    3. Верхньорівневі шари парентяться до контролера без "стрибка",
       внутрішній парентинг і трек-матти відновлюються.
    4. Час зсувається на startTime прекомпу, шари обрізаються по його in/out.
    5. Оригінальний прекомп-шар вимикається (не видаляється).
*/

(function extractLayers() {
    var SCRIPT_NAME = "Extract Layers";

    var comp = app.project.activeItem;
    if (!(comp instanceof CompItem)) {
        alert("Відкрийте композицію та виділіть прекомп-шар(и).", SCRIPT_NAME);
        return;
    }

    var sel = comp.selectedLayers;
    var precomps = [];
    for (var i = 0; i < sel.length; i++) {
        if (sel[i] instanceof AVLayer && sel[i].source instanceof CompItem) {
            precomps.push(sel[i]);
        }
    }
    if (!precomps.length) {
        alert("Серед виділених шарів немає прекомпів.", SCRIPT_NAME);
        return;
    }
    if (typeof precomps[0].setParentWithJump !== "function") {
        alert("Ця версія After Effects не підтримує setParentWithJump(). Оновіть AE.", SCRIPT_NAME);
        return;
    }

    var warnings = [];
    var extractedTotal = 0;

    app.beginUndoGroup(SCRIPT_NAME);
    try {
        for (var k = 0; k < precomps.length; k++) {
            extractedTotal += extractOne(comp, precomps[k], warnings);
        }
    } catch (e) {
        alert("Помилка: " + e.toString() + (e.line ? " (рядок " + e.line + ")" : ""), SCRIPT_NAME);
    } finally {
        app.endUndoGroup();
    }

    var msg = "Витягнуто шарів: " + extractedTotal;
    if (warnings.length) {
        msg += "\n\nЗверніть увагу:\n• " + warnings.join("\n• ");
    }
    alert(msg, SCRIPT_NAME);

    // ------------------------------------------------------------

    function extractOne(comp, pl, warnings) {
        var src = pl.source;
        var n = src.numLayers;
        if (n === 0) return 0;

        var tag = "«" + pl.name + "»: ";

        // --- Перевірки того, що парентинг не переносить ---
        if (pl.stretch !== 100) warnings.push(tag + "stretch " + pl.stretch + "% — таймінг не масштабовано.");
        if (pl.timeRemapEnabled) warnings.push(tag + "Time Remap не переноситься.");
        var op = pl.property("ADBE Transform Group").property("ADBE Opacity");
        if (op.numKeys > 0 || op.value !== 100) warnings.push(tag + "прозорість прекомпу не успадковується шарами.");
        if (pl.property("ADBE Effect Parade").numProperties > 0) warnings.push(tag + "ефекти прекомп-шару не перенесено.");
        if (pl.property("ADBE Mask Parade").numProperties > 0) warnings.push(tag + "маски прекомп-шару не перенесено.");
        if (pl.blendingMode !== BlendingMode.NORMAL) warnings.push(tag + "режим накладання прекомпу не перенесено.");
        if (pl.hasTrackMatte) warnings.push(tag + "трек-матт прекомпу не перенесено.");
        if (pl.threeDLayer) warnings.push(tag + "прекомп у 3D — перевірте 2D-шари після витягування.");
        for (var c = 1; c <= n; c++) {
            if (src.layer(c) instanceof CameraLayer || src.layer(c) instanceof LightLayer) {
                warnings.push(tag + "камера/світло з прекомпу тепер впливає на батьківську композицію.");
                break;
            }
        }

        // --- Шар-контролер з трансформаціями прекомпу ---
        var wasLocked = pl.locked;
        pl.locked = false;

        var ctrl = pl.duplicate();
        if (ctrl.timeRemapEnabled) ctrl.timeRemapEnabled = false;
        var tmpNull = comp.layers.addNull();
        var nullSrc = tmpNull.source;
        tmpNull.remove();
        ctrl.replaceSource(nullSrc, false);
        ctrl.name = pl.name + " [transform]";
        ctrl.enabled = false;
        try { ctrl.audioEnabled = false; } catch (e1) {}
        var fx = ctrl.property("ADBE Effect Parade");
        for (var f = fx.numProperties; f >= 1; f--) fx.property(f).remove();
        var masks = ctrl.property("ADBE Mask Parade");
        for (var m = masks.numProperties; m >= 1; m--) masks.property(m).remove();

        // --- Копіювання шарів (зверху вниз, щоб зберегти порядок) ---
        var newL = [];
        var lockedFlags = [];
        for (var i = 1; i <= n; i++) {
            src.layer(i).copyToComp(comp);
            var L = comp.layer(1);
            lockedFlags[i] = L.locked;
            L.locked = false;
            L.moveBefore(pl);
            newL[i] = L;
        }

        // --- Час, парентинг, трек-матти ---
        var offset = pl.startTime;
        for (var j = 1; j <= n; j++) {
            var s = src.layer(j);
            var NL = newL[j];

            NL.startTime = NL.startTime + offset;

            var parentTarget = s.parent ? newL[s.parent.index] : ctrl;
            NL.setParentWithJump(parentTarget);

            if (typeof NL.setTrackMatte === "function") {
                try {
                    if (s.hasTrackMatte && s.trackMatteLayer) {
                        NL.setTrackMatte(newL[s.trackMatteLayer.index], s.trackMatteType);
                    }
                } catch (e2) {}
            }

            // Обрізка по видимому діапазону прекомп-шару
            var a = Math.max(NL.inPoint, pl.inPoint);
            var b = Math.min(NL.outPoint, pl.outPoint);
            if (b > a) {
                NL.inPoint = a;
                NL.outPoint = b;
            } else {
                NL.enabled = false; // шар не був видимий у прекомпі
            }
        }

        // --- Відновлення блокувань, вимкнення оригіналу ---
        for (var q = 1; q <= n; q++) {
            if (lockedFlags[q]) newL[q].locked = true;
        }
        pl.enabled = false;
        try { pl.audioEnabled = false; } catch (e3) {}
        pl.locked = wasLocked;

        return n;
    }
})();
