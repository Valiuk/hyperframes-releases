/**
 * Тонка обгортка над window.__adobe_cep__ — щоб не тягнути повний CSInterface.js.
 */
(function (global) {
  'use strict';

  const bridge = global.__adobe_cep__;

  function evalScript(script) {
    return new Promise((resolve, reject) => {
      if (!bridge) { reject(new Error('CEP-хост недоступний. Панель відкрита поза After Effects?')); return; }
      bridge.evalScript(script, (res) => {
        if (res === 'EvalScript error.') {
          reject(new Error('ExtendScript не виконався: ' + script.slice(0, 90)));
        } else {
          resolve(res === undefined || res === null ? '' : String(res));
        }
      });
    });
  }

  /**
   * Корінь розширення. У CEP __dirname — це вже папка з index.html,
   * але на різних версіях трапляється по-різному, тож перевіряємо кандидатів
   * за наявністю jsx/host.jsx, а не вгадуємо.
   */
  let cachedDir = null;
  function extensionDir() {
    if (cachedDir) return cachedDir;
    const fs = require('fs');
    const path = require('path');
    const tried = [];

    if (typeof __dirname !== 'undefined') {
      tried.push(__dirname, path.dirname(__dirname), path.join(__dirname, '..'));
    }
    try {
      const sys = decodeURI(bridge.getSystemPath('extension')).replace(/^file:\/{2,3}/, '');
      tried.push(sys);
    } catch (e) { /* getSystemPath є не завжди */ }
    try {
      tried.push(path.dirname(decodeURIComponent(global.location.pathname).replace(/^\//, '')));
      tried.push(path.dirname(decodeURIComponent(global.location.pathname)));
    } catch (e) { /* ignore */ }

    for (const c of tried) {
      try {
        if (c && fs.existsSync(path.join(c, 'jsx', 'host.jsx'))) { cachedDir = c; return c; }
      } catch (e) { /* ignore */ }
    }
    throw new Error('Не знайшов jsx/host.jsx. Перевірені шляхи: ' + tried.join(' | '));
  }

  function jsxPath() {
    return require('path').join(extensionDir(), 'jsx', 'host.jsx').replace(/\\/g, '/');
  }

  let loaded = false;
  async function loadHost() {
    if (loaded) return;
    const jsx = jsxPath();
    // evalFile мовчки повертає false на неіснуючому файлі — тому перевіряємо явно
    const res = await evalScript(
      '$.evalFile("' + jsx + '"); (typeof AET === "object" && AET !== null) ? "ready" : "missing"');
    if (res.trim() !== 'ready') {
      throw new Error('host.jsx не завантажився (' + jsx + '). Відповідь хоста: "' + res.slice(0, 60) + '"');
    }
    loaded = true;
  }

  /** Виклик хендлера з host.jsx. Кидає Error з людським текстом. */
  async function host(name, payload) {
    await loadHost();
    const arg = encodeURIComponent(JSON.stringify(payload === undefined ? null : payload));
    const raw = await evalScript('AET.dispatch("' + name + '","' + arg + '")');

    if (!raw) {
      loaded = false;   // наступний виклик перезавантажить host.jsx
      throw new Error('Хост нічого не повернув на «' + name + '». Налаштування ▸ Перевірити зв\'язок.');
    }
    let parsed;
    try {
      parsed = JSON.parse(decodeURIComponent(raw));
    } catch (e) {
      throw new Error('Нечитабельна відповідь хоста (' + raw.length + ' симв.): ' + raw.slice(0, 140));
    }
    if (!parsed.ok) throw new Error(parsed.error);
    return parsed.data;
  }

  global.CEP = {
    evalScript, host, extensionDir, jsxPath,
    reset: () => { loaded = false; cachedDir = null; }
  };
})(window);
