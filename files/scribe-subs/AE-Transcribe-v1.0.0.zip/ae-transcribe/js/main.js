/**
 * AE Transcribe — логіка панелі.
 */
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);

  // напис на маркері композиції в AE обмежуємо словами, щоб не захаращувати таймлайн —
  // повний текст лишається в панелі, SRT/TXT-експорті й текстових шарах як і раніше
  const MARKER_MAX_WORDS = 3;
  function markerLabel(text) {
    const words = String(text || '').trim().split(/\s+/).filter(Boolean);
    if (words.length <= MARKER_MAX_WORDS) return words.join(' ');
    return words.slice(0, MARKER_MAX_WORDS).join(' ') + '…';
  }

  const ui = {
    source: $('source'), refresh: $('refresh'), run: $('run'),
    search: $('search'), follow: $('follow'), list: $('list'), empty: $('empty'),
    splitModeBtn: $('splitModeBtn'),
    translateBtn: $('translateBtn'),
    exportSrt: $('exportSrt'), exportTxt: $('exportTxt'), makeLayers: $('makeLayers'),
    openSettings: $('openSettings'), closeSettings: $('closeSettings'),
    saveSettings: $('saveSettings'), settings: $('settings'), status: $('status'),
    forget: $('forget'),
    speakersBtn: $('speakersBtn'), speakers: $('speakers'),
    speakerList: $('speakerList'), spHint: $('spHint'), doSplit: $('doSplit'),
    cutBtn: $('cutBtn'), undoBtn: $('undoBtn')
  };

  const state = {
    cfg: null,
    sel: null,          // дані виділеного шару
    phrases: [],        // фрази/речення у ЧАСІ ДЖЕРЕЛА
    rawWords: [],       // сирі слова від ElevenLabs (без offset) — для перегрупування без повторного запиту
    offset: 0,          // ss, застосований при транскрипції (додається до start/end слів)
    splitMode: 'phrase', // 'phrase' — короткі рядки, 'sentence' — по реченнях
    translations: null,  // масив рядків українською, паралельний до phrases
    showTranslation: false,
    busy: false,
    translating: false,
    pollId: null,
    currentIdx: -1,
    ctx: null,          // активна композиція: шари з аудіо, тривалість, шлях проєкту
    sessionKey: null,   // ключ, під яким розшифровка лежить на диску
    speakerNames: {},   // speaker_0 → як його назвав користувач
    cutMode: false,     // режим ✂: клік по слову розрізає рядок
    manual: false,      // чи є ручні розрізи/злиття/зміни спікера
    undo: []            // знімки структури для «↶»
  };

  /* ---------------- статус ---------------- */

  // мовчазна смерть панелі — найгірший режим відмови: помилка в одному місці
  // раніше просто зупиняла ініціалізацію, і зовні це виглядало як «нічого не працює»
  window.addEventListener('error', (ev) => {
    say('Збій панелі: ' + (ev.message || 'невідомо') +
      (ev.filename ? ' (' + ev.filename.split('/').pop() + ':' + ev.lineno + ')' : ''), 'err');
  });
  window.addEventListener('unhandledrejection', (ev) => {
    const r = ev.reason;
    say('Збій панелі: ' + ((r && r.message) ? r.message : String(r)), 'err');
  });

  let statusTimer = null;
  function say(msg, kind) {
    clearTimeout(statusTimer);
    ui.status.textContent = msg || '';
    ui.status.className = 'status' + (msg ? ' show' : '') + (kind === 'err' ? ' err' : '');
    if (msg && kind !== 'err' && kind !== 'hold') {
      statusTimer = setTimeout(() => say(''), 4000);
    }
  }

  /* ---------------- час ---------------- */

  // час усередині файлу-джерела -> час композиції
  function srcToComp(t) {
    const s = state.sel;
    if (!s) return t;
    const raw = s.startTime + t * (s.stretch / 100);
    return Math.round(raw / s.frameDuration) * s.frameDuration;   // рівно по кадрах
  }

  function compToSrc(t) {
    const s = state.sel;
    if (!s) return t;
    return (t - s.startTime) / (s.stretch / 100);
  }

  function tc(t) {
    const fd = (state.sel && state.sel.frameDuration) ||
      (state.ctx && state.ctx.frameDuration) || (1 / 25);
    const fps = Math.round(1 / fd);
    const total = Math.max(0, t);
    const h = Math.floor(total / 3600);
    const m = Math.floor(total / 60) % 60;
    const s = Math.floor(total) % 60;
    const f = Math.floor((total % 1) * fps);
    const p = (n) => String(n).padStart(2, '0');
    return (h ? p(h) + ':' : '') + p(m) + ':' + p(s) + ':' + p(f);
  }

  /**
   * Gemini повертає лише перекладений текст фрази, без власних таймкодів на слова.
   * Щоб клік по конкретному перекладеному слову все ж переносив плейхед у відповідне
   * місце всередині фрази (а не завжди на її початок), розподіляємо тривалість фрази
   * між словами пропорційно їхній довжині — це наближення, але зберігає порядок
   * і темп зчитування, тому клікабельність відчувається так само, як в оригіналі.
   */
  function splitProportional(ph, text) {
    const words = String(text || '').split(/\s+/).filter(Boolean);
    if (!words.length) return [];
    const dur = Math.max(0.01, ph.end - ph.start);
    const weights = words.map((w) => w.length + 1);
    const total = weights.reduce((a, b) => a + b, 0);
    let acc = 0;
    return words.map((w, i) => {
      const start = ph.start + (acc / total) * dur;
      acc += weights[i];
      const end = ph.start + (acc / total) * dur;
      return { text: w, start, end };
    });
  }

  /* ---------------- прив'язка до композиції ----------------
     Розшифровка належить композиції, а не виділеному шару. Панель сама
     знаходить аудіошар, а при перемиканні комп підвантажує збережену сесію. */

  function clearTranscript() {
    state.speakerNames = {};
    state.manual = false;
    state.undo = [];
    state.phrases = [];
    state.rawWords = [];
    state.offset = 0;
    state.translations = null;
    state.translationModel = null;
    state.showTranslation = false;
    state.currentIdx = -1;
  }

  /** Обирає шар, з якого брати аудіо: виділений → збережений → перший озвучений. */
  function pickLayer(saved) {
    const ctx = state.ctx;
    const list = ctx.layers || [];
    const byRef = (ref) => ref && (
      list.find((l) => l.layerIndex === ref.layerIndex && l.layerName === ref.layerName) ||
      list.find((l) => l.file === ref.file) || null);

    let L = null;
    if (ctx.selectedIndex) L = list.find((l) => l.layerIndex === ctx.selectedIndex) || null;
    if (!L && saved) L = byRef(saved.sel);
    if (!L && state.sel && state.sel.compId === ctx.compId) L = byRef(state.sel);
    if (!L) L = list.find((l) => l.audioActive !== false && l.enabled !== false) || list[0] || null;

    const compFields = {
      compId: ctx.compId, compName: ctx.compName,
      compDuration: ctx.compDuration, frameDuration: ctx.frameDuration
    };

    if (L) {
      state.sel = Object.assign({}, L, compFields);
    } else if (saved && saved.sel) {
      // шар видалили, але розшифровка лишилась — геометрію беремо зі збереженої
      state.sel = Object.assign({}, saved.sel, compFields, { stale: true });
    } else {
      state.sel = null;
    }
    ui.run.disabled = !L || state.busy;
    return L;
  }

  function updateHeader() {
    const ctx = state.ctx;
    if (!ctx) return;
    const n = state.phrases.length;
    let tail;
    if (!state.sel) tail = '<span class="warn">немає шарів з аудіо</span>';
    else if (state.sel.stale) tail = '<span class="warn">' + escapeHtml(state.sel.layerName) + ' — шару вже немає</span>';
    else tail = escapeHtml(state.sel.layerName);

    ui.source.className = 'source';
    ui.source.innerHTML = '<strong>' + escapeHtml(ctx.compName) + '</strong> · ' + tail +
      (n ? ' · <span class="badge">' + n + '</span>' : '');
    ui.forget.disabled = !n;
  }

  /** Відновлює збережену сесію поверх свіжозібраних фраз. */
  function applySession(saved) {
    if (!saved || !Array.isArray(saved.rawWords) || !saved.rawWords.length) return false;
    state.speakerNames = saved.speakerNames || {};
    state.rawWords = saved.rawWords;
    state.offset = saved.offset || 0;
    if (saved.splitMode) { state.splitMode = saved.splitMode; }
    state.phrases = Core.buildPhrases(state.rawWords, state.cfg, state.offset, state.splitMode);

    // якщо рядки різали вручну — перегруповуємо ті самі слова за збереженою структурою
    if (saved.manual && Array.isArray(saved.lengths)) {
      const flat = state.phrases.reduce((a, p) => a.concat(p.words), []);
      const sum = saved.lengths.reduce((a, b) => a + b, 0);
      if (sum === flat.length) {
        state.phrases = regroup(flat, saved.lengths, saved.speakers);
        state.manual = true;
      }
    }

    const n = state.phrases.length;
    if (Array.isArray(saved.texts) && saved.texts.length === n) {
      saved.texts.forEach((t, i) => { if (t) state.phrases[i].text = t; });
    }
    if (Array.isArray(saved.marked) && saved.marked.length === n) {
      saved.marked.forEach((m, i) => { state.phrases[i].marked = !!m; });
    }
    state.translations = (Array.isArray(saved.translations) && saved.translations.length === n)
      ? saved.translations : null;
    state.showTranslation = !!saved.showTranslation && !!state.translations;
    state.translationModel = state.translations ? (saved.translationModel || null) : null;
    return true;
  }

  /* ---------------- ручне розрізання ----------------
     Рядок = проміжок слів. Розрізати — поділити проміжок на два; злити —
     з'єднати сусідні. Слова зі своїми таймкодами Scribe не змінюються, тому
     навігація по слову, маркери й розкладка по спікерах лишаються точними.  */

  const joinWords = (ws) => ws.map((w) => w.text).join(' ');

  function dominantSpeaker(words) {
    const n = {};
    let best = null;
    for (const w of words) {
      if (!w.speaker) continue;
      n[w.speaker] = (n[w.speaker] || 0) + 1;
      if (!best || n[w.speaker] > n[best]) best = w.speaker;
    }
    return best;
  }

  function mkPhrase(words, speaker, marked) {
    return {
      words,
      text: joinWords(words),
      start: words[0].start,
      end: words[words.length - 1].end,
      speaker: speaker || dominantSpeaker(words),
      marked: !!marked
    };
  }

  function regroup(flat, lengths, speakers) {
    const out = [];
    let k = 0;
    lengths.forEach((len, i) => {
      const ws = flat.slice(k, k + len);
      k += len;
      if (ws.length) out.push(mkPhrase(ws, speakers && speakers[i]));
    });
    return out;
  }

  function snapshot() {
    return {
      lengths: state.phrases.map((p) => p.words.length),
      texts: state.phrases.map((p) => p.text),
      speakers: state.phrases.map((p) => p.speaker || null),
      marked: state.phrases.map((p) => !!p.marked),
      translations: Array.isArray(state.translations) ? state.translations.slice() : null,
      manual: state.manual
    };
  }

  function pushUndo() {
    state.undo.push(snapshot());
    if (state.undo.length > 50) state.undo.shift();
    ui.undoBtn.disabled = false;
  }

  /** Маркери, які панель вважає поставленими: ключ — кадр початку рядка. */
  function markerMap() {
    const m = new Map();
    const fd = (state.sel && state.sel.frameDuration) || (1 / 25);
    const showTr = state.showTranslation && Array.isArray(state.translations);
    state.phrases.forEach((p, i) => {
      if (!p.marked) return;
      const t = srcToComp(p.start);
      m.set(Math.round(t / fd), {
        time: t,
        duration: Math.max(0, srcToComp(p.end) - t),
        comment: markerLabel((showTr ? state.translations[i] : p.text) || '')
      });
    });
    return m;
  }

  /** Приводить маркери в AE до нового стану: прибирає зайві, ставить/оновлює потрібні. */
  async function syncMarkers(before, after) {
    if (!state.sel) return;
    const jobs = [];
    for (const [k, mk] of before) if (!after.has(k)) jobs.push({ time: mk.time, on: false });
    for (const [k, mk] of after) {
      const was = before.get(k);
      if (!was || Math.abs(was.duration - mk.duration) > 1e-6 || was.comment !== mk.comment) {
        jobs.push(Object.assign({ on: true }, mk));
      }
    }
    for (const j of jobs) {
      await CEP.host('toggleMarker', Object.assign({ compId: state.sel.compId }, j));
    }
  }

  async function afterStructureChange(before, note) {
    render();
    persist();
    updateHeader();
    try {
      await syncMarkers(before, markerMap());
    } catch (e) {
      say('Рядки змінено, але маркери в AE не оновились: ' + e.message, 'err');
      return;
    }
    if (note) say(note);
  }

  function splitAt(i, k) {
    const ph = state.phrases[i];
    if (!ph || k <= 0 || k >= ph.words.length) return;

    const before = markerMap();
    pushUndo();

    const wa = ph.words.slice(0, k), wb = ph.words.slice(k);
    // спікер, призначений вручну, успадковують обидві половини; якщо ж він
    // збігається з розміткою Scribe — кожна половина бере свого домінантного
    const overridden = ph.speaker && ph.speaker !== dominantSpeaker(ph.words);
    const A = mkPhrase(wa, overridden ? ph.speaker : null, ph.marked);
    const B = mkPhrase(wb, overridden ? ph.speaker : null, ph.marked);
    const edited = ph.text !== joinWords(ph.words);

    state.phrases.splice(i, 1, A, B);

    if (Array.isArray(state.translations)) {
      // переклад ділимо за тим самим наближенням, що й клікабельність слів
      const tokens = splitProportional(ph, state.translations[i]);
      const cut = B.start;
      const ta = tokens.filter((t) => (t.start + t.end) / 2 < cut).map((t) => t.text).join(' ');
      const tb = tokens.filter((t) => (t.start + t.end) / 2 >= cut).map((t) => t.text).join(' ');
      state.translations.splice(i, 1, ta, tb);
    }

    state.manual = true;
    const notes = ['Розрізано'];
    if (edited) notes.push('ручну правку тексту цього рядка скинуто');
    if (Array.isArray(state.translations)) notes.push('переклад поділено наближено — перевір межу');
    afterStructureChange(before, notes.join(' · '));
  }

  function mergeWithPrev(i) {
    if (i <= 0 || i >= state.phrases.length) return;
    const a = state.phrases[i - 1], b = state.phrases[i];

    const before = markerMap();
    pushUndo();

    const M = mkPhrase(a.words.concat(b.words), a.speaker, a.marked || b.marked);
    // ручні правки тексту зберігаємо — їх можна склеїти без втрат
    if (a.text !== joinWords(a.words) || b.text !== joinWords(b.words)) {
      M.text = a.text + ' ' + b.text;
    }
    state.phrases.splice(i - 1, 2, M);

    if (Array.isArray(state.translations)) {
      const t = [state.translations[i - 1], state.translations[i]].filter(Boolean).join(' ');
      state.translations.splice(i - 1, 2, t);
    }

    state.manual = true;
    const differ = a.speaker && b.speaker && a.speaker !== b.speaker;
    afterStructureChange(before, differ
      ? 'Злито рядки різних спікерів — лишився спікер верхнього рядка'
      : 'Злито з попереднім рядком');
  }

  function cycleSpeaker(i, backwards) {
    const ids = speakerIds();
    const ph = state.phrases[i];
    // до наявних спікерів додаємо «нового» — щоб можна було виділити
    // людину, яку Scribe злив з кимось іншим
    let fresh = 1;
    while (ids.indexOf('manual_' + fresh) >= 0) fresh++;
    const pool = ids.concat(['manual_' + fresh]);

    const at = pool.indexOf(ph.speaker);
    const next = pool[(at + (backwards ? pool.length - 1 : 1)) % pool.length];

    pushUndo();
    ph.speaker = next;
    state.manual = true;
    render();
    persist();
    const idx = speakerIds().indexOf(next);
    say('Рядок → ' + speakerName(next, idx) + '  (Shift+клік — у зворотний бік)');
  }

  function runUndo() {
    const snap = state.undo.pop();
    ui.undoBtn.disabled = !state.undo.length;
    if (!snap) return;

    const before = markerMap();
    const flat = state.phrases.reduce((a, p) => a.concat(p.words), []);
    state.phrases = regroup(flat, snap.lengths, snap.speakers);
    state.phrases.forEach((p, i) => {
      p.text = snap.texts[i];
      p.marked = snap.marked[i];
    });
    state.translations = snap.translations;
    if (!state.translations) state.showTranslation = false;
    state.manual = snap.manual;
    afterStructureChange(before, 'Скасовано');
  }

  function setCutMode(on) {
    state.cutMode = on;
    ui.cutBtn.classList.toggle('active', on);
    ui.list.classList.toggle('cutting', on);
    render();
    if (on) say('✂ Клік по слову — розріз перед ним · ⤒ — злити з попереднім · Ctrl+Z — скасувати', 'hold');
    else say('');
  }

  let persistTimer = null;
  function persist() {
    clearTimeout(persistTimer);
    persistTimer = setTimeout(() => {
      if (!state.sessionKey || !state.rawWords.length) return;
      try {
        Core.saveSession(state.sessionKey, {
          version: 1,
          savedAt: Date.now(),
          compId: state.ctx ? state.ctx.compId : 0,
          compName: state.ctx ? state.ctx.compName : '',
          sel: state.sel ? {
            layerIndex: state.sel.layerIndex, layerName: state.sel.layerName,
            file: state.sel.file, startTime: state.sel.startTime,
            inPoint: state.sel.inPoint, outPoint: state.sel.outPoint,
            stretch: state.sel.stretch, sourceDuration: state.sel.sourceDuration
          } : null,
          rawWords: state.rawWords,
          offset: state.offset,
          splitMode: state.splitMode,
          texts: state.phrases.map((p) => p.text),
          marked: state.phrases.map((p) => !!p.marked),
          // ручна структура: скільки слів у кожному рядку + спікер рядка.
          // Без цього ручні розрізи губилися б при перемиканні композицій
          lengths: state.phrases.map((p) => p.words.length),
          speakers: state.phrases.map((p) => p.speaker || null),
          manual: state.manual,
          translations: state.translations,
          showTranslation: state.showTranslation,
          translationModel: state.translationModel || null,
          speakerNames: state.speakerNames
        });
      } catch (e) {
        say('Не вдалося зберегти розшифровку: ' + e.message, 'err');
      }
    }, 400);
  }

  async function readContext(quiet) {
    let ctx;
    try {
      ctx = await CEP.host('getContext');
    } catch (e) {
      state.ctx = null; state.sel = null;
      ui.run.disabled = true;
      ui.forget.disabled = true;
      ui.source.className = 'source bad';
      ui.source.textContent = e.message;
      return null;
    }

    const switched = !state.ctx || state.ctx.compId !== ctx.compId;
    state.ctx = ctx;
    try {
      state.sessionKey = Core.sessionKey(ctx.projectPath, ctx.compId);
    } catch (e) {
      state.sessionKey = null;   // без сесій панель має лишатись робочою
      say('Сесії композицій недоступні: ' + e.message, 'err');
    }

    if (switched) {
      const saved = state.sessionKey ? Core.loadSession(state.sessionKey) : null;
      clearTranscript();
      pickLayer(saved);
      const restored = applySession(saved);
      updateSplitModeBtn();
      render();
      if (restored && !quiet) {
        say('Розшифровку композиції «' + ctx.compName + '» відновлено · ' + state.phrases.length + ' рядків');
      }
    } else {
      pickLayer(null);          // шар могли посунути — оновлюємо startTime/stretch
    }

    updateHeader();
    if (state.sel && state.sel.timeRemap && !quiet) {
      say('У шара ввімкнено Time Remap — таймкоди будуть приблизні.', 'hold');
    }
    return ctx;
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  /* ---------------- транскрипція ---------------- */

  async function runTranscription() {
    if (state.busy) return;
    await readContext(true);
    const sel = state.sel;
    if (!sel || sel.stale) { say('У цій композиції немає шару з аудіофайлом.', 'err'); return; }

    const cfg = state.cfg;
    if (!cfg.apiKey) { openSettings(); say('Спершу додай API-ключ ElevenLabs.', 'err'); return; }

    // діапазон у часі джерела
    let ss = 0, dur = 0;
    if (cfg.trimToInOut) {
      ss = Math.max(0, compToSrc(sel.inPoint));
      dur = Math.max(0, compToSrc(sel.outPoint) - ss);
    }

    state.busy = true;
    ui.run.disabled = true;
    let wav = null;

    try {
      const key = Core.cacheKey(sel.file, cfg, ss, dur);
      let data = Core.readCache(key);

      if (data) {
        say('Взято з кешу — натисни «Транскрибувати» ще раз, щоб перезапитати.');
      } else {
        say('Витягую аудіо…', 'hold');
        wav = await Core.extractAudio(sel.file, { ffmpeg: cfg.ffmpeg, ss, dur });

        say('Надсилаю в ElevenLabs…', 'hold');
        data = await Core.transcribe(wav, cfg, (p) => {
          if (p < 1) say('Завантаження ' + Math.round(p * 100) + '%…', 'hold');
          else say('Scribe розпізнає…', 'hold');
        });
        Core.writeCache(key, data);
      }

      state.rawWords = data.words || [];
      state.offset = ss;
      state.phrases = Core.buildPhrases(state.rawWords, cfg, state.offset, state.splitMode);
      state.manual = false;
      state.undo = [];
      state.translations = null;
      state.showTranslation = false;
      render();
      const lang = data.language_code ? ' · ' + data.language_code : '';
      const unit = state.splitMode === 'sentence' ? ' речень' : ' фраз';
      persist();
      updateHeader();
      say(state.phrases.length + unit + lang);
    } catch (e) {
      say(e.message, 'err');
    } finally {
      if (wav) Core.unlink(wav);
      state.busy = false;
      ui.run.disabled = !state.sel || !!state.sel.stale;
    }
  }

  /* ---------------- рендер ---------------- */

  function render() {
    const has = state.phrases.length > 0;
    ui.exportSrt.disabled = ui.exportTxt.disabled = ui.makeLayers.disabled = !has;
    updateSpeakersBtn();
    ui.translateBtn.disabled = !has || state.translating;
    ui.splitModeBtn.disabled = !has;
    ui.cutBtn.disabled = !has;
    ui.undoBtn.disabled = !state.undo.length;
    ui.list.classList.toggle('cutting', state.cutMode && has);
    state.currentIdx = -1;

    if (!has) { ui.list.innerHTML = ''; ui.list.appendChild(ui.empty); return; }

    const showTr = state.showTranslation && Array.isArray(state.translations);
    const spIds = speakerIds();
    // мітки спікерів показуємо, коли є діаризація, а в режимі ✂ — завжди:
    // так спікерів можна розставити вручну навіть без розмітки Scribe
    const showChips = spIds.length > 0 || state.cutMode;

    const frag = document.createDocumentFragment();
    state.phrases.forEach((ph, i) => {
      const row = document.createElement('div');
      row.className = 'phrase' + (ph.marked ? ' marked' : '');
      row.dataset.i = String(i);

      const mark = document.createElement('input');
      mark.type = 'checkbox';
      mark.className = 'mark';
      mark.checked = !!ph.marked;
      mark.title = 'Позначити рядок';
      row.appendChild(mark);

      const time = document.createElement('div');
      time.className = 'tc';
      time.textContent = tc(srcToComp(ph.start));
      if (state.cutMode && i > 0) {
        const join = document.createElement('button');
        join.className = 'ghost join';
        join.textContent = '⤒';
        join.title = 'Злити з попереднім рядком';
        time.appendChild(join);
      }

      const body = document.createElement('div');
      body.className = 'body';

      if (showChips) {
        const sp = document.createElement('span');
        sp.className = 'speaker chip';
        const si = spIds.indexOf(ph.speaker);
        const sw = document.createElement('span');
        sw.className = 'sp-swatch';
        sw.style.background = si >= 0 ? SP_COLORS[si % SP_COLORS.length] : '#555';
        sp.appendChild(sw);
        sp.appendChild(document.createTextNode(ph.speaker ? speakerName(ph.speaker, si) : 'без спікера'));
        sp.title = 'Клік — наступний спікер, Shift+клік — попередній';
        body.appendChild(sp);
      }

      const text = document.createElement('div');
      text.className = 'text';

      if (showTr && !state.cutMode) {
        // кожне перекладене слово отримує наближений таймкод (див. splitProportional) —
        // клік по слову веде саме на його місце в оригінальному аудіо, а не завжди на початок фрази
        const trWords = splitProportional(ph, state.translations[i]);
        trWords.forEach((w, wi) => {
          const span = document.createElement('span');
          span.className = 'w';
          span.dataset.t = String(w.start);
          span.dataset.te = String(w.end);
          span.textContent = w.text;
          text.appendChild(span);
          if (wi < trWords.length - 1) text.appendChild(document.createTextNode(' '));
        });
      } else {
        ph.words.forEach((w, wi) => {
          const span = document.createElement('span');
          span.className = 'w' + (w.event ? ' event' : '');
          span.dataset.t = String(w.start);
          span.dataset.k = String(wi);          // індекс слова — точка розрізу
          span.textContent = w.text;
          text.appendChild(span);
          if (wi < ph.words.length - 1) text.appendChild(document.createTextNode(' '));
        });
      }

      body.appendChild(text);
      if (state.cutMode && showTr && state.translations[i]) {
        // різати можна лише по справжніх словах Scribe — переклад показуємо під ними
        const under = document.createElement('div');
        under.className = 'tr-under';
        under.textContent = state.translations[i];
        body.appendChild(under);
      }
      row.appendChild(time);
      row.appendChild(body);
      frag.appendChild(row);
    });

    ui.list.innerHTML = '';
    ui.list.appendChild(frag);
    applyFilter();
    updateTranslateBtn();
    updateModelHints();
  }

  /* ---------------- навігація по таймлайну ---------------- */

  async function seek(srcTime) {
    if (!state.sel) return;
    try {
      await CEP.host('setTime', { compId: state.sel.compId, time: srcToComp(srcTime) });
    } catch (e) {
      say(e.message, 'err');
    }
  }

  ui.list.addEventListener('click', (ev) => {
    if (ev.target.closest('.mark')) return;   // клік по чекбоксу — не стрибати по таймлайну
    const row = ev.target.closest('.phrase');
    if (!row) return;
    if (row.querySelector('.text').isContentEditable) return;
    const i = Number(row.dataset.i);

    if (ev.target.closest('.speaker.chip')) { cycleSpeaker(i, ev.shiftKey); return; }

    if (state.cutMode) {
      if (ev.target.closest('.join')) { mergeWithPrev(i); return; }
      const w = ev.target.closest('.w');
      if (w && w.dataset.k && w.dataset.k !== '0') splitAt(i, Number(w.dataset.k));
      return;                                   // у режимі ✂ не стрибаємо по таймлайну
    }

    const word = ev.target.closest('.w');
    seek(word ? Number(word.dataset.t) : state.phrases[i].start);
  });

  // чекбокс навпроти рядка — ставить/знімає справжній маркер композиції в AE
  // на позиції фрази; панель підсвічує рядок одразу, не чекаючи відповіді хоста
  ui.list.addEventListener('change', async (ev) => {
    const mark = ev.target.closest ? ev.target.closest('.mark') : null;
    if (!mark) return;
    const row = mark.closest('.phrase');
    const i = Number(row.dataset.i);
    const ph = state.phrases[i];
    const on = mark.checked;

    ph.marked = on;
    row.classList.toggle('marked', on);

    if (!state.sel) {
      say('Немає зв\'язку з AE — позначку видно лише в панелі.', 'hold');
      return;
    }

    try {
      const fullText = (state.showTranslation && Array.isArray(state.translations)
        ? state.translations[i] : ph.text) || '';
      await CEP.host('toggleMarker', {
        compId: state.sel.compId,
        time: srcToComp(ph.start),
        duration: Math.max(0, srcToComp(ph.end) - srcToComp(ph.start)),
        comment: markerLabel(fullText),
        on
      });
      persist();
    } catch (e) {
      // відкат, якщо AE відмовив (композицію закрито, шар видалено тощо)
      ph.marked = !on;
      mark.checked = !on;
      row.classList.toggle('marked', !on);
      say(e.message, 'err');
    }
  });

  // подвійний клік — правка тексту фрази (оригінал іде в SRT і в текстові шари;
  // у режимі перекладу правиться сам переклад)
  ui.list.addEventListener('dblclick', (ev) => {
    if (state.cutMode) return;
    if (ev.target.closest('.mark') || ev.target.closest('.speaker')) return;
    const row = ev.target.closest('.phrase');
    if (!row) return;
    const text = row.querySelector('.text');
    text.contentEditable = 'true';
    text.focus();
    document.execCommand('selectAll', false, null);
  });

  ui.list.addEventListener('focusout', (ev) => {
    const text = ev.target.closest ? ev.target.closest('.text') : null;
    if (!text || !text.isContentEditable) return;
    text.contentEditable = 'false';
    const i = Number(text.closest('.phrase').dataset.i);
    const clean = text.textContent.trim().replace(/\s+/g, ' ');
    if (state.showTranslation && Array.isArray(state.translations)) {
      state.translations[i] = clean;
    } else {
      state.phrases[i].text = clean;
    }
    persist();
  });

  /* ---------------- слідування за плейхедом ---------------- */

  function startPolling() {
    stopPolling();
    state.pollId = setInterval(async () => {
      if (state.busy) return;
      let st;
      try {
        st = await CEP.host('getState');
      } catch (e) { return; }               // композицію могли закрити — мовчимо
      if (!st.compId) return;

      // перемкнули композицію — підтягуємо її власну розшифровку
      if (!state.ctx || st.compId !== state.ctx.compId) { await readContext(false); return; }

      if (ui.follow.checked && state.sel && state.phrases.length) highlight(compToSrc(st.time));
    }, 350);
  }
  function stopPolling() { if (state.pollId) clearInterval(state.pollId); state.pollId = null; }

  function highlight(srcTime) {
    let idx = -1;
    for (let i = 0; i < state.phrases.length; i++) {
      const p = state.phrases[i];
      if (srcTime >= p.start && srcTime <= p.end) { idx = i; break; }
    }
    if (idx === state.currentIdx) { markWord(idx, srcTime); return; }

    const prev = ui.list.querySelector('.phrase.current');
    if (prev) { prev.classList.remove('current'); prev.querySelectorAll('.w.on').forEach((w) => w.classList.remove('on')); }
    state.currentIdx = idx;
    if (idx < 0) return;

    const row = ui.list.querySelector('.phrase[data-i="' + idx + '"]');
    if (!row) return;
    row.classList.add('current');
    const box = ui.list.getBoundingClientRect(), r = row.getBoundingClientRect();
    if (r.top < box.top || r.bottom > box.bottom) row.scrollIntoView({ block: 'center' });
    markWord(idx, srcTime);
  }

  function markWord(idx, srcTime) {
    if (idx < 0) return;
    const row = ui.list.querySelector('.phrase[data-i="' + idx + '"]');
    if (!row) return;
    const wordEls = row.querySelectorAll('.w');
    let wi = -1;

    if (state.showTranslation) {
      for (let i = 0; i < wordEls.length; i++) {
        const t0 = Number(wordEls[i].dataset.t);
        const t1 = Number(wordEls[i].dataset.te || t0);
        if (srcTime >= t0 && srcTime <= t1) { wi = i; break; }
      }
    } else {
      const words = state.phrases[idx].words;
      for (let i = 0; i < words.length; i++) {
        if (srcTime >= words[i].start && srcTime <= words[i].end) { wi = i; break; }
      }
    }
    wordEls.forEach((el, i) => el.classList.toggle('on', i === wi));
  }

  /* ---------------- пошук ---------------- */

  function applyFilter() {
    const q = ui.search.value.trim().toLowerCase();
    const showTr = state.showTranslation && Array.isArray(state.translations);
    ui.list.querySelectorAll('.phrase').forEach((row) => {
      const i = Number(row.dataset.i);
      const src = showTr ? (state.translations[i] || '') : state.phrases[i].text;
      const hit = q && src.toLowerCase().includes(q);
      row.classList.toggle('dim', !!q && !hit);
      row.classList.toggle('hit', !!hit);
    });
  }

  /* ---------------- експорт ---------------- */

  function exportPhrases() {
    // у файл пишемо час композиції: так субтитри збігаються з рендером
    return state.phrases.map((p) => ({
      text: p.text,
      start: srcToComp(p.start),
      end: srcToComp(p.end)
    }));
  }

  ui.exportSrt.addEventListener('click', () => {
    try {
      const f = Core.writeNextTo(state.sel.file, '.srt', Core.toSrt(exportPhrases()));
      say('Збережено: ' + f);
    } catch (e) { say(e.message, 'err'); }
  });

  ui.exportTxt.addEventListener('click', () => {
    try {
      const f = Core.writeNextTo(state.sel.file, '.txt',
        state.phrases.map((p) => p.text).join('\n'));
      say('Збережено: ' + f);
    } catch (e) { say(e.message, 'err'); }
  });

  ui.makeLayers.addEventListener('click', async () => {
    try {
      const res = await CEP.host('createTextLayers', {
        compId: state.sel.compId,
        phrases: exportPhrases(),
        style: { fontSize: state.cfg.fontSize || 0, yFactor: 0.82, label: 9 }
      });
      say('Створено шарів: ' + res.created);
    } catch (e) { say(e.message, 'err'); }
  });

  /* ---------------- фрази ⇄ речення ---------------- */

  function updateSplitModeBtn() {
    const isSentence = state.splitMode === 'sentence';
    // кнопка показує ЦІЛЬ кліку (як і «Переклад»/«Оригінал»), не поточний стан
    ui.splitModeBtn.textContent = isSentence ? 'Фрази' : 'Речення';
    ui.splitModeBtn.classList.toggle('active', isSentence);
    ui.splitModeBtn.title = isSentence
      ? 'Зараз розбито по реченнях (розрив на .!?…). Клік — короткі рядки, як у субтитрах'
      : 'Зараз короткі рядки, як у субтитрах. Клік — розбити по реченнях';
  }

  let splitModeArmed = 0;
  function onSplitModeClick() {
    // перебудова з нуля знищить ручні розрізи — просимо повторний клік
    if (state.manual && Date.now() - splitModeArmed > 3000) {
      splitModeArmed = Date.now();
      say('Є ручні розрізи. Ще один клік протягом 3 с перебудує рядки і скине їх.', 'hold');
      return;
    }
    splitModeArmed = 0;
    const next = state.splitMode === 'sentence' ? 'phrase' : 'sentence';
    state.splitMode = next;
    state.cfg.splitMode = next;
    Core.saveConfig(state.cfg);
    updateSplitModeBtn();

    if (!state.rawWords.length) return;   // ще не транскрибовано — застосується при наступному запуску

    // індекси рядків зміняться, тож переклад і позначки-маркери прив'язані до
    // старого групування більше не мають сенсу в панелі (самі маркери в AE лишаються)
    const hadExtra = (Array.isArray(state.translations) && state.translations.length > 0) ||
      state.phrases.some((p) => p.marked);

    state.phrases = Core.buildPhrases(state.rawWords, state.cfg, state.offset, state.splitMode);
    state.manual = false;
    state.undo = [];
    state.translations = null;
    state.showTranslation = false;
    render();

    persist();
    updateHeader();
    const unit = next === 'sentence' ? ' речень' : ' фраз';
    say(state.phrases.length + unit + (hadExtra ? ' · переклад і позначки в панелі скинуто' : ''));
  }

  ui.splitModeBtn.addEventListener('click', onSplitModeClick);
  ui.cutBtn.addEventListener('click', () => setCutMode(!state.cutMode));
  ui.undoBtn.addEventListener('click', runUndo);

  document.addEventListener('keydown', (ev) => {
    const t = ev.target;
    if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
    // ev.code, а не ev.key: на українській розкладці Ctrl+Z дає key === 'я'
    if ((ev.ctrlKey || ev.metaKey) && !ev.shiftKey && ev.code === 'KeyZ') {
      ev.preventDefault();
      runUndo();
    } else if (ev.code === 'Escape' && state.cutMode) {
      setCutMode(false);
    }
  });

  /* ---------------- переклад (Gemini) ---------------- */

  function updateTranslateBtn() {
    const has = Array.isArray(state.translations) && state.translations.length === state.phrases.length;
    ui.translateBtn.textContent = state.translating
      ? 'Перекладаю…'
      : (has && state.showTranslation ? 'Оригінал' : 'Переклад');
    ui.translateBtn.classList.toggle('active', !!(has && state.showTranslation));
  }

  async function onTranslateClick(force) {
    if (state.translating || !state.phrases.length) return;

    const has = Array.isArray(state.translations) && state.translations.length === state.phrases.length;
    if (has && force !== true) {
      // переклад уже готовий — просто перемикаємо відображення
      state.showTranslation = !state.showTranslation;
      render();
      return;
    }

    const cfg = state.cfg;
    if (!cfg.geminiApiKey) { openSettings(); say('Спершу додай API-ключ Gemini.', 'err'); return; }

    state.translating = true;
    ui.translateBtn.disabled = true;
    say('Перекладаю…', 'hold');

    try {
      const key = Core.translationCacheKey(state.phrases, cfg);
      let arr = force === true ? null : Core.readCache(key);
      if (!arr) {
        arr = await Core.translatePhrases(state.phrases, cfg, (p) => {
          say('Перекладаю ' + Math.round(p * 100) + '%…', 'hold');
        });
        Core.writeCache(key, arr);
      }
      state.translations = arr;
      state.translationModel = cfg.geminiModel || Core.DEFAULTS.geminiModel;
      state.showTranslation = true;
      persist();
      say('Перекладено на українську');
    } catch (e) {
      // за типом збою підказуємо наступний крок, а не лише код помилки
      let hint = '';
      if (e.kind === 'overload') hint = '  →  відкрий ▾ і обери модель із зеленою позначкою';
      else if (e.kind === 'quota') hint = '  →  це ліміт твого ключа; інша модель може мати окремий ліміт (▾)';
      else if (e.kind === 'missing') hint = '  →  обери іншу модель у ▾';
      say(e.message + hint, 'err');
      updateModelHints();
    } finally {
      state.translating = false;
      render();
    }
  }

  ui.translateBtn.addEventListener('click', () => onTranslateClick(false));

  /* ---------------- вибір моделі Gemini ---------------- */

  const modelUi = {
    pop: $('modelPop'), btn: $('modelBtn'), list: $('modelList'), note: $('modelNote'),
    filter: $('modelFilter'), all: $('modelAll'), refresh: $('modelRefresh'),
    custom: $('modelCustom'), customSet: $('modelCustomSet'), retranslate: $('modelRetranslate'),
    probe: $('modelProbe'), statusLink: $('modelStatusLink'), dot: $('modelDot')
  };
  const modelState = { list: null, at: 0, loading: false, probing: new Set(), probingRun: false };

  const currentModel = () => state.cfg.geminiModel || Core.DEFAULTS.geminiModel;

  // для перекладу підходять лише текстові моделі: ембединги, TTS, генерація
  // зображень/відео та live-аудіо або впадуть, або перекладуть погано
  const NON_TEXT = /embed|tts|imagen|image|veo|aqa|live|native-audio|robotics|computer-use|learnlm/i;
  function isTextModel(m) {
    return m.methods.indexOf('generateContent') >= 0 && !NON_TEXT.test(m.id);
  }

  function modelVersion(id) {
    const mm = id.match(/gemini-(\d+(?:\.\d+)?)/);
    return mm ? parseFloat(mm[1]) : 0;
  }

  function modelTag(id) {
    if (/latest/.test(id)) return 'alias';
    if (/preview/.test(id)) return 'preview';
    if (/exp/.test(id)) return 'exp';
    return '';
  }
  const TAG_TEXT = { alias: 'найновіша', preview: 'preview', exp: 'exp' };

  function sortModels(a, b) {
    const ta = modelTag(a.id) === 'alias', tb = modelTag(b.id) === 'alias';
    if (ta !== tb) return ta ? -1 : 1;
    const va = modelVersion(a.id), vb = modelVersion(b.id);
    if (va !== vb) return vb - va;
    const sa = modelTag(a.id) ? 1 : 0, sb = modelTag(b.id) ? 1 : 0;   // стабільні вище preview
    if (sa !== sb) return sa - sb;
    return a.id.localeCompare(b.id);
  }

  function groupName(m) {
    if (modelTag(m.id) === 'alias') return 'Завжди найновіша версія';
    const v = modelVersion(m.id);
    return v ? 'Gemini ' + Math.floor(v) : 'Інші';
  }

  function updateModelHints() {
    const m = currentModel();
    ui.translateBtn.title = 'Переклад українською · ' + m;
    const hs = Core.healthSummary(m);
    modelUi.dot.className = 'hd mini ' + hs.level + (hs.stale ? ' stale' : '');
    modelUi.btn.title = 'Модель Gemini: ' + m + ' — ' + hs.text;
    const has = Array.isArray(state.translations) && state.translations.length === state.phrases.length;
    const r = modelUi.retranslate;
    r.classList.toggle('hidden', !has);
    if (has) {
      r.textContent = (state.translationModel && state.translationModel !== m)
        ? 'Перекласти заново моделлю ' + m
        : 'Перекласти ще раз (' + m + ')';
    }
  }

  function renderModelList() {
    const cur = currentModel();
    const q = modelUi.filter.value.trim().toLowerCase();
    modelUi.list.innerHTML = '';

    let items = (modelState.list || []).filter((m) => modelUi.all.checked || isTextModel(m));
    if (q) items = items.filter((m) => (m.id + ' ' + m.name).toLowerCase().includes(q));
    items.sort(sortModels);

    // поточна модель могла бути введена вручну і в списку не значитись
    if (modelState.list && !modelState.list.some((m) => m.id === cur) && (!q || cur.includes(q))) {
      items.unshift({ id: cur, name: 'Поточна — у списку ключа не знайдена', methods: [], missing: true });
    }

    const frag = document.createDocumentFragment();
    let lastGroup = null;
    for (const m of items) {
      const g = m.missing ? 'Поточна' : groupName(m);
      if (g !== lastGroup) {
        const h = document.createElement('div');
        h.className = 'pm-group';
        h.textContent = g;
        frag.appendChild(h);
        lastGroup = g;
      }
      const row = document.createElement('div');
      row.className = 'pm-item' + (m.id === cur ? ' on' : '');
      row.dataset.id = m.id;
      row.title = m.input ? 'Контекст: ' + m.input.toLocaleString('uk-UA') + ' токенів' : m.id;

      const check = document.createElement('span');
      check.className = 'pm-check';
      check.textContent = m.id === cur ? '✓' : '';

      const main = document.createElement('span');
      main.className = 'pm-main';
      const nm = document.createElement('span');
      nm.className = 'pm-name';
      nm.textContent = m.name || m.id;
      const idEl = document.createElement('span');
      idEl.className = 'pm-id';
      idEl.textContent = m.id;
      main.appendChild(nm);
      main.appendChild(idEl);

      const tagKind = m.missing ? '' : modelTag(m.id);
      const tag = document.createElement('span');
      if (tagKind) {
        tag.className = 'pm-tag ' + tagKind;
        tag.textContent = TAG_TEXT[tagKind];
      }

      const probing = modelState.probing.has(m.id);
      const hs = Core.healthSummary(m.id);
      const dot = document.createElement('span');
      dot.className = 'hd ' + (probing ? 'probing' : hs.level + (hs.stale ? ' stale' : ''));
      row.title = (probing ? 'Перевіряю…' : hs.text) +
        (m.input ? ' · контекст ' + m.input.toLocaleString('uk-UA') + ' токенів' : '');

      row.appendChild(check);
      row.appendChild(dot);
      row.appendChild(main);
      row.appendChild(tag);
      frag.appendChild(row);
    }
    modelUi.list.appendChild(frag);

    if (modelState.list && !items.length) {
      setModelNote(q ? 'Нічого не знайдено за «' + q + '».' : 'Текстових моделей у цього ключа немає — спробуй «Показати всі».');
    }
  }

  function setModelNote(text, isErr) {
    modelUi.note.textContent = text || '';
    modelUi.note.className = 'pop-note' + (isErr ? ' err' : '');
  }

  async function loadModels(force) {
    if (modelState.loading) return;
    modelState.loading = true;
    modelUi.refresh.classList.add('spin');
    if (!modelState.list) setModelNote('Завантажую список моделей…');
    try {
      const res = await Core.listGeminiModels(state.cfg, !!force);
      modelState.list = res.models;
      modelState.at = res.at;
      const textN = res.models.filter(isTextModel).length;
      const when = new Date(res.at).toLocaleString('uk-UA', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
      setModelNote(textN + ' текстових моделей · список від ' + when + (res.cached ? ' (кеш)' : ''));
    } catch (e) {
      setModelNote(e.message, true);
    } finally {
      modelState.loading = false;
      modelUi.refresh.classList.remove('spin');
      renderModelList();
    }
  }

  function positionModelPop() {
    const bar = modelUi.btn.closest('.bar');
    const top = Math.round(bar.getBoundingClientRect().bottom) + 4;
    modelUi.pop.style.top = top + 'px';
    modelUi.pop.style.maxHeight = Math.max(180, window.innerHeight - top - 8) + 'px';
  }

  function openModelPop() {
    positionModelPop();
    modelUi.pop.classList.remove('hidden');
    modelUi.btn.classList.add('open');
    modelUi.custom.value = '';
    updateModelHints();
    renderModelList();
    if (!modelState.list) loadModels(false);
    modelUi.filter.focus();
  }

  function closeModelPop() {
    modelUi.pop.classList.add('hidden');
    modelUi.btn.classList.remove('open');
  }

  const modelPopOpen = () => !modelUi.pop.classList.contains('hidden');

  function setModel(id) {
    id = String(id || '').trim().replace(/^models\//, '');
    if (!id) return;
    state.cfg.geminiModel = id;
    Core.saveConfig(state.cfg);
    const field = $('geminiModel');            // тримаємо в синхроні з полем у ⚙
    if (field) field.value = id;
    renderModelList();
    updateModelHints();
    const has = Array.isArray(state.translations) && state.translations.length === state.phrases.length;
    say('Модель перекладу: ' + id + (has && state.translationModel !== id ? ' · поточний переклад зроблено іншою — «Перекласти заново»' : ''));
  }

  modelUi.btn.addEventListener('click', () => (modelPopOpen() ? closeModelPop() : openModelPop()));
  modelUi.refresh.addEventListener('click', () => loadModels(true));
  modelUi.filter.addEventListener('input', renderModelList);
  modelUi.all.addEventListener('change', renderModelList);

  modelUi.list.addEventListener('click', (ev) => {
    const row = ev.target.closest('.pm-item');
    if (row) setModel(row.dataset.id);
  });
  modelUi.list.addEventListener('dblclick', (ev) => {
    if (ev.target.closest('.pm-item')) closeModelPop();   // дабл-клік — обрати й закрити
  });

  modelUi.customSet.addEventListener('click', () => setModel(modelUi.custom.value));
  modelUi.custom.addEventListener('keydown', (ev) => {
    if (ev.code === 'Enter' || ev.code === 'NumpadEnter') setModel(modelUi.custom.value);
  });

  modelUi.retranslate.addEventListener('click', () => {
    const sameModel = state.translationModel === currentModel();
    closeModelPop();
    state.translations = null;
    state.showTranslation = false;
    // тією ж моделлю — оминаємо кеш, інакше отримаємо той самий результат
    onTranslateClick(sameModel);
  });

  /* ---------------- перевірка стану моделей ---------------- */

  const PROBE_MAX = 8;          // більше за раз — марна витрата ліміту ключа
  const PROBE_PARALLEL = 3;

  function renderModelListKeepScroll() {
    const y = modelUi.list.scrollTop;
    renderModelList();
    modelUi.list.scrollTop = y;
  }

  async function probeVisible() {
    if (modelState.probingRun) return;
    if (!state.cfg.geminiApiKey) { setModelNote('Додай ключ Gemini в ⚙.', true); return; }

    // перевіряємо лише текстові моделі зі списку на екрані; поточну — завжди першою
    const byId = new Map((modelState.list || []).map((m) => [m.id, m]));
    const visible = [...modelUi.list.querySelectorAll('.pm-item')].map((r) => r.dataset.id)
      .filter((id) => byId.has(id) && isTextModel(byId.get(id)));
    const cur = currentModel();
    const queue = [cur].concat(visible.filter((id) => id !== cur)).slice(0, PROBE_MAX);
    const total = queue.length;
    const tested = queue.slice();

    modelState.probingRun = true;
    modelUi.probe.disabled = true;
    queue.forEach((id) => modelState.probing.add(id));
    renderModelListKeepScroll();
    setModelNote('Перевіряю 0/' + total + '…');

    let done = 0;
    const worker = async () => {
      while (queue.length) {
        const id = queue.shift();
        try { await Core.probeGeminiModel(state.cfg, id); } catch (e) { /* записано в журнал */ }
        modelState.probing.delete(id);
        done++;
        setModelNote('Перевіряю ' + done + '/' + total + '…');
        renderModelListKeepScroll();
        updateModelHints();
      }
    };
    try {
      await Promise.all(Array.from({ length: PROBE_PARALLEL }, worker));
    } finally {
      modelState.probingRun = false;
      modelUi.probe.disabled = false;
    }

    const lv = tested.map((id) => Core.healthSummary(id).level);
    const n = (k) => lv.filter((x) => x === k).length;
    const P = Core.plural;
    const parts = [P(n('ok'), 'працює', 'працюють', 'працюють')];
    if (n('warn')) parts.push(P(n('warn'), 'повільна чи нестабільна', 'повільні чи нестабільні', 'повільних чи нестабільних'));
    if (n('down')) parts.push(P(n('down'), 'зі збоєм', 'зі збоєм', 'зі збоєм'));
    if (n('quota')) parts.push(P(n('quota'), 'вперлась у ліміт ключа', 'вперлись у ліміт ключа', 'вперлись у ліміт ключа'));
    if (n('missing')) parts.push(P(n('missing'), 'недоступна', 'недоступні', 'недоступних'));
    setModelNote('Перевірено ' + P(total, 'модель', 'моделі', 'моделей') + ': ' + parts.join(', ') +
      '. Кожна перевірка — крихітний запит, що враховується в ліміті ключа.');
    renderModelListKeepScroll();
    updateModelHints();
  }

  function openExternal(url) {
    try {
      if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) {
        window.cep.util.openURLInDefaultBrowser(url);
        return;
      }
    } catch (e) { /* падаємо на системний спосіб */ }
    try {
      const { spawn } = require('child_process');
      if (process.platform === 'win32') spawn('cmd', ['/c', 'start', '', url], { detached: true, windowsHide: true });
      else spawn('open', [url], { detached: true });
    } catch (e) {
      say('Не вдалося відкрити браузер: ' + url, 'err');
    }
  }

  modelUi.probe.addEventListener('click', probeVisible);
  modelUi.statusLink.addEventListener('click', () => openExternal('https://aistudio.google.com/status'));

  // закриття: клік поза вікном або Esc (навіть з фокусом у полі фільтра)
  document.addEventListener('mousedown', (ev) => {
    if (!modelPopOpen()) return;
    if (modelUi.pop.contains(ev.target) || modelUi.btn.contains(ev.target)) return;
    closeModelPop();
  });
  document.addEventListener('keydown', (ev) => {
    if (ev.code === 'Escape' && modelPopOpen()) {
      ev.stopPropagation();
      closeModelPop();
    }
  }, true);
  window.addEventListener('resize', () => { if (modelPopOpen()) positionModelPop(); });

  /* ---------------- композиції по спікерах ---------------- */

  // кольори міток шарів в AE, якими розводимо спікерів
  const SP_LABELS = [9, 11, 5, 2, 14, 4, 6, 10];
  const SP_COLORS = ['#5a8fd6', '#c76fb0', '#6fc78f', '#d6b45a', '#a97fd6', '#d67f5a', '#5ac7c7', '#9ad65a'];

  function speakerIds() {
    const seen = [];
    for (const p of state.phrases) {
      if (p.speaker && seen.indexOf(p.speaker) < 0) seen.push(p.speaker);
    }
    return seen;
  }

  function speakerName(id, i) {
    return state.speakerNames[id] || ('Спікер ' + (i + 1));
  }

  function updateSpeakersBtn() {
    const n = speakerIds().length;
    ui.speakersBtn.disabled = n < 1 || !state.sel || !!state.sel.stale;
    ui.speakersBtn.title = n < 1
      ? 'Спікерів не розмічено — увімкни «Розділяти спікерів» у ⚙ і перетранскрибуй'
      : 'Розкласти ' + n + ' спікер(ів) по окремих композиціях';
  }

  function mmss(t) {
    const m = Math.floor(t / 60), sec = Math.round(t % 60);
    return m + ':' + String(sec).padStart(2, '0');
  }

  function currentTurnOpts() {
    return {
      padding: parseFloat($('spPad').value) || 0,
      minTurn: parseFloat($('spMin').value) || 0
    };
  }

  function renderSpeakerList() {
    const ids = speakerIds();
    const groups = Core.buildTurns(state.phrases, currentTurnOpts());
    ui.speakerList.innerHTML = '';

    if (!ids.length) {
      ui.spHint.textContent = 'У цій розшифровці спікерів не розмічено. Увімкни «Розділяти спікерів» у налаштуваннях і запусти транскрипцію ще раз.';
      ui.doSplit.disabled = true;
      return;
    }

    ids.forEach((id, i) => {
      const g = groups.find((x) => x.id === id) || { turns: [], total: 0 };
      const row = document.createElement('div');
      row.className = 'sp-row';
      row.dataset.id = id;

      const box = document.createElement('input');
      box.type = 'checkbox';
      box.className = 'sp-on';
      box.checked = g.turns.length > 0;
      box.disabled = g.turns.length === 0;

      const name = document.createElement('input');
      name.type = 'text';
      name.className = 'sp-name';
      name.value = speakerName(id, i);
      name.addEventListener('change', () => {
        state.speakerNames[id] = name.value.trim() || ('Спікер ' + (i + 1));
        persist();
      });

      const stat = document.createElement('div');
      stat.className = 'sp-stat';
      stat.innerHTML = '<span class="sp-swatch" style="background:' + SP_COLORS[i % SP_COLORS.length] + '"></span>' +
        g.turns.length + ' × ' + mmss(g.total);

      row.appendChild(box);
      row.appendChild(name);
      row.appendChild(stat);
      ui.speakerList.appendChild(row);
    });

    const totalTurns = groups.reduce((n, g) => n + g.turns.length, 0);
    ui.spHint.textContent = 'Буде створено композицію на кожного позначеного спікера, ' +
      'усередині — ' + totalTurns + ' обрізаних копій шару «' + (state.sel ? state.sel.layerName : '') + '».';
    ui.doSplit.disabled = false;
  }

  function openSpeakers() {
    if (!state.phrases.length) return;
    renderSpeakerList();
    ui.speakers.classList.remove('hidden');
  }

  async function runSplit() {
    if (!state.sel || state.sel.stale) { say('Немає живого шару з аудіо в цій композиції.', 'err'); return; }

    const ids = speakerIds();
    const groups = Core.buildTurns(state.phrases, currentTurnOpts());
    const chosen = [];

    ui.speakerList.querySelectorAll('.sp-row').forEach((row, i) => {
      if (!row.querySelector('.sp-on').checked) return;
      const id = row.dataset.id;
      const g = groups.find((x) => x.id === id);
      if (!g || !g.turns.length) return;
      chosen.push({
        name: row.querySelector('.sp-name').value.trim() || speakerName(id, i),
        label: SP_LABELS[ids.indexOf(id) % SP_LABELS.length],
        // у хост віддаємо ЧАС КОМПОЗИЦІЇ, квантований по кадрах
        turns: g.turns.map((t) => ({ start: srcToComp(t.start), end: srcToComp(t.end) }))
      });
    });

    if (!chosen.length) { say('Не позначено жодного спікера.', 'err'); return; }

    const mode = document.querySelector('input[name="spMode"]:checked').value;
    ui.doSplit.disabled = true;
    say('Створюю композиції…', 'hold');

    try {
      const res = await CEP.host('splitBySpeaker', {
        compId: state.sel.compId,
        layerIndex: state.sel.layerIndex,
        speakers: chosen,
        mode,
        open: $('spOpen').checked
      });
      ui.speakers.classList.add('hidden');
      const total = res.comps.reduce((n, c) => n + c.layers, 0);
      say('Готово: ' + res.comps.length + ' композицій, ' + total + ' фрагментів · папка «' + res.folder + '»');
    } catch (e) {
      say(e.message, 'err');
    } finally {
      ui.doSplit.disabled = false;
    }
  }

  ui.speakersBtn.addEventListener('click', openSpeakers);
  $('closeSpeakers').addEventListener('click', () => ui.speakers.classList.add('hidden'));
  ui.doSplit.addEventListener('click', runSplit);
  $('spPad').addEventListener('change', renderSpeakerList);
  $('spMin').addEventListener('change', renderSpeakerList);

  /* ---------------- налаштування ---------------- */


  const fields = ['apiKey', 'ffmpeg', 'model', 'language', 'maxGap', 'sentenceGap', 'maxChars',
    'trimToInOut', 'diarize', 'tagAudioEvents', 'geminiApiKey', 'geminiModel'];

  function fillSettings() {
    fields.forEach((k) => {
      const el = $(k);
      if (el.type === 'checkbox') el.checked = !!state.cfg[k];
      else el.value = state.cfg[k];
    });
  }

  function openSettings() { fillSettings(); ui.settings.classList.remove('hidden'); }

  ui.openSettings.addEventListener('click', openSettings);
  ui.closeSettings.addEventListener('click', () => ui.settings.classList.add('hidden'));
  ui.saveSettings.addEventListener('click', () => {
    fields.forEach((k) => {
      const el = $(k);
      if (el.type === 'checkbox') state.cfg[k] = el.checked;
      else if (el.type === 'number') state.cfg[k] = parseFloat(el.value) || Core.DEFAULTS[k];
      else state.cfg[k] = el.value.trim();
    });
    Core.saveConfig(state.cfg);
    ui.settings.classList.add('hidden');
    say('Налаштування збережено');
  });

  /* ---------------- діагностика мосту ---------------- */

  $('checkLink').addEventListener('click', async () => {
    const out = $('diagOut');
    out.classList.remove('hidden');
    const lines = [];

    const path = require('path'), fs = require('fs');
    lines.push('__dirname: ' + (typeof __dirname !== 'undefined' ? __dirname : '—'));
    try {
      const dir = CEP.extensionDir();
      lines.push('корінь:    ' + dir);
      lines.push('host.jsx:  ' + (fs.existsSync(path.join(dir, 'jsx', 'host.jsx')) ? 'знайдено' : 'НЕМАЄ'));
    } catch (e) {
      lines.push('корінь:    ✗ ' + e.message);
    }

    const probes = [
      ['арифметика', '1+1'],
      ['evalFile  ', '$.evalFile("' + safeJsx() + '")'],
      ['typeof AET', 'typeof AET'],
      ['ping      ', 'AET.dispatch("ping","null")'],
      ['кирилиця  ', 'AET.dispatch("getSelection","null")']
    ];

    for (const [label, script] of probes) {
      try {
        const raw = await CEP.evalScript(script);
        let shown = raw === '' ? '(порожньо)' : raw.slice(0, 160);
        if (raw.indexOf('%7B') === 0 || raw.indexOf('%7b') === 0) {
          try { shown = decodeURIComponent(raw).slice(0, 160); } catch (e) { /* ignore */ }
        }
        lines.push(label + ' → ' + shown);
      } catch (e) {
        lines.push(label + ' → ✗ ' + e.message);
      }
    }

    out.textContent = lines.join('\n');
  });

  function safeJsx() {
    try { return CEP.jsxPath(); } catch (e) { return ''; }
  }

  /* ---------------- старт ---------------- */

  ui.refresh.addEventListener('click', () => readContext(false));

  ui.forget.addEventListener('click', () => {
    if (!state.sessionKey) return;
    Core.dropSession(state.sessionKey);
    clearTranscript();
    render();
    updateHeader();
    say('Розшифровку цієї композиції забуто.');
  });
  ui.run.addEventListener('click', runTranscription);
  ui.search.addEventListener('input', applyFilter);
  window.addEventListener('focus', () => readContext(true));

  (async function init() {
    if (Core.fatal) { say(Core.fatal, 'err'); ui.run.disabled = true; return; }
    state.cfg = Core.loadConfig();
    state.splitMode = state.cfg.splitMode || 'phrase';
    updateSplitModeBtn();
    try {
      const info = await CEP.host('ping');
      ui.source.textContent = 'Виділи шар з аудіо · ' + info.app + ' ' + info.version;
    } catch (e) {
      ui.source.className = 'source bad';
      ui.source.textContent = 'Немає зв\'язку з AE';
      say(e.message + '  →  ⚙ Перевірити зв\'язок з AE', 'err');
      ui.run.disabled = true;
      return;
    }
    await readContext(false);
    if (!state.cfg.apiKey) say('Додай API-ключ ElevenLabs у налаштуваннях ⚙', 'hold');
    startPolling();
  })();
})();
