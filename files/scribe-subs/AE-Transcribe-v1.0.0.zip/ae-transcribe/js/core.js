/**
 * AE Transcribe — робота з диском, ffmpeg та ElevenLabs Scribe.
 * Усе через Node (--enable-nodejs), тому запит іде повз CORS браузера.
 */
(function (global) {
  'use strict';

  if (typeof require === 'undefined') {
    global.Core = { fatal: 'Node.js вимкнено. Додай --enable-nodejs у CEFCommandLine та перезапусти After Effects.' };
    return;
  }

  const fs = require('fs');
  const os = require('os');
  const path = require('path');
  const https = require('https');
  const crypto = require('crypto');
  const { spawn } = require('child_process');

  const HOME = path.join(os.homedir(), '.ae-transcribe');
  const CACHE = path.join(HOME, 'cache');
  const SESSIONS = path.join(HOME, 'sessions');
  const CFG = path.join(HOME, 'config.json');

  const DEFAULTS = {
    apiKey: '',
    ffmpeg: process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg',
    model: 'scribe_v2',
    language: '',          // порожньо = автовизначення (важливо для мультигео)
    tagAudioEvents: false,
    diarize: false,
    trimToInOut: true,
    maxGap: 0.35,
    sentenceGap: 3.0,      // фолбек лише для режиму «Речення»: рве без пунктуації тільки на дуже довгій тиші
    maxChars: 42,
    fontSize: 0,           // 0 = авто від висоти композиції
    geminiApiKey: '',
    geminiModel: 'gemini-3.6-flash',
    splitMode: 'phrase'   // 'phrase' — короткі рядки (як субтитри), 'sentence' — по реченнях
  };

  function ensureDirs() {
    for (const d of [HOME, CACHE, SESSIONS]) {
      if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
    }
  }

  function loadConfig() {
    ensureDirs();
    try {
      return Object.assign({}, DEFAULTS, JSON.parse(fs.readFileSync(CFG, 'utf8')));
    } catch (e) {
      return Object.assign({}, DEFAULTS);
    }
  }

  function saveConfig(cfg) {
    ensureDirs();
    fs.writeFileSync(CFG, JSON.stringify(cfg, null, 2), 'utf8');
    return cfg;
  }

  /* ---------------- ffmpeg ---------------- */

  function extractAudio(srcFile, opts) {
    return new Promise((resolve, reject) => {
      if (!fs.existsSync(srcFile)) {
        reject(new Error('Вихідний файл не знайдено на диску: ' + srcFile));
        return;
      }
      ensureDirs();
      const out = path.join(os.tmpdir(), 'aet_' + Date.now() + '.wav');
      const args = ['-hide_banner', '-loglevel', 'error', '-y'];
      if (opts.ss > 0) args.push('-ss', opts.ss.toFixed(3));
      args.push('-i', srcFile);
      if (opts.dur > 0) args.push('-t', opts.dur.toFixed(3));
      args.push('-vn', '-ac', '1', '-ar', '16000', '-c:a', 'pcm_s16le', out);

      // spawn з масивом аргументів: пробіли й кирилиця в шляхах не ламаються
      const p = spawn(opts.ffmpeg, args, { windowsHide: true });
      let err = '';
      p.stderr.on('data', (d) => { err += d.toString(); });
      p.on('error', (e) => {
        reject(new Error('ffmpeg не запустився (' + e.code + '). Вкажи повний шлях до ffmpeg у налаштуваннях.'));
      });
      p.on('close', (code) => {
        if (code === 0 && fs.existsSync(out)) resolve(out);
        else reject(new Error('ffmpeg завершився з кодом ' + code + '. ' + err.trim().slice(0, 300)));
      });
    });
  }

  /* ---------------- ElevenLabs Scribe ---------------- */

  function buildMultipart(fields, fileBuffer, fileName) {
    const boundary = '----AET' + crypto.randomBytes(8).toString('hex');
    const chunks = [];
    for (const key of Object.keys(fields)) {
      if (fields[key] === '' || fields[key] === null || fields[key] === undefined) continue;
      chunks.push(Buffer.from(
        '--' + boundary + '\r\n' +
        'Content-Disposition: form-data; name="' + key + '"\r\n\r\n' +
        fields[key] + '\r\n', 'utf8'));
    }
    chunks.push(Buffer.from(
      '--' + boundary + '\r\n' +
      'Content-Disposition: form-data; name="file"; filename="' + fileName + '"\r\n' +
      'Content-Type: audio/wav\r\n\r\n', 'utf8'));
    chunks.push(fileBuffer);
    chunks.push(Buffer.from('\r\n--' + boundary + '--\r\n', 'utf8'));
    return { body: Buffer.concat(chunks), boundary };
  }

  function transcribe(wavPath, cfg, onProgress) {
    return new Promise((resolve, reject) => {
      if (!cfg.apiKey) { reject(new Error('Не вказано ключ ElevenLabs. Відкрий налаштування панелі.')); return; }

      const buf = fs.readFileSync(wavPath);
      const { body, boundary } = buildMultipart({
        model_id: cfg.model,
        timestamps_granularity: 'word',
        tag_audio_events: cfg.tagAudioEvents ? 'true' : 'false',
        diarize: cfg.diarize ? 'true' : 'false',
        language_code: cfg.language || ''
      }, buf, 'audio.wav');

      const req = https.request({
        method: 'POST',
        host: 'api.elevenlabs.io',
        path: '/v1/speech-to-text',
        headers: {
          'xi-api-key': cfg.apiKey,
          'Accept': 'application/json',
          'Content-Type': 'multipart/form-data; boundary=' + boundary,
          'Content-Length': body.length
        }
      }, (res) => {
        let data = '';
        res.setEncoding('utf8');
        res.on('data', (d) => { data += d; });
        res.on('end', () => {
          if (res.statusCode === 401) { reject(new Error('ElevenLabs відхилив ключ (401). Перевір API-ключ.')); return; }
          if (res.statusCode === 429) { reject(new Error('Ліміт запитів ElevenLabs (429). Спробуй за хвилину.')); return; }
          if (res.statusCode < 200 || res.statusCode >= 300) {
            let msg = data.slice(0, 300);
            try { msg = JSON.stringify(JSON.parse(data).detail || msg); } catch (e) {}
            reject(new Error('ElevenLabs ' + res.statusCode + ': ' + msg));
            return;
          }
          try { resolve(JSON.parse(data)); }
          catch (e) { reject(new Error('Не вдалося розібрати відповідь ElevenLabs.')); }
        });
      });

      req.on('error', (e) => reject(new Error('Мережа: ' + e.message)));
      req.setTimeout(30 * 60 * 1000, () => { req.destroy(new Error('таймаут 30 хв')); });

      // прогрес завантаження — файл може бути на десятки МБ
      const CHUNK = 256 * 1024;
      let sent = 0;
      (function write() {
        while (sent < body.length) {
          const end = Math.min(sent + CHUNK, body.length);
          const ok = req.write(body.slice(sent, end));
          sent = end;
          if (onProgress) onProgress(sent / body.length);
          if (!ok) { req.once('drain', write); return; }
        }
        req.end();
      })();
    });
  }

  /* ---------------- стан моделей Gemini ----------------
     Google не публікує стан окремих моделей у машиночитаному вигляді, тому
     міряємо самі: кожен справжній запит перекладу (пасивно) і кнопка
     «Перевірити» (активно, крихітний запит) пишуть сюди результат.
     503/500/таймаут — навантаження на боці Google; 429 — ліміт САМЕ твого
     ключа. Їх тримаємо окремо, бо лікуються вони по-різному.               */

  const HEALTH_FILE = path.join(HOME, 'gemini-health.json');
  const HEALTH_KEEP = 25;                  // подій на модель
  const HEALTH_TTL = 24 * 3600 * 1000;
  const SLOW_MS = 8000;                    // крихітна перевірка довше 8 с — модель «важка»
  const RECENT_MS = 30 * 60 * 1000;

  function classifyStatus(status) {
    if (status >= 200 && status < 300) return 'ok';
    if (status === 429) return 'quota';
    if (status === 404) return 'missing';
    if (status === 401 || status === 403) return 'auth';
    if (status === 400) return 'bad';
    if (status >= 500) return 'overload';
    return 'bad';
  }

  function readHealth() {
    try { return JSON.parse(fs.readFileSync(HEALTH_FILE, 'utf8')) || {}; } catch (e) { return {}; }
  }

  function recordHealth(model, status, ms, source, kind) {
    try {
      ensureDirs();
      const h = readHealth();
      const now = Date.now();
      const list = (h[model] || []).filter((e) => now - e.at < HEALTH_TTL);
      list.push({ at: now, status, ms: Math.round(ms), source, kind: kind || classifyStatus(status) });
      h[model] = list.slice(-HEALTH_KEEP);
      fs.writeFileSync(HEALTH_FILE, JSON.stringify(h), 'utf8');
    } catch (e) { /* журнал стану не має права ламати переклад */ }
  }

  // 1 збій, 2 збої, 5 збоїв; 11 збоїв
  function plural(n, one, few, many) {
    const d = n % 10, h = n % 100;
    if (d === 1 && h !== 11) return n + ' ' + one;
    if (d >= 2 && d <= 4 && (h < 12 || h > 14)) return n + ' ' + few;
    return n + ' ' + many;
  }

  function agoText(ms) {
    const m = Math.round(ms / 60000);
    if (m < 1) return 'щойно';
    if (m < 60) return m + ' хв тому';
    const h = Math.round(m / 60);
    return h + ' год тому';
  }

  /**
   * Підсумок для крапки біля моделі.
   * level: ok | warn | down | quota | missing | unknown;  stale — дані старші за 30 хв.
   */
  function healthSummary(model, now) {
    now = now || Date.now();
    // мережа, ключ і кривий запит не кажуть нічого про навантаження моделі
    const ev = (readHealth()[model] || []).filter((e) =>
      now - e.at < HEALTH_TTL && e.kind !== 'network' && e.kind !== 'auth' && e.kind !== 'bad');
    if (!ev.length) {
      return { level: 'unknown', stale: false, text: 'Немає даних — натисни «Перевірити»' };
    }

    const last = ev[ev.length - 1];
    const age = now - last.at;
    const recent = ev.filter((e) => now - e.at < RECENT_MS);
    const over = recent.filter((e) => e.kind === 'overload').length;
    const ok = recent.filter((e) => e.kind === 'ok').length;
    const sec = (last.ms / 1000).toFixed(1) + ' с';
    const when = agoText(age);
    const tally = recent.length > 1
      ? ' · за 30 хв: ' + plural(ok, 'успіх', 'успіхи', 'успіхів') + ', ' + plural(over, 'збій', 'збої', 'збоїв')
      : '';

    let level, text;
    if (last.kind === 'missing') {
      level = 'missing';
      text = 'Недоступна для цього ключа (404) · ' + when;
    } else if (last.kind === 'quota') {
      level = 'quota';
      text = 'Ліміт твого ключа (429) — це не збій Google, інша модель може мати окремий ліміт · ' + when;
    } else if (last.kind === 'overload') {
      level = (over >= 2 || ok === 0) ? 'down' : 'warn';
      text = (level === 'down' ? 'Збій / перевантаження' : 'Нестабільно') +
        ' (' + (last.status || 'таймаут') + ') · ' + when + tally;
    } else if (last.source === 'probe' && last.ms > SLOW_MS) {
      level = 'warn';
      text = 'Відповідає повільно: ' + sec + ' на крихітний запит · ' + when + tally;
    } else if (over > 0) {
      level = 'warn';
      text = 'Зараз працює, але були збої' + tally + ' · ' + when;
    } else {
      level = 'ok';
      text = 'Працює' + (last.source === 'probe' ? ' · ' + sec : '') + ' · ' + when + tally;
    }

    return { level, stale: age > RECENT_MS, text: text + (age > RECENT_MS ? ' (дані застарілі)' : '') };
  }

  /** Крихітний запит до моделі: міряє лише, чи й як швидко вона відповідає. */
  function probeGeminiModel(cfg, model) {
    return new Promise((resolve) => {
      const body = Buffer.from(JSON.stringify({
        contents: [{ parts: [{ text: 'Reply with one word: ok' }] }],
        generationConfig: { maxOutputTokens: 16, temperature: 0 }
      }), 'utf8');
      const t0 = Date.now();
      let done = false;
      const finish = (status, kind) => {
        if (done) return;
        done = true;
        const ms = Date.now() - t0;
        recordHealth(model, status, ms, 'probe', kind);
        resolve({ model, status, ms, kind: kind || classifyStatus(status) });
      };

      const req = https.request({
        method: 'POST',
        host: 'generativelanguage.googleapis.com',
        path: '/v1beta/models/' + encodeURIComponent(model) + ':generateContent',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': cfg.geminiApiKey,
          'Content-Length': body.length
        }
      }, (res) => {
        res.on('data', () => {});
        res.on('end', () => finish(res.statusCode));
      });
      req.on('error', (e) => finish(0, /таймаут|timeout/i.test(e.message) ? 'overload' : 'network'));
      req.setTimeout(20000, () => req.destroy(new Error('таймаут')));
      req.end(body);
    });
  }

  /* ---------------- переклад через Gemini ---------------- */

  // одна фраза за раз, а пачками — швидше й дешевше, і вкладається в ліміт токенів відповіді
  const GEMINI_CHUNK = 50;

  function geminiTranslateChunk(texts, cfg) {
    return new Promise((resolve, rejectRaw) => {
      // кожна помилка несе kind — панель за ним підкаже, що робити далі
      let kind = 'bad';
      const reject = (e) => { if (!e.kind) e.kind = kind; rejectRaw(e); };
      const t0 = Date.now();
      if (!cfg.geminiApiKey) { reject(new Error('Не вказано ключ Gemini. Відкрий налаштування панелі.')); return; }

      const prompt =
        'Переклади кожен рядок цього масиву субтитрів українською мовою. ' +
        'Пиши природною розмовною українською, як у якісному дубляжі субтитрів. ' +
        'Не додавай, не прибирай, не об’єднуй і не розбивай рядки. ' +
        'Поверни JSON-масив рядків — той самий порядок, рівно ' + texts.length + ' елементів, без пояснень.\n\n' +
        JSON.stringify(texts);

      const body = Buffer.from(JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          responseMimeType: 'application/json',
          responseSchema: { type: 'ARRAY', items: { type: 'STRING' } },
          temperature: 0.2
        }
      }), 'utf8');

      const model = cfg.geminiModel || DEFAULTS.geminiModel;
      const req = https.request({
        method: 'POST',
        host: 'generativelanguage.googleapis.com',
        path: '/v1beta/models/' + encodeURIComponent(model) + ':generateContent',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': cfg.geminiApiKey,
          'Content-Length': body.length
        }
      }, (res) => {
        let data = '';
        res.setEncoding('utf8');
        res.on('data', (d) => { data += d; });
        res.on('end', () => {
          kind = classifyStatus(res.statusCode);
          recordHealth(model, res.statusCode, Date.now() - t0, 'translate');
          if (res.statusCode === 503 || res.statusCode === 500 || res.statusCode === 502 || res.statusCode === 504) {
            reject(new Error('Gemini ' + res.statusCode + ': модель ' + model + ' зараз перевантажена або збоїть.'));
            return;
          }
          if (res.statusCode === 400) { reject(new Error('Gemini відхилив запит (400). Перевір модель у налаштуваннях.')); return; }
          if (res.statusCode === 403) { reject(new Error('Gemini: доступ заборонено (403). Перевір API-ключ.')); return; }
          if (res.statusCode === 404) {
            let msg = 'модель недоступна';
            try { msg = JSON.parse(data).error.message || msg; } catch (e) {}
            reject(new Error('Gemini 404: ' + msg + ' — постав нову назву моделі в ⚙ (наприклад gemini-3.6-flash).'));
            return;
          }
          if (res.statusCode === 429) { reject(new Error('Ліміт запитів Gemini (429). Спробуй за хвилину.')); return; }
          if (res.statusCode < 200 || res.statusCode >= 300) {
            let msg = data.slice(0, 300);
            try { msg = JSON.parse(data).error.message || msg; } catch (e) {}
            reject(new Error('Gemini ' + res.statusCode + ': ' + msg));
            return;
          }
          try {
            const parsed = JSON.parse(data);
            const text = parsed.candidates[0].content.parts[0].text;
            const arr = JSON.parse(text);
            if (!Array.isArray(arr)) throw new Error('відповідь не масив');
            resolve(arr);
          } catch (e) {
            reject(new Error('Не вдалося розібрати відповідь Gemini.'));
          }
        });
      });

      req.on('error', (e) => {
        const timedOut = /таймаут|timeout/i.test(e.message);
        kind = timedOut ? 'overload' : 'network';
        recordHealth(model, 0, Date.now() - t0, 'translate', kind);
        reject(new Error(timedOut
          ? 'Gemini не відповів за 2 хв — модель ' + model + ' перевантажена.'
          : 'Мережа: ' + e.message));
      });
      req.setTimeout(2 * 60 * 1000, () => { req.destroy(new Error('таймаут 2 хв')); });
      req.end(body);
    });
  }

  async function translatePhrases(phrases, cfg, onProgress) {
    const texts = phrases.map((p) => p.text);
    const out = [];
    for (let i = 0; i < texts.length; i += GEMINI_CHUNK) {
      const chunk = texts.slice(i, i + GEMINI_CHUNK);
      let res = await geminiTranslateChunk(chunk, cfg);
      if (!Array.isArray(res)) res = [];
      // якщо модель повернула не той розмір — вирівнюємо, аби індекси не поїхали
      while (res.length < chunk.length) res.push(chunk[res.length]);
      res.length = chunk.length;
      out.push.apply(out, res);
      if (onProgress) onProgress(Math.min(1, (i + chunk.length) / texts.length));
    }
    return out;
  }

  function translationCacheKey(phrases, cfg) {
    const raw = phrases.map((p) => p.text).join('\u241F') + '|' + (cfg.geminiModel || DEFAULTS.geminiModel) + '|ukr';
    return 'tr_' + crypto.createHash('md5').update(raw).digest('hex');
  }

  /* ---------------- кеш ---------------- */

  function cacheKey(srcFile, cfg, ss, dur) {
    const st = fs.statSync(srcFile);
    const raw = [srcFile, st.size, st.mtimeMs, cfg.model, cfg.language, cfg.diarize,
      cfg.tagAudioEvents, ss.toFixed(3), dur.toFixed(3)].join('|');
    return crypto.createHash('md5').update(raw).digest('hex');
  }

  function readCache(key) {
    const f = path.join(CACHE, key + '.json');
    if (!fs.existsSync(f)) return null;
    try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return null; }
  }

  function writeCache(key, data) {
    ensureDirs();
    fs.writeFileSync(path.join(CACHE, key + '.json'), JSON.stringify(data), 'utf8');
  }

  /* ---------------- групування у фрази / речення ---------------- */

  const TERMINAL = /[.!?…।॥]["»)]?$/;

  // поширені скорочення, після яких крапка не означає кінець речення —
  // інакше режим «Речення» розбивав би текст на кожному «т.д.», «Mr.» тощо.
  // Список не вичерпний — це евристика, а не повноцінний детектор скорочень.
  const ABBREVIATIONS = new Set([
    'р.', 'рр.', 'ст.', 'м.', 'вул.', 'просп.', 'пров.', 'обл.', 'р-н',
    'т.д.', 'т.п.', 'т.і.', 'т.ін.', 'ін.', 'див.', 'напр.', 'ім.',
    'п.', 'пп.', 'гр.', 'грн.', 'тис.', 'млн.', 'млрд.', 'проф.', 'акад.',
    'канд.', 'доц.', 'др.', 'д-р', 'о.', 'вид.', 'ред.', 'та ін.',
    'mr.', 'mrs.', 'ms.', 'dr.', 'prof.', 'sr.', 'jr.', 'vs.', 'etc.',
    'e.g.', 'i.e.', 'inc.', 'ltd.', 'co.', 'st.', 'ave.', 'no.', 'approx.',
    'a.m.', 'p.m.'
  ]);

  // окремо — одна літера з крапкою (ініціал: «А.», «J.») теж не кінець речення
  const INITIAL = /^[A-ZА-ЯІЇЄҐ]\.$/;

  function isSentenceEnd(word) {
    if (!TERMINAL.test(word)) return false;
    const lower = word.toLowerCase();
    if (ABBREVIATIONS.has(lower)) return false;
    if (INITIAL.test(word)) return false;
    return true;
  }

  function buildPhrases(words, cfg, offset, mode) {
    const bySentence = mode === 'sentence';
    const src = (words || []).filter((w) =>
      w.type === 'word' || (cfg.tagAudioEvents && w.type === 'audio_event'));
    const out = [];
    let cur = null;

    for (const w of src) {
      const word = {
        text: w.text,
        start: w.start + offset,
        end: w.end + offset,
        speaker: w.speaker_id || null,
        event: w.type === 'audio_event'
      };

      if (cur) {
        const prev = cur.words[cur.words.length - 1];
        const gap = word.start - prev.end;
        const speakerChanged = cfg.diarize && word.speaker && prev.speaker && word.speaker !== prev.speaker;

        let shouldBreak;
        if (bySentence) {
          // речення: пауза сама по собі НЕ рве речення (диктор може драматично
          // паузити посеред фрази) — рвемо лише на межі речення (з урахуванням
          // скорочень), на зміні спікера, або коли тиша аж надто довга і явно
          // означає, що Scribe просто не розставив пунктуацію
          shouldBreak = speakerChanged || gap > cfg.sentenceGap || isSentenceEnd(prev.text);
        } else {
          // фрази: як і раніше — короткі рядки, обмежені довжиною й паузою
          const wouldBe = cur.text.length + 1 + word.text.length;
          shouldBreak = gap > cfg.maxGap || wouldBe > cfg.maxChars || speakerChanged ||
            (TERMINAL.test(prev.text) && cur.text.length > 12);
        }

        if (shouldBreak) {
          out.push(cur);
          cur = null;
        }
      }

      if (!cur) cur = { words: [], text: '', start: word.start, end: word.end, speaker: word.speaker };
      cur.words.push(word);
      cur.text = (cur.text ? cur.text + ' ' : '') + word.text;
      cur.end = word.end;
    }
    if (cur) out.push(cur);
    return out;
  }

  /* ---------------- експорт ---------------- */

  function srtTime(t) {
    if (t < 0) t = 0;
    const ms = Math.round(t * 1000);
    const h = Math.floor(ms / 3600000);
    const m = Math.floor(ms / 60000) % 60;
    const s = Math.floor(ms / 1000) % 60;
    const p = (n, w) => String(n).padStart(w, '0');
    return `${p(h, 2)}:${p(m, 2)}:${p(s, 2)},${p(ms % 1000, 3)}`;
  }

  function toSrt(phrases) {
    return phrases.map((p, i) =>
      `${i + 1}\n${srtTime(p.start)} --> ${srtTime(p.end)}\n${p.text}\n`).join('\n');
  }

  function writeNextTo(srcFile, ext, content) {
    const dir = path.dirname(srcFile);
    const base = path.basename(srcFile, path.extname(srcFile));
    let target = path.join(dir, base + ext);
    try {
      fs.writeFileSync(target, content, 'utf8');
    } catch (e) {
      target = path.join(HOME, base + ext);   // папка джерела може бути тільки для читання
      fs.writeFileSync(target, content, 'utf8');
    }
    return target;
  }

  /* ---------------- список моделей Gemini ----------------
     Беремо з API під конкретний ключ: набір моделей залежить від проєкту
     Google, а назви змінюються частіше, ніж оновлюється плагін.
     Кешуємо на добу, щоб вікно відкривалось миттєво.                      */

  const MODELS_FILE = path.join(HOME, 'gemini-models.json');
  const MODELS_TTL = 24 * 3600 * 1000;

  function httpsGet(host, reqPath, headers) {
    return new Promise((resolve, reject) => {
      const req = https.request({ method: 'GET', host, path: reqPath, headers }, (res) => {
        let data = '';
        res.setEncoding('utf8');
        res.on('data', (d) => { data += d; });
        res.on('end', () => resolve({ status: res.statusCode, body: data }));
      });
      req.on('error', (e) => reject(new Error('Мережа: ' + e.message)));
      req.setTimeout(30000, () => { req.destroy(new Error('таймаут 30 с')); });
      req.end();
    });
  }

  async function listGeminiModels(cfg, force) {
    if (!cfg.geminiApiKey) {
      throw new Error('Додай ключ Gemini в ⚙ — список моделей залежить від ключа.');
    }
    const keyHash = crypto.createHash('md5').update(cfg.geminiApiKey).digest('hex').slice(0, 12);

    if (!force) {
      try {
        const c = JSON.parse(fs.readFileSync(MODELS_FILE, 'utf8'));
        if (c.keyHash === keyHash && Date.now() - c.at < MODELS_TTL && Array.isArray(c.models)) {
          return { models: c.models, cached: true, at: c.at };
        }
      } catch (e) { /* кешу немає — тягнемо з мережі */ }
    }

    const out = [];
    let token = '';
    for (let page = 0; page < 10; page++) {
      const q = '/v1beta/models?pageSize=1000' + (token ? '&pageToken=' + encodeURIComponent(token) : '');
      const r = await httpsGet('generativelanguage.googleapis.com', q, { 'x-goog-api-key': cfg.geminiApiKey });
      if (r.status === 400 || r.status === 401 || r.status === 403) {
        throw new Error('Gemini не віддав список моделей (' + r.status + '). Перевір API-ключ.');
      }
      if (r.status !== 200) throw new Error('Gemini ' + r.status + ': ' + r.body.slice(0, 200));
      let j;
      try { j = JSON.parse(r.body); } catch (e) { throw new Error('Gemini повернув нечитабельний список моделей.'); }
      for (const m of (j.models || [])) {
        out.push({
          id: String(m.name || '').replace(/^models\//, ''),
          name: m.displayName || '',
          methods: m.supportedGenerationMethods || [],
          input: m.inputTokenLimit || 0
        });
      }
      token = j.nextPageToken;
      if (!token) break;
    }

    ensureDirs();
    const at = Date.now();
    fs.writeFileSync(MODELS_FILE, JSON.stringify({ at, keyHash, models: out }), 'utf8');
    return { models: out, cached: false, at };
  }

  /* ---------------- сесія композиції ----------------
     Розшифровка живе не в панелі, а на диску, прив'язана до пари
     «проєкт + id композиції». Тому вона переживає перемикання комп,
     закриття панелі й перезапуск AE.                                    */

  function sessionKey(projectPath, compId) {
    return crypto.createHash('md5')
      .update(String(projectPath || 'untitled') + '|' + String(compId))
      .digest('hex');
  }

  function sessionFile(key) { return path.join(SESSIONS, key + '.json'); }

  function saveSession(key, payload) {
    ensureDirs();
    fs.writeFileSync(sessionFile(key), JSON.stringify(payload), 'utf8');
  }

  function loadSession(key) {
    const f = sessionFile(key);
    if (!fs.existsSync(f)) return null;
    try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return null; }
  }

  function dropSession(key) {
    try { fs.unlinkSync(sessionFile(key)); return true; } catch (e) { return false; }
  }

  /* ---------------- репліки спікерів ----------------
     Сусідні фрази одного спікера зливаються в одну репліку. Запас на краях
     не дає відрізати вдих і хвіст слова, але ніколи не залазить на сусідню
     репліку іншого спікера.                                                */

  function buildTurns(phrases, opts) {
    const pad = Math.max(0, opts.padding || 0);
    const minTurn = Math.max(0, opts.minTurn || 0);
    const raw = [];
    let cur = null;

    for (const p of phrases) {
      const id = p.speaker || 'speaker_?';
      if (cur && cur.id === id) {
        cur.end = p.end;
        cur.count++;
      } else {
        if (cur) raw.push(cur);
        cur = { id, start: p.start, end: p.end, count: 1 };
      }
    }
    if (cur) raw.push(cur);

    // Запас на краях ділимо з сусідом навпіл, інакше репліки двох спікерів
    // накладаються і в кожну композицію потрапляє хвіст чужої мови.
    const orig = raw.map((t) => ({ start: t.start, end: t.end, len: t.end - t.start }));
    for (let i = 0; i < raw.length; i++) {
      const gapL = i > 0 ? orig[i].start - orig[i - 1].end : orig[i].start;
      const gapR = i < raw.length - 1 ? orig[i + 1].start - orig[i].end : Infinity;
      const padL = Math.max(0, Math.min(pad, gapL / 2));
      const padR = Math.max(0, Math.min(pad, gapR === Infinity ? pad : gapR / 2));
      raw[i].start = Math.max(0, orig[i].start - padL);
      raw[i].end = orig[i].end + padR;
    }

    // мінімальну довжину міряємо ДО запасу, щоб коротке «ага» не проходило
    // фільтр лише тому, що його роздули краями
    const kept = raw.filter((t, i) => orig[i].len >= minTurn);

    const byId = new Map();
    for (const t of kept) {
      if (!byId.has(t.id)) byId.set(t.id, { id: t.id, turns: [], total: 0, lines: 0 });
      const g = byId.get(t.id);
      g.turns.push({ start: t.start, end: t.end });
      g.total += t.end - t.start;
      g.lines += t.count;
    }
    return Array.from(byId.values());
  }

  global.Core = {
    loadConfig, saveConfig, DEFAULTS,
    extractAudio, transcribe,
    cacheKey, readCache, writeCache,
    buildPhrases, toSrt, writeNextTo,
    translatePhrases, translationCacheKey,
    sessionKey, saveSession, loadSession, dropSession,
    listGeminiModels, healthSummary, probeGeminiModel, recordHealth, plural,
    buildTurns,
    unlink: (f) => { try { fs.unlinkSync(f); } catch (e) {} }
  };
})(window);
