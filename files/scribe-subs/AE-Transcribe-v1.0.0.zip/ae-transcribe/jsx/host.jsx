/**
 * AE Transcribe — ExtendScript host (ES3)
 * Панель спілкується з ним лише через AET.dispatch(name, encodedJsonArg).
 * Аргумент і відповідь передаються у encodeURIComponent, щоб кирилиця,
 * лапки та переноси рядків не ламали evalScript.
 */
var AET = (function () {

    /* ---------- JSON serializer (в ExtendScript немає JSON) ---------- */

    function esc(s) {
        s = String(s);
        var out = '', c, code, i;
        for (i = 0; i < s.length; i++) {
            c = s.charAt(i);
            code = s.charCodeAt(i);
            if (c === '"') { out += '\\"'; }
            else if (c === '\\') { out += '\\\\'; }
            else if (code < 32 || code > 126) { out += '\\u' + ('0000' + code.toString(16)).slice(-4); }
            else { out += c; }
        }
        return '"' + out + '"';
    }

    function ser(v) {
        if (v === null || v === undefined) { return 'null'; }
        var t = typeof v, i, a, k, p;
        if (t === 'number') { return isFinite(v) ? String(v) : 'null'; }
        if (t === 'boolean') { return v ? 'true' : 'false'; }
        if (t === 'string') { return esc(v); }
        if (v instanceof Array) {
            a = [];
            for (i = 0; i < v.length; i++) { a.push(ser(v[i])); }
            return '[' + a.join(',') + ']';
        }
        p = [];
        for (k in v) { if (v.hasOwnProperty(k)) { p.push(esc(k) + ':' + ser(v[k])); } }
        return '{' + p.join(',') + '}';
    }

    /* ---------- helpers ---------- */

    function activeComp() {
        var c = app.project.activeItem;
        if (!(c instanceof CompItem)) {
            throw new Error('Відкрий композицію та зроби її активною.');
        }
        return c;
    }

    function compById(id) {
        if (!id) { return activeComp(); }
        var i, it;
        for (i = 1; i <= app.project.numItems; i++) {
            it = app.project.item(i);
            if (it instanceof CompItem && it.id === id) { return it; }
        }
        throw new Error('Композицію не знайдено — можливо, її закрито або видалено.');
    }

    function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

    /* ---------- handlers ---------- */

    var handlers = {};

    handlers.ping = function () {
        return { app: app.appName, version: app.version, build: app.buildName };
    };

    handlers.getSelection = function () {
        var comp = activeComp();
        var sel = comp.selectedLayers;
        if (!sel || sel.length === 0) {
            throw new Error('Виділи в композиції шар з аудіо.');
        }
        var layer = sel[0];
        var src = layer.source;
        if (!src || !(src instanceof FootageItem)) {
            throw new Error('Шар «' + layer.name + '» не є футеджем. Потрібен відео- або аудіошар.');
        }
        if (!src.hasAudio) {
            throw new Error('У шарі «' + layer.name + '» немає аудіодоріжки.');
        }
        var ms = src.mainSource;
        if (!(ms instanceof FileSource) || !ms.file) {
            throw new Error('У джерела немає файлу на диску (солід, плейсхолдер або прокладка).');
        }
        return {
            compId: comp.id,
            compName: comp.name,
            compDuration: comp.duration,
            frameDuration: comp.frameDuration,
            layerIndex: layer.index,
            layerName: layer.name,
            sourceName: src.name,
            file: ms.file.fsName,
            sourceDuration: src.duration,
            startTime: layer.startTime,
            inPoint: layer.inPoint,
            outPoint: layer.outPoint,
            stretch: layer.stretch,
            timeRemap: (layer.timeRemapEnabled === true)
        };
    };

    /**
     * Контекст активної композиції: сама композиція + усі шари, придатні до
     * транскрипції. Не кидає помилку через відсутність виділення — саме це
     * дозволяє прив'язувати розшифровку до композиції, а не до вибраного шару.
     */
    handlers.getContext = function () {
        var comp = activeComp();
        var layers = [], i, layer, src, ms, selected = 0;

        for (i = 1; i <= comp.numLayers; i++) {
            layer = comp.layer(i);
            src = layer.source;
            if (!src || !(src instanceof FootageItem) || !src.hasAudio) { continue; }
            ms = src.mainSource;
            if (!(ms instanceof FileSource) || !ms.file) { continue; }

            layers.push({
                layerIndex: layer.index,
                layerName: layer.name,
                sourceName: src.name,
                file: ms.file.fsName,
                sourceDuration: src.duration,
                startTime: layer.startTime,
                inPoint: layer.inPoint,
                outPoint: layer.outPoint,
                stretch: layer.stretch,
                enabled: (layer.enabled === true),
                audioActive: (layer.audioEnabled === true),
                timeRemap: (layer.timeRemapEnabled === true)
            });
            if (layer.selected && !selected) { selected = layer.index; }
        }

        return {
            compId: comp.id,
            compName: comp.name,
            compDuration: comp.duration,
            frameDuration: comp.frameDuration,
            time: comp.time,
            projectPath: (app.project.file ? app.project.file.fsName : ''),
            projectName: (app.project.file ? app.project.file.name : 'без назви'),
            selectedIndex: selected,
            layers: layers
        };
    };

    /** Легкий пул для таймера: активна композиція + позиція плейхеда одним викликом. */
    handlers.getState = function () {
        var c = app.project.activeItem;
        if (!(c instanceof CompItem)) { return { compId: 0, time: 0 }; }
        return { compId: c.id, compName: c.name, time: c.time };
    };

    handlers.getTime = function (a) {
        var comp = (a && a.compId) ? compById(a.compId) : activeComp();
        return { time: comp.time, compId: comp.id };
    };

    handlers.setTime = function (a) {
        var comp = compById(a.compId);
        if (app.project.activeItem !== comp) { comp.openInViewer(); }
        comp.time = clamp(a.time, 0, comp.duration - comp.frameDuration);
        return { time: comp.time };
    };

    handlers.selectLayer = function (a) {
        var comp = compById(a.compId);
        var i;
        for (i = 1; i <= comp.numLayers; i++) { comp.layer(i).selected = false; }
        if (a.layerIndex >= 1 && a.layerIndex <= comp.numLayers) {
            comp.layer(a.layerIndex).selected = true;
        }
        return true;
    };

    /**
     * Ставить або знімає маркер композиції на місці фрази (клік по чекбоксу в панелі).
     * Ідентифікуємо маркер за часом (з точністю до half-frame), а не за індексом,
     * бо ключі маркерів можуть перенумеровуватись між викликами.
     */
    handlers.toggleMarker = function (a) {
        var comp = compById(a.compId);
        var mp = comp.markerProperty;
        var t = clamp(a.time, 0, comp.duration - comp.frameDuration);
        var tol = comp.frameDuration / 2;
        var i, foundIndex = -1;

        for (i = 1; i <= mp.numKeys; i++) {
            if (Math.abs(mp.keyTime(i) - t) < tol) { foundIndex = i; break; }
        }

        app.beginUndoGroup('AE Transcribe: маркер');
        try {
            if (a.on === false) {
                if (foundIndex > 0) { mp.removeKey(foundIndex); }
                return { on: false };
            }
            var mv = new MarkerValue(a.comment || '');
            var dur = a.duration || 0;
            if (dur < 0) { dur = 0; }
            if (t + dur > comp.duration) { dur = Math.max(0, comp.duration - t); }
            mv.duration = dur;
            if (foundIndex > 0) {
                mp.setValueAtKey(foundIndex, mv);
            } else {
                mp.setValueAtTime(t, mv);
            }
        } finally {
            app.endUndoGroup();
        }
        return { on: true };
    };

    /**
     * Розкладає репліки спікерів по окремих композиціях.
     * На кожну репліку — окрема копія вихідного шару, обрізана по in/out.
     * mode='timeline' — копії лишаються на своїх місцях (синхронно з оригіналом),
     * mode='compact'  — репліки зсуваються впритул, без пауз.
     */
    handlers.splitBySpeaker = function (a) {
        var comp = compById(a.compId);
        if (a.layerIndex < 1 || a.layerIndex > comp.numLayers) {
            throw new Error('Шар №' + a.layerIndex + ' уже не існує в композиції.');
        }
        var srcLayer = comp.layer(a.layerIndex);
        var i, j;

        // межі, за які шар не можна обрізати (з урахуванням розтягування)
        function bounds(l) {
            var span = (l.source && l.source.duration)
                ? l.source.duration * (l.stretch / 100) : l.containingComp.duration;
            return { lo: l.startTime, hi: l.startTime + span };
        }

        function trimTo(l, tin, tout) {
            var b = bounds(l), fd = l.containingComp.frameDuration;
            if (tin < b.lo) { tin = b.lo; }
            if (tout > b.hi) { tout = b.hi; }
            if (tout - tin < fd) { tout = tin + fd; }
            // порядок важливий: inPoint не можна завести за поточний outPoint
            if (tin > l.outPoint) { l.outPoint = tout; l.inPoint = tin; }
            else { l.inPoint = tin; l.outPoint = tout; }
        }

        var folderName = comp.name + ' · спікери';
        var folder = null, it;
        for (i = 1; i <= app.project.numItems; i++) {
            it = app.project.item(i);
            if (it instanceof FolderItem && it.name === folderName) { folder = it; break; }
        }

        var made = [], first = null;

        app.beginUndoGroup('AE Transcribe: композиції по спікерах');
        try {
            if (!folder) { folder = app.project.items.addFolder(folderName); }

            for (i = 0; i < a.speakers.length; i++) {
                var sp = a.speakers[i];
                if (!sp.turns || !sp.turns.length) { continue; }

                var total = 0;
                for (j = 0; j < sp.turns.length; j++) {
                    total += (sp.turns[j].end - sp.turns[j].start);
                }
                var dur = (a.mode === 'compact')
                    ? Math.max(total, comp.frameDuration)
                    : comp.duration;

                var target = app.project.items.addComp(
                    comp.name + ' · ' + sp.name,
                    comp.width, comp.height, comp.pixelAspect, dur, comp.frameRate);
                target.parentFolder = folder;
                target.bgColor = comp.bgColor;

                var cursor = 0;
                for (j = 0; j < sp.turns.length; j++) {
                    var t0 = sp.turns[j].start, t1 = sp.turns[j].end, len = t1 - t0;
                    srcLayer.copyToComp(target);
                    var dup = target.layer(1);          // copyToComp кладе копію наверх

                    if (a.mode === 'compact') {
                        dup.startTime = dup.startTime + (cursor - t0);
                        trimTo(dup, cursor, cursor + len);
                        cursor += len;
                    } else {
                        trimTo(dup, t0, t1);
                    }
                    dup.name = sp.name + ' ' + (j + 1);
                    if (sp.label) { dup.label = sp.label; }
                }

                made.push({ name: target.name, layers: sp.turns.length, duration: dur });
                if (!first) { first = target; }
            }

            if (first && a.open) { first.openInViewer(); }
        } finally {
            app.endUndoGroup();
        }

        return { folder: folderName, comps: made };
    };

    handlers.createTextLayers = function (a) {
        var comp = compById(a.compId);
        var st = a.style || {};
        var size = st.fontSize || Math.round(comp.height * 0.055);
        var yPos = comp.height * (st.yFactor || 0.82);
        var made = 0, i, ph, tl, td, dur = comp.duration;

        app.beginUndoGroup('AE Transcribe: субтитри');
        try {
            for (i = 0; i < a.phrases.length; i++) {
                ph = a.phrases[i];
                if (!ph.text) { continue; }
                if (ph.start >= dur) { continue; }

                tl = comp.layers.addText(ph.text);
                tl.name = ('000' + (i + 1)).slice(-3) + ' · ' + ph.text.substr(0, 24);
                tl.label = st.label || 9;

                td = tl.property('Source Text').value;
                td.fontSize = size;
                td.justification = ParagraphJustification.CENTER_JUSTIFY;
                td.applyFill = true;
                td.fillColor = [1, 1, 1];
                if (st.font) { td.font = st.font; }
                tl.property('Source Text').setValue(td);
                tl.property('Transform').property('Position').setValue([comp.width / 2, yPos]);

                tl.inPoint = clamp(ph.start, 0, dur - comp.frameDuration);
                tl.outPoint = clamp(ph.end, tl.inPoint + comp.frameDuration, dur);
                made++;
            }
        } finally {
            app.endUndoGroup();
        }
        return { created: made };
    };

    handlers.importFile = function (a) {
        var f = new File(a.path);
        if (!f.exists) { throw new Error('Файл не знайдено: ' + a.path); }
        app.beginUndoGroup('AE Transcribe: імпорт');
        try {
            var item = app.project.importFile(new ImportOptions(f));
        } finally {
            app.endUndoGroup();
        }
        return { name: item.name };
    };

    /* ---------- dispatch ---------- */

    function dispatch(name, encodedArg) {
        var res;
        try {
            if (!handlers[name]) { throw new Error('Невідома команда: ' + name); }
            var arg = null;
            if (encodedArg) {
                var raw = decodeURIComponent(encodedArg);
                if (raw && raw !== 'null') { arg = eval('(' + raw + ')'); }
            }
            res = { ok: true, data: handlers[name](arg) };
        } catch (e) {
            res = { ok: false, error: (e && e.message) ? e.message : String(e) };
        }
        return encodeURIComponent(ser(res));
    }

    return { dispatch: dispatch, serialize: ser };
})();
