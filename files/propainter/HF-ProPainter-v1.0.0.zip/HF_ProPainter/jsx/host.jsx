// HF ProPainter — ExtendScript side
// ppPrepare: renders source frames and a white-on-black mask as PNG sequences
// ppImport:  imports the cleaned sequence and places it above the source layer

function ppJson(v) {
    if (v === null || v === undefined) return 'null';
    var t = typeof v;
    if (t === 'number') return isFinite(v) ? String(v) : 'null';
    if (t === 'boolean') return v ? 'true' : 'false';
    if (t === 'string') {
        return '"' + v.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r/g, '\\r').replace(/\n/g, '\\n').replace(/\t/g, '\\t') + '"';
    }
    var parts = [];
    for (var k in v) if (v.hasOwnProperty(k)) parts.push(ppJson(k) + ':' + ppJson(v[k]));
    return '{' + parts.join(',') + '}';
}
function ppErr(msg) { return ppJson({ ok: false, error: msg }); }

function ppPad(n, w) { var s = String(n); while (s.length < w) s = '0' + s; return s; }

function ppClearMatte(layer) {
    try { if (layer.trackMatteType !== TrackMatteType.NO_TRACK_MATTE) layer.setTrackMatte(null, TrackMatteType.NO_TRACK_MATTE); } catch (e) {
        try { layer.trackMatteType = TrackMatteType.NO_TRACK_MATTE; } catch (e2) {}
    }
}

function ppPrepLayer(layer) {
    try { layer.enabled = true; } catch (e) {}
    try { layer.guideLayer = false; } catch (e) {}
    try { layer.solo = false; } catch (e) {}
    ppClearMatte(layer);
}

function ppSetPng(om) {
    var tpls = om.templates, i;
    for (i = 0; i < tpls.length; i++) {
        if (/png/i.test(tpls[i]) && /seq|послід/i.test(tpls[i])) { om.applyTemplate(tpls[i]); return true; }
    }
    for (i = 0; i < tpls.length; i++) {
        if (/png/i.test(tpls[i])) { om.applyTemplate(tpls[i]); return true; }
    }
    try { om.setSettings({ 'Format': 'PNG Sequence' }); return true; } catch (e) {}
    return false;
}

function ppCountPng(folder) {
    return folder.getFiles('*.png').length;
}

// Renders ONE comp to a PNG sequence. Must be called outside of an undo group.
function ppRenderOne(comp, start, dur, folder, label) {
    var rq = app.project.renderQueue;
    var states = [], i;
    for (i = 1; i <= rq.numItems; i++) {
        states.push(rq.item(i).render);
        try { rq.item(i).render = false; } catch (e) {}
    }
    var rqi = null, status = '';
    try {
        rqi = rq.items.add(comp);
        try { rqi.applyTemplate('Best Settings'); } catch (e) {}
        rqi.timeSpanStart = start;
        rqi.timeSpanDuration = dur;
        var om = rqi.outputModule(1);
        if (!ppSetPng(om)) throw new Error('Не знайдено шаблон виводу PNG Sequence.');
        om.file = new File(folder.fsName + '/f_[#####].png');
        rqi.render = true;
        rq.render();
        try { status = String(rqi.status); } catch (e) {}
    } finally {
        try { if (rqi) rqi.remove(); } catch (e) {}
        for (i = 0; i < states.length && i < rq.numItems; i++) { try { rq.item(i + 1).render = states[i]; } catch (e) {} }
    }
    var n = ppCountPng(folder);
    if (n === 0) throw new Error('Рендер «' + label + '» не створив жодного кадру (статус: ' + status + ').');
    return n;
}

function ppPrepare(opts) {
    var comp = app.project.activeItem;
    if (!(comp instanceof CompItem)) return ppErr('Відкрий композицію і виділи шари.');
    var sel = comp.selectedLayers;
    var src, mlay, mode;

    if (sel.length === 1) {
        src = sel[0]; mlay = src; mode = 'masks';
        var mp = src.property('ADBE Mask Parade');
        if (!mp || mp.numProperties === 0) return ppErr('На виділеному шарі немає масок. Намалюй маску навколо об\'єкта або виділи 2 шари (маска + відео).');
    } else if (sel.length === 2) {
        if (sel[0].index < sel[1].index) { mlay = sel[0]; src = sel[1]; } else { mlay = sel[1]; src = sel[0]; }
        mode = 'matte';
    } else {
        return ppErr('Виділи 1 шар з масками або 2 шари (верхній — маска, нижній — відео).');
    }

    var fd = comp.frameDuration;
    var t0 = Math.max(comp.workAreaStart, src.inPoint);
    var t1 = Math.min(comp.workAreaStart + comp.workAreaDuration, src.outPoint);
    t0 = Math.round(t0 / fd) * fd;
    if (t1 - t0 < fd) return ppErr('Відео-шар не потрапляє в робочу область композиції.');
    var nFrames = Math.round((t1 - t0) / fd);

    var root = new Folder(opts.workDir);
    if (!root.exists && !root.create()) return ppErr('Не вдалося створити робочу папку: ' + opts.workDir);
    var d = new Date();
    var stamp = d.getFullYear() + ppPad(d.getMonth() + 1, 2) + ppPad(d.getDate(), 2) + '_' + ppPad(d.getHours(), 2) + ppPad(d.getMinutes(), 2) + ppPad(d.getSeconds(), 2);
    var job = new Folder(root.fsName + '/job_' + stamp);
    var fSrc = new Folder(job.fsName + '/src');
    var fMask = new Folder(job.fsName + '/mask');
    job.create(); fSrc.create(); fMask.create();

    var srcComp = null, maskComp = null, bgSource = null;
    function cleanup() {
        app.beginUndoGroup('HF ProPainter: cleanup');
        try { if (srcComp) srcComp.remove(); } catch (e1) {}
        try { if (maskComp) maskComp.remove(); } catch (e2) {}
        try { if (bgSource) bgSource.remove(); } catch (e3) {}
        app.endUndoGroup();
    }

    // 1) build temp comps (inside an undo group)
    app.beginUndoGroup('HF ProPainter: prepare');
    try {
        srcComp = app.project.items.addComp('PP_src_tmp', comp.width, comp.height, comp.pixelAspect, comp.duration, comp.frameRate);
        src.copyToComp(srcComp);
        var sl = srcComp.layer(1);
        ppPrepLayer(sl);
        if (mode === 'masks') {
            var smp = sl.property('ADBE Mask Parade');
            for (var i = 1; i <= smp.numProperties; i++) smp.property(i).maskMode = MaskMode.NONE;
        }

        maskComp = app.project.items.addComp('PP_mask_tmp', comp.width, comp.height, comp.pixelAspect, comp.duration, comp.frameRate);
        var bg = maskComp.layers.addSolid([0, 0, 0], 'PP_bg', comp.width, comp.height, comp.pixelAspect, comp.duration);
        bgSource = bg.source;
        mlay.copyToComp(maskComp);
        var ml = maskComp.layer(1);
        ppPrepLayer(ml);
        if (mode === 'masks') {
            // mask = union of all masks, regardless of the modes the user set (Subtract / None / Inverted)
            var mmp = ml.property('ADBE Mask Parade');
            for (var mi = 1; mi <= mmp.numProperties; mi++) {
                try { mmp.property(mi).maskMode = MaskMode.ADD; } catch (e) {}
                try { mmp.property(mi).inverted = false; } catch (e) {}
            }
        }
        try { ml.blendingMode = BlendingMode.NORMAL; } catch (e) {}
        try {
            var op = ml.property('ADBE Transform Group').property('ADBE Opacity');
            if (op.numKeys === 0 && !op.expressionEnabled) op.setValue(100);
        } catch (e) {}
        var fill = ml.property('ADBE Effect Parade').addProperty('ADBE Fill');
        for (var p = 1; p <= fill.numProperties; p++) {
            var pr = fill.property(p);
            if (pr.propertyValueType === PropertyValueType.COLOR) { pr.setValue([1, 1, 1, 1]); break; }
        }
    } catch (e) {
        app.endUndoGroup();
        cleanup();
        return ppErr('Помилка підготовки композицій: ' + e.toString());
    }
    app.endUndoGroup();

    // 2) render each comp separately (outside any undo group)
    var nSrc = 0, nMask = 0;
    try {
        nSrc = ppRenderOne(srcComp, t0, t1 - t0, fSrc, 'відео');
        nMask = ppRenderOne(maskComp, t0, t1 - t0, fMask, 'маска');
    } catch (e) {
        cleanup();
        return ppErr(e.toString().replace(/^Error:\s*/, ''));
    }

    // 3) remove temp comps
    cleanup();
    if (nSrc !== nMask) return ppErr('Відрендерено кадрів відео: ' + nSrc + ', маски: ' + nMask + '. Кількість має збігатися.');

    $.global.PP_JOB = { comp: comp, src: src, t0: t0 };
    return ppJson({ ok: true, job: job.fsName.replace(/\\/g, '/'), frames: nFrames, mode: mode, fps: comp.frameRate });
}

function ppImport(dir, engine) {
    var label = engine === 'minimax' ? 'MiniMax' : (engine === 'diffueraser' ? 'DiffuEraser' : 'ProPainter');
    var job = $.global.PP_JOB;
    if (!job) return ppErr('Втрачено дані завдання (AE перезапускався?). Результат лежить у: ' + dir);
    var files = new Folder(dir).getFiles('clean_*.png');
    if (!files.length) return ppErr('У папці результату немає кадрів: ' + dir);
    files.sort(function (a, b) { return a.name < b.name ? -1 : 1; });

    app.beginUndoGroup('HF ProPainter: import');
    try {
        var io = new ImportOptions(files[0]);
        io.sequence = true;
        io.forceAlphabetical = true;
        var item = app.project.importFile(io);
        item.mainSource.conformFrameRate = job.comp.frameRate;

        var folder = null;
        for (var i = 1; i <= app.project.numItems; i++) {
            var it = app.project.item(i);
            if (it instanceof FolderItem && it.name === 'ProPainter') { folder = it; break; }
        }
        if (!folder) folder = app.project.items.addFolder('ProPainter');
        item.parentFolder = folder;

        var name = label + ' clean ' + new Folder(dir).parent.name.replace('job_', '');
        item.name = name;
        var layer = job.comp.layers.add(item);
        layer.startTime = job.t0;
        layer.name = name;
        try { layer.moveBefore(job.src); } catch (e) {}
        for (var s = 0; s < job.comp.selectedLayers.length; s++) job.comp.selectedLayers[s].selected = false;
        layer.selected = true;
    } catch (e) {
        app.endUndoGroup();
        return ppErr('Помилка імпорту: ' + e.toString());
    }
    app.endUndoGroup();
    return ppJson({ ok: true, name: name });
}
