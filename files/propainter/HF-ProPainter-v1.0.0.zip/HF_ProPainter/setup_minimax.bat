@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo  MiniMax-Remover setup  (folder: %CD%)
echo ============================================
echo.
echo === 1/5 Code ===
if not exist pipeline_minimax_remover.py (
  curl -fL -o mm.zip https://github.com/zibojia/MiniMax-Remover/archive/refs/heads/main.zip || curl -fL -o mm.zip https://github.com/zibojia/MiniMax-Remover/archive/refs/heads/master.zip
  if not exist mm.zip (echo Failed to download code & pause & exit /b 1)
  tar -xf mm.zip
  for /d %%D in (MiniMax-Remover-*) do xcopy "%%D\*.py" . /Y /Q >nul
  del mm.zip
)
if not exist pipeline_minimax_remover.py (echo pipeline_minimax_remover.py not found & pause & exit /b 1)

echo === 2/5 Python 3.10 ===
py install 3.10
echo === 3/5 Virtual environment ===
if not exist venv py -3.10 -m venv venv
call venv\Scripts\activate
python -m pip install --upgrade pip

echo === 4/5 Packages ===
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
pip install "diffusers==0.33.1" "transformers==4.51.3" "accelerate<1.8" einops scipy opencv-python huggingface_hub omegaconf

echo === 5/5 Weights (~2-3 GB) ===
python -c "from huggingface_hub import snapshot_download; snapshot_download('zibojia/minimax-remover', local_dir='weights', allow_patterns=['vae/*','transformer/*','scheduler/*'])"

echo.
python -c "import torch; print('GPU OK:', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else '')"
python -c "import sys; sys.path.insert(0,'.'); import pipeline_minimax_remover; print('Pipeline import OK')"
echo.
echo Done. In the panel choose MiniMax-Remover and set this folder:
echo %CD%
pause
