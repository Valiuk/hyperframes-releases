@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================
echo  DiffuEraser setup  (folder: %CD%)
echo  Needs ~10 GB of disk space for weights
echo ============================================
echo.
echo === 1/6 Code ===
if not exist run_diffueraser.py (
  curl -fL -o de.zip https://github.com/lixiaowen-xw/DiffuEraser/archive/refs/heads/master.zip || curl -fL -o de.zip https://github.com/lixiaowen-xw/DiffuEraser/archive/refs/heads/main.zip
  if not exist de.zip (echo Failed to download code & pause & exit /b 1)
  tar -xf de.zip
  for /d %%D in (DiffuEraser-*) do xcopy "%%D\*" . /E /Y /Q >nul
  del de.zip
)
if not exist run_diffueraser.py (echo run_diffueraser.py not found & pause & exit /b 1)

echo === 2/6 Python 3.10 ===
py install 3.10
echo === 3/6 Virtual environment ===
if not exist venv py -3.10 -m venv venv
call venv\Scripts\activate
python -m pip install --upgrade pip

echo === 4/6 Packages ===
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
findstr /V /I /R "^torch ^torchvision ^torchaudio ^xformers" requirements.txt > req_panel.txt
pip install -r req_panel.txt
pip install imageio imageio-ffmpeg opencv-python huggingface_hub

echo === 5/6 Weights (several GB, be patient) ===
python -c "from huggingface_hub import snapshot_download as d; d('lixiaowen/diffuEraser', local_dir='weights/diffuEraser')"
python -c "from huggingface_hub import snapshot_download as d; d('stabilityai/sd-vae-ft-mse', local_dir='weights/sd-vae-ft-mse', allow_patterns=['*.json','*.safetensors'])"
python -c "from huggingface_hub import snapshot_download as d; d('stable-diffusion-v1-5/stable-diffusion-v1-5', local_dir='weights/stable-diffusion-v1-5', allow_patterns=['model_index.json','feature_extractor/*','scheduler/*','text_encoder/*','tokenizer/*','unet/*','vae/*'], ignore_patterns=['*.fp16.*','*non_ema*','*.ckpt','*.msgpack','*.onnx*'])"
python -c "from huggingface_hub import snapshot_download as d; d('wangfuyun/PCM_Weights', local_dir='weights/PCM_Weights', allow_patterns=['sd15/*2step*'])"

if not exist "weights\stable-diffusion-v1-5\text_encoder\config.json" (echo WARNING: Stable Diffusion 1.5 download incomplete - run this script again)

echo === 6/6 ProPainter prior weights ===
if not exist weights\propainter mkdir weights\propainter
for %%F in (ProPainter.pth raft-things.pth recurrent_flow_completion.pth) do (
  if not exist "weights\propainter\%%F" (
    if exist "C:\AI\ProPainter\weights\%%F" (
      copy "C:\AI\ProPainter\weights\%%F" "weights\propainter\" >nul
    ) else (
      curl -fL -o "weights\propainter\%%F" "https://github.com/sczhou/ProPainter/releases/download/v0.1.0/%%F"
    )
  )
)

echo.
python -c "import torch; print('GPU OK:', torch.cuda.is_available(), torch.cuda.get_device_name(0) if torch.cuda.is_available() else '')"
python -c "import sys; sys.path.insert(0,'.'); from diffueraser.diffueraser import DiffuEraser; print('DiffuEraser import OK')"
echo.
echo Done. In the panel choose DiffuEraser and set this folder:
echo %CD%
pause
