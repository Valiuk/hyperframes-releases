# HF ProPainter wrapper
# 1) finds the mask bounding box across all frames and crops that region
# 2) runs ProPainter on the crop (downscaled to --max_side if needed)
# 3) pastes the result back into the full-res frames only inside the (feathered) mask
import argparse
import glob
import os
import shutil
import subprocess
import sys

import cv2
import numpy as np


def say(*a):
    print(*a, flush=True)


def progress(i, n, stage):
    print("PROGRESS %d %d %s" % (i, n, stage), flush=True)


def fail(msg):
    say("ERROR: " + msg)
    sys.exit(1)


def pngs(d):
    return sorted(glob.glob(os.path.join(d, "*.png")))


def fit(lo, hi, limit, align=8, minimum=64):
    """Return (start, length) covering [lo, hi), length multiple of align, inside [0, limit)."""
    length = int(np.ceil(max(hi - lo, minimum) / float(align))) * align
    max_len = (limit // align) * align
    length = min(length, max_len)
    center = (lo + hi) / 2.0
    start = int(round(center - length / 2.0))
    start = max(0, min(start, limit - length))
    return start, length


def read_binary(path, thr):
    g = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
    if g is None:
        fail("Не вдалося прочитати маску: " + path)
    return (g > thr).astype(np.uint8)


def reset_dir(d):
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d, exist_ok=True)


def find_output_frames(out_root, n):
    groups = {}
    for p in glob.glob(os.path.join(out_root, "**", "*.png"), recursive=True):
        groups.setdefault(os.path.dirname(p), []).append(p)
    best = None
    for d, files in groups.items():
        if len(files) >= n and (best is None or abs(len(files) - n) < abs(len(groups[best]) - n)):
            best = d
    if best:
        return [cv2.imread(p) for p in sorted(groups[best])[:n]]

    vids = glob.glob(os.path.join(out_root, "**", "inpaint_out.mp4"), recursive=True)
    if vids:
        cap = cv2.VideoCapture(vids[0])
        frames = []
        while True:
            ok, f = cap.read()
            if not ok:
                break
            frames.append(f)
        cap.release()
        if len(frames) >= n:
            return frames[:n]
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--engine", choices=["propainter", "minimax", "diffueraser"], default="propainter")
    ap.add_argument("--propainter", default="")
    ap.add_argument("--minimax", default="")
    ap.add_argument("--diffueraser", default="")
    ap.add_argument("--de_chunk", type=int, default=30)
    ap.add_argument("--fps", type=float, default=25)
    ap.add_argument("--mm_steps", type=int, default=6)
    ap.add_argument("--mm_chunk", type=int, default=33)
    ap.add_argument("--src", required=True)
    ap.add_argument("--mask", required=True)
    ap.add_argument("--work", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--max_side", type=int, default=720)
    ap.add_argument("--margin", type=int, default=48)
    ap.add_argument("--dilation", type=int, default=4)
    ap.add_argument("--feather", type=float, default=6)
    ap.add_argument("--chunk", type=int, default=50)
    ap.add_argument("--threshold", type=int, default=10)
    ap.add_argument("--max_coverage", type=float, default=60)
    ap.add_argument("--fp16", action="store_true")
    a = ap.parse_args()

    src = pngs(a.src)
    msk = pngs(a.mask)
    if not src:
        fail("Немає кадрів у " + a.src)
    if len(src) != len(msk):
        fail("Кількість кадрів (%d) і масок (%d) не збігається" % (len(src), len(msk)))
    n = len(src)

    first = cv2.imread(src[0])
    if first is None:
        fail("Не вдалося прочитати кадр: " + src[0])
    H, W = first.shape[:2]

    # ---- bounding box over all frames ----
    x0, y0, x1, y1 = W, H, 0, 0
    coverage = 0.0
    for i, p in enumerate(msk):
        b = read_binary(p, a.threshold)
        coverage += float(b.mean())
        x, y, w, h = cv2.boundingRect(b)
        if w > 0 and h > 0:
            x0, y0 = min(x0, x), min(y0, y)
            x1, y1 = max(x1, x + w), max(y1, y + h)
        if i % 10 == 0:
            progress(i, n * 2, "crop")
    if x1 <= x0 or y1 <= y0:
        fail("Маска порожня: на жодному кадрі немає білої області")
    coverage = coverage / n * 100
    say("Маска займає в середньому %.1f%% кадру" % coverage)
    if coverage > a.max_coverage:
        fail("Маска займає %.0f%% кадру — схоже, вона інвертована або охоплює весь шар. "
             "Маска має покривати лише об'єкт, який треба прибрати." % coverage)

    pad = a.margin + a.dilation * 2
    align = 16 if a.engine == "minimax" else 8
    cx, cw = fit(x0 - pad, x1 + pad, W, align)
    cy, ch = fit(y0 - pad, y1 + pad, H, align)

    scale = min(1.0, float(a.max_side) / max(cw, ch))
    pw = max(64, int(cw * scale) // align * align)
    ph = max(64, int(ch * scale) // align * align)
    say("Кадр %dx%d, ділянка %dx%d @ (%d,%d), обробка %dx%d" % (W, H, cw, ch, cx, cy, pw, ph))

    # ---- write cropped input ----
    in_f = os.path.join(a.work, "pp_in", "frames")
    in_m = os.path.join(a.work, "pp_in", "masks")
    reset_dir(in_f)
    reset_dir(in_m)
    for i in range(n):
        f = cv2.imread(src[i])[cy:cy + ch, cx:cx + cw]
        m = read_binary(msk[i], a.threshold)[cy:cy + ch, cx:cx + cw]
        if (pw, ph) != (cw, ch):
            f = cv2.resize(f, (pw, ph), interpolation=cv2.INTER_AREA)
            m = cv2.resize(m, (pw, ph), interpolation=cv2.INTER_NEAREST)
        cv2.imwrite(os.path.join(in_f, "%05d.png" % i), f)
        cv2.imwrite(os.path.join(in_m, "%05d.png" % i), m * 255)
        if i % 10 == 0:
            progress(n + i, n * 2, "crop")

    # ---- inpainting engine ----
    out_raw = os.path.join(a.work, "pp_out")
    reset_dir(out_raw)
    progress(0, n, "inpaint")
    if a.engine == "propainter":
        cmd = [
            sys.executable, "inference_propainter.py",
            "--video", in_f,
            "--mask", in_m,
            "--output", out_raw,
            "--width", str(pw),
            "--height", str(ph),
            "--mask_dilation", str(a.dilation),
            "--subvideo_length", str(a.chunk),
            "--save_frames",
        ]
        if a.fp16:
            cmd.append("--fp16")
        cwd = a.propainter
        say("Запуск ProPainter…")
    elif a.engine == "diffueraser":
        cmd = [
            sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), "de_infer.py"),
            "--repo", a.diffueraser,
            "--frames", in_f,
            "--masks", in_m,
            "--out", out_raw,
            "--fps", str(a.fps),
            "--dilation", str(max(1, a.dilation)),
            "--max_size", str(max(pw, ph)),
            "--chunk", str(a.de_chunk),
        ]
        cwd = a.diffueraser
        say("Запуск DiffuEraser…")
    else:
        cmd = [
            sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), "mm_infer.py"),
            "--repo", a.minimax,
            "--weights", os.path.join(a.minimax, "weights"),
            "--frames", in_f,
            "--masks", in_m,
            "--out", out_raw,
            "--steps", str(a.mm_steps),
            "--dilation", str(max(1, a.dilation)),
            "--chunk", str(a.mm_chunk),
        ]
        cwd = a.minimax
        say("Запуск MiniMax-Remover…")

    rc = subprocess.call(cmd, cwd=cwd)
    if rc != 0:
        fail("Модель завершилась з кодом %d — дивись повідомлення вище. Якщо там CUDA out of memory, зменш «Макс. розмір обробки» або «Кадрів за прохід»." % rc)

    preds = find_output_frames(out_raw, n)
    if preds is None:
        fail("Не знайдено результат моделі у " + out_raw)

    # ---- composite back into full-res frames ----
    reset_dir(a.out)
    k = int(round(a.dilation / scale)) + 2
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * k + 1, 2 * k + 1))
    for i in range(n):
        orig = cv2.imread(src[i])
        pred = preds[i]
        if pred is None:
            fail("Порожній кадр результату #%d" % i)
        if pred.shape[1] != cw or pred.shape[0] != ch:
            pred = cv2.resize(pred, (cw, ch), interpolation=cv2.INTER_CUBIC)

        b = read_binary(msk[i], a.threshold)[cy:cy + ch, cx:cx + cw]
        alpha = cv2.dilate(b * 255, kernel).astype(np.float32) / 255.0
        if a.feather > 0:
            alpha = cv2.GaussianBlur(alpha, (0, 0), a.feather)
        alpha[b > 0] = 1.0
        alpha = alpha[..., None]

        region = orig[cy:cy + ch, cx:cx + cw].astype(np.float32)
        orig[cy:cy + ch, cx:cx + cw] = np.clip(pred.astype(np.float32) * alpha + region * (1 - alpha), 0, 255).astype(np.uint8)
        cv2.imwrite(os.path.join(a.out, "clean_%05d.png" % i), orig)
        if i % 5 == 0 or i == n - 1:
            progress(i + 1, n, "composite")

    say("OK: %d кадрів" % n)


if __name__ == "__main__":
    main()
