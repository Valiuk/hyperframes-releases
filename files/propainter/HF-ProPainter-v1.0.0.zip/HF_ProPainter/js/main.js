(function () {
  'use strict';

  var cep = window.__adobe_cep__;
  var nodeRequire = window.require || (window.cep_node && window.cep_node.require);
  var fs = nodeRequire('fs');
  var path = nodeRequire('path');
  var cp = nodeRequire('child_process');
  var proc = window.process || nodeRequire('process');

  var $ = function (id) { return document.getElementById(id); };
  var KEY = 'hf_propainter_settings_v1';
  var DEF = {
    engine: 'propainter',
    ppDir: 'C:\\AI\\ProPainter',
    mmDir: 'C:\\AI\\MiniMaxRemover',
    mmSteps: '6',
    mmChunk: '33',
    deDir: 'C:\\AI\\DiffuEraser',
    deChunk: '30',
    maxSideByEngine: { propainter: '720', minimax: '720', diffueraser: '640' },
    workDir: 'C:\\AI\\PP_work',
    maxSide: '720',
    margin: '48',
    dilation: '4',
    feather: '6',
    chunk: '50',
    fp16: true,
    cleanup: true
  };

  var child = null;
  var busy = false;
  var cancelled = false;

  // ---------- helpers ----------
  function extPath() {
    var p = decodeURI(cep.getSystemPath('extension'));
    return proc.platform === 'win32' ? p.replace('file:///', '') : p.replace('file://', '');
  }

  function evalJSX(code) {
    return new Promise(function (resolve) { cep.evalScript(code, resolve); });
  }

  function parse(res) {
    try { return JSON.parse(res); } catch (e) { return { ok: false, error: String(res) }; }
  }

  function log(text) {
    var el = $('log');
    el.textContent += text + '\n';
    if (el.textContent.length > 30000) el.textContent = el.textContent.slice(-20000);
    el.scrollTop = el.scrollHeight;
  }

  function setProgress(frac, text, cls) {
    if (frac !== null) $('bar').style.width = Math.max(0, Math.min(1, frac)) * 100 + '%';
    if (text !== undefined) {
      $('status').textContent = text;
      $('status').className = cls || '';
    }
  }

  function setBusy(b) {
    busy = b;
    $('run').disabled = b;
    $('cancel').disabled = !b;
  }

  function fail(msg) {
    setBusy(false);
    child = null;
    setProgress(null, msg, 'err');
    log('ПОМИЛКА: ' + msg);
  }

  function rm(p) {
    try { fs.rmSync(p, { recursive: true, force: true }); } catch (e) {}
  }

  // ---------- settings ----------
  function loadSettings() {
    var s = {};
    try { s = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) {}
    Object.keys(DEF).forEach(function (k) { if (s[k] === undefined) s[k] = DEF[k]; });
    maxSideByEngine = Object.assign({}, DEF.maxSideByEngine, s.maxSideByEngine || {});
    ['ppDir', 'mmDir', 'deDir', 'workDir', 'margin', 'dilation', 'feather', 'chunk', 'mmSteps', 'mmChunk', 'deChunk'].forEach(function (k) { $(k).value = s[k]; });
    $('fp16').checked = !!s.fp16;
    $('cleanup').checked = !!s.cleanup;
    setEngine(s.engine, true);
  }

  var engine = 'propainter';
  var maxSideByEngine = Object.assign({}, DEF.maxSideByEngine);
  var ENGINE_NAMES = { propainter: 'ProPainter', minimax: 'MiniMax-Remover', diffueraser: 'DiffuEraser' };
  function setEngine(e, silent) {
    engine = ENGINE_NAMES[e] ? e : 'propainter';
    $('maxSide').value = maxSideByEngine[engine];
    document.body.className = 'engine-' + engine;
    Array.prototype.forEach.call(document.querySelectorAll('[data-engine]'), function (b) {
      b.classList.toggle('active', b.getAttribute('data-engine') === engine);
    });
    $('run').textContent = 'Видалити об\'єкт (' + ENGINE_NAMES[engine] + ')';
    if (!silent) readSettings();
  }

  function readSettings() {
    var s = {};
    ['ppDir', 'mmDir', 'deDir', 'workDir', 'margin', 'dilation', 'feather', 'chunk', 'mmSteps', 'mmChunk', 'deChunk'].forEach(function (k) { s[k] = String($(k).value).trim(); });
    s.fp16 = $('fp16').checked;
    s.cleanup = $('cleanup').checked;
    s.engine = engine;
    maxSideByEngine[engine] = String($('maxSide').value);
    s.maxSideByEngine = maxSideByEngine;
    s.maxSide = maxSideByEngine[engine];
    localStorage.setItem(KEY, JSON.stringify(s));
    return s;
  }

  // ---------- main flow ----------
  async function run() {
    if (busy) return;
    cancelled = false;
    $('log').textContent = '';
    var s = readSettings();

    var engDir = s.engine === 'minimax' ? s.mmDir : (s.engine === 'diffueraser' ? s.deDir : s.ppDir);
    var py = path.join(engDir, 'venv', 'Scripts', 'python.exe');
    if (s.engine === 'minimax') {
      if (!fs.existsSync(path.join(s.mmDir, 'pipeline_minimax_remover.py'))) {
        $('settings').open = true;
        return fail('Не знайдено pipeline_minimax_remover.py у папці MiniMax-Remover. Запусти setup_minimax.bat або перевір шлях.');
      }
      if (!fs.existsSync(path.join(s.mmDir, 'weights', 'transformer'))) {
        $('settings').open = true;
        return fail('Не знайдено ваги (weights\\transformer). Запусти setup_minimax.bat ще раз.');
      }
    } else if (s.engine === 'diffueraser') {
      if (!fs.existsSync(path.join(s.deDir, 'run_diffueraser.py'))) {
        $('settings').open = true;
        return fail('Не знайдено run_diffueraser.py у папці DiffuEraser. Запусти setup_diffueraser.bat або перевір шлях.');
      }
      if (!fs.existsSync(path.join(s.deDir, 'weights', 'diffuEraser'))) {
        $('settings').open = true;
        return fail('Не знайдено ваги (weights\\diffuEraser). Запусти setup_diffueraser.bat ще раз.');
      }
    } else if (!fs.existsSync(path.join(s.ppDir, 'inference_propainter.py'))) {
      $('settings').open = true;
      return fail('Не знайдено inference_propainter.py у папці ProPainter. Перевір шлях у налаштуваннях.');
    }
    if (!fs.existsSync(py)) {
      $('settings').open = true;
      return fail('Не знайдено venv\\Scripts\\python.exe у ' + engDir + '. Спершу запусти setup-скрипт моделі.');
    }
    if (/[^\x00-\x7F]/.test(s.workDir) || /\s/.test(s.workDir)) {
      $('settings').open = true;
      return fail('Робоча папка має бути латиницею і без пробілів (напр. C:\\AI\\PP_work).');
    }
    try { fs.mkdirSync(s.workDir, { recursive: true }); } catch (e) { return fail('Не вдалося створити робочу папку: ' + e.message); }

    setBusy(true);
    setProgress(0.02, 'Рендер кадрів і маски в AE…');
    log('Рендер у AE…');

    var prep = parse(await evalJSX('ppPrepare(' + JSON.stringify({ workDir: s.workDir.replace(/\\/g, '/') }) + ')'));
    if (!prep.ok) return fail(prep.error || 'Помилка підготовки');
    if (cancelled) return fail('Скасовано');

    var job = prep.job.replace(/\//g, path.sep);
    var outDir = path.join(job, 'clean');
    log('Кадрів: ' + prep.frames + ', режим: ' + (prep.mode === 'masks' ? 'маски на шарі' : 'шар-маска'));
    setProgress(0.1, 'Обрізка ділянки…');

    var args = [
      path.join(extPath(), 'pp_run.py'),
      '--engine', s.engine,
      '--propainter', s.ppDir,
      '--minimax', s.mmDir,
      '--mm_steps', s.mmSteps,
      '--mm_chunk', s.mmChunk,
      '--diffueraser', s.deDir,
      '--de_chunk', s.deChunk,
      '--fps', String(prep.fps || 25),
      '--src', path.join(job, 'src'),
      '--mask', path.join(job, 'mask'),
      '--work', job,
      '--out', outDir,
      '--max_side', s.maxSide,
      '--margin', s.margin,
      '--dilation', s.dilation,
      '--feather', s.feather,
      '--chunk', s.chunk
    ];
    if (s.fp16) args.push('--fp16');

    var env = Object.assign({}, proc.env, { PYTHONUNBUFFERED: '1', PYTHONIOENCODING: 'utf-8' });
    try {
      child = cp.spawn(py, args, { cwd: engDir, env: env, windowsHide: true });
    } catch (e) {
      return fail('Не вдалося запустити Python: ' + e.message);
    }

    var stage = 'crop';
    function onLine(line) {
      line = line.trim();
      if (!line) return;
      var m = line.match(/^PROGRESS (\d+) (\d+) (\w+)/);
      if (m) {
        var i = +m[1], n = +m[2] || 1;
        stage = m[3];
        if (stage === 'crop') setProgress(0.1 + 0.08 * i / n, 'Обрізка ділянки… ' + i + '/' + n);
        else if (stage === 'inpaint') setProgress(0.2 + 0.66 * i / n, ENGINE_NAMES[s.engine] + ' працює… ' + (i ? i + '/' + n : ''));
        else if (stage === 'composite') setProgress(0.88 + 0.08 * i / n, 'Складання кадрів… ' + i + '/' + n);
        return;
      }
      var t = line.match(/(\d+)%\|/);
      if (t && stage === 'inpaint') {
        setProgress(0.2 + 0.66 * (+t[1]) / 100, 'ProPainter: ' + line.replace(/\s+/g, ' ').slice(0, 70));
        return;
      }
      log(line);
    }
    function bind(stream) {
      var buf = '';
      stream.on('data', function (d) {
        buf += d.toString('utf8');
        var parts = buf.split(/\r\n|\n|\r/);
        buf = parts.pop();
        parts.forEach(onLine);
      });
      stream.on('end', function () { if (buf) onLine(buf); });
    }
    bind(child.stdout);
    bind(child.stderr);

    child.on('error', function (e) { fail('Python: ' + e.message); });
    child.on('close', async function (code) {
      child = null;
      if (cancelled) return fail('Скасовано');
      if (code !== 0) return fail('Обробка завершилась з помилкою (код ' + code + '). Деталі в лозі.');

      setProgress(0.97, 'Імпорт у проєкт…');
      var imp = parse(await evalJSX('ppImport(' + JSON.stringify(outDir.replace(/\\/g, '/')) + ',' + JSON.stringify(s.engine) + ')'));
      if (!imp.ok) return fail(imp.error || 'Помилка імпорту');

      if (s.cleanup) ['src', 'mask', 'pp_in', 'pp_out'].forEach(function (d) { rm(path.join(job, d)); });
      setBusy(false);
      setProgress(1, 'Готово: шар «' + imp.name + '» додано над відео.', 'ok');
      log('Готово. Результат: ' + outDir);
    });
  }

  function cancel() {
    if (!busy) return;
    cancelled = true;
    if (child) {
      try { cp.exec('taskkill /pid ' + child.pid + ' /T /F'); } catch (e) { try { child.kill(); } catch (e2) {} }
    }
    setProgress(null, 'Скасування…');
  }

  function pickFolder(id) {
    try {
      var r = window.cep.fs.showOpenDialog(false, true, 'Оберіть папку', $(id).value);
      if (r && r.data && r.data.length) { $(id).value = r.data[0].replace(/\//g, '\\'); readSettings(); }
    } catch (e) { log('Діалог вибору недоступний: ' + e.message); }
  }

  // ---------- init ----------
  Array.prototype.forEach.call(document.querySelectorAll('[data-engine]'), function (b) {
    b.addEventListener('click', function () { if (!busy) setEngine(b.getAttribute('data-engine')); });
  });
  loadSettings();
  $('run').addEventListener('click', run);
  $('cancel').addEventListener('click', cancel);
  $('openWork').addEventListener('click', function () {
    var d = $('workDir').value;
    try { fs.mkdirSync(d, { recursive: true }); } catch (e) {}
    cp.exec('explorer "' + d + '"');
  });
  Array.prototype.forEach.call(document.querySelectorAll('[data-pick]'), function (b) {
    b.addEventListener('click', function () { pickFolder(b.getAttribute('data-pick')); });
  });
  Array.prototype.forEach.call(document.querySelectorAll('input, select'), function (el) {
    el.addEventListener('change', readSettings);
  });
})();
