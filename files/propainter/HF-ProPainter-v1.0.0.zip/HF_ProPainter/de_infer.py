# HF ProPainter — DiffuEraser engine
# DiffuEraser only accepts mp4 input, so: PNG frames -> mp4 (mask losslessly),
# run run_diffueraser.py, then split the result back into PNG frames.
import argparse
import glob
import math
import os
import subprocess
import sys

import cv2
import numpy as np


def say(*a):
    print(*a, flush=True)


def fail(msg):
    say("ERROR: " + msg)
    sys.exit(1)


def write_mp4(paths, out, fps, lossless, gray=False):
    import imageio
    params = ["-qp", "0"] if lossless else ["-crf", "10"]
    w = imageio.get_writer(out, fps=fps, codec="libx264", quality=None,
                           ffmpeg_params=params, pixelformat="yuv420p", macro_block_size=8)
    for p in paths:
        if gray:
            g = cv2.imread(p, cv2.IMREAD_GRAYSCALE)
            g = np.where(g > 127, 255, 0).astype(np.uint8)
            img = np.stack([g, g, g], axis=-1)
        else:
            img = cv2.cvtColor(cv2.imread(p), cv2.COLOR_BGR2RGB)
        w.append_data(img)
    w.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--frames", required=True)
    ap.add_argument("--masks", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--fps", type=float, default=25)
    ap.add_argument("--dilation", type=int, default=8)
    ap.add_argument("--max_size", type=int, default=640)
    ap.add_argument("--chunk", type=int, default=30)
    a = ap.parse_args()

    fpaths = sorted(glob.glob(os.path.join(a.frames, "*.png")))
    mpaths = sorted(glob.glob(os.path.join(a.masks, "*.png")))
    n = len(fpaths)
    if n == 0 or n != len(mpaths):
        fail("Кадри/маски не знайдено або їх кількість не збігається")

    # DiffuEraser requires the input video and its own priori video to have the exact same fps.
    # Fractional rates (29.97, 23.976) drift after an mp4 round-trip, so use a whole number:
    # inpainting is per-frame, the rate itself does not matter.
    fps = max(1, int(round(a.fps)))

    work = os.path.dirname(os.path.abspath(a.out))
    vid = os.path.join(work, "de_video.mp4")
    msk = os.path.join(work, "de_mask.mp4")
    res_dir = os.path.join(work, "de_result")
    os.makedirs(res_dir, exist_ok=True)

    say("DiffuEraser: збирання mp4 з кадрів…")
    write_mp4(fpaths, vid, fps, lossless=False)
    write_mp4(mpaths, msk, fps, lossless=True, gray=True)

    video_length = int(math.ceil(n / float(fps))) + 1   # DiffuEraser takes the limit in seconds
    cmd = [
        sys.executable, "run_diffueraser.py",
        "--input_video", vid,
        "--input_mask", msk,
        "--video_length", str(video_length),
        "--mask_dilation_iter", str(max(1, a.dilation)),
        "--max_img_size", str(a.max_size),
        "--subvideo_length", str(a.chunk),
        "--save_path", res_dir,
    ]
    say("DiffuEraser: етап 1 — ProPainter-основа, етап 2 — дифузія…")
    rc = subprocess.call(cmd, cwd=a.repo)
    if rc != 0:
        fail("run_diffueraser.py завершився з кодом %d" % rc)

    result = os.path.join(res_dir, "diffueraser_result.mp4")
    if not os.path.exists(result):
        fail("Не знайдено diffueraser_result.mp4")

    cap = cv2.VideoCapture(result)
    frames = []
    while True:
        ok, f = cap.read()
        if not ok:
            break
        frames.append(f)
    cap.release()
    if len(frames) < n:
        if len(frames) >= n - 2 and frames:
            frames += [frames[-1]] * (n - len(frames))
        else:
            fail("DiffuEraser повернув %d кадрів замість %d" % (len(frames), n))

    os.makedirs(a.out, exist_ok=True)
    for i in range(n):
        cv2.imwrite(os.path.join(a.out, "%05d.png" % i), frames[i])
    print("PROGRESS %d %d inpaint" % (n, n), flush=True)
    say("DiffuEraser: готово")


if __name__ == "__main__":
    main()
