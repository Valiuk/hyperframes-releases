# HF ProPainter — MiniMax-Remover engine
# Reads cropped frames + binary masks, runs MiniMax-Remover in overlapping chunks,
# writes inpainted frames as PNG.
import argparse
import glob
import os
import sys

import cv2
import numpy as np


def say(*a):
    print(*a, flush=True)


def fail(msg):
    say("ERROR: " + msg)
    sys.exit(1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--weights", required=True)
    ap.add_argument("--frames", required=True)
    ap.add_argument("--masks", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--steps", type=int, default=6)
    ap.add_argument("--dilation", type=int, default=6)
    ap.add_argument("--chunk", type=int, default=33)
    ap.add_argument("--overlap", type=int, default=4)
    ap.add_argument("--seed", type=int, default=42)
    a = ap.parse_args()

    sys.path.insert(0, a.repo)
    import torch
    from diffusers.models import AutoencoderKLWan
    from diffusers.schedulers import UniPCMultistepScheduler
    from transformer_minimax_remover import Transformer3DModel
    from pipeline_minimax_remover import Minimax_Remover_Pipeline

    if not torch.cuda.is_available():
        fail("CUDA недоступна — перевір драйвер NVIDIA і встановлення PyTorch")

    fpaths = sorted(glob.glob(os.path.join(a.frames, "*.png")))
    mpaths = sorted(glob.glob(os.path.join(a.masks, "*.png")))
    n = len(fpaths)
    if n == 0 or n != len(mpaths):
        fail("Кадри/маски не знайдено або їх кількість не збігається")

    frames = [cv2.cvtColor(cv2.imread(p), cv2.COLOR_BGR2RGB) for p in fpaths]
    masks = [(cv2.imread(p, cv2.IMREAD_GRAYSCALE) > 127).astype(np.float32) for p in mpaths]
    H, W = frames[0].shape[:2]
    if H % 16 or W % 16:
        fail("Розмір обробки має бути кратним 16 (%dx%d)" % (W, H))

    say("MiniMax-Remover: завантаження моделі…")
    dev = torch.device("cuda")
    vae = AutoencoderKLWan.from_pretrained(os.path.join(a.weights, "vae"), torch_dtype=torch.float16)
    transformer = Transformer3DModel.from_pretrained(os.path.join(a.weights, "transformer"), torch_dtype=torch.float16)
    scheduler = UniPCMultistepScheduler.from_pretrained(os.path.join(a.weights, "scheduler"))
    pipe = Minimax_Remover_Pipeline(transformer=transformer, vae=vae, scheduler=scheduler).to(dev)
    try:
        pipe.set_progress_bar_config(disable=True)
    except Exception:
        pass

    L = max(5, ((a.chunk - 1) // 4) * 4 + 1)          # Wan VAE wants 4k+1 frames
    ov = max(0, min(a.overlap, L // 2))
    step = L - ov

    acc = np.zeros((n, H, W, 3), np.float32)
    wsum = np.zeros((n,), np.float32)
    gen = torch.Generator(device=dev)

    s = 0
    while True:
        e = min(s + L, n)
        m = e - s
        target = ((m - 1 + 3) // 4) * 4 + 1
        idx = list(range(s, e)) + [e - 1] * (target - m)

        img = np.stack([frames[i] for i in idx]).astype(np.float32) / 127.5 - 1.0
        msk = np.stack([masks[i] for i in idx])[..., None]   # f h w 1 — format expected by the pipeline
        img_t = torch.from_numpy(img).half().to(dev)
        msk_t = torch.from_numpy(msk).half().to(dev)

        say("Кадри %d–%d з %d" % (s + 1, e, n))
        with torch.no_grad():
            out = pipe(
                images=img_t,
                masks=msk_t,
                num_frames=target,
                height=H,
                width=W,
                num_inference_steps=a.steps,
                generator=gen.manual_seed(a.seed),
                iterations=a.dilation,
            ).frames[0]
        out = np.asarray(out, dtype=np.float32)[:m]

        for j in range(m):
            w = 1.0
            if s > 0 and j < ov:
                w = (j + 1.0) / (ov + 1.0)
            if e < n and j >= m - ov:
                w = min(w, (m - j) / (ov + 1.0))
            acc[s + j] += out[j] * w
            wsum[s + j] += w

        del img_t, msk_t
        torch.cuda.empty_cache()
        print("PROGRESS %d %d inpaint" % (e, n), flush=True)
        if e >= n:
            break
        s += step

    os.makedirs(a.out, exist_ok=True)
    for i in range(n):
        f = np.clip(acc[i] / max(wsum[i], 1e-6) * 255.0, 0, 255).astype(np.uint8)
        cv2.imwrite(os.path.join(a.out, "%05d.png" % i), cv2.cvtColor(f, cv2.COLOR_RGB2BGR))
    say("MiniMax-Remover: готово")


if __name__ == "__main__":
    main()
