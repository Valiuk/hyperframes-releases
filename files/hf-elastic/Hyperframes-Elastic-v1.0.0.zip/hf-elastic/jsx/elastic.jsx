/**
 * Hyperframes Elastic — ExtendScript engine
 * Стиснення та розтягування (squash & stretch) на Scale,
 * кероване швидкістю та ключами Position.
 * ES3 — жодних let/const, JSON, Array.forEach.
 */

var HFElastic = (function () {

    var MARK = "// @hf-elastic";

    // ---------- утиліти ----------

    function parseParams(str) {
        var p = {}, i, pair, parts = String(str).split("&");
        for (i = 0; i < parts.length; i++) {
            pair = parts[i].split("=");
            if (pair.length === 2) {
                var v = decodeURIComponent(pair[1]);
                p[pair[0]] = isNaN(parseFloat(v)) ? v : parseFloat(v);
            }
        }
        return p;
    }

    function activeComp() {
        var it = app.project ? app.project.activeItem : null;
        if (!it || !(it instanceof CompItem)) return null;
        return it;
    }

    function isMarked(prop) {
        return prop.expressionEnabled && prop.expression.indexOf(MARK) !== -1;
    }

    function fmt(n) {
        if (isNaN(n)) n = 0;
        return (Math.round(n * 10000) / 10000).toFixed(4);
    }

    function tGroup(layer) { return layer.property("ADBE Transform Group"); }

    function positionProp(layer) {
        try { return tGroup(layer).property("ADBE Position"); } catch (e) { return null; }
    }

    function scaleProp(layer) {
        try { return tGroup(layer).property("ADBE Scale"); } catch (e) { return null; }
    }

    function rotationProp(layer) {
        try { return tGroup(layer).property("ADBE Rotate Z"); } catch (e) { return null; }
    }

    /** Скільки ключів на позиції (з урахуванням розділених вимірів) */
    function posKeyCount(layer) {
        var pos = positionProp(layer);
        if (!pos) return 0;
        if (pos.dimensionsSeparated) {
            var d, best = 0;
            for (d = 0; d < 3; d++) {
                try {
                    var f = pos.getSeparationFollower(d);
                    if (f && f.numKeys > best) best = f.numKeys;
                } catch (e) { }
            }
            return best;
        }
        return pos.numKeys;
    }

    // ---------- вираз squash & stretch ----------

    /**
     * a > 0 — розтяг уздовж осі руху, стиск упоперек
     * a < 0 — стиск уздовж осі руху (те, що діється в момент удару)
     * Складова "рух" бере поточну швидкість; складова "удар" — швидкість
     * на підльоті до пройденого ключа Position плюс згасаюче коливання.
     */
    function exprSquash(p) {
        var useMove = (p.mode === "move" || p.mode === "both") ? 1 : 0;
        var useHit = (p.mode === "hit" || p.mode === "both") ? 1 : 0;

        return MARK + " squash\n" +
            "amt = " + fmt(p.amount / 100) + ";\n" +
            "maxV = " + fmt(p.maxv) + ";\n" +
            "amp = " + fmt(p.amp / 100) + ";\n" +
            "freq = " + fmt(p.freq) + ";\n" +
            "decay = " + fmt(p.decay) + ";\n" +
            "sm = " + fmt(p.smooth) + ";\n" +
            "useMove = " + useMove + ";\n" +
            "useHit = " + useHit + ";\n" +
            "aligned = " + (p.aligned ? 1 : 0) + ";\n" +
            "vol = " + (p.volume ? 1 : 0) + ";\n" +
            "\n" +
            "pos = thisLayer.transform.position;\n" +
            "fd = thisComp.frameDuration;\n" +
            "\n" +
            "// поточна швидкість, згладжена по сусідніх кадрах\n" +
            "v = pos.velocityAtTime(time);\n" +
            "if (sm > 0) {\n" +
            "  v = (pos.velocityAtTime(time - sm*fd) + pos.velocityAtTime(time) + pos.velocityAtTime(time + sm*fd))/3;\n" +
            "}\n" +
            "vx = v[0];\n" +
            "vy = (v.length > 1) ? v[1] : 0;\n" +
            "spd = Math.sqrt(vx*vx + vy*vy);\n" +
            "\n" +
            "// вісь руху: +1 горизонталь, -1 вертикаль\n" +
            "axisMove = aligned ? 1 : (Math.abs(vx) - Math.abs(vy))/(Math.abs(vx) + Math.abs(vy) + 0.001);\n" +
            "aMove = useMove ? clamp(spd/maxV, 0, 1)*amt*axisMove : 0;\n" +
            "\n" +
            "// удар: згасаюче коливання після пройденого ключа позиції\n" +
            "aHit = 0;\n" +
            "if (useHit && pos.numKeys > 0) {\n" +
            "  n = pos.nearestKey(time).index;\n" +
            "  if (pos.key(n).time > time) n--;\n" +
            "  if (n > 0) {\n" +
            "    t = time - pos.key(n).time;\n" +
            "    kv = pos.velocityAtTime(pos.key(n).time - fd/10);\n" +
            "    kx = kv[0];\n" +
            "    ky = (kv.length > 1) ? kv[1] : 0;\n" +
            "    kspd = Math.sqrt(kx*kx + ky*ky);\n" +
            "    axisHit = aligned ? 1 : (Math.abs(kx) - Math.abs(ky))/(Math.abs(kx) + Math.abs(ky) + 0.001);\n" +
            "    osc = clamp(kspd/maxV, 0, 1)*amp*Math.cos(freq*t*2*Math.PI)/Math.exp(decay*t);\n" +
            "    aHit = -osc*axisHit;\n" +
            "  }\n" +
            "}\n" +
            "\n" +
            "a = aMove + aHit;\n" +
            "sx = 1 + a;\n" +
            "if (sx < 0.05) sx = 0.05;\n" +
            "sy = vol ? 1/sx : 1 - a;\n" +
            "\n" +
            "r = [value[0]*sx, value[1]*sy];\n" +
            "if (value.length > 2) r = r.concat([value[2]]);\n" +
            "r;";
    }

    /** Розворот шару за напрямком руху — щоб розтяг ішов уздовж траєкторії */
    function exprAlign(p) {
        return MARK + " align\n" +
            "minSpd = " + fmt(p.maxv * 0.05) + ";\n" +
            "pos = thisLayer.transform.position;\n" +
            "v = pos.velocityAtTime(time);\n" +
            "vy = (v.length > 1) ? v[1] : 0;\n" +
            "sp = Math.sqrt(v[0]*v[0] + vy*vy);\n" +
            "k = clamp(sp/minSpd, 0, 1);\n" +
            "value + radiansToDegrees(Math.atan2(vy, v[0]))*k;";
    }

    // ---------- запікання ----------

    function bakeProp(prop, expr, srcProp, tail, comp) {
        if (!srcProp || srcProp.numKeys < 1) return false;

        var fd = comp.frameDuration;
        var t0 = srcProp.keyTime(1);
        var t1 = srcProp.keyTime(srcProp.numKeys) + tail;
        if (t1 > comp.duration) t1 = comp.duration;
        if (t0 < 0) t0 = 0;

        prop.expression = expr;

        var times = [], values = [], t;
        for (t = t0; t <= t1 + fd * 0.5; t += fd) {
            times.push(t);
            values.push(prop.valueAtTime(t, false)); // false = значення після виразу
        }

        prop.expression = "";
        while (prop.numKeys > 0) prop.removeKey(1);
        prop.setValuesAtTimes(times, values);

        var i;
        for (i = 1; i <= prop.numKeys; i++) {
            try {
                prop.setInterpolationTypeAtKey(i, KeyframeInterpolationType.LINEAR,
                                                  KeyframeInterpolationType.LINEAR);
            } catch (e) { }
        }
        return true;
    }

    /** Часові межі для запікання беремо з ключів позиції */
    function timeSource(layer) {
        var pos = positionProp(layer);
        if (!pos) return null;
        if (pos.dimensionsSeparated) {
            var d, best = null;
            for (d = 0; d < 3; d++) {
                try {
                    var f = pos.getSeparationFollower(d);
                    if (f && (!best || f.numKeys > best.numKeys)) best = f;
                } catch (e) { }
            }
            return best;
        }
        return pos;
    }

    // ---------- дії ----------

    function run(action, paramStr) {
        var p = parseParams(paramStr);
        var comp = activeComp();
        if (!comp) return "err|Відкрийте композицію";

        var layers = comp.selectedLayers;
        if (!layers || layers.length === 0) return "err|Виділіть хоча б один шар";

        var sExpr = exprSquash(p);
        var rExpr = exprAlign(p);
        var touched = 0, noKeys = 0, i;

        app.beginUndoGroup("Hyperframes Elastic — " + action);
        try {
            for (i = 0; i < layers.length; i++) {
                var layer = layers[i];
                var sc = scaleProp(layer);
                var rot = rotationProp(layer);
                if (!sc) continue;

                if (action === "remove") {
                    if (isMarked(sc)) { sc.expression = ""; touched++; }
                    if (rot && isMarked(rot)) rot.expression = "";
                    continue;
                }

                if (action === "bake") {
                    var src = timeSource(layer);
                    if (!src || src.numKeys < 1) { noKeys++; continue; }
                    if (p.aligned && rot) bakeProp(rot, rExpr, src, p.tail, comp);
                    if (bakeProp(sc, sExpr, src, p.tail, comp)) touched++;
                    continue;
                }

                // apply
                sc.expression = sExpr;
                if (p.aligned && rot) rot.expression = rExpr;
                else if (rot && isMarked(rot)) rot.expression = "";
                touched++;
            }
        } catch (e) {
            app.endUndoGroup();
            return "err|" + e.toString();
        }
        app.endUndoGroup();

        if (touched === 0) {
            if (noKeys > 0) return "err|Немає ключів Position — запікати нічого";
            return "err|У виділенні немає шарів зі Scale";
        }
        var msg = touched + " шар(ів)";
        if (noKeys > 0) msg += " · без ключів пропущено: " + noKeys;
        return "ok|" + msg;
    }

    /** Anchor Point у точку контакту, з компенсацією позиції */
    function anchor(where) {
        var comp = activeComp();
        if (!comp) return "err|Відкрийте композицію";
        var layers = comp.selectedLayers;
        if (!layers || layers.length === 0) return "err|Виділіть хоча б один шар";

        var done = 0, skipped = 0, i, k;

        app.beginUndoGroup("Hyperframes Elastic — anchor");
        try {
            for (i = 0; i < layers.length; i++) {
                var layer = layers[i];
                if (!(layer instanceof AVLayer)) { skipped++; continue; }

                var ap = tGroup(layer).property("ADBE Anchor Point");
                var pos = positionProp(layer);
                var scv = scaleProp(layer).value;
                if (ap.numKeys > 0) { skipped++; continue; }

                var w = layer.width, h = layer.height;
                var ty = (where === "bottom") ? h : (where === "top" ? 0 : h / 2);
                var old = ap.value;
                var d = [w / 2 - old[0], ty - old[1]];
                var shift = [d[0] * scv[0] / 100, d[1] * scv[1] / 100];

                var na = [w / 2, ty];
                if (old.length > 2) na.push(old[2]);
                ap.setValue(na);

                if (pos.dimensionsSeparated) {
                    var dim;
                    for (dim = 0; dim < 2; dim++) {
                        var f = pos.getSeparationFollower(dim);
                        if (!f) continue;
                        if (f.numKeys > 0) {
                            for (k = 1; k <= f.numKeys; k++) f.setValueAtKey(k, f.keyValue(k) + shift[dim]);
                        } else {
                            f.setValue(f.value + shift[dim]);
                        }
                    }
                } else if (pos.numKeys > 0) {
                    for (k = 1; k <= pos.numKeys; k++) {
                        var kv = pos.keyValue(k);
                        var nv = [kv[0] + shift[0], kv[1] + shift[1]];
                        if (kv.length > 2) nv.push(kv[2]);
                        pos.setValueAtKey(k, nv);
                    }
                } else {
                    var pv = pos.value;
                    var np = [pv[0] + shift[0], pv[1] + shift[1]];
                    if (pv.length > 2) np.push(pv[2]);
                    pos.setValue(np);
                }
                done++;
            }
        } catch (e) {
            app.endUndoGroup();
            return "err|" + e.toString();
        }
        app.endUndoGroup();

        if (done === 0) return "err|Не вдалося: ключі на Anchor Point або не AV-шар";
        return "ok|Anchor перенесено: " + done;
    }

    function status() {
        var comp = activeComp();
        if (!comp) return "no-comp|Композицію не відкрито";
        var l = comp.selectedLayers;
        if (!l || l.length === 0) return "no-sel|Немає виділених шарів";
        if (l.length === 1) {
            return "ok|" + l[0].name + " · Position: " + posKeyCount(l[0]) + " кл.";
        }
        return "ok|Шарів: " + l.length;
    }

    function expressionOnly(paramStr) {
        return exprSquash(parseParams(paramStr));
    }

    return {
        apply: function (s) { return run("apply", s); },
        bake: function (s) { return run("bake", s); },
        clear: function (s) { return run("remove", s); },
        anchorBottom: function () { return anchor("bottom"); },
        anchorCenter: function () { return anchor("center"); },
        status: status,
        expr: expressionOnly
    };
})();
