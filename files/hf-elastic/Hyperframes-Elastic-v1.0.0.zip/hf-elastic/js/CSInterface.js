/* Мінімальний міст CEP <-> ExtendScript (підмножина офіційного CSInterface.js) */
var SystemPath = {
    EXTENSION: "extension",
    USER_DATA: "userData",
    COMMON_FILES: "commonFiles"
};

function CSInterface() { }

CSInterface.prototype.evalScript = function (script, callback) {
    if (typeof callback !== "function") callback = function () { };
    window.__adobe_cep__.evalScript(script, callback);
};

CSInterface.prototype.getSystemPath = function (type) {
    var path = decodeURI(window.__adobe_cep__.getSystemPath(type));
    if (navigator.platform.indexOf("Win") >= 0) {
        path = path.replace("file:///", "");
    } else {
        path = path.replace("file://", "");
    }
    return path;
};

CSInterface.prototype.getHostEnvironment = function () {
    return JSON.parse(window.__adobe_cep__.getHostEnvironment());
};

CSInterface.prototype.addEventListener = function (type, listener, obj) {
    window.__adobe_cep__.addEventListener(type, listener, obj);
};

CSInterface.prototype.getExtensionID = function () {
    return window.__adobe_cep__.getExtensionId();
};
