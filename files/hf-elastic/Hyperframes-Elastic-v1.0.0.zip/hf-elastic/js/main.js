(function () {
  "use strict";

  var cs = new CSInterface();
  var $ = function (id) { return document.getElementById(id); };

  var HINTS = {
    move: "Шар розтягується вздовж напрямку руху й стискається впоперек — тим сильніше, чим більша швидкість. На зупинці повертається у 100%.",
    hit: "У момент проходження ключа позиції шар стискається вздовж осі підльоту й пружинить, поки коливання не згасне. Ключ із Easy Ease на вльоті гасить швидкість — удару не буде.",
    both: "Розтяг під час руху плюс пружний удар на кожному ключі позиції. Найближче до класичного squash & stretch."
  };

  var PRESETS = {
    ball:  { amount: 30, amp: 30, freq: 3.0, decay: 7.0,  maxv: 2200, smooth: 0 },
    ui:    { amount: 18, amp: 14, freq: 3.6, decay: 9.0,  maxv: 1400, smooth: 1 },
    jelly: { amount: 40, amp: 34, freq: 5.5, decay: 3.2,  maxv: 1600, smooth: 1 },
    heavy: { amount: 12, amp: 10, freq: 1.8, decay: 5.0,  maxv: 3000, smooth: 2 }
  };

  var mode = "hit";
  var NUMS = ["amount", "amp", "freq", "decay", "maxv", "smooth"];

  // ---------- параметри ----------

  function params() {
    var p = { mode: mode, tail: parseFloat($("tail").value) || 1.2 };
    for (var i = 0; i < NUMS.length; i++) p[NUMS[i]] = parseFloat($(NUMS[i]).value);
    p.volume = $("volume").checked ? 1 : 0;
    p.aligned = $("aligned").checked ? 1 : 0;
    return p;
  }

  function query(p) {
    var out = [];
    for (var k in p) if (p.hasOwnProperty(k)) out.push(k + "=" + encodeURIComponent(p[k]));
    return out.join("&");
  }

  // ---------- поля ----------

  function link(id) {
    var s = $(id), n = $(id + "N");
    s.addEventListener("input", function () { n.value = s.value; draw(); });
    n.addEventListener("input", function () {
      var v = parseFloat(n.value);
      if (!isNaN(v)) { s.value = v; draw(); }
    });
  }

  function setValues(preset) {
    for (var k in preset) if (preset.hasOwnProperty(k) && $(k)) {
      $(k).value = preset[k];
      $(k + "N").value = preset[k];
    }
    draw();
  }

  function applyMode(next) {
    mode = next;
    var btns = document.querySelectorAll(".mode"), i;
    for (i = 0; i < btns.length; i++) {
      btns[i].classList.toggle("is-on", btns[i].dataset.mode === next);
    }
    var rows = document.querySelectorAll("[data-for]");
    for (i = 0; i < rows.length; i++) {
      rows[i].classList.toggle("hidden", rows[i].dataset.for.indexOf(next) === -1);
    }
    $("modeHint").textContent = HINTS[next];
    draw();
  }

  // ---------- прев'ю ----------

  var cv = $("curve"), ctx = cv.getContext("2d");
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  var T_IN = 0.6;      // час розгону до удару
  var T_TOTAL = 2.4;   // вікно прев'ю
  var V_MAX = 2200;    // швидкість на підльоті до ключа, px/s

  function css(v) {
    return getComputedStyle(document.documentElement).getPropertyValue(v).trim();
  }

  function fit() {
    var r = window.devicePixelRatio || 1;
    cv.width = cv.clientWidth * r;
    cv.height = cv.clientHeight * r;
    ctx.setTransform(r, 0, 0, r, 0, 0);
    draw();
  }

  /** Швидкість модельного руху: розгін до V_MAX і різка зупинка на ключі */
  function speedAt(t) {
    if (t >= T_IN) return 0;
    return V_MAX * (t / T_IN);
  }

  /** Множники масштабу [sx, sy] у момент t для поточних налаштувань */
  function scaleAt(t, p) {
    var useMove = (p.mode === "move" || p.mode === "both");
    var useHit = (p.mode === "hit" || p.mode === "both");

    var aMove = 0, aHit = 0;

    if (useMove) {
      aMove = Math.min(speedAt(t) / p.maxv, 1) * (p.amount / 100);
    }
    if (useHit && t >= T_IN) {
      var dt = t - T_IN;
      var k = Math.min(V_MAX / p.maxv, 1);
      aHit = -k * (p.amp / 100) * Math.cos(p.freq * dt * 2 * Math.PI) / Math.exp(p.decay * dt);
    }

    var a = aMove + aHit;
    var sx = Math.max(1 + a, 0.05);
    var sy = p.volume ? 1 / sx : 1 - a;
    return [sx, sy];
  }

  /** Пройдена частка шляху (для положення кульки) */
  function progress(t) {
    if (t >= T_IN) return 1;
    var x = t / T_IN;
    return x * x; // інтеграл лінійного розгону
  }

  function draw() {
    var p = params();
    var w = cv.clientWidth, h = cv.clientHeight;
    var padL = 12, padR = 12;
    var gTop = 10, gBot = h * 0.62;      // зона графіка
    var bTop = h * 0.62, bBot = h - 8;   // зона кульки

    ctx.clearRect(0, 0, w, h);

    // --- збір точок ---
    var pts = [], i, t, s, lo = 1, hi = 1;
    for (i = 0; i <= 260; i++) {
      t = i / 260 * T_TOTAL;
      s = scaleAt(t, p);
      if (s[0] < lo) lo = s[0];
      if (s[1] < lo) lo = s[1];
      if (s[0] > hi) hi = s[0];
      if (s[1] > hi) hi = s[1];
      pts.push([t, s[0], s[1]]);
    }
    var span = Math.max(hi - lo, 0.3);
    lo -= span * 0.15; hi += span * 0.15;

    function X(tt) { return padL + tt / T_TOTAL * (w - padL - padR); }
    function Y(vv) { return gBot - (vv - lo) / (hi - lo) * (gBot - gTop); }

    // --- сітка: 100% і момент удару ---
    ctx.strokeStyle = "#3a3a3a"; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(padL, Y(1) + 0.5); ctx.lineTo(w - padR, Y(1) + 0.5); ctx.stroke();

    ctx.strokeStyle = css("--hit");
    ctx.globalAlpha = 0.5;
    ctx.beginPath(); ctx.moveTo(X(T_IN) + 0.5, gTop); ctx.lineTo(X(T_IN) + 0.5, gBot); ctx.stroke();
    ctx.globalAlpha = 1;

    // --- криві ---
    function stroke(idx, color) {
      ctx.strokeStyle = color; ctx.lineWidth = 1.6;
      ctx.beginPath();
      for (var j = 0; j < pts.length; j++) {
        var px = X(pts[j][0]), py = Y(pts[j][idx]);
        if (j === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.stroke();
    }
    stroke(2, css("--y"));
    stroke(1, css("--x"));

    // --- кулька ---
    var loop = reduce ? T_IN + 0.12 : (Date.now() % 3200) / 3200 * T_TOTAL;
    var sc = scaleAt(loop, p);
    var R = Math.min((bBot - bTop) / 2 - 2, 16);
    var wallX = w - padR - 6;
    var startX = padL + 8;
    var cx = startX + progress(loop) * (wallX - R - startX);
    if (loop >= T_IN) cx = wallX - R * sc[0];
    var cy = (bTop + bBot) / 2;

    ctx.strokeStyle = "#3a3a3a";
    ctx.beginPath(); ctx.moveTo(wallX + 0.5, bTop + 4); ctx.lineTo(wallX + 0.5, bBot); ctx.stroke();

    ctx.fillStyle = css("--x");
    ctx.globalAlpha = 0.85;
    ctx.beginPath();
    if (ctx.ellipse) {
      ctx.ellipse(cx, cy, R * sc[0], R * sc[1], 0, 0, Math.PI * 2);
    } else {
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
    }
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  if (!reduce) setInterval(draw, 1000 / 30);

  // ---------- зв'язок з After Effects ----------

  function bootstrap() {
    var path = cs.getSystemPath(SystemPath.EXTENSION) + "/jsx/elastic.jsx";
    path = path.replace(/\\/g, "/");
    cs.evalScript('$.evalFile(new File("' + encodeURI(path) + '"))', function () { poll(); });
  }

  function call(fn, cb) {
    cs.evalScript("HFElastic." + fn + '("' + query(params()) + '")', function (res) {
      cb(String(res || ""));
    });
  }

  function simple(fn) {
    cs.evalScript("HFElastic." + fn + "()", function (res) { report(String(res || "")); });
  }

  function report(res) {
    var log = $("log");
    var parts = res.split("|");
    if (parts[0] === "ok") {
      log.className = "log ok";
      log.textContent = "Готово: " + parts[1];
    } else {
      log.className = "log err";
      log.textContent = parts.slice(1).join("|") || "Не вдалося виконати";
    }
    poll();
  }

  function poll() {
    cs.evalScript("HFElastic.status()", function (res) {
      var parts = String(res || "").split("|");
      var el = $("status");
      el.textContent = parts[1] || "Немає зв'язку з After Effects";
      el.classList.toggle("warn", parts[0] !== "ok");
    });
  }

  // ---------- події ----------

  for (var i = 0; i < NUMS.length; i++) link(NUMS[i]);

  var modeBtns = document.querySelectorAll(".mode");
  for (i = 0; i < modeBtns.length; i++) {
    modeBtns[i].addEventListener("click", function () { applyMode(this.dataset.mode); });
  }

  var chips = document.querySelectorAll(".presets .chip");
  for (i = 0; i < chips.length; i++) {
    chips[i].addEventListener("click", function () { setValues(PRESETS[this.dataset.preset]); });
  }

  $("volume").addEventListener("change", draw);
  $("aligned").addEventListener("change", draw);

  $("apply").addEventListener("click", function () { call("apply", report); });
  $("bake").addEventListener("click", function () { call("bake", report); });
  $("clear").addEventListener("click", function () { call("clear", report); });
  $("apBottom").addEventListener("click", function () { simple("anchorBottom"); });
  $("apCenter").addEventListener("click", function () { simple("anchorCenter"); });

  $("copy").addEventListener("click", function () {
    call("expr", function (expr) {
      var ta = document.createElement("textarea");
      ta.value = expr;
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand("copy"); } catch (e) { }
      document.body.removeChild(ta);
      var log = $("log");
      log.className = "log ok";
      log.textContent = "Вираз у буфері обміну";
    });
  });

  window.addEventListener("resize", fit);
  window.addEventListener("focus", poll);
  setInterval(function () { if (document.hasFocus()) poll(); }, 1500);

  applyMode("hit");
  fit();
  bootstrap();
})();
