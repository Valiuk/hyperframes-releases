/*
  add_slot_rig.jsx — «Slot rig»: один нуль у компі Game, яким можна масштабувати й рухати
  барабани разом із рамкою.

  Чому так: на рамці стоять вирази на Anchor / Position / Scale (сітки й відступи Gap X / Gap Y),
  тому масштабувати її напряму не вийде. Скрипт створює нуль у центрі сітки і робить його батьком
  для Slot і рамки. Вираз рамки лишається (він дає «локальний» масштаб від сітки й відступів),
  а масштаб і позиція нуля множаться зверху.

  Після запуску: вибери шар «Slot rig» у Game і міняй Scale / Position / Rotation як завгодно.
  Повторний запуск безпечний. Усе — один крок Undo.
*/
(function () {
    var proj = app.project;
    if (!proj) { alert("Відкрий проєкт."); return; }
    function compNamed(n) {
        for (var i = 1; i <= proj.numItems; i++) {
            var it = proj.item(i);
            if (it instanceof CompItem && it.name === n && it.numLayers > 0) return it;
        }
        return null;
    }
    function compAny(n) {
        for (var i = 1; i <= proj.numItems; i++) if (proj.item(i) instanceof CompItem && proj.item(i).name === n) return proj.item(i);
        return null;
    }
    function tr(l) { return l.property("ADBE Transform Group"); }

    var game = compNamed("Game"), slot = compAny("Slot");
    if (!game || !slot) { alert("Не знайдено компи Game / Slot."); return; }
    var frameSrc = compAny("Frame_grid") || compAny("Frame");

    var slotLayers = [], frameLayers = [];
    for (var i = 1; i <= game.numLayers; i++) {
        var L = game.layer(i);
        if (L.source === slot) slotLayers.push(L);
        else if (frameSrc && L.source === frameSrc) frameLayers.push(L);
    }
    if (!slotLayers.length) { alert("У Game немає шару Slot."); return; }

    app.beginUndoGroup("Slot rig");

    // ---- нуль у центрі сітки ----
    var rig = null;
    for (var i = 1; i <= game.numLayers; i++) if (game.layer(i).name === "Slot rig") rig = game.layer(i);
    var created = false;
    if (!rig) {
        // центр сітки = поточна позиція рамки (вираз ставить її саме в центр сітки); інакше — центр Slot
        var c = frameLayers.length ? tr(frameLayers[0]).property("ADBE Position").value
                                   : tr(slotLayers[0]).property("ADBE Position").value;
        rig = game.layers.addNull();
        rig.name = "Slot rig";
        rig.label = 9;
        tr(rig).property("ADBE Position").setValue([c[0], c[1]]);
        rig.moveToEnd();                          // у кінець — індекси інших шарів Game не зсуваються
        created = true;
    }

    // ---- Slot ----
    // В ExtendScript: layer.parent = X — прив'язка БЕЗ стрибка (AE компенсує трансформації, як звичайне
    // батьківство в UI); setParentWithJump — шар «стрибає». Перша версія скрипта помилково брала
    // setParentWithJump, тож Slot з'їжджав. Якщо нуль від першої версії — спершу відв'язуємо Slot
    // так само «зі стрибком» (це повертає його на старе місце), потім прив'язуємо правильно.
    var repair = !created && rig.comment !== "slot rig v2";
    var nSlot = 0;
    for (var i = 0; i < slotLayers.length; i++) {
        var S = slotLayers[i];
        if (S.parent === rig && repair) S.setParentWithJump(null);
        if (S.parent === rig) continue;
        S.parent = rig;
        nSlot++;
    }
    rig.comment = "slot rig v2";

    // ---- рамка: позиція задана виразом у координатах Game → переводимо в координати нуля ----
    var nFrame = 0, rp = tr(rig).property("ADBE Position").valueAtTime(0, false);
    var FRAME_POS = '// рамка стоїть у точці нуля «Slot rig» (центр сітки); без батька — як було\n' +
        'hasParent ? parent.transform.anchorPoint : [' + rp[0].toFixed(3) + ', ' + rp[1].toFixed(3) + '];';
    for (var i = 0; i < frameLayers.length; i++) {
        var F = frameLayers[i], pos = tr(F).property("ADBE Position");
        if (F.parent === rig && repair && !pos.expression) F.setParentWithJump(null);   // ремонт першої версії
        if (F.parent === rig) {
            // якщо вираз позиції перезаписав add_spacing_controls.jsx — повертаємо версію для батька
            if (pos.expression && pos.expression.indexOf("hasParent") === -1) { pos.expression = FRAME_POS; nFrame++; }
            continue;
        }
        if (pos.expression) { F.parent = rig; pos.expression = FRAME_POS; }   // позицію задає вираз
        else F.parent = rig;                                                    // без стрибка
        nFrame++;
    }

    app.endUndoGroup();
    alert((created ? "Створено нуль «Slot rig» у Game.\n" : (repair ? "Виправлено прив'язку від першої версії скрипта.\n" : "Нуль «Slot rig» уже був.\n")) +
          "Прив'язано: Slot — " + nSlot + ", рамка — " + nFrame + ".\n\n" +
          "Масштабуй і рухай «Slot rig» — барабани й рамка змінюються разом.\n" +
          "Gap X / Gap Y, Reels / Rows працюють як і раніше.\n" +
          "Якщо перезапустиш add_spacing_controls.jsx — запусти цей скрипт ще раз.");
})();
