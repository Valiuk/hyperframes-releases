/*
  resize_skin_symbols.jsx — підігнати розмір символів одного скіна відносно «лінійки» (напрямних).

  Вибираєш скін і відсоток: 100% — символ упирається в напрямні більшою стороною,
  80% — на п'яту частину менший і т. д. Застосовується до всіх pragmatic_symbol_N, де є цей скін.
  Позиція — по центру напрямних. Після роботи показує підсумок по кожному символу.
  Повторний запуск з іншим відсотком безпечний (розмір рахується заново, а не множиться).
*/
(function () {
    var proj = app.project;
    if (!proj) { alert("Відкрий проєкт."); return; }
    function tr(l) { return l.property("ADBE Transform Group"); }
    function guideBox(comp) {
        var xs = [], ys = [];
        try { var g = comp.guides; for (var i = 0; i < g.length; i++) (g[i].orientationType === 0 ? ys : xs).push(g[i].position); } catch (e) {}
        function span(a) { if (a.length < 2) return null; var mn = a[0], mx = a[0]; for (var k = 1; k < a.length; k++) { if (a[k] < mn) mn = a[k]; if (a[k] > mx) mx = a[k]; } return [mn, mx]; }
        var sx = span(xs), sy = span(ys);
        if (!sx || !sy || sx[1] - sx[0] > comp.width * 0.9 || sy[1] - sy[0] > comp.height * 0.9) return { x1: 100, x2: 412, y1: 100, y2: 412, fb: true };
        return { x1: sx[0], x2: sx[1], y1: sy[0], y2: sy[1] };
    }

    // компи pragmatic_symbol_N, відсортовані за N
    var comps = [];
    for (var i = 1; i <= proj.numItems; i++) {
        var it = proj.item(i);
        if (it instanceof CompItem && /^pragmatic_symbol_\d+$/.test(it.name)) comps.push(it);
    }
    comps.sort(function (a, b) { return parseInt(a.name.replace(/\D/g, ""), 10) - parseInt(b.name.replace(/\D/g, ""), 10); });
    if (!comps.length) { alert("Не знайдено компів pragmatic_symbol_N."); return; }

    // список скінів: шари з іменем, що відрізняється від назви джерела (так названі додані скіни)
    var names = [], seen = {};
    for (var c = 0; c < comps.length; c++) for (var i = 1; i <= comps[c].numLayers; i++) {
        var L = comps[c].layer(i), nm = L.name;
        if (L.source && nm !== L.source.name && !seen[nm]) { seen[nm] = true; names.push(nm); }
    }
    if (!names.length) { alert("Не знайдено доданих скінів (шарів з власною назвою)."); return; }

    var dlg = new Window("dialog", "Розмір символів скіна");
    dlg.alignChildren = "fill";
    var g1 = dlg.add("group"); g1.add("statictext", undefined, "Скін:");
    var dd = g1.add("dropdownlist", undefined, names); dd.selection = 0;
    for (var i = 0; i < names.length; i++) if (names[i] === "Joker") dd.selection = i;
    var g2 = dlg.add("group"); g2.add("statictext", undefined, "Розмір відносно лінійки, %:");
    var et = g2.add("edittext", undefined, "80"); et.characters = 5;
    var gb = dlg.add("group"); gb.alignment = "right";
    gb.add("button", undefined, "Скасувати", { name: "cancel" });
    gb.add("button", undefined, "Застосувати", { name: "ok" });
    if (dlg.show() !== 1) return;
    var SKIN = dd.selection.text, PCT = parseFloat(et.text);
    if (!(PCT > 0)) { alert("Вкажи відсоток числом."); return; }

    app.beginUndoGroup("Resize symbols: " + SKIN);
    var rep = [], fb = false;
    for (var c = 0; c < comps.length; c++) {
        var comp = comps[c], L = null;
        for (var i = 1; i <= comp.numLayers; i++) if (comp.layer(i).name === SKIN) L = comp.layer(i);
        if (!L) continue;
        var b = guideBox(comp); if (b.fb) fb = true;
        var r = L.sourceRectAtTime(0, false);                 // видима область картинки в координатах шару
        var gw = b.x2 - b.x1, gh = b.y2 - b.y1;
        var s = Math.min(gw / r.width, gh / r.height) * PCT;  // у відсотках Scale
        var ap = [r.left + r.width / 2, r.top + r.height / 2], pos = [(b.x1 + b.x2) / 2, (b.y1 + b.y2) / 2], sc = [s, s];
        if (L.threeDLayer) { ap.push(0); pos.push(0); sc.push(100); }
        tr(L).property("ADBE Anchor Point").setValue(ap);
        tr(L).property("ADBE Scale").setValue(sc);
        tr(L).property("ADBE Position").setValue(pos);
        rep.push(comp.name.replace("pragmatic_symbol_", "Symbol_") + ": " + Math.round(r.width * s / 100) + "×" + Math.round(r.height * s / 100) +
                 " (лінійка " + Math.round(gw) + "×" + Math.round(gh) + ")");
    }
    app.endUndoGroup();
    alert(SKIN + " — " + PCT + "% від лінійки:\n\n" + rep.join("\n") +
          (fb ? "\n\nНапрямні в частині компів не знайдено — взято стандартні 100…412." : ""));
})();
