/*
  export_variation.jsx — зберігає окремий «легкий» проєкт з вибраними скінами шаблону.

  Що робить:
   1. Питає: один або кілька скінів (Ctrl/Shift-клік), сітку (одна або всі), куди зберегти.
      Кілька скінів → у копії вони перенумеровуються 1…N і так само перемикаються слайдером Slot
      (відповідність номерів записується в коментар шару керування в render).
   2. Зберігає оригінал (якщо є незбережені зміни) і робить Save As у новий файл —
      оригінальний .aep на диску не чіпається.
   3. У новому проєкті:
      • у всіх компах-перемикачах лишає тільки шари вибраних скінів, решту видаляє
        (один скін — вираз замінюється на сталу видимість; кілька — на перемикач з новим номером);
      • у рамках лишає тільки вибрану сітку (або всі, якщо так обрано);
      • при одній сітці видаляє приховані колонки і глови (n > Reels);
      • Reduce Project: прибирає все, що не використовується компом render — з урахуванням компів,
        на які посилаються вирази (comp("…")), щоб нічого не зламалось.
   4. Зберігає новий файл. Після роботи відкритий саме він.

  Файли футажу лишаються на своїх місцях. Щоб отримати переносну папку —
  File > Dependencies > Collect Files у новому проєкті.
*/
(function () {
    var proj = app.project;
    if (!proj || !proj.file) { alert("Спершу збережи проєкт (потрібен шлях до оригіналу)."); return; }

    // ---------------- утиліти ----------------
    function compNamed(n) {
        for (var i = 1; i <= proj.numItems; i++) {
            var it = proj.item(i);
            if (it instanceof CompItem && it.name === n && it.numLayers > 0) return it;
        }
        return null;
    }
    function allComps() {
        var a = [];
        for (var i = 1; i <= proj.numItems; i++) if (proj.item(i) instanceof CompItem) a.push(proj.item(i));
        return a;
    }
    function tr(l) { return l.property("ADBE Transform Group"); }
    function opac(l) { return tr(l).property("ADBE Opacity"); }
    function effectByName(l, n) {
        var fx = l.property("ADBE Effect Parade");
        if (!fx) return null;
        for (var i = 1; i <= fx.numProperties; i++) if (fx.property(i).name === n) return fx.property(i);
        return null;
    }
    var RX_MY = new RegExp("myLayerIndex\\s*=\\s*(\\d+)");
    var RX_EQ = new RegExp("===\\s*(\\d+)");
    var RX_GRID = new RegExp("C\\s*==\\s*(\\d+)\\s*&&\\s*R\\s*==\\s*(\\d+)");
    var RX_COMP = new RegExp("comp\\(\"([^\"]+)\"\\)", "g");

    function slotOf(layer) {                 // номер скіна, до якого належить шар, або 0
        var ex = opac(layer).expression;
        if (!ex || ex.indexOf('effect("Slot")') === -1) return 0;
        if (ex.indexOf("thisLayer.index") !== -1) return layer.index;
        var m = ex.match(RX_MY) || ex.match(RX_EQ);
        return m ? parseInt(m[1], 10) : 0;
    }
    function gridOf(layer) {                 // "CxR" для шару-варіанта рамки, або ""
        var ex = opac(layer).expression;
        if (!ex || ex.indexOf('effect("Reels")') === -1) return "";
        var m = ex.match(RX_GRID);
        return m ? (m[1] + "x" + m[2]) : "";
    }
    function bakeVisible(layer) {
        var o = opac(layer);
        o.expression = "";
        if (o.numKeys === 0 && o.value < 1) o.setValue(100);
    }
    function safeName(s) { return String(s).replace(/[\\\/:*?"<>|]/g, "_").replace(/\s+/g, "_"); }

    var render = compNamed("render");
    if (!render) { alert("Комп render не знайдено."); return; }
    var ctl = render.layer(1);
    var slotFx = effectByName(ctl, "Slot"), reelsFx = effectByName(ctl, "Reels"), rowsFx = effectByName(ctl, "Rows");
    if (!slotFx) { alert("На першому шарі render немає слайдера Slot."); return; }

    // ---------------- список скінів ----------------
    var skins = {}, logo = compNamed("pragmatic_Logo");
    var scan = logo ? [logo] : allComps();
    for (var c = 0; c < scan.length; c++) {
        var cc = scan[c];
        for (var i = 1; i <= cc.numLayers; i++) {
            var L = cc.layer(i), s = slotOf(L);
            if (s && !skins[s]) skins[s] = (L.name && L.name !== (L.source ? L.source.name : "")) ? L.name : (L.source ? L.source.name : "Skin " + s);
        }
    }
    var slotList = [];
    for (var k in skins) if (skins.hasOwnProperty(k)) slotList.push(parseInt(k, 10));
    slotList.sort(function (a, b) { return a - b; });
    if (!slotList.length) { alert("Не знайдено жодного скіна."); return; }

    var curSlot = Math.round(slotFx.property(1).value);
    var curR = reelsFx ? Math.round(reelsFx.property(1).value) : 0;
    var curW = rowsFx ? Math.round(rowsFx.property(1).value) : 0;

    // ---------------- діалог ----------------
    var dlg = new Window("dialog", "Експорт варіації");
    dlg.alignChildren = "fill";
    dlg.add("statictext", undefined, "Скіни (Ctrl/Shift-клік — кілька):");
    var lbSkin = dlg.add("listbox", undefined, [], { multiselect: true });
    lbSkin.preferredSize = [320, 260];
    for (var i = 0; i < slotList.length; i++) {
        var it = lbSkin.add("item", slotList[i] + " — " + skins[slotList[i]]);
        if (slotList[i] === curSlot) it.selected = true;
    }
    var ddReels = null, ddRows = null;
    if (reelsFx && rowsFx) {
        var g2 = dlg.add("group");
        g2.add("statictext", undefined, "Барабани:");
        ddReels = g2.add("dropdownlist", undefined, ["3", "4", "5", "6", "7"]);
        ddReels.selection = Math.min(4, Math.max(0, curR - 3));
        g2.add("statictext", undefined, "Ряди:");
        ddRows = g2.add("dropdownlist", undefined, ["3", "4", "5", "6", "7"]);
        ddRows.selection = Math.min(4, Math.max(0, curW - 3));
    }
    var cbAllGrids = dlg.add("checkbox", undefined, "Лишити всі сітки (перемикаються Reels / Rows)");
    cbAllGrids.value = false;
    var cbCols = dlg.add("checkbox", undefined, "Видалити приховані колонки й глови (тільки при одній сітці)");
    cbCols.value = true;
    var btns = dlg.add("group"); btns.alignment = "right";
    btns.add("button", undefined, "Скасувати", { name: "cancel" });
    btns.add("button", undefined, "Зберегти як…", { name: "ok" });
    if (dlg.show() !== 1) return;

    var SEL = [];
    if (lbSkin.selection) for (var i = 0; i < lbSkin.selection.length; i++) SEL.push(slotList[lbSkin.selection[i].index]);
    SEL.sort(function (a, b) { return a - b; });
    if (!SEL.length) { alert("Не вибрано жодного скіна."); return; }
    var NEWNUM = {};                          // старий номер → новий (1…N)
    for (var i = 0; i < SEL.length; i++) NEWNUM[SEL[i]] = i + 1;
    var SINGLE = SEL.length === 1;
    var REELS = ddReels ? parseInt(ddReels.selection.text, 10) : 0;
    var ROWS = ddRows ? parseInt(ddRows.selection.text, 10) : 0;
    var ALLGRIDS = !REELS || cbAllGrids.value;
    var GRID = ALLGRIDS ? "" : (REELS + "x" + ROWS);
    var skinTag = SINGLE ? safeName(skins[SEL[0]]) : (SEL.length + "skins");

    var origFile = proj.file;
    var defName = origFile.name.replace(/\.aep$/i, "") + "__" + skinTag + (GRID ? "_" + GRID : "") + ".aep";
    var out = new File(origFile.parent.fsName + "/" + defName).saveDlg("Зберегти варіацію як", "After Effects:*.aep");
    if (!out) return;
    if (!/\.aep$/i.test(out.name)) out = new File(out.fsName + ".aep");
    if (out.fsName === origFile.fsName) { alert("Обери інший файл — оригінал перезаписувати не можна."); return; }

    if (proj.dirty && confirm("У проєкті є незбережені зміни. Зберегти оригінал перед експортом?")) proj.save();
    proj.save(out);                           // далі працюємо вже в копії

    var log = [];
    app.beginUndoGroup("Export variation");

    // ---------------- 1. контроли ----------------
    slotFx.property(1).setValue(1);
    if (REELS && !ALLGRIDS) { reelsFx.property(1).setValue(REELS); rowsFx.property(1).setValue(ROWS); }

    // ---------------- 2. скіни й сітки рамок ----------------
    // спершу збираємо рішення для всіх шарів (індекси ще не зсунуті), потім змінюємо
    var comps = allComps(), plan = [];
    for (var c = 0; c < comps.length; c++) {
        var cc = comps[c], del = [], keep = [];
        for (var i = 1; i <= cc.numLayers; i++) {
            var L = cc.layer(i), s = slotOf(L), g = gridOf(L);
            if (s) { if (NEWNUM[s]) keep.push({ layer: L, num: NEWNUM[s] }); else del.push(L); }
            else if (g && GRID) { if (g === GRID) keep.push({ layer: L, num: 0 }); else del.push(L); }
        }
        if (del.length || keep.length) plan.push({ keep: keep, del: del });
    }
    var nKeep = 0, nDel = 0;
    for (var p = 0; p < plan.length; p++) {
        for (var i = 0; i < plan[p].keep.length; i++) {
            var K = plan[p].keep[i];
            if (K.num === 0 || SINGLE) bakeVisible(K.layer);     // сітка або єдиний скін — завжди видно
            else opac(K.layer).expression =                      // кілька скінів — перемикач з новим номером
                'Math.round(comp("render").layer(1).effect("Slot")("Slider")) === ' + K.num + ' ? 100 : 0;';
            nKeep++;
        }
    }
    for (var p = 0; p < plan.length; p++) {
        var d = plan[p].del;
        d.sort(function (a, b) { return b.index - a.index; });
        for (var i = 0; i < d.length; i++) { d[i].remove(); nDel++; }
    }
    log.push("Шари скінів/сіток: лишено " + nKeep + ", видалено " + nDel);
    var mapText = [];
    for (var i = 0; i < SEL.length; i++) mapText.push((i + 1) + " = " + skins[SEL[i]]);
    try { ctl.comment = "Slot: " + mapText.join(", "); } catch (e) {}

    // ---------------- 3. приховані колонки ----------------
    var slot = compNamed("Slot");
    if (cbCols.value && !ALLGRIDS && slot) {
        // якщо затримка ще рахується від індексу шару (оригінальний вираз) — переводимо на номер колонки
        var nul = null; try { nul = slot.layer("Null 2"); } catch (e) {}
        var colLayers = [], glows = [];
        for (var i = 1; i <= slot.numLayers; i++) {
            var L = slot.layer(i);
            if (L.source && /^Column_\d+$/.test(L.source.name)) colLayers.push(L);
            else if (L.source && L.source.name === "Symbol_glow") glows.push(L);
        }
        if (nul) {
            for (var i = 0; i < colLayers.length; i++) {
                var fx = colLayers[i].property("ADBE Effect Parade");
                for (var j = 1; j <= fx.numProperties; j++) {
                    if (fx.property(j).matchName !== "ADBE Offset") continue;
                    var sp = fx.property(j).property("ADBE Offset-0001");
                    if (sp.expression.indexOf("minIndex") === -1) continue;
                    sp.expression =
                        'var n = thisComp.layer("' + nul.name + '");\n' +
                        'var ctrl = n.effect("Offset")("Shift Center To");\n' +
                        'var delaySec = n.effect("Delay")("Slider");\n' +
                        'var col = parseInt(thisLayer.source.name.replace(/[^0-9]/g, ""), 10);\n' +
                        'var delay = (col - 2) * delaySec;\n' +
                        'var t0 = (ctrl.numKeys > 0) ? ctrl.key(1).time : n.inPoint;\n' +
                        'value + (ctrl.valueAtTime(time - delay) - ctrl.valueAtTime(t0));';
                }
            }
        }
        var rm = [];
        for (var i = 0; i < colLayers.length; i++)
            if (parseInt(colLayers[i].source.name.replace(/[^0-9]/g, ""), 10) > REELS) rm.push(colLayers[i]);
        for (var i = 0; i < glows.length; i++) {
            var num = parseInt(glows[i].name.replace(/[^0-9]/g, ""), 10);
            if (num > REELS) rm.push(glows[i]);
        }
        rm.sort(function (a, b) { return b.index - a.index; });
        for (var i = 0; i < rm.length; i++) rm[i].remove();
        log.push("Приховані колонки/глови видалено: " + rm.length);
    }

    // ---------------- 4. Reduce Project з урахуванням виразів ----------------
    function scanGroup(g, found) {
        for (var i = 1; i <= g.numProperties; i++) {
            var p = g.property(i);
            if (p.propertyType === PropertyType.PROPERTY) {
                if (p.canSetExpression && p.expression) {
                    var ex = p.expression, m;
                    RX_COMP.lastIndex = 0;
                    while ((m = RX_COMP.exec(ex)) !== null) found[m[1]] = true;
                }
            } else scanGroup(p, found);
        }
    }
    var keepItems = [render], seen = {}, queue = [render];
    seen[render.id] = true;
    while (queue.length) {
        var cc = queue.shift(), found = {};
        for (var i = 1; i <= cc.numLayers; i++) {
            var L = cc.layer(i);
            if (L.source instanceof CompItem && !seen[L.source.id]) { seen[L.source.id] = true; queue.push(L.source); }
            try { scanGroup(L, found); } catch (e) {}
        }
        for (var nm in found) {
            if (!found.hasOwnProperty(nm)) continue;
            var ref = compNamed(nm);
            if (ref && !seen[ref.id]) { seen[ref.id] = true; queue.push(ref); keepItems.push(ref); }
        }
    }
    var before = proj.numItems;
    proj.reduceProject(keepItems);
    log.push("Reduce Project: " + before + " → " + proj.numItems + " елементів");

    app.endUndoGroup();
    proj.save();

    alert("Готово. Збережено й відкрито:\n" + proj.file.fsName + "\n\n" +
          (SINGLE ? "" : "Нумерація слайдера Slot у копії:\n" + mapText.join("\n") + "\n\n") + log.join("\n") +
          "\n\nОригінал не змінено. Для переносної папки: File > Dependencies > Collect Files.");
})();
