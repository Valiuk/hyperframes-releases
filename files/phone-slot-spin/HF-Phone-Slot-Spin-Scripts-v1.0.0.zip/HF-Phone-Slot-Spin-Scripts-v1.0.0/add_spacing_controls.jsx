/*
  add_spacing_controls.jsx — відступи між барабанами (по ширині) і рядами (по висоті) + рамка під них.
  Потрібна встановлена система сіток (setup_grid_system.jsx: контроли Reels / Rows на render).

  На шар render додаються слайдери:
    Gap X — додатковий відступ між колонками, px у координатах Game
    Gap Y — додатковий відступ між рядами, px у координатах Game
  Розмір символів не змінюється — росте тільки крок сітки.

  Як це працює по вертикалі: ряди задані всередині стрічки Column_N (крок 266, період 2394),
  тож змінити крок напряму не можна без поломки безшовного wrap. Тому шар колонки
  розтягується по Y у f разів, а кожен символ усередині стискається на 1/f — символи лишаються
  без спотворень, відстань між ними росте, wrap і вирівнювання зупинок не ламаються.

  Рамка (Frame_grid у Game) масштабується навколо центру сітки: по X на (p+GapX)/p, по Y на (p+GapY)/p.
  Повторний запуск безпечний. Усе — один крок Undo.
*/
(function () {
    var GRID = { cx: 432, cy: 740, w: 760, h: 600, pmax: 190 };   // як у setup_grid_system.jsx

    var proj = app.project;
    if (!proj) { alert("Відкрий проєкт."); return; }
    function compNamed(n) {
        for (var i = 1; i <= proj.numItems; i++) {
            var it = proj.item(i);
            if (it instanceof CompItem && it.name === n && it.numLayers > 0) return it;
        }
        return null;
    }
    function compAny(n) {
        for (var i = 1; i <= proj.numItems; i++) if (proj.item(i) instanceof CompItem && proj.item(i).name === n) return proj.item(i);
        return null;
    }
    function tr(l) { return l.property("ADBE Transform Group"); }
    function effectByName(l, n) {
        var fx = l.property("ADBE Effect Parade");
        for (var i = 1; i <= fx.numProperties; i++) if (fx.property(i).name === n) return fx.property(i);
        return null;
    }
    function layerBySource(c, src) { for (var i = 1; i <= c.numLayers; i++) if (c.layer(i).source === src) return c.layer(i); return null; }

    var render = compNamed("render"), slot = compNamed("Slot"), game = compNamed("Game");
    if (!render || !slot || !game) { alert("Не знайдено render / Slot / Game."); return; }
    var ctlLayer = render.layer(1);
    if (!effectByName(ctlLayer, "Reels") || !effectByName(ctlLayer, "Rows")) {
        alert("Спершу встанови систему сіток (setup_grid_system.jsx) — потрібні контроли Reels і Rows."); return;
    }
    var slotInGame = layerBySource(game, slot);
    if (!slotInGame) { alert("Шар Slot у Game не знайдено."); return; }

    app.beginUndoGroup("Reel spacing (Gap X / Gap Y)");
    var log = [];

    // ---------- 1. Контроли ----------
    function addSlider(name, val) {
        if (effectByName(ctlLayer, name)) return;
        var e = ctlLayer.property("ADBE Effect Parade").addProperty("ADBE Slider Control");
        e.name = name; e.property(1).setValue(val);
        log.push("Контрол " + name);
    }
    addSlider("Gap X", 0);
    addSlider("Gap Y", 0);

    // ---------- 2. Константи зі сцени ----------
    var colLayers = [], cols = [];
    for (var i = 1; i <= slot.numLayers; i++) {
        var L = slot.layer(i);
        if (L.source && /^Column_\d+$/.test(L.source.name)) { colLayers.push(L); cols.push(L.source); }
    }
    if (!colLayers.length) { alert("У Slot немає шарів Column_N."); app.endUndoGroup(); return; }

    var gs = tr(slotInGame).property("ADBE Scale").value[0] / 100;
    var gp = tr(slotInGame).property("ADBE Position").value;
    var ga = tr(slotInGame).property("ADBE Anchor Point").value;
    // Центр сітки в тому просторі, де живуть значення шару Slot: без батька — координати Game,
    // з «Slot rig» — точка опори нуля (нуль стоїть рівно в центрі сітки). Без цього після
    // add_slot_rig.jsx барабани з'їжджали за межі кадру.
    function gridIn(layer) {
        if (layer.parent) { var pa = tr(layer.parent).property("ADBE Anchor Point").value; return [pa[0], pa[1]]; }
        return [GRID.cx, GRID.cy];
    }
    var GP = gridIn(slotInGame);
    var SX = ga[0] + (GP[0] - gp[0]) / gs, SY = ga[1] + (GP[1] - gp[1]) / gs;

    var STEP = 266;
    try {
        var fx = cols[0].layer("Control").property("ADBE Effect Parade");
        STEP = fx.property(2).property(1).value + fx.property(3).property(1).value;
    } catch (e) {}
    var baseScale = tr(colLayers[0]).property("ADBE Scale").valueAtTime(0, true)[0];
    var basePs = STEP * baseScale / 100;
    var colY0 = tr(colLayers[0]).property("ADBE Position").valueAtTime(0, true)[1];

    var HEAD =
        'var ctl = comp("render").layer(1);\n' +
        'var C = Math.min(7, Math.max(3, Math.round(ctl.effect("Reels")("Slider"))));\n' +
        'var R = Math.min(7, Math.max(3, Math.round(ctl.effect("Rows")("Slider"))));\n' +
        'var p = Math.min(' + GRID.w + ' / C, ' + GRID.h + ' / R, ' + GRID.pmax + ');   // розмір клітинки, px Game\n' +
        'var gx = Math.max(-p * 0.5, ctl.effect("Gap X")("Slider"));\n' +
        'var gy = Math.max(-p * 0.5, ctl.effect("Gap Y")("Slider"));\n' +
        'var f = (p + gy) / p;                                 // розтяг стрічки по Y\n';
    var HEAD_SLOT = HEAD +
        'var GS = ' + gs + ';\n' +
        'var ps = p / GS, psx = (p + gx) / GS, psy = (p + gy) / GS;   // px Slot\n' +
        'var SX = ' + SX.toFixed(3) + ', SY = ' + SY.toFixed(3) + ';\n' +
        'var yOff = (R % 2 == 0) ? psy / 2 : 0;\n';
    var NUM_SRC = 'var n = parseInt(thisLayer.source.name.replace(/[^0-9]/g, ""), 10);\n';
    var NUM_NAME = 'var n = parseInt(thisLayer.name.replace(/[^0-9]/g, ""), 10);\n';

    // ---------- 3. Колонки ----------
    for (var c = 0; c < colLayers.length; c++) {
        var t = tr(colLayers[c]);
        t.property("ADBE Position").expression = HEAD_SLOT + NUM_SRC + '[SX + (n - (C + 1) / 2) * psx, SY + yOff];';
        t.property("ADBE Scale").expression = HEAD_SLOT +
            'var s = ps / ' + STEP + ' * 100;\n' +
            'var k = value[0] / ' + baseScale + ';   // «відскок» із ключів\n' +
            '[s * k, s * k * f];';
        t.property("ADBE Opacity").expression = HEAD_SLOT + NUM_SRC + '(n <= C) ? value : 0;';
    }
    log.push("Колонки: " + colLayers.length);

    // ---------- 4. Символи всередині стрічок (компенсація розтягу) ----------
    var symCount = 0;
    for (var c = 0; c < cols.length; c++) {
        var cc = cols[c];
        for (var j = 1; j <= cc.numLayers; j++) {
            var s = cc.layer(j);
            if (s.name === "Control" || !s.source) continue;
            tr(s).property("ADBE Scale").expression = HEAD +
                '// стрічку розтягнуто по Y у f разів — символ стискаємо назад, щоб не спотворювався\n' +
                '[value[0], value[1] / f];';
            symCount++;
        }
    }
    log.push("Символи зі стисненням по Y: " + symCount);

    // ---------- 5. Glow ----------
    var glowSrc = compAny("Symbol_glow"), gcount = 0;
    if (glowSrc) {
        for (var i = 1; i <= slot.numLayers; i++) {
            var g = slot.layer(i);
            if (g.source !== glowSrc) continue;
            var t = tr(g);
            var gyOff = t.property("ADBE Position").valueAtTime(0, true)[1] - colY0;
            var nameNum = /\d+$/.test(g.name);
            var NUM = nameNum ? NUM_NAME : 'var n = ' + (gcount + 1) + ';\n';
            t.property("ADBE Position").expression = HEAD_SLOT + NUM +
                '[SX + (n - (C + 1) / 2) * psx, SY + yOff + ' + gyOff.toFixed(2) + ' * ps / ' + basePs.toFixed(3) + ' * f];';
            t.property("ADBE Scale").expression = HEAD_SLOT +
                'var k = ps / ' + basePs.toFixed(3) + ';\n[value[0] * k, value[1] * k * f];';
            t.property("ADBE Opacity").expression = HEAD_SLOT + NUM + '(n <= C) ? value : 0;';
            gcount++;
        }
    }
    log.push("Glow: " + gcount);

    // ---------- 6. Маска рядів ----------
    var masks = slotInGame.property("ADBE Mask Parade"), gm = null;
    for (var i = 1; i <= masks.numProperties; i++) if (masks.property(i).name === "Grid rows") gm = masks.property(i);
    if (gm) {
        gm.property("ADBE Mask Shape").expression = HEAD_SLOT +
            'var on = ctl.effect("Crop rows")("Checkbox") == 1;\n' +
            'var hw = 5000, hh = on ? R * psy / 2 : 5000;\n' +
            'createPath([[SX - hw, SY - hh], [SX + hw, SY - hh], [SX + hw, SY + hh], [SX - hw, SY + hh]], [], [], true);';
        log.push("Маска рядів оновлена");
    }

    // ---------- 7. Рамка ----------
    var fsrc = compAny("Frame_grid") || compAny("Frame");
    var fcount = 0;
    for (var i = 1; i <= game.numLayers; i++) {
        var fl = game.layer(i);
        if (fl.source !== fsrc) continue;
        var t = tr(fl);
        // базові значення без виразів — щоб повторний запуск не накопичував зміни
        var A = t.property("ADBE Anchor Point").valueAtTime(0, true);
        var P = t.property("ADBE Position").valueAtTime(0, true);
        var S = t.property("ADBE Scale").valueAtTime(0, true);
        // центр сітки в координатах рамки — точка, навколо якої зібрані всі PNG рамок
        var FX, FY, ok = false, off = (fsrc.width - 1331) / 2;   // полотно рамок могло бути розширене (extend_grids_7x7)
        var EX = 665.5 + off, EY = 714.914 + off;
        var am = t.property("ADBE Anchor Point").expression.match(new RegExp("\\[\\s*([-0-9.]+)\\s*,\\s*([-0-9.]+)\\s*\\]"));
        if (am) { FX = parseFloat(am[1]); FY = parseFloat(am[2]); ok = Math.abs(FX - EX) < 40 && Math.abs(FY - EY) < 60; }
        if (!ok && !fl.parent) {
            FX = A[0] + (GRID.cx - P[0]) / (S[0] / 100);
            FY = A[1] + (GRID.cy - P[1]) / (S[1] / 100);
            ok = Math.abs(FX - EX) < 40 && Math.abs(FY - EY) < 60;
        }
        if (!ok) { FX = EX; FY = EY; }
        t.property("ADBE Anchor Point").expression = '// центр сітки в координатах рамки\n[' + FX.toFixed(3) + ', ' + FY.toFixed(3) + '];';
        t.property("ADBE Position").expression = fl.parent
            ? '// рамка стоїть у точці нуля «Slot rig» (центр сітки); без батька — як було\nhasParent ? parent.transform.anchorPoint : [' + GRID.cx + ', ' + GRID.cy + '];'
            : '[' + GRID.cx + ', ' + GRID.cy + '];';
        t.property("ADBE Scale").expression = HEAD +
            '[' + S[0].toFixed(3) + ' * (p + gx) / p, ' + S[1].toFixed(3) + ' * (p + gy) / p];';
        fcount++;
    }
    log.push("Рамка (" + (fsrc ? fsrc.name : "—") + "): " + fcount + " шар(и) масштабуються з відступами");

    app.endUndoGroup();
    alert("Готово.\n\n" + log.join("\n") +
          "\n\nGap X / Gap Y на шарі render — відступи в px Game (можна й від'ємні, до −½ клітинки).");
})();
