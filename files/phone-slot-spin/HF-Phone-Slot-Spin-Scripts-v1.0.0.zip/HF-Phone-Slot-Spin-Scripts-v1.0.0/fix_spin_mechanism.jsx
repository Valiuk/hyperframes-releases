/*
  fix_spin_mechanism.jsx — виправлення механіки прокрутки в phone_slot_spin.

  1. Дрейф: ключі Null 2 (Offset > Shift Center To) вирівнюються так, щоб кожна зупинка
     була рівно на N × крок символа (266 px) від стартового значення. Пікові (overshoot) ключі
     зсуваються разом зі своєю зупинкою, easing і таймінг ключів не змінюються.
  2. Symbol_WIN: показує діагностику (позиція, collapse на колонках) і за згодою ставить WIN
     у той ряд, який зупиняється в центрі барабана на фінальному спіні; символ під ним ховається.
  3. Вирази колонок більше не падають без ключів (ctrl.key(1) лише якщо ключі є),
     затримка рахується від номера колонки, а не від індексу шару.
  4. Параметричний режим: на Null 2 додаються слайдери і чекбокс "Param spins".
     Вимкнений — працюють ключі (як зараз). Увімкнений — рух рахується виразом, дрейфу немає в принципі.

  Повторний запуск безпечний. Усе — один крок Undo.
*/
(function () {
    var proj = app.project;
    if (!proj) { alert("Відкрий проєкт."); return; }

    function compNamed(n) {
        for (var i = 1; i <= proj.numItems; i++) {
            var it = proj.item(i);
            if (it instanceof CompItem && it.name === n && it.numLayers > 0) return it;
        }
        return null;
    }
    function tr(l) { return l.property("ADBE Transform Group"); }
    function effectByName(l, n) {
        var fx = l.property("ADBE Effect Parade");
        for (var i = 1; i <= fx.numProperties; i++) if (fx.property(i).name === n) return fx.property(i);
        return null;
    }
    function effectByMatch(l, m) {
        var fx = l.property("ADBE Effect Parade");
        for (var i = 1; i <= fx.numProperties; i++) if (fx.property(i).matchName === m) return fx.property(i);
        return null;
    }

    var slot = compNamed("Slot");
    if (!slot) { alert("Комп Slot не знайдено."); return; }

    // ---- Null 2 ----
    var nul = null;
    try { nul = slot.layer("Null 2"); } catch (e) {}
    if (!nul) {
        for (var i = 1; i <= slot.numLayers; i++) {
            var L = slot.layer(i);
            if (effectByMatch(L, "ADBE Offset") && effectByName(L, "Delay")) { nul = L; break; }
        }
    }
    if (!nul) { alert("Не знайдено Null 2 з ефектом Offset і слайдером Delay."); return; }
    var nulOffset = effectByMatch(nul, "ADBE Offset");
    var shift = nulOffset.property("ADBE Offset-0001");

    // ---- колонки ----
    var colLayers = [];
    for (var i = 1; i <= slot.numLayers; i++) {
        var L = slot.layer(i);
        if (L.source && /^Column_\d+$/.test(L.source.name) && effectByMatch(L, "ADBE Offset")) colLayers.push(L);
    }
    if (!colLayers.length) { alert("У Slot не знайдено шарів Column_N з ефектом Offset."); return; }

    // крок символа і стартова позиція зі шару Control у Column_1
    var col1 = colLayers[0].source, STEP = 266, START = -138;
    try {
        var c = col1.layer("Control");
        START = effectByName(c, "Start Position").property(1).value;
        STEP = effectByName(c, "Base Offset").property(1).value + effectByName(c, "Offset Adjustment").property(1).value;
    } catch (e) {}
    var PERIOD = col1.height;

    app.beginUndoGroup("Fix spin mechanism");
    var log = [];

    // =========================================================
    // 1. Вирівнювання ключів (дрейф)
    // =========================================================
    var n = shift.numKeys;
    if (n >= 2) {
        var ys = [], xs = [];
        for (var k = 1; k <= n; k++) { var v = shift.keyValue(k); xs.push(v[0]); ys.push(v[1]); }
        var base = ys[0], TOL = 6;
        // зупинки = ключі, що стоять парами з однаковим значенням (settle + hold), + перший і останній
        var rest = [];
        for (var k = 0; k < n; k++) {
            var r = (k === 0 || k === n - 1);
            if (k > 0 && Math.abs(ys[k] - ys[k - 1]) < TOL) r = true;
            if (k < n - 1 && Math.abs(ys[k] - ys[k + 1]) < TOL) r = true;
            rest.push(r);
        }
        // групи сусідніх зупинок → одне вирівняне значення на групу
        var target = [], k = 0, fixes = [];
        while (k < n) {
            if (!rest[k]) { target.push(null); k++; continue; }
            var j = k, sum = 0;
            while (j < n && rest[j] && (j === k || Math.abs(ys[j] - ys[j - 1]) < TOL)) { sum += ys[j]; j++; }
            var mean = sum / (j - k);
            var snapped = (k === 0) ? base : base + Math.round((mean - base) / STEP) * STEP;
            for (var q = k; q < j; q++) target.push(snapped);
            if (k > 0) fixes.push((snapped - mean).toFixed(1));
            k = j;
        }
        // пікові ключі зсуваються разом із наступною зупинкою
        for (var k = n - 1; k >= 0; k--) {
            if (target[k] !== null) continue;
            var d = 0;
            for (var j = k + 1; j < n; j++) if (target[j] !== null) { d = target[j] - ys[j]; break; }
            target[k] = ys[k] + d;
        }
        var changed = 0;
        for (var k = 0; k < n; k++) {
            if (Math.abs(target[k] - ys[k]) > 0.01) { shift.setValueAtKey(k + 1, [xs[k], target[k]]); changed++; }
        }
        log.push("1. Ключі Null: змінено " + changed + " з " + n + ". Корекції зупинок, px: " + fixes.join(", "));
    } else {
        log.push("1. На Null 2 немає ключів — вирівнювати нічого.");
    }

    // =========================================================
    // 3. Надійні вирази на колонках
    // =========================================================
    var COL_EXPR =
        '// Колонка повторює рух Null 2 із затримкою за номером колонки\n' +
        'var n = thisComp.layer("' + nul.name + '");\n' +
        'var ctrl = n.effect("' + nulOffset.name + '")("Shift Center To");\n' +
        'var delaySec = n.effect("Delay")("Slider");\n' +
        'var col = parseInt(thisLayer.source.name.replace(/[^0-9]/g, ""), 10);\n' +
        'var delay = (col - 2) * delaySec;          // як в оригіналі: Column_1 стартує на один крок раніше\n' +
        'var t0 = (ctrl.numKeys > 0) ? ctrl.key(1).time : n.inPoint;\n' +
        'value + (ctrl.valueAtTime(time - delay) - ctrl.valueAtTime(t0));';
    for (var i = 0; i < colLayers.length; i++)
        effectByMatch(colLayers[i], "ADBE Offset").property("ADBE Offset-0001").expression = COL_EXPR;
    log.push("3. Вирази Offset оновлено на " + colLayers.length + " колонках (без залежності від key(1) та індексу шару)");

    // =========================================================
    // 4. Параметричний режим
    // =========================================================
    function addSlider(name, val) {
        var e = effectByName(nul, name);
        if (e) return e;
        e = nul.property("ADBE Effect Parade").addProperty("ADBE Slider Control");
        e.name = name; e.property(1).setValue(val); return e;
    }
    var t0 = shift.numKeys ? shift.keyTime(1) : 3;
    var base0 = shift.numKeys ? shift.keyValue(1) : shift.value;
    if (!effectByName(nul, "Param spins")) {
        var cb = nul.property("ADBE Effect Parade").addProperty("ADBE Checkbox Control");
        cb.name = "Param spins"; cb.property(1).setValue(0);
    }
    // значення за замовчуванням повторюють поточну анімацію
    addSlider("First spin (s)", t0);
    addSlider("Interval (s)", 5);
    addSlider("Spins", 9);
    addSlider("Final start (s)", t0 + 39);
    addSlider("Symbols first", 15);
    addSlider("Symbols per spin", 8);
    addSlider("Symbols final", 28);
    addSlider("Spin dur (s)", 1);
    addSlider("Final dur (s)", 2);
    addSlider("Peak at (0-1)", 0.62);
    addSlider("Final peak at (0-1)", 0.8);
    addSlider("Overshoot (px)", Math.round(STEP / 2));

    shift.expression =
        'if (effect("Param spins")("Checkbox") == 0) { value; } else {\n' +
        '  var P = function (n) { return effect(n)("Slider").value; };\n' +
        '  var STEP = ' + STEP + ';\n' +
        '  var y = ' + base0[1].toFixed(3) + ';\n' +
        '  var t0 = P("First spin (s)"), iv = P("Interval (s)"), N = Math.max(1, Math.round(P("Spins")));\n' +
        '  var tF = P("Final start (s)"); if (tF <= 0) tF = t0 + (N - 1) * iv;\n' +
        '  var s1 = Math.round(P("Symbols first")), sN = Math.round(P("Symbols per spin")), sF = Math.round(P("Symbols final"));\n' +
        '  var d = P("Spin dur (s)"), dF = P("Final dur (s)"), pk = P("Peak at (0-1)"), pkF = P("Final peak at (0-1)"), ov = P("Overshoot (px)");\n' +
        '  for (var k = 0; k < N; k++) {\n' +
        '    var last = (k == N - 1);\n' +
        '    var ts = last ? tF : t0 + k * iv;\n' +
        '    var dur = last ? dF : d, pf = last ? pkF : pk;\n' +
        '    var D = (last ? sF : (k == 0 ? s1 : sN)) * STEP;   // завжди ціле число символів → без дрейфу\n' +
        '    if (time < ts) break;\n' +
        '    if (time < ts + dur) {\n' +
        '      var tp = ts + dur * pf;\n' +
        '      y = (time < tp) ? ease(time, ts, tp, y, y + D + ov) : ease(time, tp, ts + dur, y + D + ov, y + D);\n' +
        '      D = 0; k = N;\n' +
        '    }\n' +
        '    y += D;\n' +
        '  }\n' +
        '  [value[0], y];\n' +
        '}';
    log.push("4. Параметричний режим додано на " + nul.name + " (чекбокс Param spins, зараз вимкнений)");

    // =========================================================
    // 2. Symbol_WIN
    // =========================================================
    var diag = [], anyCollapse = false, winInfo = "";
    for (var i = 0; i < colLayers.length; i++) {
        if (colLayers[i].collapseTransformation) anyCollapse = true;
        diag.push(colLayers[i].source.name + ": collapse " + (colLayers[i].collapseTransformation ? "ON" : "off"));
    }
    var winLayer = null;
    try { winLayer = col1.layer("Symbol_WIN"); } catch (e) {}
    if (winLayer) {
        var wy = tr(winLayer).property("ADBE Position").value[1];
        winInfo = "Symbol_WIN у " + col1.name + ": y = " + wy.toFixed(0) + ", з'являється на кадрі " +
                  Math.round(winLayer.inPoint / col1.frameDuration) + (wy < 0 || wy > PERIOD ? " — ПОЗА межами компа 0…" + PERIOD : "");
    }
    var msgWin = "Symbol_WIN — діагностика:\n" + winInfo + "\n" + diag.join("\n") +
        (anyCollapse ? "\n\nНа частині колонок увімкнено collapse — WIN може бути видно поза межами стрічки."
                     : "\n\nCollapse вимкнено — WIN на y<0 обрізається і в кадрі не з'являється.") +
        "\n\nПоставити WIN у ряд, який зупиняється в центрі барабана на фінальному спіні (у кожній колонці),\nі ховати символ під ним?";
    if (winLayer && confirm(msgWin)) {
        var fixedCols = 0;
        for (var i = 0; i < colLayers.length; i++) {
            var cc = colLayers[i].source, w = null;
            try { w = cc.layer("Symbol_WIN"); } catch (e) {}
            if (!w) continue;
            tr(w).property("ADBE Position").expression =
                '// WIN у ряду, що зупиняється в центрі шару колонки на фінальному спіні\n' +
                'var ctl = thisComp.layer("Control");\n' +
                'var START = ctl.effect("Start Position")("Slider");\n' +
                'var STEP = ctl.effect("Base Offset")("Slider") + ctl.effect("Offset Adjustment")("Slider");\n' +
                'var H = thisComp.height;\n' +
                'var S = comp("' + slot.name + '"), L = S.layer(thisComp.name);\n' +
                'var sh = L.effect("' + effectByMatch(colLayers[i], "ADBE Offset").name + '")("Shift Center To").valueAtTime(S.duration - S.frameDuration);\n' +
                'var yc = ((H - sh[1]) % H + H) % H;        // піксель стрічки, що опиниться в центрі (Offset з wrap)\n' +
                'var rows = Math.round(H / STEP);\n' +
                'var m = Math.round((yc - START) / STEP); m = ((m - 1) % rows + rows) % rows + 1;\n' +
                '[transform.position[0], START + m * STEP];';
            for (var j = 1; j <= cc.numLayers; j++) {
                var s = cc.layer(j);
                if (s === w || s.name === "Control" || !s.source) continue;
                tr(s).property("ADBE Opacity").expression =
                    'var w = thisComp.layer("Symbol_WIN");\n' +
                    '(time >= w.inPoint && Math.abs(transform.position[1] - w.transform.position[1]) < 1) ? 0 : value;';
            }
            fixedCols++;
        }
        log.push("2. WIN прив'язано до центрального ряду фінальної зупинки в " + fixedCols + " колонках");
    } else {
        log.push("2. WIN не змінено" + (winInfo ? " (" + winInfo + ")" : ""));
    }

    app.endUndoGroup();
    alert("Готово.\n\n" + log.join("\n\n") +
          "\n\nПараметричний режим: увімкни Param spins на " + nul.name + ". Якщо міняєш Final start / Final dur,\n" +
          "зсунь також ключі Time Remap колонок (підміна на WIN) і старти Symbol_glow.");
})();
