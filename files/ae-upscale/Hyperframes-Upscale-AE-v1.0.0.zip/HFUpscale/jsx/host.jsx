/* Hyperframes Upscale — host side (ExtendScript, ES3) */

// ---------- tiny JSON (ASCII-safe: all non-ASCII escaped as \uXXXX) ----------
function hfuStr(v) {
    if (v === null || v === undefined) return 'null';
    var t = typeof v, i, out;
    if (t === 'number') return isFinite(v) ? String(v) : 'null';
    if (t === 'boolean') return v ? 'true' : 'false';
    if (t === 'string') {
        out = '"';
        for (i = 0; i < v.length; i++) {
            var c = v.charCodeAt(i), ch = v.charAt(i);
            if (ch === '"') out += '\\"';
            else if (ch === '\\') out += '\\\\';
            else if (c < 32 || c > 126) {
                var h = c.toString(16);
                while (h.length < 4) h = '0' + h;
                out += '\\u' + h;
            } else out += ch;
        }
        return out + '"';
    }
    if (v instanceof Array) {
        var a = [];
        for (i = 0; i < v.length; i++) a.push(hfuStr(v[i]));
        return '[' + a.join(',') + ']';
    }
    var parts = [];
    for (var k in v) if (v.hasOwnProperty(k)) parts.push(hfuStr(k) + ':' + hfuStr(v[k]));
    return '{' + parts.join(',') + '}';
}

function hfuParse(enc) {
    return eval('(' + decodeURIComponent(enc) + ')');
}

var HFU_IMAGE_EXT = /\.(png|jpe?g|webp|tiff?|bmp|psd|exr|tga|gif)$/i;

function hfuAllComps() {
    var res = [];
    for (var i = 1; i <= app.project.numItems; i++) {
        var it = app.project.item(i);
        if (it instanceof CompItem) res.push(it);
    }
    return res;
}

function hfuLayersUsing(item) {
    var res = [], comps = hfuAllComps();
    for (var c = 0; c < comps.length; c++) {
        var comp = comps[c];
        for (var l = 1; l <= comp.numLayers; l++) {
            var lyr = comp.layer(l);
            try { if (lyr.source && lyr.source.id === item.id) res.push(lyr); } catch (e) {}
        }
    }
    return res;
}

function hfuMaxScale(layers) {
    var m = 0;
    for (var i = 0; i < layers.length; i++) {
        var p = layers[i].property('ADBE Transform Group').property('ADBE Scale');
        var vals = [];
        if (p.numKeys > 0) { for (var k = 1; k <= p.numKeys; k++) vals.push(p.keyValue(k)); }
        else vals.push(p.value);
        for (var j = 0; j < vals.length; j++) {
            m = Math.max(m, Math.abs(vals[j][0]), Math.abs(vals[j][1]));
        }
    }
    return m || 100;
}

function hfuDescribe(it) {
    var f = it.file, name = f ? f.name : it.name;
    var isStill = it.mainSource.isStill;
    var kind = isStill ? 'image' : (HFU_IMAGE_EXT.test(decodeURI(name)) ? 'sequence' : 'video');
    var layers = hfuLayersUsing(it);
    var ms = it.mainSource;
    return {
        id: it.id,
        name: it.name,
        path: f.fsName,
        width: it.width,
        height: it.height,
        kind: kind,
        fps: isStill ? 0 : it.frameRate,
        nativeFps: isStill ? 0 : (ms.nativeFrameRate || it.frameRate),
        duration: isStill ? 0 : it.duration,
        hasAudio: !!it.hasAudio,
        usedIn: layers.length,
        maxScale: hfuMaxScale(layers)
    };
}

function hfu_getSelection() {
    try {
        if (!app.project) return hfuStr({ ok: false, error: 'Немає відкритого проєкту' });
        var items = [], seen = {}, i;
        var add = function (it) {
            if (!it || !(it instanceof FootageItem)) return;
            if (!(it.mainSource instanceof FileSource) || !it.file) return;
            if (seen[it.id]) return;
            seen[it.id] = true;
            items.push(hfuDescribe(it));
        };
        var comp = app.project.activeItem;
        if (comp && comp instanceof CompItem && comp.selectedLayers.length) {
            for (i = 0; i < comp.selectedLayers.length; i++) add(comp.selectedLayers[i].source);
        }
        if (!items.length) {
            var sel = app.project.selection;
            for (i = 0; i < sel.length; i++) add(sel[i]);
        }
        return hfuStr({ ok: true, items: items });
    } catch (e) {
        return hfuStr({ ok: false, error: e.toString() + ' (line ' + e.line + ')' });
    }
}

// ---------- visual-size compensation ----------
function hfuMapProp(p, fn) {
    if (!p) return;
    try {
        if (p.numKeys > 0) {
            for (var k = 1; k <= p.numKeys; k++) p.setValueAtKey(k, fn(p.keyValue(k)));
        } else {
            p.setValue(fn(p.value));
        }
    } catch (e) {}
}

function hfuMulPts(pts, r) {
    var o = [];
    for (var i = 0; i < pts.length; i++) o.push([pts[i][0] * r, pts[i][1] * r]);
    return o;
}

function hfuCompensateLayer(lyr, r) {
    var tr = lyr.property('ADBE Transform Group');
    hfuMapProp(tr.property('ADBE Anchor Point'), function (v) {
        var o = []; for (var i = 0; i < v.length; i++) o.push(v[i]);
        o[0] *= r; o[1] *= r; return o;
    });
    hfuMapProp(tr.property('ADBE Scale'), function (v) {
        var o = []; for (var i = 0; i < v.length; i++) o.push(v[i]);
        o[0] /= r; o[1] /= r; return o;
    });
    var masks = lyr.property('ADBE Mask Parade');
    if (masks) {
        for (var m = 1; m <= masks.numProperties; m++) {
            var mk = masks.property(m);
            hfuMapProp(mk.property('ADBE Mask Shape'), function (s) {
                var n = new Shape();
                n.vertices = hfuMulPts(s.vertices, r);
                n.inTangents = hfuMulPts(s.inTangents, r);
                n.outTangents = hfuMulPts(s.outTangents, r);
                n.closed = s.closed;
                return n;
            });
            hfuMapProp(mk.property('ADBE Mask Feather'), function (v) { return [v[0] * r, v[1] * r]; });
            hfuMapProp(mk.property('ADBE Mask Offset'), function (v) { return v * r; });
        }
    }
}

function hfuUpscaledFolder() {
    for (var i = 1; i <= app.project.numItems; i++) {
        var it = app.project.item(i);
        if (it instanceof FolderItem && it.name === 'Upscaled' && it.parentFolder === app.project.rootFolder) return it;
    }
    return app.project.items.addFolder('Upscaled');
}

// payload: { id, path, mode: 'replace'|'swap'|'import', keepVisual, conformFps }
function hfu_apply(enc) {
    var p;
    try { p = hfuParse(enc); } catch (e) { return hfuStr({ ok: false, error: 'Bad payload: ' + e }); }
    app.beginUndoGroup('Hyperframes Upscale');
    try {
        var it = app.project.itemByID(p.id);
        if (!it) throw new Error('Футаж не знайдено в проєкті (id ' + p.id + ')');
        var f = new File(p.path);
        if (!f.exists) throw new Error('Файл результату не існує: ' + p.path);
        var oldW = it.width, touched = 0, r, layers, i;

        if (p.mode === 'replace') {
            var oldConform = it.mainSource.conformFrameRate;
            layers = hfuLayersUsing(it);
            it.replace(f);
            if (p.conformFps > 0) it.mainSource.conformFrameRate = p.conformFps;
            else if (p.conformFps === -1) { try { it.mainSource.conformFrameRate = 0; } catch (e) {} }   // new frame rate (60 fps): use the file's own
            else if (oldConform > 0) it.mainSource.conformFrameRate = oldConform;
            r = it.width / oldW;
            if (p.keepVisual && Math.abs(r - 1) > 0.001) {
                for (i = 0; i < layers.length; i++) { hfuCompensateLayer(layers[i], r); touched++; }
            }
            app.endUndoGroup();
            return hfuStr({ ok: true, newId: it.id, ratio: r, layers: touched });
        }

        var ni = app.project.importFile(new ImportOptions(f));
        ni.parentFolder = hfuUpscaledFolder();
        if (p.conformFps > 0 && ni.mainSource && !ni.mainSource.isStill) ni.mainSource.conformFrameRate = p.conformFps;
        r = ni.width / oldW;

        if (p.mode === 'swap') {
            layers = hfuLayersUsing(it);
            for (i = 0; i < layers.length; i++) {
                layers[i].replaceSource(ni, false);
                if (p.keepVisual && Math.abs(r - 1) > 0.001) hfuCompensateLayer(layers[i], r);
                touched++;
            }
        }
        app.endUndoGroup();
        return hfuStr({ ok: true, newId: ni.id, ratio: r, layers: touched });
    } catch (e) {
        app.endUndoGroup();
        return hfuStr({ ok: false, error: e.toString() });
    }
}
