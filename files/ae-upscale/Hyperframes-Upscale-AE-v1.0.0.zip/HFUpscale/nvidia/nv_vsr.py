"""HF Upscale - NVIDIA RTX Video Super Resolution worker.

Streams frames ffmpeg -> GPU (nvidia-vfx VideoSuperRes) -> ffmpeg, no frames on disk.
Usage:  python nv_vsr.py --check
        python nv_vsr.py job.json
Progress lines on stdout:  P <done> <total> <fps>
"""
import json
import os
import subprocess
import sys
import time


def tail(p, n=600):
    try:
        with open(p, 'rb') as f:
            return f.read().decode('utf-8', 'replace')[-n:].strip()
    except OSError:
        return ''


def quality(VideoSuperRes, name):
    return getattr(VideoSuperRes.QualityLevel, name, VideoSuperRes.QualityLevel.HIGH)


def check():
    try:
        import torch
        from nvvfx import VideoSuperRes
        if not torch.cuda.is_available():
            raise RuntimeError('PyTorch does not see a CUDA GPU (driver too old or CPU-only torch)')
        vsr = VideoSuperRes(quality=VideoSuperRes.QualityLevel.HIGH)
        vsr.output_width, vsr.output_height = 512, 288
        vsr.load()
        out = torch.from_dlpack(vsr.run(torch.rand(3, 144, 256, device='cuda')).image).clone()
        print(json.dumps({'ok': True, 'gpu': torch.cuda.get_device_name(0), 'torch': torch.__version__,
                          'shape': list(out.shape)}))
    except Exception as e:  # noqa: BLE001
        print(json.dumps({'ok': False, 'error': repr(e)}))
        sys.exit(1)


def read_exact(stream, n):
    buf = bytearray()
    while len(buf) < n:
        chunk = stream.read(n - len(buf))
        if not chunk:
            return None if not buf else bytes(buf)
        buf.extend(chunk)
    return buf


def run(job):
    import torch
    from nvvfx import VideoSuperRes

    w, h = job['width'], job['height']
    W, H = job['outWidth'], job['outHeight']
    # VSR itself goes up to 4x; anything beyond (or odd sizes) is finished with Lanczos in the encoder
    VW, VH = int(job.get('vsrWidth') or W), int(job.get('vsrHeight') or H)
    W8, H8 = -(-VW // 8) * 8, -(-VH // 8) * 8        # SDK wants multiples of 8
    ff = job['ffmpeg']
    log_dir = job['logDir']
    dec_log, enc_log = os.path.join(log_dir, 'decode.log'), os.path.join(log_dir, 'encode.log')

    vsr = VideoSuperRes(quality=quality(VideoSuperRes, job.get('quality', 'ULTRA')))
    vsr.output_width, vsr.output_height = W8, H8
    vsr.load()

    dec_cmd = [ff, '-v', 'error'] + list(job.get('inputArgs', [])) + ['-i', job['input']]
    if job.get('still'):
        dec_cmd += ['-frames:v', '1']
    dec_cmd += ['-f', 'rawvideo', '-pix_fmt', 'rgb24', '-']

    enc_cmd = [ff, '-y', '-v', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W8}x{H8}',
               '-framerate', str(job.get('fps', '30')), '-i', '-']
    if job.get('audio'):
        enc_cmd += ['-i', job.get('audioSource', job['input']), '-map', '0:v:0', '-map', '1:a:0?']
    if (W8, H8) != (W, H):
        enc_cmd += ['-vf', f'scale={W}:{H}:flags=lanczos']
    enc_cmd += list(job.get('encodeArgs', []))
    if job.get('audio'):
        enc_cmd += ['-shortest']
    enc_cmd += [job['output']]

    frame_bytes = w * h * 3
    flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    with open(dec_log, 'wb') as dl, open(enc_log, 'wb') as el:
        dec = subprocess.Popen(dec_cmd, stdout=subprocess.PIPE, stderr=dl, bufsize=frame_bytes * 2, creationflags=flags)
        enc = subprocess.Popen(enc_cmd, stdin=subprocess.PIPE, stderr=el, creationflags=flags)
        total = int(job.get('frames') or 0)
        n, t0 = 0, time.time()
        try:
            while True:
                buf = read_exact(dec.stdout, frame_bytes)
                if buf is None:
                    break
                if len(buf) != frame_bytes:
                    raise RuntimeError('Frame size mismatch: got %d bytes, expected %d (%dx%d). '
                                       'Rotated video?' % (len(buf), frame_bytes, w, h))
                t = torch.frombuffer(buf, dtype=torch.uint8).to('cuda')
                t = t.view(h, w, 3).permute(2, 0, 1).float().div(255.0).contiguous()
                out = torch.from_dlpack(vsr.run(t).image)
                o = out.clamp(0, 1).mul(255).round().to(torch.uint8).permute(1, 2, 0).contiguous().cpu().numpy()
                enc.stdin.write(o.tobytes())
                n += 1
                if n % 5 == 0 or n == total or n == 1:
                    print('P %d %d %.2f' % (n, total, n / max(1e-6, time.time() - t0)), flush=True)
        except BrokenPipeError:
            pass
        finally:
            try:
                enc.stdin.close()
            except OSError:
                pass
            enc.wait()
            dec.kill()
            dec.wait()

    if enc.returncode != 0:
        raise RuntimeError('ffmpeg (encode): ' + tail(enc_log))
    if n == 0:
        raise RuntimeError('ffmpeg (decode) gave no frames: ' + tail(dec_log))
    print('DONE %d' % n, flush=True)


def main():
    if len(sys.argv) > 1 and sys.argv[1] == '--check':
        return check()
    with open(sys.argv[1], encoding='utf-8') as f:
        job = json.load(f)
    try:
        run(job)
    except Exception as e:  # noqa: BLE001
        print('E ' + str(e).replace('\n', ' '), flush=True)
        sys.exit(1)


if __name__ == '__main__':
    main()
