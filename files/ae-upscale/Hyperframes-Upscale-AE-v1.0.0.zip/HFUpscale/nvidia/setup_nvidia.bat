@echo off
setlocal
rem HF Upscale - NVIDIA RTX Video Super Resolution engine
call "%~dp0env.bat" || exit /b 1
echo Installing NVIDIA VFX bindings...
"%VPY%" -m pip install numpy nvidia-vfx --extra-index-url https://pypi.nvidia.com || (echo [ERROR] nvidia-vfx install failed - see the lines above & exit /b 1)
echo Checking...
"%VPY%" "%~dp0nv_vsr.py" --check
if errorlevel 1 (echo [ERROR] check failed - update the NVIDIA driver to 570.65 or newer & exit /b 1)
echo DONE
exit /b 0
