@echo off
rem Shared Python environment for HF Upscale AI engines (PyTorch CUDA)
set "ROOT=%PUBLIC%\HFUpscale\nvvsr"
if not exist "%ROOT%" mkdir "%ROOT%"
set "OKVER=import sys; assert (3,10) <= sys.version_info[:2] < (3,14)"
set "VPY=%ROOT%\venv\Scripts\python.exe"
set "PYEXE="

rem 1) private Python installed earlier by HF Upscale
if exist "%ROOT%\python312\python.exe" set "PYEXE=%ROOT%\python312\python.exe"

rem 2) py launcher
if not defined PYEXE for %%V in (3.12 3.11 3.13 3.10) do if not defined PYEXE (
  for /f "delims=" %%P in ('py -%%V -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%P"
)

rem 3) standard install folders (works even if PATH was not updated)
if not defined PYEXE for %%V in (312 311 313 310) do if not defined PYEXE (
  if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python%%V\python.exe"
  if exist "%ProgramFiles%\Python%%V\python.exe" set "PYEXE=%ProgramFiles%\Python%%V\python.exe"
)

rem 4) python on PATH (only if the version fits)
if not defined PYEXE for /f "delims=" %%P in ('python -c "%OKVER%; print(sys.executable)" 2^>nul') do set "PYEXE=%%P"

rem 5) nothing suitable - install a private Python 3.12 (no admin rights needed)
if not defined PYEXE (
  echo Suitable Python not found - downloading the official Python 3.12 installer from python.org...
  curl.exe -L --fail -o "%ROOT%\python-installer.exe" "https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe" || curl.exe -L --fail -o "%ROOT%\python-installer.exe" "https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe" || (echo [ERROR] Python download failed - check the internet connection & exit /b 1)
  echo Installing Python 3.12 privately for HF Upscale ^(about 1 minute^)...
  start "" /wait "%ROOT%\python-installer.exe" /quiet InstallAllUsers=0 TargetDir="%ROOT%\python312" Include_launcher=0 PrependPath=0 Include_test=0 Include_doc=0 Shortcuts=0 AssociateFiles=0
  del "%ROOT%\python-installer.exe" >nul 2>nul
  if exist "%ROOT%\python312\python.exe" set "PYEXE=%ROOT%\python312\python.exe"
)
if not defined PYEXE (
  echo [ERROR] Python installation failed. Install Python 3.12 manually from python.org and press Install again.
  exit /b 1
)
"%PYEXE%" -c "%OKVER%" || (echo [ERROR] %PYEXE% is not Python 3.10-3.13 & exit /b 1)
echo Using: %PYEXE%

if exist "%VPY%" (
  "%VPY%" -c "%OKVER%" >nul 2>nul || (
    echo Existing environment uses an unsupported Python - recreating...
    rmdir /s /q "%ROOT%\venv"
  )
)
if not exist "%VPY%" (
  echo Creating virtual environment...
  "%PYEXE%" -m venv "%ROOT%\venv" || (echo [ERROR] venv failed & exit /b 1)
)
"%VPY%" -m pip install --upgrade pip
"%VPY%" -c "import torch, torchvision; assert torch.cuda.is_available()" >nul 2>nul
if errorlevel 1 (
  echo Installing PyTorch + torchvision with CUDA ^(about 3 GB, be patient^)...
  "%VPY%" -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cu128 || (echo [ERROR] torch install failed - see the lines above & exit /b 1)
) else (
  echo PyTorch with CUDA already installed.
)
exit /b 0
