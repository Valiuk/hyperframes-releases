/* Hyperframes Upscale — panel logic (CEP, Node enabled) */
(function () {
  'use strict';

  const cs = new CSInterface();
  const nodeRequire = (window.cep_node && window.cep_node.require) || window.require;
  const proc = (window.cep_node && window.cep_node.process) || window.process;
  const fs = nodeRequire('fs');
  const path = nodeRequire('path');
  const cp = nodeRequire('child_process');
  const https = nodeRequire('https');
  const Buffer = nodeRequire('buffer').Buffer;

  const IS_WIN = proc.platform === 'win32';
  const EXE = IS_WIN ? '.exe' : '';
  const EXT_DIR = path.normalize(cs.getSystemPath(SystemPath.EXTENSION));
  const $ = (id) => document.getElementById(id);

  // ---------------- settings ----------------
  const DEFAULTS = {
    engine: 'local',
    factor: '2',
    target: '1080',
    motion: 'off',
    quality: 'ULTRA',
    nvPython: '',
    applyMode: 'replace',
    keepVisual: true,
    realesrganPath: '',
    localModel: 'realesrgan-x4plus',
    gpuId: '',
    tile: '',
    ffmpegPath: '',
    videoCodec: 'prores422hq',
    replicateToken: '',
    cloudImageModel: 'topaz-image',
    topazEnhance: 'Standard V2',
    cloudVideoModel: 'topaz-video',
    cloudConcurrency: 3,
    customModel: '',
    customInput: '{\n  "image": "{{file}}",\n  "scale": {{scale}}\n}',
    outDir: '',
    workDir: IS_WIN
      ? path.join(proc.env.PUBLIC || 'C:\\Users\\Public', 'HFUpscale')
      : '/Users/Shared/HFUpscale',
    keepTemp: false
  };
  let S = Object.assign({}, DEFAULTS);
  try { Object.assign(S, JSON.parse(localStorage.getItem('hfu.settings') || '{}')); } catch (e) {}
  const save = () => localStorage.setItem('hfu.settings', JSON.stringify(S));

  // ---------------- models (shared with the HF Upscale app) ----------------
  const ROOT = IS_WIN ? path.join(proc.env.PUBLIC || 'C:\\Users\\Public', 'HFUpscale') : '/Users/Shared/HFUpscale';
  const CUSTOM_MODELS = path.join(ROOT, 'tools', 'models');   // path must contain "models" — Real-ESRGAN checks it
  const NV_DIR = path.join(ROOT, 'nvvsr');                      // shared Python env with the app
  const NV_WORKER = path.join(NV_DIR, 'nv_vsr.py');
  const BUILTIN_MODELS = [
    { id: 'realesrgan-x4plus', label: 'Реальне відео й фото', tag: 'x4plus', scales: [4], mb: 64 },
    { id: 'realesr-animevideov3', label: 'Графіка, геймплей, 2D (швидко)', tag: 'av3', scales: [2, 3, 4] },
    { id: 'realesrgan-x4plus-anime', label: 'Ілюстрації', tag: 'anime', scales: [4], mb: 17 }
  ];
  const CM_BASE = 'https://raw.githubusercontent.com/upscayl/custom-models/4b6d2cfa59c7442af115dfc6e50fd8d7d40b96ef/models/';
  const COMMUNITY_MODELS = [
    { id: '4xLSDIRplusC', label: 'Стиснене відео й фото', tag: 'lsdirC', mb: 33, license: 'CC BY 4.0 · Phhofm', desc: 'Пережаті кліпи з месенджерів і соцмереж: прибирає блоки стиснення.' },
    { id: '4xNomos8kSC', label: 'Фото: різкість і текстури', tag: 'nomos', mb: 33, license: 'CC BY 4.0 · Phhofm', desc: 'Реальна зйомка: природніша шкіра, тканини, природа.' },
    { id: '4xLSDIR', label: 'Чисті фото й рендери', tag: 'lsdir', mb: 33, license: 'CC BY 4.0 · Phhofm', desc: 'Якісні джерела: продуктові фото, рендери, експорти з AE.' },
    { id: '4xLSDIRCompactC3', label: 'Стиснене відео (швидко)', tag: 'lsdirC3', mb: 1.2, license: 'CC BY 4.0 · Phhofm', desc: 'Легка модель для довгих пережатих відео.' },
    { id: '4xHFA2k', label: 'Аніме та 2D-арт', tag: 'hfa2k', mb: 33, license: 'CC BY 4.0 · Phhofm', desc: 'Мальована анімація й арт: найчистіші лінії.' },
    { id: 'RealESRGAN_General_x4_v3', label: 'Універсальна легка', tag: 'genv3', mb: 2.4, license: 'BSD-3 · xinntao', desc: 'Швидка, трохи м\u2019якша за x4plus.' },
    { id: '4x_NMKD-Siax_200k', label: 'NMKD Siax — універсальна', tag: 'siax', mb: 67, license: 'ліцензія не вказана', desc: 'Чисті й злегка стиснені зображення.' },
    { id: '4x_NMKD-Superscale-SP_178000_G', label: 'NMKD Superscale — чисті фото', tag: 'superscale', mb: 67, license: 'ліцензія не вказана', desc: 'Ідеально чисті реальні фото.' }
  ];
  const ALL_MODELS = BUILTIN_MODELS.concat(COMMUNITY_MODELS.map((m) => Object.assign({ scales: [4], community: true }, m)));
  const modelInfo = (id) => ALL_MODELS.find((m) => m.id === id) || BUILTIN_MODELS[0];
  const haveCommunity = (id) => fs.existsSync(path.join(CUSTOM_MODELS, id + '.param')) && fs.existsSync(path.join(CUSTOM_MODELS, id + '.bin'));
  const NV_TAG = { ULTRA: 'rtx', HIGH: 'rtx-hi', HIGHBITRATE_ULTRA: 'rtx-clean', MEDIUM: 'rtx-draft' };
  const MOTION = { off: { m: 1 }, fps2: { m: 2, fpsMul: 2, tag: '60fps', audio: true }, slow2: { m: 2, fpsMul: 1, tag: 'slow2' }, slow4: { m: 4, fpsMul: 1, tag: 'slow4' } };

  // ---------------- logging ----------------
  function log(msg, isErr) {
    const box = $('log');
    box.hidden = false;
    const line = document.createElement('div');
    if (isErr) line.className = 'e';
    line.textContent = new Date().toLocaleTimeString() + '  ' + msg;
    box.appendChild(line);
    box.scrollTop = box.scrollHeight;
  }

  // ---------------- host bridge ----------------
  function host(fn, arg) {
    const call = arg === undefined ? fn + '()' : fn + '("' + encodeURIComponent(JSON.stringify(arg)) + '")';
    return new Promise((resolve) => {
      cs.evalScript(call, (r) => {
        try { resolve(JSON.parse(r)); } catch (e) { resolve({ ok: false, error: 'Host: ' + r }); }
      });
    });
  }

  function ensureHostLoaded() {
    cs.evalScript('typeof hfu_getSelection', (t) => {
      if (t !== 'function') {
        const p = encodeURIComponent(path.join(EXT_DIR, 'jsx', 'host.jsx'));
        cs.evalScript('$.evalFile(new File(decodeURIComponent("' + p + '")))');
      }
    });
  }

  // ---------------- binaries ----------------
  function searchPath(name) {
    const dirs = (proc.env.PATH || '').split(path.delimiter);
    if (!IS_WIN) dirs.push('/opt/homebrew/bin', '/usr/local/bin', '/usr/bin');
    for (const d of dirs) {
      const p = path.join(d, name + EXE);
      if (d && fs.existsSync(p)) return p;
    }
    return null;
  }
  // ASCII location the panel can always write to (extension folder may be read-only)
  const TOOLS_DIR = IS_WIN
    ? path.join(proc.env.PUBLIC || 'C:\\Users\\Public', 'HFUpscale', 'tools')
    : '/Users/Shared/HFUpscale/tools';

  function findIn(dir, file, depth) {
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return null; }
    for (const e of entries) if (e.isFile() && e.name.toLowerCase() === file.toLowerCase()) return path.join(dir, e.name);
    if (depth <= 0) return null;
    for (const e of entries) {
      if (e.isDirectory() && e.name !== 'models') {
        const r = findIn(path.join(dir, e.name), file, depth - 1);
        if (r) return r;
      }
    }
    return null;
  }
  function findBin(name, configured) {
    if (configured) return fs.existsSync(configured) ? configured : null;
    return findIn(path.join(EXT_DIR, 'bin'), name + EXE, 3) || findIn(TOOLS_DIR, name + EXE, 4) || searchPath(name);
  }

  // ---------------- tool installer ----------------
  const TOOL_URLS = {
    realesrgan: {
      win32: 'https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-windows.zip',
      darwin: 'https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesrgan-ncnn-vulkan-20220424-macos.zip'
    },
    ffmpeg: {
      win32: 'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip',
      darwin: 'https://evermeet.cx/ffmpeg/getrelease/zip'
    }
  };

  async function installTool(tool) {
    const url = TOOL_URLS[tool][proc.platform];
    const st = $(tool === 'realesrgan' ? 'dlRealesrgan' : 'dlFfmpeg');
    if (!url) { st.textContent = 'Для цієї системи автозавантаження немає'; return; }
    const dir = path.join(TOOLS_DIR, tool);
    const zip = path.join(TOOLS_DIR, tool + '_download.zip');
    try {
      mkdirp(dir);
      st.textContent = 'Завантаження…';
      await download(url, zip, (f) => { st.textContent = 'Завантаження ' + Math.round(f * 100) + '%'; });
      st.textContent = 'Розпаковую…';
      if (IS_WIN) {
        const q = (x) => "'" + x.replace(/'/g, "''") + "'";
        await run('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command',
          'Expand-Archive -LiteralPath ' + q(zip) + ' -DestinationPath ' + q(dir) + ' -Force'], { cwd: TOOLS_DIR });
      } else {
        await run('/usr/bin/ditto', ['-x', '-k', zip, dir], { cwd: TOOLS_DIR });
        const exe = findIn(dir, tool === 'realesrgan' ? 'realesrgan-ncnn-vulkan' : 'ffmpeg', 4);
        if (exe) fs.chmodSync(exe, 0o755);
        try { await run('/usr/bin/xattr', ['-dr', 'com.apple.quarantine', dir], { cwd: TOOLS_DIR }); } catch (e) {}
      }
      try { fs.unlinkSync(zip); } catch (e) {}
      if (tool === 'realesrgan') S.realesrganPath = ''; else S.ffmpegPath = '';
      save();
      $(tool === 'realesrgan' ? 'realesrganPath' : 'ffmpegPath').value = '';
      refreshBins();
      const found = tool === 'realesrgan' ? bins.realesrgan : bins.ffmpeg;
      st.textContent = found ? 'Встановлено: ' + found : 'Розпаковано, але файл не знайдено в ' + dir;
      log(st.textContent, !found);
    } catch (e) {
      st.textContent = 'Помилка: ' + e.message;
      log(tool + ': ' + e.message, true);
    }
  }

  const bins = {};
  function refreshBins() {
    bins.realesrgan = findBin('realesrgan-ncnn-vulkan', S.realesrganPath);
    bins.ffmpeg = findBin('ffmpeg', S.ffmpegPath);
    bins.rife = findBin('rife-ncnn-vulkan', '');
    const vpy = S.nvPython || path.join(NV_DIR, 'venv', IS_WIN ? 'Scripts' : 'bin', 'python' + EXE);
    let pk = [];
    try { pk = fs.readdirSync(path.join(NV_DIR, 'venv', IS_WIN ? 'Lib' : 'lib', 'site-packages')); } catch (e) {}
    bins.nvidia = fs.existsSync(vpy) && (pk.some((n) => /^(nvvfx|nvidia_vfx)/i.test(n)) || !!S.nvPython) ? vpy : null;
    bins.python = fs.existsSync(vpy) ? vpy : null;
    $('stNvidia').className = 'dot ' + (bins.nvidia ? 'ok' : 'bad');
    $('stNvidia').title = bins.nvidia || 'не встановлено';
    $('stRealesrgan').className = 'dot ' + (bins.realesrgan ? 'ok' : 'bad');
    $('stFfmpeg').className = 'dot ' + (bins.ffmpeg ? 'ok' : 'bad');
    $('stRealesrgan').title = bins.realesrgan || 'не знайдено';
    $('stFfmpeg').title = bins.ffmpeg || 'не знайдено';
  }

  // ---------------- process helpers ----------------
  function run(bin, args, opts) {
    opts = opts || {};
    return new Promise((resolve, reject) => {
      const env = Object.assign({}, proc.env, { PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1', PYTHONUNBUFFERED: '1' });
      const child = cp.spawn(bin, args, { cwd: opts.cwd || path.dirname(bin), windowsHide: true, env });
      if (opts.job) opts.job.procs.push(child);
      let tail = '';
      const onData = (d) => {
        const s = d.toString();
        tail = (tail + s).slice(-2000);
        if (opts.onOutput) opts.onOutput(s);
      };
      child.stdout.on('data', onData);
      child.stderr.on('data', onData);
      child.on('error', (e) => reject(new Error(path.basename(bin) + ': ' + e.message)));
      child.on('close', (code) => {
        if (opts.job) opts.job.procs = opts.job.procs.filter((c) => c !== child);
        if (opts.job && opts.job.cancelled) return reject(new Error('Скасовано'));
        if (code === 0 || opts.allowFail) resolve(tail);
        else reject(new Error(path.basename(bin) + ' завершився з кодом ' + code + '\n' + tail.trim().split('\n').slice(-4).join('\n')));
      });
    });
  }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function mkdirp(d) { fs.mkdirSync(d, { recursive: true }); }
  function rmrf(d) { try { fs.rmSync(d, { recursive: true, force: true }); } catch (e) { try { fs.rmdirSync(d, { recursive: true }); } catch (e2) {} } }
  function moveFile(a, b) {
    try { fs.renameSync(a, b); } catch (e) { fs.copyFileSync(a, b); fs.unlinkSync(a); }
  }
  const isAscii = (s) => /^[\x20-\x7e]*$/.test(s);

  function outputPath(job, ext, tag) {
    const dir = S.outDir || path.join(path.dirname(job.path), 'upscaled');
    mkdirp(dir);
    const pl = job.plan || planFor(job);
    const mot = job.kind === 'video' && MOTION[S.motion].tag ? '_' + MOTION[S.motion].tag : '';
    const base = path.parse(job.path).name + (pl.upscale ? '_' + pl.tag + '_' + tag : '') + mot;
    let p = path.join(dir, base + ext), n = 1;
    while (fs.existsSync(p)) p = path.join(dir, base + '_' + (n++) + ext);
    return p;
  }

  function fpsFrac(f) {
    const known = [[23.976, '24000/1001'], [29.97, '30000/1001'], [47.952, '48000/1001'], [59.94, '60000/1001'], [119.88, '120000/1001']];
    for (const [v, s] of known) if (Math.abs(f - v) < 0.01) return s;
    return String(Math.round(f * 1000) / 1000);
  }
  const countPng = (d) => { try { return fs.readdirSync(d).filter((f) => f.endsWith('.png')).length; } catch (e) { return 0; } };
  const pad8 = (n) => String(n).padStart(8, '0');
  function eta(t0, done, total) {
    if (done < 3) return '';
    const left = (Date.now() - t0) / done * (total - done) / 1000;
    return ' · ~' + (left > 90 ? Math.round(left / 60) + ' хв' : Math.round(left) + ' с');
  }

  // ---------------- output plan: factor, auto or exact size ----------------
  function planFor(job) {
    const w = job.width, h = job.height, short = Math.min(w, h);
    if (S.factor === 'size') {
      const t = Math.max(64, parseInt(S.target, 10) || 1080);
      const f = t / short;
      let W = Math.round(w * f / 2) * 2, H = Math.round(h * f / 2) * 2;
      if (w <= h) W = t; else H = t;
      return { f, W, H, tag: t + 'p', label: t + 'p', upscale: f > 1.001 };
    }
    const f = S.factor === 'auto' ? (job.maxScale / 100 > 2 ? 4 : 2) : (parseInt(S.factor, 10) || 2);
    return { f, W: w * f, H: h * f, tag: 'x' + f, label: f + '×', upscale: f > 1.001 };
  }

  // ---------------- Real-ESRGAN ----------------
  function esrganArgs(input, output, scale, safe) {
    const info = modelInfo(S.localModel);
    const mdir = info.community ? CUSTOM_MODELS : path.join(path.dirname(bins.realesrgan), 'models');
    const a = ['-i', input, '-o', output, '-m', mdir, '-n', S.localModel, '-s', String(scale), '-f', 'png', '-j', '2:2:4'];
    if (String(S.gpuId).trim() !== '') a.push('-g', String(S.gpuId).trim());
    const userTile = parseInt(S.tile, 10);
    if (userTile > 0) a.push('-t', String(userTile));
    else if (!safe) a.push('-t', info.mb && info.mb > 10 ? '400' : '512');   // auto (200) is very conservative for 8–12 GB cards
    return a;
  }
  async function runEsrgan(input, output, scale, opts) {
    try { await run(bins.realesrgan, esrganArgs(input, output, scale, false), opts); }
    catch (e) {
      if ((opts.job && opts.job.cancelled) || parseInt(S.tile, 10) > 0) throw e;
      log('Real-ESRGAN: великий тайл не вмістився — повторюю з безпечним розміром');
      await run(bins.realesrgan, esrganArgs(input, output, scale, true), opts);
    }
  }
  function runScaleFor(f) {
    const native = modelInfo(S.localModel).scales.slice().sort((a, b) => a - b);
    return native.find((n) => n >= f - 1e-6) || native[native.length - 1];
  }
  async function ensureModel(id, onMsg) {
    const info = modelInfo(id);
    if (!info.community || haveCommunity(id)) return;
    mkdirp(CUSTOM_MODELS);
    for (const ext of ['.param', '.bin']) {
      const dst = path.join(CUSTOM_MODELS, id + ext);
      await download(CM_BASE + id + ext, dst + '.part', (f) => onMsg && onMsg('Завантажую модель ' + info.label + ' ' + Math.round(f * 100) + '%'));
      moveFile(dst + '.part', dst);
    }
    fillModelSelect(); renderCatalog();
  }
  function needEsrgan() { if (!bins.realesrgan) throw new Error('Real-ESRGAN не знайдено. Налаштування → «Завантажити» біля Real-ESRGAN.'); }
  function needFfmpeg(why) { if (!bins.ffmpeg) throw new Error('Потрібен ffmpeg (' + why + '). Налаштування → «Завантажити» біля ffmpeg.'); }

  // ---------------- NVIDIA RTX Video Super Resolution ----------------
  function syncNvFiles() {
    try {
      mkdirp(NV_DIR);
      for (const f of ['nv_vsr.py', 'env.bat', 'setup_nvidia.bat']) fs.copyFileSync(path.join(EXT_DIR, 'nvidia', f), path.join(NV_DIR, f));
    } catch (e) {}
  }
  async function nvRun(spec, job, onProg) {
    if (!bins.nvidia) throw new Error('NVIDIA-рушій не встановлено. Налаштування → розділ NVIDIA → «Встановити».');
    needFfmpeg('NVIDIA-рушій читає й пише файли через ffmpeg');
    syncNvFiles();
    const wd = path.join(S.workDir, 'nv_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6));
    mkdirp(wd);
    try {
      const jobFile = path.join(wd, 'job.json');
      fs.writeFileSync(jobFile, JSON.stringify(Object.assign({ ffmpeg: bins.ffmpeg, quality: S.quality, logDir: wd }, spec)), 'utf8');
      let err = '';
      await run(bins.nvidia, [NV_WORKER, jobFile], {
        job, cwd: NV_DIR,
        onOutput: (s) => {
          for (const line of s.split(/\r?\n/)) {
            const m = line.match(/^P (\d+) (\d+) ([\d.]+)/);
            if (m && onProg) onProg(+m[1], +m[2], parseFloat(m[3]));
            if (line.startsWith('E ')) err = line.slice(2);
          }
        }
      }).catch((e) => { throw new Error(err || e.message); });
    } finally { if (!S.keepTemp) rmrf(wd); }
  }

  // ---------------- RIFE (frame interpolation) ----------------
  async function detectCuts(framesDir, job) {
    // read the PNG sequence at 1 fps so that pts_time == frame index
    let out = '';
    await run(bins.ffmpeg, ['-hide_banner', '-framerate', '1', '-i', path.join(framesDir, '%08d.png'),
      '-vf', "select='gt(scene\\,0.3)',showinfo", '-f', 'null', '-'], { job, allowFail: true, onOutput: (t) => { out += t; } });
    const cuts = new Set();
    for (const m of out.matchAll(/pts_time:\s*([\d.]+)/g)) { const n = Math.round(parseFloat(m[1])); if (n > 0) cuts.add(n - 1); }
    return cuts;
  }
  async function rifeInterpolate(framesDir, count, mult, wd, job, onProg) {
    if (!bins.rife) throw new Error('RIFE не знайдено — перевірте папку bin/rife панелі.');
    const outDir = path.join(wd, 'rife');
    mkdirp(outDir);
    const cuts = await detectCuts(framesDir, job);
    const total = count * mult;
    const args = ['-i', framesDir, '-o', outDir, '-m', path.join(path.dirname(bins.rife), 'rife-v4.6'), '-n', String(total), '-f', '%08d.png'];
    if (String(S.gpuId).trim() !== '') args.push('-g', String(S.gpuId).trim());
    let watching = true;
    (async () => { while (watching) { await sleep(1000); if (onProg) onProg(countPng(outDir), total); } })();
    try { await run(bins.rife, args, { job }); } finally { watching = false; }
    // keep original frames untouched and never blend across hard cuts (hold the last frame instead)
    for (let i = 0; i < total; i++) {
      const sx = Math.floor(i / mult), frac = i % mult;
      let src = -1;
      if (sx >= count - 1) src = count - 1; else if (frac === 0 || cuts.has(sx)) src = sx;
      if (src >= 0) fs.copyFileSync(path.join(framesDir, pad8(src + 1) + '.png'), path.join(outDir, pad8(i + 1) + '.png'));
    }
    return { dir: outDir, count: total, cuts: cuts.size };
  }

  // ---------------- local engines (Real-ESRGAN / NVIDIA) ----------------
  const codecTable = {
    prores422hq: { ext: '.mov', v: ['-c:v', 'prores_ks', '-profile:v', '3', '-pix_fmt', 'yuv422p10le'], a: ['-c:a', 'pcm_s16le'] },
    prores4444: { ext: '.mov', v: ['-c:v', 'prores_ks', '-profile:v', '4', '-pix_fmt', 'yuva444p10le'], a: ['-c:a', 'pcm_s16le'] },
    h264: { ext: '.mp4', v: ['-c:v', 'libx264', '-crf', '14', '-preset', 'slow', '-pix_fmt', 'yuv420p'], a: ['-c:a', 'aac', '-b:a', '320k'] }
  };
  const engTag = () => S.engine === 'nvidia' ? (NV_TAG[S.quality] || 'rtx') : modelInfo(S.localModel).tag;

  async function localImage(job, wd) {
    const pl = job.plan;
    if (!pl.upscale) throw new Error('Для зображення ціль має бути більшою за оригінал (' + job.width + '×' + job.height + ').');
    const { W, H, f } = pl;
    const dest = outputPath(job, '.png', engTag());
    if (S.engine === 'nvidia') {
      job.setStatus('NVIDIA RTX…', 0.1, true);
      await nvRun({ input: job.path, output: dest, width: job.width, height: job.height, still: true, frames: 1, outWidth: W, outHeight: H,
        vsrWidth: Math.min(W, job.width * 4), vsrHeight: Math.min(H, job.height * 4), encodeArgs: ['-frames:v', '1'] }, job);
      return { file: dest, conformFps: 0 };
    }
    needEsrgan();
    await ensureModel(S.localModel, (m) => job.setStatus(m, 0.02));
    const ext = path.extname(job.path).toLowerCase();
    let input = path.join(wd, 'in' + ext);
    if (/^\.(png|jpe?g|webp)$/.test(ext)) fs.copyFileSync(job.path, input);
    else {
      needFfmpeg(ext + ' → PNG');
      input = path.join(wd, 'in.png');
      await run(bins.ffmpeg, ['-y', '-i', job.path, '-frames:v', '1', input], { job });
    }
    const rs = runScaleFor(f);
    let out = path.join(wd, 'out.png');
    job.setStatus('Апскейл…', 0.05);
    await runEsrgan(input, out, rs, { job, onOutput: (s) => {
      const m = s.match(/(\d+(?:\.\d+)?)%/g);
      if (m) job.setStatus('Апскейл…', 0.05 + 0.9 * parseFloat(m[m.length - 1]) / 100);
    } });
    if (job.width * rs !== W || job.height * rs !== H) {
      needFfmpeg('точний розмір ' + W + '×' + H);
      const resized = path.join(wd, 'out_resized.png');
      await run(bins.ffmpeg, ['-y', '-i', out, '-vf', 'scale=' + W + ':' + H + ':flags=lanczos', resized], { job });
      out = resized;
    }
    moveFile(out, dest);
    return { file: dest, conformFps: 0 };
  }

  async function localVideo(job, wd) {
    needFfmpeg('відео');
    const pl = job.plan, mot = MOTION[S.motion];
    const { W, H, f } = pl;
    if (!pl.upscale && mot.m === 1 && W === job.width && H === job.height) throw new Error('Нічого робити: розмір не змінюється і плавність вимкнена.');
    const fpsOut = job.nativeFps * (mot.fpsMul || 1);
    const audio = job.hasAudio && (mot.m === 1 || !!mot.audio);
    let c = S.videoCodec;
    if (c === 'prores4444' && S.engine === 'nvidia' && pl.upscale) c = 'prores422hq';   // RTX VSR has no alpha
    const codec = codecTable[c];
    const dest = outputPath(job, codec.ext, engTag());
    const vsrW = Math.min(W, job.width * 4), vsrH = Math.min(H, job.height * 4);
    const t0 = Date.now();
    // conform: keep the old interpretation unless the frame rate itself changes (60 fps / slow-mo)
    const conformFps = mot.m > 1 ? -1 : 0;

    if (S.engine === 'nvidia' && mot.m === 1 && pl.upscale) {
      const total = Math.max(1, Math.round(job.duration * job.nativeFps));
      job.setStatus('Запуск NVIDIA RTX…', 0.01, true);
      await nvRun({ input: job.path, output: dest, width: job.width, height: job.height, outWidth: W, outHeight: H, vsrWidth: vsrW, vsrHeight: vsrH,
        fps: fpsFrac(job.nativeFps), frames: total, audio: job.hasAudio, encodeArgs: codec.v.concat(job.hasAudio ? codec.a : []) }, job,
        (n, tot, fps) => job.setStatus('RTX ' + n + '/' + tot + ' · ' + fps.toFixed(1) + ' к/с' + eta(t0, n, tot), 0.02 + 0.96 * Math.min(1, n / tot)));
      return { file: dest, conformFps };
    }

    // 1) frames
    const total0 = Math.max(1, Math.round(job.duration * job.nativeFps));
    let dir = path.join(wd, 'frames');
    mkdirp(dir);
    const ffProg = (base, span, label, total) => (s) => {
      const m = s.match(/frame=\s*(\d+)/g);
      if (m) { const n = parseInt(m[m.length - 1].replace(/\D/g, ''), 10); job.setStatus(label + ' ' + n + '/' + total, base + span * Math.min(1, n / total)); }
    };
    job.setStatus('Розбиваю на кадри…', 0.01);
    const extract = (sync) => run(bins.ffmpeg, ['-y', '-i', job.path].concat(sync, [path.join(dir, '%08d.png')]), { job, onOutput: ffProg(0, 0.06, 'Кадри', total0) });
    try { await extract(['-fps_mode', 'passthrough']); }
    catch (e) { if (!/fps_mode/.test(e.message)) throw e; await extract(['-vsync', '0']); }
    let count = countPng(dir);

    // 2) smoothness
    if (mot.m > 1) {
      const tR = Date.now();
      const r = await rifeInterpolate(dir, count, mot.m, wd, job,
        (n, tot) => job.setStatus('Плавність (RIFE) ' + n + '/' + tot + eta(tR, n, tot), 0.06 + (pl.upscale ? 0.2 : 0.84) * Math.min(1, n / tot)));
      dir = r.dir; count = r.count;
      if (r.cuts) log(job.name + ': знайдено склейок — ' + r.cuts + ', на них кадри не змішуються');
    }
    const base = mot.m > 1 && pl.upscale ? 0.26 : 0.06, span = 0.92 - base;

    // 3) upscale + 4) encode
    const encodeSeq = async (pattern) => {
      const args = ['-y', '-framerate', fpsFrac(fpsOut), '-i', pattern];
      if (audio) args.push('-i', job.path, '-map', '0:v:0', '-map', '1:a:0?');
      const w2 = W - (codec.ext === '.mp4' ? W % 2 : 0), h2 = H - (codec.ext === '.mp4' ? H % 2 : 0);
      args.push('-vf', 'scale=' + w2 + ':' + h2 + ':flags=lanczos');
      args.push.apply(args, codec.v);
      if (audio) args.push.apply(args, codec.a.concat(['-shortest']));
      args.push(dest);
      job.setStatus('Збираю відео…', 0.92);
      await run(bins.ffmpeg, args, { job, onOutput: ffProg(0.92, 0.07, 'Кодування', count) });
    };
    if (!pl.upscale) {
      await encodeSeq(path.join(dir, '%08d.png'));
    } else if (S.engine === 'nvidia') {
      await nvRun({ input: path.join(dir, '%08d.png'), inputArgs: ['-framerate', fpsFrac(fpsOut)], output: dest,
        width: job.width, height: job.height, outWidth: W, outHeight: H, vsrWidth: vsrW, vsrHeight: vsrH, fps: fpsFrac(fpsOut), frames: count,
        audio, audioSource: job.path, encodeArgs: codec.v.concat(audio ? codec.a : []) }, job,
        (n, tot, fps) => job.setStatus('RTX ' + n + '/' + tot + ' · ' + fps.toFixed(1) + ' к/с' + eta(t0, n, tot), base + span * Math.min(1, n / tot)));
    } else {
      needEsrgan();
      await ensureModel(S.localModel, (m) => job.setStatus(m, base));
      const upDir = path.join(wd, 'up');
      mkdirp(upDir);
      let watching = true;
      const tE = Date.now();
      (async () => { while (watching) { await sleep(1000); const n = countPng(upDir); job.setStatus('Апскейл ' + n + '/' + count + eta(tE, n, count), base + span * Math.min(1, n / count)); } })();
      try { await runEsrgan(dir, upDir, runScaleFor(f), { job }); } finally { watching = false; }
      await encodeSeq(path.join(upDir, '%08d.png'));
    }
    return { file: dest, conformFps };
  }

  // ---------------- Replicate ----------------
  function httpReq(method, url, headers, body) {
    return new Promise((resolve, reject) => {
      const u = new URL(url);
      const req = https.request({ method, hostname: u.hostname, path: u.pathname + u.search, headers }, (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks).toString('utf8') }));
      });
      req.on('error', reject);
      if (typeof body === 'function') body(req); else { if (body) req.write(body); req.end(); }
    });
  }

  async function api(method, p, json) {
    const body = json ? JSON.stringify(json) : null;
    const headers = { Authorization: 'Bearer ' + S.replicateToken.trim() };
    if (body) { headers['Content-Type'] = 'application/json'; headers['Content-Length'] = Buffer.byteLength(body); }
    const r = await httpReq(method, 'https://api.replicate.com' + p, headers, body);
    let data = null;
    try { data = JSON.parse(r.body); } catch (e) {}
    return { status: r.status, data, raw: r.body };
  }

  const MIME = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.tif': 'image/tiff', '.tiff': 'image/tiff',
    '.mp4': 'video/mp4', '.mov': 'video/quicktime', '.webm': 'video/webm', '.mkv': 'video/x-matroska', '.avi': 'video/x-msvideo' };

  function replicateUpload(file, job) {
    const size = fs.statSync(file).size;
    const ext = path.extname(file).toLowerCase();
    const boundary = '----hfu' + Date.now().toString(16);
    const head = Buffer.from('--' + boundary + '\r\nContent-Disposition: form-data; name="content"; filename="input' + ext +
      '"\r\nContent-Type: ' + (MIME[ext] || 'application/octet-stream') + '\r\n\r\n');
    const tail = Buffer.from('\r\n--' + boundary + '--\r\n');
    return httpReq('POST', 'https://api.replicate.com/v1/files', {
      Authorization: 'Bearer ' + S.replicateToken.trim(),
      'Content-Type': 'multipart/form-data; boundary=' + boundary,
      'Content-Length': head.length + size + tail.length
    }, (req) => {
      req.write(head);
      let sent = 0;
      const rs = fs.createReadStream(file);
      rs.on('data', (c) => { sent += c.length; job.setStatus('Вивантаження ' + Math.round(100 * sent / size) + '%', 0.15 * sent / size); });
      rs.on('end', () => { req.write(tail); req.end(); });
      rs.pipe(req, { end: false });
    }).then((r) => {
      let d = null; try { d = JSON.parse(r.body); } catch (e) {}
      if (r.status >= 300 || !d || !d.urls) throw new Error('Вивантаження не вдалося (' + r.status + '): ' + r.body.slice(0, 300));
      return d.urls.get;
    });
  }

  async function createPrediction(model, input) {
    let r = await api('POST', '/v1/models/' + model + '/predictions', { input });
    if (r.status === 404 || (r.status === 422 && /version/i.test(r.raw))) {
      const m = await api('GET', '/v1/models/' + model);
      if (!m.data || !m.data.latest_version) throw new Error('Модель ' + model + ' не знайдено на Replicate');
      r = await api('POST', '/v1/predictions', { version: m.data.latest_version.id, input });
    }
    if (r.status >= 300) throw new Error('Replicate ' + r.status + ': ' + ((r.data && (r.data.detail || r.data.title)) || r.raw.slice(0, 300)));
    return r.data;
  }

  function download(url, dest, onProgress, redirects) {
    redirects = redirects === undefined ? 5 : redirects;
    return new Promise((resolve, reject) => {
      https.get(url, (res) => {
        if ([301, 302, 303, 307, 308].indexOf(res.statusCode) >= 0 && res.headers.location && redirects > 0) {
          res.resume();
          return resolve(download(new URL(res.headers.location, url).toString(), dest, onProgress, redirects - 1));
        }
        if (res.statusCode !== 200) { res.resume(); return reject(new Error('Завантаження: HTTP ' + res.statusCode)); }
        const total = parseInt(res.headers['content-length'] || '0', 10);
        let got = 0;
        const ws = fs.createWriteStream(dest);
        res.on('data', (c) => { got += c.length; if (total && onProgress) onProgress(got / total); });
        res.pipe(ws);
        ws.on('finish', () => ws.close(() => resolve(dest)));
        ws.on('error', reject);
      }).on('error', reject);
    });
  }

  function topazRes(job) {
    const shortSide = Math.min(job.width, job.height) * job.factorUsed;
    return shortSide <= 720 ? '720p' : shortSide <= 1080 ? '1080p' : '4k';
  }

  function buildCloudRequest(job, fileUrl) {
    const isVideo = job.kind === 'video';
    const choice = isVideo ? S.cloudVideoModel : S.cloudImageModel;
    if (choice === 'topaz-image') {
      return { model: 'topazlabs/image-upscale', tag: 'topaz', input: {
        image: fileUrl, upscale_factor: job.factorUsed + 'x', enhance_model: S.topazEnhance, output_format: 'png' } };
    }
    if (choice === 'real-esrgan') {
      return { model: 'nightmareai/real-esrgan', tag: 'esrgan', input: { image: fileUrl, scale: job.factorUsed, face_enhance: false } };
    }
    if (choice === 'topaz-video') {
      return { model: 'topazlabs/video-upscale', tag: 'topaz', input: {
        video: fileUrl, target_resolution: topazRes(job),
        target_fps: Math.min(120, Math.max(15, Math.round(job.nativeFps || 30))) } };
    }
    if (!S.customModel.trim()) throw new Error('Вкажіть свою модель у налаштуваннях (owner/name).');
    const filled = S.customInput
      .split('{{file}}').join(fileUrl)
      .split('{{scale}}').join(String(job.factorUsed))
      .split('{{fps}}').join(String(Math.round(job.nativeFps || 30)));
    let input;
    try { input = JSON.parse(filled); } catch (e) { throw new Error('JSON своєї моделі некоректний: ' + e.message); }
    return { model: S.customModel.trim(), tag: S.customModel.trim().split('/').pop().replace(/[^\w-]/g, ''), input };
  }

  async function cloudJob(job, wd) {
    if (!S.replicateToken.trim()) throw new Error('Додайте API-токен Replicate у налаштуваннях.');
    const size = fs.statSync(job.path).size;
    if (size > 100 * 1024 * 1024) throw new Error('Файл більший за 100 МБ — Replicate його не прийме. Скоротіть кліп або використайте локальний рушій.');

    const fileUrl = await replicateUpload(job.path, job);
    const reqd = buildCloudRequest(job, fileUrl);
    job.setStatus('У черзі Replicate…', 0.16, true);
    let pred = await createPrediction(reqd.model, reqd.input);
    job.cancelUrl = pred.urls && pred.urls.cancel;

    while (['starting', 'processing'].indexOf(pred.status) >= 0) {
      if (job.cancelled) {
        if (job.cancelUrl) await httpReq('POST', job.cancelUrl, { Authorization: 'Bearer ' + S.replicateToken.trim(), 'Content-Length': 0 });
        throw new Error('Скасовано');
      }
      await sleep(2500);
      const r = await api('GET', '/v1/predictions/' + pred.id);
      if (r.data) pred = r.data;
      const pcts = (pred.logs || '').match(/(\d{1,3})%/g);
      if (pcts) job.setStatus('Обробка ' + pcts[pcts.length - 1], 0.16 + 0.7 * parseInt(pcts[pcts.length - 1], 10) / 100);
      else job.setStatus(pred.status === 'starting' ? 'Запуск моделі…' : 'Обробка…', null, true);
    }
    if (pred.status !== 'succeeded') throw new Error('Replicate: ' + (pred.error || pred.status));

    let out = pred.output;
    if (Array.isArray(out)) out = out[out.length - 1];
    if (out && typeof out === 'object') out = out.url || out.uri || Object.values(out)[0];
    if (typeof out !== 'string') throw new Error('Не вдалося прочитати вихід моделі: ' + JSON.stringify(pred.output).slice(0, 200));

    let ext = path.extname(new URL(out).pathname).toLowerCase() || (job.kind === 'video' ? '.mp4' : '.png');
    const tmp = path.join(wd, 'cloud_out' + ext);
    await download(out, tmp, (f) => job.setStatus('Завантаження ' + Math.round(f * 100) + '%', 0.88 + 0.1 * f));
    const dest = outputPath(job, ext, reqd.tag);
    moveFile(tmp, dest);
    return { file: dest, conformFps: job.kind === 'video' ? job.fps : 0 };
  }

  // ---------------- queue ----------------
  let jobs = [];
  let running = false;
  let seq = 0;


  function makeJob(item) {
    const job = Object.assign({}, item, { uid: ++seq, status: 'queued', progress: 0, text: '', procs: [], cancelled: false });
    if (item.kind === 'sequence') { job.status = 'unsupported'; job.text = 'Секвенції зображень поки не підтримуються'; }
    job.setStatus = (text, prog, indet) => {
      job.text = text;
      if (prog !== null && prog !== undefined) job.progress = prog;
      job.indet = !!indet;
      renderJob(job);
    };
    return job;
  }

  async function processJob(job) {
    job.status = 'running';
    job.cancelled = false;
    job.plan = planFor(job);
    job.factorUsed = job.plan.f;
    const engine = S.engine;
    if (!isAscii(S.workDir)) log('Тимчасова папка містить не латинські символи — Real-ESRGAN може не прочитати шлях. Змініть її в налаштуваннях.', true);
    const wd = path.join(S.workDir, 'job_' + Date.now() + '_' + job.uid);
    mkdirp(wd);
    try {
      let res;
      if (engine === 'cloud') {
        job.factorUsed = job.plan.f <= 2 ? 2 : 4;   // cloud models only take whole factors
        res = await cloudJob(job, wd);
      } else res = job.kind === 'image' ? await localImage(job, wd) : await localVideo(job, wd);

      job.setStatus('Імпорт в After Effects…', 0.99);
      // slow-mo changes the clip's length — never swap it into existing layers, only import it
      const slow = engine !== 'cloud' && job.kind === 'video' && MOTION[S.motion].m > 1 && !MOTION[S.motion].audio;
      const mode = slow ? 'import' : S.applyMode;
      if (slow && S.applyMode !== 'import') log(job.name + ': слоумо змінює тривалість, тому результат лише імпортовано в папку Upscaled');
      const r = await host('hfu_apply', { id: job.id, path: res.file, mode, keepVisual: S.keepVisual, conformFps: res.conformFps });
      if (!r.ok) throw new Error(r.error);
      job.status = 'done';
      job.result = res.file;
      job.setStatus('Готово · ' + path.basename(res.file) + (r.layers ? ' · шарів скориговано: ' + r.layers : ''), 1);
      log(job.name + ' → ' + res.file);
    } catch (e) {
      job.status = job.cancelled ? 'queued' : 'error';
      job.setStatus(job.cancelled ? 'Скасовано' : e.message, 0);
      if (!job.cancelled) log(job.name + ': ' + e.message, true);
    } finally {
      if (!S.keepTemp) rmrf(wd);
    }
  }

  async function startQueue() {
    refreshBins();
    running = true;
    renderControls();
    const conc = S.engine === 'local' ? 1 : Math.max(1, Math.min(8, parseInt(S.cloudConcurrency, 10) || 1));
    const worker = async () => {
      while (running) {
        const next = jobs.find((j) => j.status === 'queued' || j.status === 'error');
        if (!next) return;
        next.status = 'running';
        await processJob(next);
        if (next.status === 'error') next.status = 'failed';
      }
    };
    await Promise.all(Array.from({ length: conc }, worker));
    jobs.forEach((j) => { if (j.status === 'failed') j.status = 'error'; });
    running = false;
    renderAll();
  }

  function stopQueue() {
    running = false;
    jobs.forEach((j) => {
      if (j.status === 'running') {
        j.cancelled = true;
        j.procs.forEach((c) => { try { c.kill(); } catch (e) {} });
      }
    });
    renderControls();
  }

  // ---------------- rendering ----------------
  const KIND = { image: 'зображення', video: 'відео', sequence: 'секвенція' };

  function targetRes(job) {
    const pl = (job.status === 'running' || job.status === 'done') && job.plan ? job.plan : planFor(job);
    return { w: pl.W, h: pl.H, f: Math.round(pl.f * 100) / 100 };
  }

  function renderJob(job) {
    let li = document.querySelector('[data-uid="' + job.uid + '"]');
    if (!li) return;
    const t = targetRes(job);
    li.className = 'job ' + job.status;
    li.querySelector('.to').textContent = t.w + '×' + t.h;
    li.querySelector('.factor').textContent = '×' + t.f;
    li.querySelector('.job-status').textContent = job.text || (job.status === 'queued' ? 'Очікує' : '');
    const bar = li.querySelector('.bar');
    bar.style.width = Math.round((job.progress || 0) * 100) + '%';
    bar.classList.toggle('indet', job.status === 'running' && !!job.indet);
  }

  function renderAll() {
    const list = $('list');
    list.innerHTML = '';
    jobs.forEach((job) => {
      const li = document.createElement('li');
      li.dataset.uid = job.uid;
      li.innerHTML =
        '<div class="job-head"><span class="job-name"></span><span class="kind"></span><span class="kind factor"></span>' +
        '<button class="icon rm" title="Прибрати">✕</button></div>' +
        '<div class="res"><span class="from"></span><span class="arrow">→</span><span class="to"></span></div>' +
        '<div class="job-status"></div><div class="bar"></div>';
      li.querySelector('.job-name').textContent = job.name;
      li.querySelector('.job-name').title = job.path;
      li.querySelector('.kind').textContent = KIND[job.kind] + (job.usedIn ? ' · у ' + job.usedIn + ' шар.' : '');
      li.querySelector('.from').textContent = job.width + '×' + job.height;
      li.querySelector('.rm').onclick = () => {
        if (job.status === 'running') return;
        jobs = jobs.filter((j) => j !== job);
        renderAll();
      };
      list.appendChild(li);
      renderJob(job);
    });
    $('empty').hidden = jobs.length > 0;
    renderControls();
  }

  function renderControls() {
    document.querySelectorAll('.seg').forEach((seg) => {
      seg.querySelectorAll('button').forEach((b) => b.classList.toggle('on', String(S[seg.dataset.key]) === b.dataset.v));
    });
    $('rowTarget').hidden = S.factor !== 'size';
    $('targetCustom').hidden = $('targetPreset').value !== 'custom';
    $('rowModel').hidden = S.engine !== 'local';
    $('rowQuality').hidden = S.engine !== 'nvidia';
    $('rowMotion').hidden = S.engine === 'cloud';
    const btn = $('btnRun');
    btn.textContent = running ? 'Зупинити' : 'Запустити';
    btn.classList.toggle('stop', running);
    btn.disabled = !running && !jobs.some((j) => j.status === 'queued' || j.status === 'error');
    $('btnAdd').disabled = running;
    $('btnClear').disabled = running || !jobs.length;
  }

  // ---------------- model list & catalog ----------------
  function fillModelSelect() {
    const sel = $('localModel');
    sel.innerHTML = '';
    const g1 = document.createElement('optgroup'); g1.label = 'Вбудовані';
    BUILTIN_MODELS.forEach((m) => g1.appendChild(new Option(m.label, m.id)));
    const g2 = document.createElement('optgroup'); g2.label = 'Спільнотні';
    COMMUNITY_MODELS.forEach((m) => g2.appendChild(new Option(m.label + (haveCommunity(m.id) ? '' : ' · ⤓ ' + m.mb + ' МБ'), m.id)));
    sel.append(g1, g2);
    sel.value = S.localModel;
    if (!sel.value) { S.localModel = BUILTIN_MODELS[0].id; sel.value = S.localModel; }
  }
  function renderCatalog() {
    const box = $('modelCatalog');
    box.innerHTML = '';
    for (const m of COMMUNITY_MODELS) {
      const d = document.createElement('div');
      d.className = 'cat' + (haveCommunity(m.id) ? ' have' : '');
      d.innerHTML = '<b></b><p></p><span class="lic"></span>';
      d.querySelector('b').textContent = m.label;
      d.querySelector('p').textContent = m.desc;
      d.querySelector('.lic').textContent = m.id + ' · ' + m.license + ' · ' + m.mb + ' МБ';
      box.appendChild(d);
    }
  }

  // ---------------- NVIDIA setup ----------------
  function nvLog(text, replace) {
    const el = $('nvLog');
    el.hidden = false;
    el.textContent = replace ? text : (el.textContent + text).split(/\n/).slice(-50).join('\n');
    el.scrollTop = el.scrollHeight;
  }
  async function nvSetup() {
    if (!IS_WIN) return nvLog('Автовстановлення є лише для Windows.', true);
    syncNvFiles();
    $('btnNvSetup').disabled = true;
    nvLog('Встановлення… 5–20 хвилин (PyTorch ~3 ГБ). Можна працювати в AE далі.\n', true);
    try {
      await run('cmd.exe', ['/d', '/c', path.join(NV_DIR, 'setup_nvidia.bat')], { cwd: NV_DIR, onOutput: (t) => nvLog(t.replace(/\r(?!\n)/g, '\n')) });
      nvLog('\nГотово. Можна вибирати рушій NVIDIA.\n');
    } catch (e) { nvLog('\n' + e.message + '\n'); }
    finally { $('btnNvSetup').disabled = false; refreshBins(); }
  }
  async function nvCheck() {
    refreshBins();
    if (!bins.python) return nvLog('Python-середовище не знайдено — натисніть «Встановити».', true);
    syncNvFiles();
    nvLog('Перевіряю…\n', true);
    const out = await run(bins.python, [NV_WORKER, '--check'], { cwd: NV_DIR, allowFail: true });
    const m = out.match(/\{.*\}/s);
    let r; try { r = m ? JSON.parse(m[0]) : null; } catch (e) { r = null; }
    if (!r) return nvLog('Помилка: ' + out.slice(-300), true);
    let msg = r.ok ? 'Працює: ' + r.gpu + ' · PyTorch ' + r.torch : 'Помилка: ' + r.error;
    if (!r.ok && /No module named 'torch'/.test(r.error)) msg = 'PyTorch не встановлено — натисніть «Встановити».';
    else if (!r.ok && /No module named 'nvvfx'/.test(r.error)) msg = 'Бібліотеку nvidia-vfx не встановлено — натисніть «Встановити».';
    nvLog(msg + '\n', true);
  }

  // ---------------- wiring ----------------
  function bindSettings() {
    const ids = ['applyMode', 'keepVisual', 'quality', 'motion', 'nvPython', 'realesrganPath', 'localModel', 'gpuId', 'tile', 'ffmpegPath', 'videoCodec',
      'replicateToken', 'cloudImageModel', 'topazEnhance', 'cloudVideoModel', 'cloudConcurrency', 'customModel', 'customInput',
      'outDir', 'workDir', 'keepTemp'];
    ids.forEach((id) => {
      const el = $(id);
      if (el.type === 'checkbox') el.checked = !!S[id]; else el.value = S[id];
      el.addEventListener('change', () => {
        S[id] = el.type === 'checkbox' ? el.checked : el.value;
        save();
        if (id === 'realesrganPath' || id === 'ffmpegPath' || id === 'nvPython') refreshBins();
        if (id === 'localModel' && modelInfo(S.localModel).community && !haveCommunity(S.localModel)) {
          ensureModel(S.localModel, (m) => log(m)).then(() => log('Модель готова: ' + modelInfo(S.localModel).label))
            .catch((e) => log('Не вдалося завантажити модель: ' + e.message, true));
        }
      });
    });
    document.querySelectorAll('.seg').forEach((seg) => {
      seg.addEventListener('click', (e) => {
        const b = e.target.closest('button');
        if (!b || running) return;
        S[seg.dataset.key] = b.dataset.v;
        save();
        jobs.forEach((j) => { if (j.status !== 'done' && j.status !== 'running') j.factorUsed = null; });
        renderAll();
      });
    });
  }

  function applyTheme() {
    try {
      const c = cs.hostEnvironment.appSkinInfo.panelBackgroundColor.color;
      document.documentElement.style.setProperty('--bg', 'rgb(' + Math.round(c.red) + ',' + Math.round(c.green) + ',' + Math.round(c.blue) + ')');
    } catch (e) {}
  }

  function init() {
    applyTheme();
    fillModelSelect();
    renderCatalog();
    syncNvFiles();
    const presets = ['720', '1080', '1440', '2160'];
    $('targetPreset').value = presets.includes(String(S.target)) ? String(S.target) : 'custom';
    $('targetCustom').value = S.target;
    $('targetPreset').onchange = () => {
      if ($('targetPreset').value !== 'custom') { S.target = $('targetPreset').value; $('targetCustom').value = S.target; }
      save(); renderAll();
    };
    $('targetCustom').onchange = () => {
      let v = Math.max(64, Math.min(8640, parseInt($('targetCustom').value, 10) || 1080));
      v -= v % 2; $('targetCustom').value = v; S.target = String(v); save(); renderAll();
    };
    $('btnNvSetup').onclick = nvSetup;
    $('btnNvCheck').onclick = nvCheck;
    cs.addEventListener('com.adobe.csxs.events.ThemeColorChanged', applyTheme);
    ensureHostLoaded();
    bindSettings();
    refreshBins();

    $('btnAdd').onclick = async () => {
      const r = await host('hfu_getSelection');
      if (!r.ok) return log(r.error, true);
      if (!r.items.length) return log('Нічого не вибрано: виділіть футажі в Project або шари з футажем у композиції.', true);
      let added = 0;
      r.items.forEach((it) => {
        if (jobs.some((j) => j.id === it.id && j.status !== 'done')) return;
        jobs.push(makeJob(it)); added++;
      });
      if (!added) log('Ці футажі вже в черзі.');
      renderAll();
    };
    $('btnClear').onclick = () => { jobs = jobs.filter((j) => j.status === 'running'); renderAll(); };
    $('btnRun').onclick = () => (running ? stopQueue() : startQueue());

    const toggleSettings = (show) => {
      $('settings').hidden = !show;
      $('btnSettings').setAttribute('aria-expanded', String(show));
      if (show) refreshBins();
    };
    $('btnSettings').onclick = () => toggleSettings($('settings').hidden);
    $('btnCloseSettings').onclick = () => toggleSettings(false);
    $('btnDlRealesrgan').onclick = () => installTool('realesrgan');
    $('btnDlFfmpeg').onclick = () => installTool('ffmpeg');
    refreshBins();
    if (!bins.realesrgan || !bins.ffmpeg) {
      log('Для локального рушія бракує: ' + [!bins.realesrgan && 'Real-ESRGAN', !bins.ffmpeg && 'ffmpeg'].filter(Boolean).join(', ') +
        '. Їх можна завантажити в налаштуваннях (⚙).');
    }

    renderAll();
  }

  init();
})();
