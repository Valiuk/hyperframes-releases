/* FaceCut — ExtendScript side (After Effects) */

function fc_str(v) {
    if (v === null || v === undefined) return "null";
    var t = typeof v;
    if (t === "number") return isFinite(v) ? String(v) : "null";
    if (t === "boolean") return v ? "true" : "false";
    if (t === "string") return '"' + encodeURIComponent(v) + '"';   // decoded in the panel
    if (v instanceof Array) {
        var a = [];
        for (var i = 0; i < v.length; i++) a.push(fc_str(v[i]));
        return "[" + a.join(",") + "]";
    }
    var p = [];
    for (var k in v) if (v.hasOwnProperty(k)) p.push('"' + k + '":' + fc_str(v[k]));
    return "{" + p.join(",") + "}";
}

function fc_parse(s) {
    s = decodeURIComponent(s);
    if (typeof JSON !== "undefined" && JSON.parse) return JSON.parse(s);
    return eval("(" + s + ")");
}

function fc_err(msg) { return fc_str({ error: msg }); }

/* Selected footage layers of the active comp */
function fc_getSelected() {
    try {
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) return fc_err("Відкрий композицію і виділи шари з відео.");
        var sel = comp.selectedLayers;
        if (!sel.length) return fc_err("Виділи один або кілька шарів з відео (ракурси).");
        var out = [], skipped = [];
        for (var i = 0; i < sel.length; i++) {
            var L = sel[i];
            var src = L.source;
            if (!(L instanceof AVLayer) || !src || !(src instanceof FootageItem) || !src.file ||
                src.mainSource.isStill || !src.hasVideo) { skipped.push(L.name + " (не відео)"); continue; }
            if (L.timeRemapEnabled) { skipped.push(L.name + " (Time Remap)"); continue; }
            if (Math.abs(L.stretch - 100) > 0.001) { skipped.push(L.name + " (Stretch " + L.stretch + "%)"); continue; }
            var s0 = Math.max(0, L.inPoint - L.startTime);
            var s1 = Math.min(src.duration, L.outPoint - L.startTime);
            if (s1 - s0 < comp.frameDuration) { skipped.push(L.name + " (порожній)"); continue; }
            out.push({
                index: L.index, name: L.name, path: src.file.fsName,
                srcStart: s0, srcEnd: s1, startTime: L.startTime,
                inPoint: L.inPoint, outPoint: L.outPoint
            });
        }
        return fc_str({ compId: comp.id, compName: comp.name, fps: comp.frameRate, layers: out, skipped: skipped });
    } catch (e) { return fc_err(e.toString()); }
}

function fc_findComp(id) {
    for (var i = 1; i <= app.project.numItems; i++) {
        var it = app.project.item(i);
        if (it instanceof CompItem && it.id === id) return it;
    }
    return null;
}

function fc_round(t, fd) { return Math.round(t / fd) * fd; }

/*
 payload: { compId, mode: keep|remove|newcomp|markers, minDur,
            layers: [{ index, name, segs: [[srcA, srcB], ...] }] }
*/
function fc_apply(encoded) {
    var P;
    try { P = fc_parse(encoded); } catch (e) { return fc_err("Bad payload: " + e); }
    var comp = fc_findComp(P.compId);
    if (!comp) return fc_err("Композицію не знайдено.");
    var fd = comp.frameDuration;
    var minLen = Math.max(fd, P.minDur || 0);

    // resolve layers and convert to comp time
    var work = [];
    for (var i = 0; i < P.layers.length; i++) {
        var d = P.layers[i];
        if (d.index > comp.numLayers) return fc_err("Шари змінилися після аналізу. Проаналізуй ще раз.");
        var L = comp.layer(d.index);
        if (L.locked && P.mode !== "newcomp") return fc_err("Шар заблоковано: " + L.name);
        if (L.name !== d.name) return fc_err("Шари змінилися після аналізу (" + d.name + "). Проаналізуй ще раз.");
        var segs = [];
        for (var j = 0; j < d.segs.length; j++) {
            var a = fc_round(L.startTime + d.segs[j][0], fd), b = fc_round(L.startTime + d.segs[j][1], fd);
            a = Math.max(a, L.inPoint); b = Math.min(b, L.outPoint);
            if (b - a >= fd - 1e-6) segs.push([a, b]);
        }
        work.push({ L: L, segs: segs });
    }

    app.beginUndoGroup("Face Cut");
    var made = 0;
    try {
        if (P.mode === "markers") {
            for (i = 0; i < work.length; i++) {
                var mk = work[i].L.property("ADBE Marker");
                for (j = 0; j < work[i].segs.length; j++) {
                    var mv = new MarkerValue("FaceCut " + (j + 1));
                    mv.duration = work[i].segs[j][1] - work[i].segs[j][0];
                    mk.setValueAtTime(work[i].segs[j][0], mv);
                    made++;
                }
            }
        } else if (P.mode === "keep" || P.mode === "remove") {
            for (i = 0; i < work.length; i++) {
                var W = work[i], parts = W.segs;
                if (P.mode === "remove" && !W.segs.length) continue;
                if (P.mode === "remove") {
                    parts = [];
                    var cur = W.L.inPoint;
                    for (j = 0; j < W.segs.length; j++) {
                        if (W.segs[j][0] - cur >= minLen - 1e-6) parts.push([cur, W.segs[j][0]]);
                        cur = Math.max(cur, W.segs[j][1]);
                    }
                    if (W.L.outPoint - cur >= minLen - 1e-6) parts.push([cur, W.L.outPoint]);
                }
                var base = W.L.name;
                for (j = 0; j < parts.length; j++) {
                    var D = W.L.duplicate();
                    D.inPoint = parts[j][0];
                    D.outPoint = parts[j][1];
                    D.name = base + " · FC " + (j + 1);
                    made++;
                }
                W.L.remove();
            }
        } else if (P.mode === "newcomp") {
            // multicam: where angles overlap in time, the upper layer wins
            work.sort(function (x, y) { return x.L.index - y.L.index; });
            var covered = [], pieces = [];
            for (i = 0; i < work.length; i++) {
                for (j = 0; j < work[i].segs.length; j++) {
                    var rest = [work[i].segs[j]];
                    for (var c = 0; c < covered.length; c++) {
                        var nr = [];
                        for (var r = 0; r < rest.length; r++) {
                            var ra = rest[r][0], rb = rest[r][1], ca = covered[c][0], cb = covered[c][1];
                            if (cb <= ra || ca >= rb) { nr.push(rest[r]); continue; }
                            if (ca > ra) nr.push([ra, ca]);
                            if (cb < rb) nr.push([cb, rb]);
                        }
                        rest = nr;
                    }
                    for (r = 0; r < rest.length; r++) {
                        if (rest[r][1] - rest[r][0] >= minLen - 1e-6) pieces.push({ L: work[i].L, a: rest[r][0], b: rest[r][1] });
                    }
                    covered.push(work[i].segs[j]);
                }
            }
            if (!pieces.length) { app.endUndoGroup(); return fc_err("Немає фрагментів."); }
            pieces.sort(function (x, y) { return x.a - y.a; });
            var total = 0;
            for (i = 0; i < pieces.length; i++) total += pieces[i].b - pieces[i].a;
            var NC = app.project.items.addComp(comp.name + " — FaceCut", comp.width, comp.height,
                comp.pixelAspect, Math.max(fd, fc_round(total, fd)), comp.frameRate);
            var cursor = 0;
            for (i = 0; i < pieces.length; i++) {
                var p = pieces[i];
                p.L.copyToComp(NC);
                var X = NC.layer(1);
                X.startTime = p.L.startTime + (cursor - p.a);
                X.inPoint = cursor;
                X.outPoint = cursor + (p.b - p.a);
                X.name = p.L.name + " · FC " + (i + 1);
                X.moveToEnd();
                cursor = X.outPoint;
                made++;
            }
            NC.openInViewer();
        }
    } catch (e) {
        app.endUndoGroup();
        return fc_err("Помилка: " + e.toString() + " (рядок " + e.line + ")");
    }
    app.endUndoGroup();
    return fc_str({ ok: true, made: made });
}
