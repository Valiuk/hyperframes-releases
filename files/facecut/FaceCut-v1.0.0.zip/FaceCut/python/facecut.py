# -*- coding: utf-8 -*-
"""
FaceCut backend: face detection + recognition for the After Effects panel.

Usage:  python facecut.py job.json
Prints JSON lines to stdout: {"type": "log"|"progress"|"result"|"error", ...}

Models: OpenCV YuNet (detection) + SFace (recognition), downloaded on first run
to ~/.facecut/models. They are loaded from memory buffers, so Cyrillic paths are fine.
"""
import sys, os, json, hashlib, subprocess, base64, time, urllib.request
from collections import deque

import numpy as np
import cv2

HOME = os.path.join(os.path.expanduser("~"), ".facecut")
MODELS_DIR = os.path.join(HOME, "models")
CACHE_DIR = os.path.join(HOME, "cache")

MODELS = {
    "yunet": ("face_detection_yunet_2023mar.onnx",
              "https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx"),
    "sface": ("face_recognition_sface_2021dec.onnx",
              "https://github.com/opencv/opencv_zoo/raw/main/models/face_recognition_sface/face_recognition_sface_2021dec.onnx"),
}

CACHE_VERSION = 2
NO_WINDOW = 0x08000000 if os.name == "nt" else 0  # CREATE_NO_WINDOW


def emit(obj):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def log(msg):
    emit({"type": "log", "msg": msg})


# ---------------------------------------------------------------- models
def model_bytes(key):
    name, url = MODELS[key]
    os.makedirs(MODELS_DIR, exist_ok=True)
    path = os.path.join(MODELS_DIR, name)
    if not os.path.exists(path) or os.path.getsize(path) < 10000:
        log("Завантажую модель %s…" % name)
        tmp = path + ".part"
        try:
            urllib.request.urlretrieve(url, tmp)
            if os.path.getsize(tmp) < 10000:
                raise RuntimeError("файл замалий — можливо, це сторінка помилки")
            os.replace(tmp, path)
        except Exception as e:
            raise RuntimeError("Не вдалося завантажити %s (%s). Завантаж вручну з %s і поклади в %s"
                               % (name, e, url, MODELS_DIR))
    with open(path, "rb") as f:
        return np.frombuffer(f.read(), dtype=np.uint8)


# ---------------------------------------------------------------- ffmpeg helpers
def probe(ffprobe, path):
    cmd = [ffprobe, "-v", "error", "-select_streams", "v:0",
           "-show_entries", "stream=width,height,r_frame_rate,avg_frame_rate:stream_side_data=rotation:stream_tags=rotate",
           "-of", "json", path]
    out = subprocess.run(cmd, capture_output=True, creationflags=NO_WINDOW)
    if out.returncode != 0:
        raise RuntimeError("ffprobe: " + out.stderr.decode("utf-8", "replace")[-400:])
    st = json.loads(out.stdout.decode("utf-8", "replace"))["streams"][0]
    w, h = int(st["width"]), int(st["height"])
    rot = 0
    try:
        rot = int(float(st.get("tags", {}).get("rotate", 0)))
    except Exception:
        pass
    for sd in st.get("side_data_list", []) or []:
        if "rotation" in sd:
            try:
                rot = int(float(sd["rotation"]))
            except Exception:
                pass
    if abs(rot) % 180 == 90:
        w, h = h, w

    def rate(s):
        try:
            a, b = s.split("/")
            v = float(a) / float(b)
            return v if 1 < v < 1000 else None
        except Exception:
            return None
    fps = rate(st.get("avg_frame_rate", "")) or rate(st.get("r_frame_rate", "")) or 25.0
    return w, h, fps


def analysis_size(w, h, width):
    W = min(int(width), w)
    W -= W % 2
    H = int(round(W * h / float(w) / 2.0)) * 2
    return W, H


def ffmpeg_reader(ffmpeg, path, start, dur, W, H, out_fps=None, sample_fps=None):
    vf = "scale=%d:%d:flags=area" % (W, H)
    if sample_fps:
        vf = "fps=%g," % sample_fps + vf
    cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin",
           "-ss", "%.4f" % start, "-i", path, "-t", "%.4f" % dur,
           "-an", "-sn", "-dn", "-vf", vf]
    if out_fps:
        cmd += ["-fps_mode", "cfr", "-r", "%.6f" % out_fps]
    cmd += ["-pix_fmt", "bgr24", "-f", "rawvideo", "-"]
    return subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            bufsize=W * H * 3 * 4, creationflags=NO_WINDOW)


def grab_frame(ffmpeg, path, t, W, H):
    cmd = [ffmpeg, "-hide_banner", "-loglevel", "error", "-nostdin", "-ss", "%.4f" % t, "-i", path,
           "-frames:v", "1", "-an", "-vf", "scale=%d:%d:flags=area" % (W, H),
           "-pix_fmt", "bgr24", "-f", "rawvideo", "-"]
    out = subprocess.run(cmd, capture_output=True, creationflags=NO_WINDOW)
    data = out.stdout
    if len(data) < W * H * 3:
        return None
    return np.frombuffer(data[:W * H * 3], np.uint8).reshape(H, W, 3)


# ---------------------------------------------------------------- analysis of one item
def cache_key(item, job):
    st = os.stat(item["path"])
    s = json.dumps([CACHE_VERSION, item["path"], st.st_size, int(st.st_mtime),
                    round(item["start"], 3), round(item["end"], 3),
                    job["step"], job["width"], bool(job["scenes"])])
    return hashlib.sha1(s.encode("utf-8")).hexdigest()[:20]


def analyze_item(idx, n_items, item, job, det, rec):
    ffmpeg, ffprobe = job.get("ffmpeg") or "ffmpeg", job.get("ffprobe") or "ffprobe"
    path = item["path"]
    if not os.path.exists(path):
        raise RuntimeError("Файл не знайдено: " + path)

    key = cache_key(item, job)
    cpath = os.path.join(CACHE_DIR, key + ".npz")
    if os.path.exists(cpath):
        try:
            d = np.load(cpath, allow_pickle=False)
            log("%s — з кешу" % item.get("name", os.path.basename(path)))
            emit({"type": "progress", "item": idx, "n": n_items, "p": 1.0})
            return {k: d[k] for k in d.files}
        except Exception:
            pass

    w, h, fps = probe(ffprobe, path)
    W, H = analysis_size(w, h, job["width"])
    start = max(0.0, float(item["start"]))
    dur = max(0.04, float(item["end"]) - start)
    step = float(job["step"])
    scenes = bool(job["scenes"])

    det.setInputSize((W, H))
    if scenes:
        proc = ffmpeg_reader(ffmpeg, path, start, dur, W, H, out_fps=fps)
        every = max(1, int(round(fps / step)))
        frame_dt = 1.0 / fps
    else:
        proc = ffmpeg_reader(ffmpeg, path, start, dur, W, H, sample_fps=step)
        every = 1
        frame_dt = 1.0 / step
    total = max(1, int(dur / frame_dt))

    fsize = W * H * 3
    k = 0
    prev = None
    hist = deque(maxlen=20)
    cuts, s_times = [], []
    f_t, f_hf, f_box, f_score, f_emb = [], [], [], [], []
    last_emit = 0

    while True:
        buf = proc.stdout.read(fsize)
        if len(buf) < fsize:
            break
        frame = np.frombuffer(buf, np.uint8).reshape(H, W, 3)
        t = k * frame_dt

        if scenes:
            small = cv2.resize(frame, (32, 18), interpolation=cv2.INTER_AREA).astype(np.int16)
            if prev is not None:
                d = float(np.mean(np.abs(small - prev)))
                med = float(np.median(hist)) if len(hist) >= 3 else 3.0
                if d > max(14.0, 4.0 * med + 4.0):
                    cuts.append(t)
                hist.append(d)
            prev = small

        if k % every == 0:
            s_times.append(t)
            _, faces = det.detect(frame)
            if faces is not None:
                for f in faces:
                    fw, fh = float(f[2]), float(f[3])
                    if fh < 20 or fw < 14:
                        continue
                    try:
                        crop = rec.alignCrop(frame, f)
                        e = rec.feature(crop).flatten().astype(np.float32)
                    except cv2.error:
                        continue
                    nrm = np.linalg.norm(e)
                    if nrm < 1e-6:
                        continue
                    f_t.append(t)
                    f_hf.append(fh / H)
                    f_box.append([f[0], f[1], fw, fh])
                    f_score.append(float(f[14]))
                    f_emb.append(e / nrm)
        k += 1
        if k - last_emit >= 25:
            last_emit = k
            emit({"type": "progress", "item": idx, "n": n_items, "p": min(1.0, k / float(total))})

    proc.stdout.close()
    err = proc.stderr.read().decode("utf-8", "replace")
    proc.wait()
    if k == 0:
        raise RuntimeError("ffmpeg не віддав жодного кадру: " + err[-400:])
    emit({"type": "progress", "item": idx, "n": n_items, "p": 1.0})

    res = {
        "meta": np.array([fps, W, H, start, dur, step, 1.0 if scenes else 0.0], np.float64),
        "s_times": np.array(s_times, np.float32),
        "cuts": np.array(cuts, np.float32),
        "f_t": np.array(f_t, np.float32),
        "f_hf": np.array(f_hf, np.float32),
        "f_box": np.array(f_box, np.float32).reshape(-1, 4),
        "f_score": np.array(f_score, np.float32),
        "f_emb": np.array(f_emb, np.float32).reshape(-1, 128),
    }
    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        with open(cpath, "wb") as fh_:
            np.savez_compressed(fh_, **res)
    except Exception as e:
        log("Кеш не збережено: %s" % e)
    log("%s — облич: %d, склейок: %d" % (item.get("name", os.path.basename(path)), len(f_t), len(cuts)))
    return res


# ---------------------------------------------------------------- clustering
def cluster(E, quality, t_assign=0.40, t_keep=0.30, t_merge=0.55):
    """Greedy centroid clustering on L2-normalised embeddings (cosine)."""
    N = len(E)
    if N == 0:
        return np.zeros(0, np.int32), np.zeros((0, 128), np.float32)
    order = np.argsort(-quality)  # best faces seed the clusters
    sums = []
    C = np.zeros((0, E.shape[1]), np.float32)
    for i in order:
        e = E[i]
        if len(C):
            s = C @ e
            j = int(np.argmax(s))
            if s[j] >= t_assign:
                sums[j] += e
                C[j] = sums[j] / np.linalg.norm(sums[j])
                continue
        sums.append(e.copy())
        C = np.vstack([C, e[None]])

    # merge very similar centroids (same person split by angle/light)
    K = len(C)
    parent = list(range(K))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    S = C @ C.T
    for a in range(K):
        for b in range(a + 1, K):
            if S[a, b] >= t_merge:
                parent[find(b)] = find(a)
    groups = {}
    for a in range(K):
        groups.setdefault(find(a), []).append(a)
    C2 = []
    for g in groups.values():
        v = np.sum([sums[a] for a in g], axis=0)
        C2.append(v / np.linalg.norm(v))
    C = np.array(C2, np.float32)

    # final assignment
    sims = E @ C.T
    best = np.argmax(sims, axis=1)
    bs = sims[np.arange(N), best]
    labels = np.where(bs >= t_keep, best, -1).astype(np.int32)

    # drop tiny clusters, renumber by size
    counts = np.bincount(labels[labels >= 0], minlength=len(C))
    min_count = max(4, int(0.003 * N))
    keep = [c for c in np.argsort(-counts) if counts[c] >= min_count]
    remap = {int(c): i for i, c in enumerate(keep)}
    labels = np.array([remap.get(int(l), -1) for l in labels], np.int32)
    return labels, C[keep] if keep else np.zeros((0, E.shape[1]), np.float32)


def make_thumb(ffmpeg, ffprobe, path, start, t, box, W, H):
    img = grab_frame(ffmpeg, path, start + t, W, H)
    if img is None:
        return ""
    x, y, w, h = [float(v) for v in box]
    cx, cy = x + w / 2, y + h / 2
    s = max(w, h) * 1.6
    x0, y0 = int(max(0, cx - s / 2)), int(max(0, cy - s / 2))
    x1, y1 = int(min(W, cx + s / 2)), int(min(H, cy + s / 2))
    crop = img[y0:y1, x0:x1]
    if crop.size == 0:
        return ""
    crop = cv2.resize(crop, (112, 112), interpolation=cv2.INTER_AREA)
    ok, jpg = cv2.imencode(".jpg", crop, [cv2.IMWRITE_JPEG_QUALITY, 85])
    return base64.b64encode(jpg.tobytes()).decode("ascii") if ok else ""


# ---------------------------------------------------------------- main
def cmd_analyze(job):
    items = job["items"]
    det = cv2.FaceDetectorYN.create("onnx", model_bytes("yunet"), np.array([], np.uint8),
                                    (320, 320), 0.75, 0.3, 5000)
    rec = cv2.FaceRecognizerSF.create("onnx", model_bytes("sface"), np.array([], np.uint8))

    results = []
    for i, it in enumerate(items):
        results.append(analyze_item(i, len(items), it, job, det, rec))

    # gather all faces across all layers (cross-angle matching)
    E, Q, owner, local = [], [], [], []
    for i, r in enumerate(results):
        n = len(r["f_t"])
        if n:
            E.append(r["f_emb"])
            Q.append(r["f_score"] * r["f_hf"])
            owner += [i] * n
            local += list(range(n))
    if not E:
        emit({"type": "result", "data": {"items": [], "clusters": [], "warning": "Облич не знайдено"}})
        return
    E = np.vstack(E)
    Q = np.concatenate(Q)
    owner = np.array(owner)
    local = np.array(local)
    log("Групую %d облич…" % len(E))
    labels, C = cluster(E, Q)

    clusters = []
    for c in range(len(C)):
        idx = np.where(labels == c)[0]
        b = idx[int(np.argmax(Q[idx]))]
        r = results[owner[b]]
        fps, W, H, start = r["meta"][:4]
        thumb = make_thumb(job.get("ffmpeg") or "ffmpeg", job.get("ffprobe") or "ffprobe",
                           items[owner[b]]["path"], float(start), float(r["f_t"][local[b]]),
                           r["f_box"][local[b]], int(W), int(H))
        layers = sorted(set(int(x) for x in owner[idx]))
        clusters.append({"id": c, "count": int(len(idx)), "layers": layers, "thumb": thumb})

    out_items = []
    pos = 0
    for i, r in enumerate(results):
        n = len(r["f_t"])
        lab = labels[pos:pos + n]
        pos += n
        fps, W, H, start, dur, step, sc = [float(v) for v in r["meta"]]
        # faces per sample time: [[cluster, heightFrac], ...]
        faces_by_t = {}
        for j in range(n):
            faces_by_t.setdefault(round(float(r["f_t"][j]), 4), []).append(
                [int(lab[j]), round(float(r["f_hf"][j]), 3)])
        samples = [[round(float(t), 4), faces_by_t.get(round(float(t), 4), [])] for t in r["s_times"]]
        out_items.append({
            "id": items[i].get("id"), "fps": fps, "start": start, "dur": dur,
            "step": step, "scenes": bool(sc),
            "cuts": [round(float(c), 4) for c in r["cuts"]],
            "samples": samples,
        })
    emit({"type": "result", "data": {"items": out_items, "clusters": clusters}})


def main():
    if len(sys.argv) < 2:
        emit({"type": "error", "msg": "usage: facecut.py job.json"})
        return
    with open(sys.argv[1], "r", encoding="utf-8") as f:
        job = json.load(f)
    try:
        if job.get("cmd") == "analyze":
            t0 = time.time()
            cmd_analyze(job)
            log("Готово за %.1f с" % (time.time() - t0))
        elif job.get("cmd") == "check":
            model_bytes("yunet"); model_bytes("sface")
            emit({"type": "result", "data": {"ok": True, "cv2": cv2.__version__}})
        else:
            emit({"type": "error", "msg": "unknown cmd"})
    except FileNotFoundError as e:
        emit({"type": "error", "msg": "Не знайдено програму (ffmpeg/ffprobe?): %s" % e})
    except Exception as e:
        import traceback
        emit({"type": "error", "msg": str(e), "trace": traceback.format_exc()[-1500:]})


if __name__ == "__main__":
    main()
