/* FaceCut — panel logic */
(function () {
  "use strict";
  var cp = require("child_process"), fs = require("fs"), path = require("path"), os = require("os");

  var $ = function (id) { return document.getElementById(id); };
  var isWin = os.platform() === "win32";
  var extDir = (function () {
    var p = decodeURIComponent(location.pathname);
    if (isWin && /^\/[A-Za-z]:/.test(p)) p = p.slice(1);
    return path.dirname(p);
  })();
  var PY_SCRIPT = path.join(extDir, "python", "facecut.py");

  var state = { info: null, result: null, sel: new Set(), proc: null, segs: [] };

  // ------------------------------------------------ settings
  var SETTINGS = ["python", "ffmpeg", "ffprobe", "step", "width", "gap", "minDur", "minFace"];
  function loadSettings() {
    try {
      var s = JSON.parse(localStorage.getItem("facecut") || "{}");
      SETTINGS.forEach(function (k) { if (s[k] !== undefined) $(k).value = s[k]; });
      if (s.solo !== undefined) $("solo").checked = s.solo;
      if (s.snap !== undefined) $("snap").checked = s.snap;
      if (s.mode) { var r = document.querySelector('input[name=mode][value="' + s.mode + '"]'); if (r) r.checked = true; }
    } catch (e) {}
  }
  function saveSettings() {
    var s = {};
    SETTINGS.forEach(function (k) { s[k] = $(k).value; });
    s.solo = $("solo").checked; s.snap = $("snap").checked; s.mode = mode();
    try { localStorage.setItem("facecut", JSON.stringify(s)); } catch (e) {}
  }
  function mode() { return document.querySelector("input[name=mode]:checked").value; }
  function num(id, d) { var v = parseFloat($(id).value); return isFinite(v) ? v : d; }

  // ------------------------------------------------ ui helpers
  function status(msg, err) { var s = $("status"); s.textContent = msg; s.className = err ? "err" : ""; }
  function progress(p) { $("prog").style.width = Math.round(Math.max(0, Math.min(1, p)) * 100) + "%"; }
  function busy(on) {
    $("btnAnalyze").disabled = on; $("btnApply").disabled = on;
    $("btnCancel").classList.toggle("hide", !on);
  }

  // ------------------------------------------------ AE bridge
  function decodeDeep(v) {
    if (typeof v === "string") return decodeURIComponent(v);
    if (Array.isArray(v)) return v.map(decodeDeep);
    if (v && typeof v === "object") { var o = {}; for (var k in v) o[k] = decodeDeep(v[k]); return o; }
    return v;
  }
  function jsx(code, cb) {
    window.__adobe_cep__.evalScript(code, function (res) {
      var out;
      try { out = decodeDeep(JSON.parse(res)); } catch (e) { out = { error: "AE: " + res }; }
      cb(out);
    });
  }

  // ------------------------------------------------ python bridge
  function runPython(job, onMsg, onDone) {
    var jobPath = path.join(os.tmpdir(), "facecut_job_" + Date.now() + ".json");
    fs.writeFileSync(jobPath, JSON.stringify(job), "utf8");
    var env = Object.assign({}, process.env, { PYTHONIOENCODING: "utf-8", PYTHONUTF8: "1" });
    var p;
    try {
      p = cp.spawn($("python").value || "python", ["-u", PY_SCRIPT, jobPath], { env: env, windowsHide: true });
    } catch (e) { onDone("Не вдалося запустити Python: " + e.message); return null; }
    var buf = "", errBuf = "", gotResult = false;
    p.stdout.setEncoding("utf8");
    p.stdout.on("data", function (d) {
      buf += d;
      var lines = buf.split("\n"); buf = lines.pop();
      lines.forEach(function (l) {
        if (!l.trim()) return;
        var m; try { m = JSON.parse(l); } catch (e) { return; }
        if (m.type === "result" || m.type === "error") gotResult = true;
        onMsg(m);
      });
    });
    p.stderr.setEncoding("utf8");
    p.stderr.on("data", function (d) { errBuf += d; if (errBuf.length > 8000) errBuf = errBuf.slice(-4000); });
    p.on("error", function (e) { onDone("Python не знайдено (" + e.message + "). Вкажи шлях у Налаштуваннях."); });
    p.on("close", function (code) {
      try { fs.unlinkSync(jobPath); } catch (e) {}
      if (code !== 0 && !gotResult) {
        var hint = /No module named/.test(errBuf) ? "\nЗапусти install.bat або: pip install opencv-python numpy" : "";
        onDone((errBuf.trim().split("\n").slice(-3).join("\n") || ("Python завершився з кодом " + code)) + hint);
      } else onDone(null);
    });
    return p;
  }

  // ------------------------------------------------ analyze
  function analyze() {
    saveSettings();
    jsx("fc_getSelected()", function (info) {
      if (info.error) { status(info.error, true); return; }
      if (!info.layers.length) { status("Немає придатних шарів.\n" + info.skipped.join("\n"), true); return; }
      state.info = info; state.result = null; state.sel = new Set();
      $("pickBlock").classList.add("hide");
      busy(true); progress(0);
      status("Аналізую " + info.layers.length + " шар(ів)…" + (info.skipped.length ? "\nПропущено: " + info.skipped.join(", ") : ""));
      var job = {
        cmd: "analyze", python: $("python").value, ffmpeg: $("ffmpeg").value, ffprobe: $("ffprobe").value,
        step: num("step", 5), width: num("width", 960), scenes: true,
        items: info.layers.map(function (L, i) {
          return { id: i, name: L.name, path: L.path, start: L.srcStart, end: L.srcEnd };
        })
      };
      var errMsg = null;
      state.proc = runPython(job, function (m) {
        if (m.type === "progress") progress((m.item + m.p) / m.n);
        else if (m.type === "log") status(m.msg);
        else if (m.type === "error") errMsg = m.msg;
        else if (m.type === "result") state.result = m.data;
      }, function (err) {
        state.proc = null; busy(false);
        if (err || errMsg) { status(err || errMsg, true); return; }
        if (!state.result || !state.result.clusters.length) { status("Облич не знайдено.", true); return; }
        progress(1);
        renderFaces();
      });
    });
  }

  function renderFaces() {
    var box = $("faces"); box.innerHTML = "";
    var R = state.result, n = state.info.layers.length;
    R.clusters.forEach(function (c) {
      var d = document.createElement("div");
      d.className = "face";
      d.title = c.count + " кадрів; шари: " + c.layers.map(function (i) { return state.info.layers[i].name; }).join(", ");
      d.innerHTML = (c.thumb ? '<img src="data:image/jpeg;base64,' + c.thumb + '">' : '<img>') +
        '<div class="n">' + c.count + (n > 1 ? " · " + c.layers.length + "/" + n + " рак." : "") + "</div>";
      d.onclick = function () {
        if (state.sel.has(c.id)) state.sel.delete(c.id); else state.sel.add(c.id);
        d.classList.toggle("sel", state.sel.has(c.id));
        recompute();
      };
      box.appendChild(d);
    });
    $("pickBlock").classList.remove("hide");
    status("Знайдено людей: " + R.clusters.length + ". Клікни на співрозмовника. Якщо він розбився на 2 картки (анфас/профіль) — вибери обидві.");
    recompute();
  }

  function recompute() {
    if (!state.result) return;
    var opt = {
      clusters: state.sel, gap: num("gap", 0.5), minDur: num("minDur", 0.4),
      minFace: num("minFace", 0) / 100, solo: $("solo").checked, snap: $("snap").checked
    };
    state.segs = state.result.items.map(function (it) { return FaceCutSeg.computeSegments(it, opt); });
    if (!state.sel.size) { $("summary").textContent = "Вибери обличчя вище."; return; }
    var cnt = 0, tot = 0, lines = [];
    state.segs.forEach(function (s, i) {
      var t = 0; s.forEach(function (x) { t += x[1] - x[0]; });
      cnt += s.length; tot += t;
      if (state.segs.length > 1) lines.push(state.info.layers[i].name + ": " + s.length + " фр., " + FaceCutSeg.fmtTime(t));
    });
    $("summary").textContent = "Фрагментів: " + cnt + ", разом " + FaceCutSeg.fmtTime(tot) + (lines.length ? "\n" + lines.join("\n") : "");
    $("summary").style.whiteSpace = "pre-wrap";
  }

  function apply() {
    if (!state.result || !state.sel.size) { status("Спочатку вибери обличчя.", true); return; }
    saveSettings();
    recompute();
    var payload = {
      compId: state.info.compId, mode: mode(), minDur: num("minDur", 0.4),
      layers: state.info.layers.map(function (L, i) { return { index: L.index, name: L.name, segs: state.segs[i] }; })
    };
    status("Застосовую…");
    jsx('fc_apply("' + encodeURIComponent(JSON.stringify(payload)) + '")', function (r) {
      if (r.error) { status(r.error, true); return; }
      status("Готово: " + r.made + (mode() === "markers" ? " маркерів." : " фрагментів.") +
        (mode() === "keep" || mode() === "remove" ? "\nШари змінено — для нового запуску проаналізуй знову (з кешу це миттєво)." : ""));
      if (mode() === "keep" || mode() === "remove") { state.result = null; $("pickBlock").classList.add("hide"); }
    });
  }

  function check() {
    saveSettings(); status("Перевіряю…");
    var msg = null, res = null;
    runPython({ cmd: "check" }, function (m) {
      if (m.type === "log") status(m.msg);
      if (m.type === "error") msg = m.msg;
      if (m.type === "result") res = m.data;
    }, function (err) {
      if (err || msg) { status(err || msg, true); return; }
      cp.execFile($("ffmpeg").value || "ffmpeg", ["-version"], { windowsHide: true }, function (e, out) {
        if (e) status("Python і моделі OK (OpenCV " + res.cv2 + "), але ffmpeg не знайдено. Вкажи шлях.", true);
        else status("Усе OK. OpenCV " + res.cv2 + ", " + String(out).split("\n")[0]);
      });
    });
  }

  // ------------------------------------------------ wire up
  loadSettings();
  $("btnAnalyze").onclick = analyze;
  $("btnApply").onclick = apply;
  $("btnCheck").onclick = check;
  $("btnCancel").onclick = function () {
    if (state.proc) { try { state.proc.kill(); } catch (e) {} }
    busy(false); status("Скасовано.");
  };
  ["gap", "minDur", "minFace", "solo", "snap"].forEach(function (id) {
    $(id).addEventListener("input", recompute); $(id).addEventListener("change", recompute);
  });
})();
