/* FaceCut — builds segments from analysis samples. Pure logic, no AE / DOM. */
(function (root) {
  "use strict";

  /**
   * item: { fps, start, dur, step, cuts:[t], samples:[[t, [[cluster, hFrac], ...]], ...] }
   *       (all times relative to item.start, i.e. to the analysed range)
   * opt:  { clusters:Set|Array, gap, minDur, minFace, solo, snap }
   * returns [[a,b], ...] in SOURCE time (item.start added), frame-rounded.
   */
  function computeSegments(item, opt) {
    var sel = opt.clusters instanceof Set ? opt.clusters : new Set(opt.clusters || []);
    if (!sel.size || !item.samples.length) return [];
    var dt = 1 / item.step;
    var half = dt / 2;
    var cuts = opt.snap ? (item.cuts || []) : [];
    var minFace = opt.minFace || 0;

    // 1. hit samples -> raw intervals
    var iv = [];
    for (var i = 0; i < item.samples.length; i++) {
      var t = item.samples[i][0], faces = item.samples[i][1];
      var hit = false, other = false;
      for (var j = 0; j < faces.length; j++) {
        var c = faces[j][0], hf = faces[j][1];
        if (sel.has(c)) { if (hf >= minFace) hit = true; }
        else if (hf >= Math.max(0.04, minFace * 0.5)) other = true;
      }
      if (hit && !(opt.solo && other)) {
        var a = Math.max(0, t - half), b = Math.min(item.dur, t + half);
        if (iv.length && a <= iv[iv.length - 1][1] + 1e-6) iv[iv.length - 1][1] = b;
        else iv.push([a, b]);
      }
    }
    if (!iv.length) return [];

    function cutBetween(a, b) {
      for (var k = 0; k < cuts.length; k++) if (cuts[k] > a + 1e-6 && cuts[k] < b - 1e-6) return true;
      return false;
    }
    function nearestCut(t, maxD) {
      var best = null, bd = maxD;
      for (var k = 0; k < cuts.length; k++) {
        var d = Math.abs(cuts[k] - t);
        if (d <= bd) { bd = d; best = cuts[k]; }
      }
      return best;
    }

    // 2. snap edges to real cuts of the source (no stray frames of a neighbour shot)
    if (cuts.length) {
      for (i = 0; i < iv.length; i++) {
        var ca = nearestCut(iv[i][0], dt), cb = nearestCut(iv[i][1], dt);
        if (ca !== null) iv[i][0] = ca;
        if (cb !== null) iv[i][1] = cb;
        if (iv[i][0] < 0.02) iv[i][0] = 0;  // first shot starts at range start
        if (item.dur - iv[i][1] < dt && !cutBetween(iv[i][1], item.dur)) iv[i][1] = item.dur;
      }
    }

    // 3. merge short gaps, but never across a source cut (that would catch another shot)
    var merged = [iv[0].slice()];
    for (i = 1; i < iv.length; i++) {
      var last = merged[merged.length - 1];
      var g = iv[i][0] - last[1];
      if (g <= (opt.gap || 0) + 1e-6 && !(g > 1e-6 && cutBetween(last[1] - 1e-6, iv[i][0] + 1e-6))) {
        last[1] = Math.max(last[1], iv[i][1]);
      } else merged.push(iv[i].slice());
    }

    // 4. frame-round, drop short ones
    var fd = 1 / item.fps, out = [];
    for (i = 0; i < merged.length; i++) {
      var A = Math.round(merged[i][0] / fd) * fd, B = Math.round(merged[i][1] / fd) * fd;
      if (B - A + 1e-6 >= Math.max(opt.minDur || 0, 2 * fd)) out.push([item.start + A, item.start + B]);
    }
    return out;
  }

  function fmtTime(s) {
    var m = Math.floor(s / 60), r = s - m * 60;
    return m + ":" + (r < 10 ? "0" : "") + r.toFixed(1);
  }

  var api = { computeSegments: computeSegments, fmtTime: fmtTime };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.FaceCutSeg = api;
})(typeof window !== "undefined" ? window : this);
