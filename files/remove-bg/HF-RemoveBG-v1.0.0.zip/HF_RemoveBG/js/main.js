(function () {
  'use strict';

  var cep = window.__adobe_cep__;
  var nodeRequire = window.require || (window.cep_node && window.cep_node.require);
  var fs = nodeRequire('fs');
  var path = nodeRequire('path');
  var cp = nodeRequire('child_process');
  var proc = window.process || nodeRequire('process');

  var $ = function (id) { return document.getElementById(id); };
  var KEY = 'hf_removebg_settings_v1';
  var DEF = { mode: 'auto', action: 'replace', toolDir: 'C:\\AI\\HF_RemoveBG', outWhere: 'near', outDir: 'C:\\AI\\RemoveBG_out' };
  var HINTS = {
    auto: 'Сам визначить: рівний фон — точне зняття кольору, інакше — нейромережа.',
    graphics: 'Тексти, логотипи, стікери на однотонному фоні. Чіткі краї, без ореолу, без відеокарти.',
    keep: 'Як «Графіка», але замкнені ділянки кольору фону всередині об\'єкта лишаються (білий текст у білій рамці).',
    photo: 'Фото та складний фон. BiRefNet_HR, чіткі краї.',
    hair: 'Люди з розпущеним волоссям, тварини, пух, дим. М\'який напівпрозорий край.'
  };

  var child = null, busy = false, cancelled = false, action = 'replace';

  function evalJSX(code) { return new Promise(function (r) { cep.evalScript(code, r); }); }
  function parse(res) { try { return JSON.parse(res); } catch (e) { return { ok: false, error: String(res) }; } }
  function log(t) { var el = $('log'); el.textContent += t + '\n'; el.scrollTop = el.scrollHeight; }
  function setProgress(f, text, cls) {
    if (f !== null) $('bar').style.width = Math.max(0, Math.min(1, f)) * 100 + '%';
    if (text !== undefined) { $('status').textContent = text; $('status').className = cls || ''; }
  }
  function setBusy(b) { busy = b; $('run').disabled = b; $('cancel').disabled = !b; }
  function fail(msg) { setBusy(false); child = null; setProgress(null, msg, 'err'); log('ПОМИЛКА: ' + msg); }

  // ---------- settings ----------
  function setAction(a) {
    action = a;
    Array.prototype.forEach.call(document.querySelectorAll('[data-action]'), function (b) {
      b.classList.toggle('active', b.getAttribute('data-action') === a);
    });
  }
  function refreshUI() {
    $('modehint').textContent = HINTS[$('mode').value] || '';
    $('outDirRow').style.display = $('outWhere').value === 'folder' ? 'flex' : 'none';
  }
  function load() {
    var s = {};
    try { s = JSON.parse(localStorage.getItem(KEY) || '{}'); } catch (e) {}
    Object.keys(DEF).forEach(function (k) { if (s[k] === undefined) s[k] = DEF[k]; });
    ['mode', 'toolDir', 'outWhere', 'outDir'].forEach(function (k) { $(k).value = s[k]; });
    setAction(s.action);
    refreshUI();
  }
  function save() {
    var s = { action: action };
    ['mode', 'toolDir', 'outWhere', 'outDir'].forEach(function (k) { s[k] = String($(k).value).trim(); });
    try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {}
    refreshUI();
    return s;
  }

  // ---------- run ----------
  async function run() {
    if (busy) return;
    cancelled = false;
    $('log').textContent = '';
    var s = save();
    var py = path.join(s.toolDir, 'venv', 'Scripts', 'python.exe');
    var script = path.join(s.toolDir, 'remove_bg.py');
    if (!fs.existsSync(script)) { $('settings').open = true; return fail('Не знайдено remove_bg.py у папці ' + s.toolDir); }
    if (!fs.existsSync(py)) { $('settings').open = true; return fail('Не знайдено venv. Спершу запусти setup.bat у папці HF_RemoveBG.'); }

    var sel = parse(await evalJSX('rbCollect()'));
    if (!sel.ok) return fail(sel.error);
    var files = sel.files;
    log('Картинок: ' + files.length + (sel.skipped ? ', пропущено (не картинки): ' + sel.skipped : ''));

    setBusy(true);
    var t0 = Date.now();
    setProgress(0.03, 'Обробка 0/' + files.length + '…');

    var args = [script, '--panel', '--mode', s.mode === 'keep' ? 'graphics' : s.mode];
    if (s.mode === 'keep') args.push('--keep-inner');
    if (s.outWhere === 'folder') {
      try { fs.mkdirSync(s.outDir, { recursive: true }); } catch (e) { return fail('Не вдалося створити папку: ' + s.outDir); }
      args.push('--out_dir', s.outDir);
    }
    args = args.concat(files);

    var env = Object.assign({}, proc.env, { PYTHONUNBUFFERED: '1', PYTHONIOENCODING: 'utf-8' });
    try { child = cp.spawn(py, args, { cwd: s.toolDir, env: env, windowsHide: true }); }
    catch (e) { return fail('Не вдалося запустити Python: ' + e.message); }

    var results = [];
    function onLine(line) {
      line = line.replace(/\s+$/, '');
      if (!line) return;
      var parts = line.split('\t');
      if (parts[0] === 'RESULT') { results.push({ src: parts[1], dst: parts[2], mode: parts[3] }); return; }
      if (parts[0] === 'FAILED') return;
      var m = line.match(/^PROGRESS (\d+) (\d+)/);
      if (m) {
        var sec = Math.round((Date.now() - t0) / 1000);
        setProgress(0.05 + 0.85 * (+m[1]) / (+m[2]), 'Обробка ' + m[1] + '/' + m[2] + '… (' + sec + ' с)');
        return;
      }
      if (/Завантаження моделі/.test(line)) setProgress(null, 'Завантаження моделі…');
      log(line);
    }
    function bind(stream) {
      var buf = '';
      stream.on('data', function (d) {
        buf += d.toString('utf8');
        var p = buf.split(/\r\n|\n|\r/); buf = p.pop(); p.forEach(onLine);
      });
      stream.on('end', function () { if (buf) onLine(buf); });
    }
    bind(child.stdout); bind(child.stderr);
    child.on('error', function (e) { fail('Python: ' + e.message); });
    child.on('close', async function (code) {
      child = null;
      if (cancelled) return fail('Скасовано');
      if (!results.length) return fail('Жодну картинку не оброблено (код ' + code + '). Деталі в лозі.');

      setProgress(0.95, 'Імпорт в After Effects…');
      var r = parse(await evalJSX('rbApply(' + JSON.stringify({ results: results, action: action }) + ')'));
      if (!r.ok) return fail(r.error);
      setBusy(false);
      var sec = Math.round((Date.now() - t0) / 1000);
      var miss = files.length - results.length;
      setProgress(1, 'Готово: ' + results.length + ' за ' + sec + ' с' + (miss ? ', з помилкою: ' + miss : '') + '.', miss ? 'err' : 'ok');
      if (r.note) log(r.note);
    });
  }

  function cancel() {
    if (!busy) return;
    cancelled = true;
    if (child) { try { cp.exec('taskkill /pid ' + child.pid + ' /T /F'); } catch (e) { try { child.kill(); } catch (e2) {} } }
    setProgress(null, 'Скасування…');
  }

  function pickFolder(id) {
    try {
      var r = window.cep.fs.showOpenDialog(false, true, 'Оберіть папку', $(id).value);
      if (r && r.data && r.data.length) { $(id).value = r.data[0].replace(/\//g, '\\'); save(); }
    } catch (e) { log('Діалог вибору недоступний: ' + e.message); }
  }

  // ---------- init ----------
  load();
  $('run').addEventListener('click', run);
  $('cancel').addEventListener('click', cancel);
  $('openOut').addEventListener('click', function () {
    var s = save();
    var d = s.outWhere === 'folder' ? s.outDir : s.toolDir;
    try { fs.mkdirSync(d, { recursive: true }); } catch (e) {}
    cp.exec('explorer "' + d + '"');
  });
  Array.prototype.forEach.call(document.querySelectorAll('[data-action]'), function (b) {
    b.addEventListener('click', function () { if (!busy) { setAction(b.getAttribute('data-action')); save(); } });
  });
  Array.prototype.forEach.call(document.querySelectorAll('[data-pick]'), function (b) {
    b.addEventListener('click', function () { pickFolder(b.getAttribute('data-pick')); });
  });
  Array.prototype.forEach.call(document.querySelectorAll('input, select'), function (el) {
    el.addEventListener('change', save);
  });
})();
