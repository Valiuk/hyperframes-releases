// HF RemoveBG — ExtendScript side

function rbJson(v) {
    if (v === null || v === undefined) return 'null';
    var t = typeof v;
    if (t === 'number') return isFinite(v) ? String(v) : 'null';
    if (t === 'boolean') return v ? 'true' : 'false';
    if (t === 'string') return '"' + v.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\r/g, '\\r').replace(/\n/g, '\\n').replace(/\t/g, '\\t') + '"';
    var parts = [], i;
    if (v instanceof Array) { for (i = 0; i < v.length; i++) parts.push(rbJson(v[i])); return '[' + parts.join(',') + ']'; }
    for (var k in v) if (v.hasOwnProperty(k)) parts.push(rbJson(k) + ':' + rbJson(v[k]));
    return '{' + parts.join(',') + '}';
}
function rbErr(m) { return rbJson({ ok: false, error: m }); }

var RB_EXT = /\.(png|jpe?g|webp|bmp|tiff?)$/i;

function rbStillFile(item) {
    try {
        if (!(item instanceof FootageItem)) return null;
        var ms = item.mainSource;
        if (!(ms instanceof FileSource) || !ms.isStill || !ms.file) return null;
        if (!RB_EXT.test(ms.file.name)) return null;
        return ms.file;
    } catch (e) { return null; }
}

// Collects still images from selected layers (active comp) or from the Project panel selection
function rbCollect() {
    var map = {}, order = [], skipped = 0, i;
    function add(item, layer) {
        var f = rbStillFile(item);
        if (!f) { skipped++; return; }
        var key = f.fsName;
        if (!map[key]) { map[key] = { item: item, layers: [], fromProject: !layer }; order.push(key); }
        if (layer) map[key].layers.push(layer);
    }
    var comp = app.project.activeItem;
    if (comp instanceof CompItem && comp.selectedLayers.length) {
        var sl = comp.selectedLayers;
        for (i = 0; i < sl.length; i++) {
            if (sl[i] instanceof AVLayer && sl[i].source) add(sl[i].source, sl[i]); else skipped++;
        }
    } else {
        var items = app.project.selection;
        for (i = 0; i < items.length; i++) add(items[i], null);
    }
    if (!order.length) {
        return rbErr('Не знайдено картинок. Виділи шари з картинками (PNG/JPG/WEBP/TIFF) у композиції або футаж у панелі Project.');
    }
    $.global.RB_SEL = map;
    return rbJson({ ok: true, files: order, skipped: skipped });
}

function rbFolder() {
    for (var i = 1; i <= app.project.numItems; i++) {
        var it = app.project.item(i);
        if (it instanceof FolderItem && it.name === 'RemoveBG') return it;
    }
    return app.project.items.addFolder('RemoveBG');
}

function rbImport(path) {
    var f = new File(path);
    // already imported earlier (re-run) — just refresh it
    for (var i = 1; i <= app.project.numItems; i++) {
        var it = app.project.item(i);
        try {
            if (it instanceof FootageItem && it.mainSource instanceof FileSource && it.mainSource.file &&
                it.mainSource.file.fsName === f.fsName) {
                it.replace(f);
                return it;
            }
        } catch (e) {}
    }
    var item = app.project.importFile(new ImportOptions(f));
    item.parentFolder = rbFolder();
    return item;
}

function rbLayersUsing(item) {
    var out = [], comps = item.usedIn;
    for (var c = 0; c < comps.length; c++) {
        for (var l = 1; l <= comps[c].numLayers; l++) {
            var ly = comps[c].layer(l);
            try { if (ly.source === item) out.push(ly); } catch (e) {}
        }
    }
    return out;
}

function rbApply(data) {
    var sel = $.global.RB_SEL;
    if (!sel) return rbErr('Втрачено виділення (AE перезапускався?). Файли лежать поруч з оригіналами.');
    var done = 0, replaced = 0, added = 0, notes = [];
    app.beginUndoGroup('HF RemoveBG');
    try {
        for (var r = 0; r < data.results.length; r++) {
            var res = data.results[r];
            var entry = sel[new File(res.src).fsName] || sel[res.src];
            var newItem = rbImport(res.dst);
            done++;
            if (!entry || data.action === 'import') continue;

            var layers = entry.layers;
            if (entry.fromProject) layers = rbLayersUsing(entry.item);
            if (entry.fromProject && !layers.length) { notes.push(entry.item.name + ': не використовується в композиціях, лише імпортовано.'); continue; }

            for (var j = 0; j < layers.length; j++) {
                var ly = layers[j];
                if (data.action === 'replace') {
                    ly.replaceSource(newItem, false);
                    replaced++;
                } else if (data.action === 'above') {
                    var dup = ly.duplicate();
                    dup.replaceSource(newItem, false);
                    dup.name = ly.name + ' (no bg)';
                    added++;
                }
            }
        }
    } catch (e) {
        app.endUndoGroup();
        return rbErr('Помилка імпорту: ' + e.toString());
    }
    app.endUndoGroup();
    var note = 'Імпортовано: ' + done + (replaced ? ', замінено шарів: ' + replaced : '') + (added ? ', додано шарів: ' + added : '');
    if (notes.length) note += '\n' + notes.join('\n');
    return rbJson({ ok: true, note: note });
}
