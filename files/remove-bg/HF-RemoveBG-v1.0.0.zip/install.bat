@echo off
setlocal
set "SRC=%~dp0HF_RemoveBG"
set "DST=%APPDATA%\Adobe\CEP\extensions\HF_RemoveBG"
echo Installing HF RemoveBG for After Effects...
if not exist "%APPDATA%\Adobe\CEP\extensions" mkdir "%APPDATA%\Adobe\CEP\extensions"
if exist "%DST%" rmdir /s /q "%DST%"
xcopy "%SRC%" "%DST%\" /e /i /y /q >nul
for %%v in (9 10 11 12 13) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
echo.
echo Done. Restart After Effects and open: Window ^> Extensions ^> HF RemoveBG
pause
