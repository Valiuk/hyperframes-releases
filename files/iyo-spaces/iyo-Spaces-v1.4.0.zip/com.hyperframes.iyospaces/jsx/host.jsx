// iyo Spaces — ExtendScript side for After Effects and Premiere Pro.
// The panel downloads files itself and passes ready local paths here.

var IYO_IS_PPRO = (BridgeTalk.appName === "premierepro");

function iyo_projectDir() {
  try {
    if (IYO_IS_PPRO) {
      var p = app.project && app.project.path;
      if (p && /\.prproj$/i.test(p)) { var f = new File(p); if (f.exists) return encodeURIComponent(f.parent.fsName); }
    } else if (app.project && app.project.file) {
      return encodeURIComponent(app.project.file.parent.fsName);
    }
  } catch (e) {}
  return "";
}

function iyo_parse(payload) { return eval("(" + decodeURIComponent(payload) + ")"); }
function iyo_result(r) { return "OK|" + r.imported + "|" + r.reused + "|" + r.placed + "|" + encodeURIComponent(r.errors.join("\n")); }

// payload: encodeURIComponent(JSON) — { toTarget: bool, items: [{ path, folders: [..], name, kind }] }
function iyo_import(payload) {
  var data;
  try { data = iyo_parse(payload); } catch (e) { return "ERR|bad payload"; }
  return IYO_IS_PPRO ? iyo_importPPRO(data) : iyo_importAE(data);
}

// ================= After Effects =================
function iyo_aeFolder(parent, name) {
  for (var i = 1; i <= app.project.numItems; i++) {
    var it = app.project.item(i);
    if (it instanceof FolderItem && it.name === name && it.parentFolder === parent) return it;
  }
  var f = app.project.items.addFolder(name); f.parentFolder = parent; return f;
}
function iyo_aeFind(file) {
  for (var i = 1; i <= app.project.numItems; i++) {
    var it = app.project.item(i);
    try { if (it instanceof FootageItem && it.file && it.file.fsName === file.fsName) return it; } catch (e) {}
  }
  return null;
}
function iyo_importAE(data) {
  var r = { imported: 0, reused: 0, placed: 0, errors: [] }, comp = null;
  if (data.toTarget) { comp = app.project.activeItem; if (!(comp instanceof CompItem)) return "ERR|notarget"; }
  app.beginUndoGroup("iyo Spaces import");
  try {
    for (var i = 0; i < data.items.length; i++) {
      var it = data.items[i];
      try {
        var file = new File(it.path);
        if (!file.exists) { r.errors.push(it.name + ": file missing"); continue; }
        var footage = iyo_aeFind(file);
        if (footage) r.reused++;
        else {
          footage = app.project.importFile(new ImportOptions(file));
          var parent = app.project.rootFolder;
          for (var k = 0; k < it.folders.length; k++) parent = iyo_aeFolder(parent, it.folders[k]);
          footage.parentFolder = parent; r.imported++;
        }
        if (comp) { var layer = comp.layers.add(footage); layer.startTime = comp.time; r.placed++; }
      } catch (e2) { r.errors.push(it.name + ": " + e2.toString()); }
    }
  } finally { app.endUndoGroup(); }
  return iyo_result(r);
}

// ================= Premiere Pro =================
function iyo_ppBin(parent, name) {
  for (var i = 0; i < parent.children.numItems; i++) {
    var c = parent.children[i];
    if (c && c.type === ProjectItemType.BIN && c.name === name) return c;
  }
  parent.createBin(name);
  for (var j = 0; j < parent.children.numItems; j++) {
    var d = parent.children[j];
    if (d && d.type === ProjectItemType.BIN && d.name === name) return d;
  }
  return parent;
}
function iyo_samePath(a, b) {
  try { return new File(a).fsName === new File(b).fsName; } catch (e) { return a === b; }
}
function iyo_ppFind(bin, path) {
  for (var i = 0; i < bin.children.numItems; i++) {
    var c = bin.children[i];
    if (!c) continue;
    if (c.type === ProjectItemType.BIN) { var f = iyo_ppFind(c, path); if (f) return f; }
    else { try { if (c.getMediaPath && iyo_samePath(c.getMediaPath(), path)) return c; } catch (e) {} }
  }
  return null;
}
function iyo_ppDuration(item) {
  try {
    var d = item.getOutPoint().seconds - item.getInPoint().seconds;
    if (d > 0.04 && d < 36000) return d;
  } catch (e) {}
  return 5;
}
function iyo_ppFreeTrack(tracks, start, end) {
  for (var i = 0; i < tracks.numTracks; i++) {
    var tr = tracks[i], free = true;
    for (var j = 0; j < tr.clips.numItems; j++) {
      var c = tr.clips[j];
      if (c.start.seconds < end - 0.001 && c.end.seconds > start + 0.001) { free = false; break; }
    }
    if (free) return i;
  }
  return -1;
}
function iyo_ppAddTrack(seq, audio) {
  try {
    app.enableQE();
    var q = qe.project.getActiveSequence();
    if (audio) q.addTracks(0, 0, 1, 1, seq.audioTracks.numTracks);
    else q.addTracks(1, seq.videoTracks.numTracks, 0);
    return audio ? seq.audioTracks.numTracks - 1 : seq.videoTracks.numTracks - 1;
  } catch (e) { return -1; }
}
function iyo_importPPRO(data) {
  var r = { imported: 0, reused: 0, placed: 0, errors: [] }, seq = null;
  if (data.toTarget) { seq = app.project.activeSequence; if (!seq) return "ERR|notarget"; }
  var placed = [];
  for (var i = 0; i < data.items.length; i++) {
    var it = data.items[i];
    try {
      var file = new File(it.path);
      if (!file.exists) { r.errors.push(it.name + ": file missing"); continue; }
      var item = iyo_ppFind(app.project.rootItem, file.fsName);
      if (item) r.reused++;
      else {
        var bin = app.project.rootItem;
        for (var k = 0; k < it.folders.length; k++) bin = iyo_ppBin(bin, it.folders[k]);
        app.project.importFiles([file.fsName], true, bin, false);
        item = iyo_ppFind(bin, file.fsName);
        if (!item) { r.errors.push(it.name + ": import failed"); continue; }
        r.imported++;
      }
      if (seq) placed.push({ item: item, audio: it.kind === "audio", name: it.name });
    } catch (e2) { r.errors.push(it.name + ": " + e2.toString()); }
  }
  if (seq && placed.length) {
    // кладемо вибране підряд від плейхеда на першу вільну доріжку (окремо відео/фото і аудіо)
    var groups = [[], []];
    for (var p = 0; p < placed.length; p++) groups[placed[p].audio ? 1 : 0].push(placed[p]);
    var t0 = seq.getPlayerPosition().seconds;
    for (var g = 0; g < 2; g++) {
      var list = groups[g]; if (!list.length) continue;
      var audio = g === 1, tracks = audio ? seq.audioTracks : seq.videoTracks, total = 0;
      for (var a = 0; a < list.length; a++) { list[a].dur = iyo_ppDuration(list[a].item); total += list[a].dur; }
      var ti = iyo_ppFreeTrack(tracks, t0, t0 + total);
      if (ti < 0) ti = iyo_ppAddTrack(seq, audio);
      if (ti < 0) ti = tracks.numTracks - 1;
      var t = t0;
      for (var b = 0; b < list.length; b++) {
        try { tracks[ti].overwriteClip(list[b].item, t); t += list[b].dur; r.placed++; }
        catch (e3) { r.errors.push(list[b].name + ": " + e3.toString()); }
      }
    }
  }
  return iyo_result(r);
}

// ================= Зворотна відправка (After Effects) =================
function iyo_q(s) { return encodeURIComponent(s); }
function iyo_json(o) {
  // мінімальна серіалізація без JSON (ExtendScript)
  if (o === null || o === undefined) return "null";
  if (typeof o === "number" || typeof o === "boolean") return String(o);
  if (typeof o === "string") return '"' + o.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "") + '"';
  if (o instanceof Array) { var a = []; for (var i = 0; i < o.length; i++) a.push(iyo_json(o[i])); return "[" + a.join(",") + "]"; }
  var p = []; for (var k in o) if (o.hasOwnProperty(k)) p.push(iyo_json(k) + ":" + iyo_json(o[k])); return "{" + p.join(",") + "}";
}
function iyo_safeName(s) { return String(s).replace(/[\\\/:*?"<>|]/g, "_").substring(0, 80); }

// Вибрані у Project футажі з файлами на диску
function iyo_selectedFiles() {
  if (IYO_IS_PPRO) return iyo_ppSelectedFiles();
  var out = [], sel = app.project.selection;
  for (var i = 0; i < sel.length; i++) {
    var it = sel[i];
    try {
      if (!(it instanceof FootageItem) || !it.file) continue;
      var still = it.mainSource && it.mainSource.isStill;
      var kind = still ? "image" : (!it.hasVideo && it.hasAudio ? "audio" : "video");
      out.push({ path: it.file.fsName, name: it.name, width: it.width || 0, height: it.height || 0, durationMs: still ? 0 : Math.round((it.duration || 0) * 1000), kind: kind });
    } catch (e) {}
  }
  return "OK|" + iyo_q(iyo_json(out));
}

// Поточний кадр активної композиції у PNG
function iyo_saveFrame(dirEnc) {
  if (IYO_IS_PPRO) return iyo_ppSaveFrame(dirEnc);
  var comp = app.project.activeItem;
  if (!(comp instanceof CompItem)) return "ERR|nocomp";
  var dir = new Folder(decodeURIComponent(dirEnc)); if (!dir.exists) dir.create();
  var frame = Math.round(comp.time * comp.frameRate);
  var f = new File(dir.fsName + "/" + iyo_safeName(comp.name) + "_f" + frame + ".png");
  comp.saveFrameToPng(comp.time, f);
  return "OK|" + iyo_q(iyo_json({ path: f.fsName, name: comp.name + " (кадр " + frame + ")", width: comp.width, height: comp.height, durationMs: 0, kind: "image" }));
}

// Рендер активної композиції в H.264 через Render Queue (інші елементи черги тимчасово вимикаються)
function iyo_renderComp(dirEnc) {
  if (IYO_IS_PPRO) return iyo_ppRender(dirEnc);
  var comp = app.project.activeItem;
  if (!(comp instanceof CompItem)) return "ERR|nocomp";
  var dir = new Folder(decodeURIComponent(dirEnc)); if (!dir.exists) dir.create();
  var rq = app.project.renderQueue, paused = [], item = null;
  try {
    for (var i = 1; i <= rq.numItems; i++) { var q = rq.item(i); if (q.status === RQItemStatus.QUEUED) { q.render = false; paused.push(q); } }
    item = rq.items.add(comp);
    var om = item.outputModule(1), tpl = null, names = om.templates;
    for (var t = 0; t < names.length; t++) if (/h\.?264/i.test(names[t])) { tpl = names[t]; break; }
    if (!tpl) { item.remove(); item = null; return "ERR|noh264"; }
    om.applyTemplate(tpl);
    var f = new File(dir.fsName + "/" + iyo_safeName(comp.name) + ".mp4");
    om.file = f;
    rq.render();
    var outFile = om.file;
    var res = { path: outFile.fsName, name: comp.name, width: comp.width, height: comp.height, durationMs: Math.round(comp.workAreaDuration * 1000), kind: "video" };
    item.remove(); item = null;
    return "OK|" + iyo_q(iyo_json(res));
  } catch (e) {
    return "ERR|" + e.toString();
  } finally {
    try { if (item) item.remove(); } catch (e2) {}
    for (var j = 0; j < paused.length; j++) { try { paused[j].render = true; } catch (e3) {} }
  }
}


// ================= Зворотна відправка (Premiere Pro) =================
var IYO_TICKS = 254016000000;
function iyo_kindByExt(p) {
  var e = (String(p).match(/\.([a-z0-9]+)$/i) || [])[1]; e = e ? e.toLowerCase() : "";
  if (/^(png|jpe?g|webp|gif|tiff?|psd|bmp|heic)$/.test(e)) return "image";
  if (/^(mp3|wav|m4a|aac|ogg|aif|aiff|flac)$/.test(e)) return "audio";
  return "video";
}
function iyo_ppSelectedFiles() {
  var out = [], sel = app.getCurrentProjectViewSelection();
  if (!sel) return "OK|" + iyo_q("[]");
  for (var i = 0; i < sel.length; i++) {
    var it = sel[i];
    try {
      if (!it || it.type === ProjectItemType.BIN || !it.getMediaPath) continue;
      var p = it.getMediaPath(); if (!p) continue;
      var w = 0, h = 0, dur = 0, kind = iyo_kindByExt(p);
      try { var m = String(it.getProjectMetadata()).match(/VideoInfo>\s*(\d+)\s*x\s*(\d+)/); if (m) { w = +m[1]; h = +m[2]; } } catch (e1) {}
      if (kind !== "image") { try { dur = Math.round((it.getOutPoint().seconds - it.getInPoint().seconds) * 1000); } catch (e2) {} }
      out.push({ path: new File(p).fsName, name: it.name, width: w, height: h, durationMs: dur, kind: kind });
    } catch (e) {}
  }
  return "OK|" + iyo_q(iyo_json(out));
}
function iyo_ppSaveFrame(dirEnc) {
  var seq = app.project.activeSequence; if (!seq) return "ERR|nocomp";
  var dir = new Folder(decodeURIComponent(dirEnc)); if (!dir.exists) dir.create();
  app.enableQE();
  var q = qe.project.getActiveSequence(), tc = q.CTI.timecode;
  var f = new File(dir.fsName + "/" + iyo_safeName(seq.name) + "_" + String(tc).replace(/[:;]/g, "-") + ".png");
  q.exportFramePNG(tc, f.fsName);
  return "OK|" + iyo_q(iyo_json({ path: f.fsName, name: seq.name + " (кадр " + tc + ")", width: seq.frameSizeHorizontal, height: seq.frameSizeVertical, durationMs: 0, kind: "image" }));
}
function iyo_findPreset(folder, depth, re) {
  if (!folder.exists || depth < 0) return null;
  var files = folder.getFiles();
  for (var i = 0; i < files.length; i++) if (files[i] instanceof File && re.test(files[i].name)) return files[i];
  for (var j = 0; j < files.length; j++) if (files[j] instanceof Folder) { var r = iyo_findPreset(files[j], depth - 1, re); if (r) return r; }
  return null;
}
function iyo_ppRender(dirEnc) {
  var seq = app.project.activeSequence; if (!seq) return "ERR|nocomp";
  var dir = new Folder(decodeURIComponent(dirEnc)); if (!dir.exists) dir.create();
  var roots = [new Folder(app.path + "/MediaIO/systempresets"), new Folder(app.path + "/Contents/MediaIO/systempresets"), new Folder(app.path)];
  var preset = null;
  for (var r = 0; r < roots.length && !preset; r++) preset = iyo_findPreset(roots[r], 4, /^Match Source - Adaptive High Bitrate\.epr$/i);
  for (var r2 = 0; r2 < roots.length && !preset; r2++) preset = iyo_findPreset(roots[r2], 4, /h\.?264.*\.epr$/i);
  if (!preset) return "ERR|noh264";
  var f = new File(dir.fsName + "/" + iyo_safeName(seq.name) + ".mp4");
  var err = seq.exportAsMediaDirect(f.fsName, preset.fsName, app.encoder.ENCODE_ENTIRE);
  if (err && String(err) !== "No Error" && !f.exists) return "ERR|" + err;
  var durMs = 0; try { durMs = Math.round(parseFloat(seq.end) / IYO_TICKS * 1000); } catch (e) {}
  return "OK|" + iyo_q(iyo_json({ path: f.fsName, name: seq.name, width: seq.frameSizeHorizontal, height: seq.frameSizeVertical, durationMs: durMs, kind: "video" }));
}
