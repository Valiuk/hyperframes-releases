/* iyo Spaces — панель After Effects: перегляд результатів нод зі spaces.iyo.gg та імпорт у проєкт.
   Мережа і файли — через Node.js (без обмежень CORS і з коректною кирилицею в шляхах),
   у ExtendScript передаються лише готові локальні шляхи. */
(function () {
  'use strict';
  const nreq = typeof require === 'function' ? require : window.cep_node.require;
  const https = nreq('https'), http = nreq('http'), fs = nreq('fs'), path = nreq('path'), os = nreq('os'), { URL } = nreq('url');

  const $ = (s) => document.querySelector(s);
  let HOST = 'AEFT';
  try { HOST = JSON.parse(window.__adobe_cep__.getHostEnvironment()).appName || 'AEFT'; } catch {}
  const IS_PPRO = HOST === 'PPRO';
  const T = IS_PPRO
    ? { target: 'У послідовність', placed: 'додано в послідовність ', noTarget: 'Відкрий послідовність, щоб додати файли в неї.', host: 'Premiere Pro', place: 'Project у бін' }
    : { target: 'У композицію', placed: 'додано в композицію ', noTarget: 'Відкрий композицію, щоб додати файли в неї.', host: 'After Effects', place: 'Project у папку' };
  const store = {
    get: (k, d) => { try { const v = localStorage.getItem('iyo.' + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
    set: (k, v) => { try { localStorage.setItem('iyo.' + k, JSON.stringify(v)); } catch {} },
  };
  const S = {
    base: store.get('base', 'https://spaces.iyo.gg'),
    cookie: store.get('cookie', ''),
    me: null, spaces: [], spaceId: store.get('spaceId', ''), sheets: [], sheetId: store.get('sheetId', ''),
    sheet: null, items: [], N: new Map(), sheetOrder: [], kind: 'all', activeOnly: true, query: '', selected: new Set(), lastClick: null,
    mode: store.get('mode', 'grid'), sort: store.get('sort', 'canvas'), cell: store.get('cell', 104), onlyFav: false, onlyNew: false,
    collapsed: new Set(), openNodes: new Set(), mapView: null, pv: null, focusKey: null,
    imported: new Set(store.get('imported', [])),
  };

  // ---------- HTTP (Node) ----------
  function request(method, url, { body, cookie = true, toFile, redirects = 5 } = {}) {
    return new Promise((resolve, reject) => {
      const u = new URL(url, S.base), sameHost = u.host === new URL(S.base).host;
      const headers = { 'accept': 'application/json, */*' };
      let data = null;
      if (body !== undefined) { data = Buffer.from(JSON.stringify(body)); headers['content-type'] = 'application/json'; headers['content-length'] = data.length; }
      if (cookie && sameHost && S.cookie) headers.cookie = S.cookie;
      if (sameHost) { const o = new URL(S.base).origin; headers.origin = o; headers.referer = o + '/'; }
      headers['user-agent'] = 'Mozilla/5.0 (iyo Spaces AE panel)';
      const lib = u.protocol === 'http:' ? http : https;
      const rq = lib.request(u, { method, headers }, (res) => {
        if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects > 0) {
          res.resume();
          const next = new URL(res.headers.location, u).toString();
          return resolve(request(method === 'POST' && res.statusCode === 303 ? 'GET' : method, next, { cookie: new URL(next).host === u.host && cookie, toFile, redirects: redirects - 1 }));
        }
        const setCookie = res.headers['set-cookie'];
        if (toFile && res.statusCode === 200) {
          const tmp = toFile + '.part';
          const out = fs.createWriteStream(tmp);
          res.pipe(out);
          out.on('finish', () => out.close(() => { fs.renameSync(tmp, toFile); resolve({ status: 200, file: toFile }); }));
          out.on('error', reject);
          return;
        }
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const text = Buffer.concat(chunks).toString('utf8');
          let json = null; try { json = JSON.parse(text); } catch {}
          resolve({ status: res.statusCode, json, text, setCookie });
        });
      });
      rq.on('error', reject);
      rq.setTimeout(60000, () => rq.destroy(new Error('timeout')));
      if (data) rq.write(data);
      rq.end();
    });
  }
  async function api(method, p, body) {
    const r = await request(method, p, { body });
    if (r.status === 401) { if (S.cookie) store.set('badCookie', S.cookie); showLogin('Сесія закінчилась. Увійди на spaces.iyo.gg у Chrome або вручну.'); throw new Error('unauthorized'); }
    if (r.status >= 400) throw new Error((r.json && r.json.error) || ('HTTP ' + r.status));
    return r.json;
  }

  // ---------- ExtendScript ----------
  const evalES = (code) => new Promise((ok) => window.__adobe_cep__.evalScript(code, ok));
  const esStr = (s) => '"' + encodeURIComponent(s) + '"';

  // ---------- статус ----------
  let statusTimer = null;
  function status(text, bad = false, sticky = false) {
    const el = $('#status'); el.textContent = text; el.classList.toggle('bad', bad);
    clearTimeout(statusTimer); if (!sticky && text) statusTimer = setTimeout(() => (el.textContent = ''), 6000);
  }

  // ---------- вхід ----------
  function showLogin(msg) {
    $('#main').hidden = true; $('#login').hidden = false; setBridgeInfo();
    $('#lg-base').value = S.base; $('#lg-email').value = store.get('email', '');
    $('#lg-err').textContent = msg || '';
  }
  const LOGIN_ERRORS = {
    jira_token_invalid: 'Токен не підходить. Перевір email і токен.',
    jira_other_account: 'Цей токен належить іншому акаунту Jira.',
    invalid_body: 'Перевір, чи заповнені обидва поля.',
  };
  async function doLogin() {
    const email = $('#lg-email').value.trim(), token = $('#lg-token').value.trim();
    S.base = ($('#lg-base').value.trim() || 'https://spaces.iyo.gg').replace(/\/+$/, '');
    if (!email || !token) { $('#lg-err').textContent = 'Введи email і токен.'; return; }
    $('#lg-go').disabled = true; $('#lg-err').textContent = '';
    try {
      const now = new Date(), exp = new Date(now.getTime() + 365 * 864e5);
      const r = await request('POST', '/api/auth/jira', { body: { email, token, tokenCreatedAt: now.toISOString(), tokenExpiresAt: exp.toISOString() }, cookie: false });
      if (r.status >= 400) {
        const code = r.json && r.json.error;
        $('#lg-err').textContent = (LOGIN_ERRORS[code] || 'Не вдалося увійти.') + ` [HTTP ${r.status}${code ? ', ' + code : ''}${!r.json && r.text ? ', ' + r.text.slice(0, 120) : ''}]`;
        console.log('login response', r.status, r.text);
        return;
      }
      const cookies = [].concat(r.setCookie || []).map((c) => c.split(';')[0]).filter(Boolean);
      if (!cookies.length) { $('#lg-err').textContent = 'Сервер не видав сесію. Спробуй ще раз.'; return; }
      S.cookie = cookies.join('; ');
      store.set('cookie', S.cookie); store.set('base', S.base); store.set('email', email);
      $('#lg-token').value = '';
      await start();
    } catch (e) { $('#lg-err').textContent = 'Немає зʼєднання з ' + S.base + ' (' + e.message + ').'; }
    finally { $('#lg-go').disabled = false; }
  }
  async function sessionLogin() {
    let v = $('#lg-cookie').value.trim().replace(/^cookie:\s*/i, '');
    S.base = ($('#lg-base').value.trim() || 'https://spaces.iyo.gg').replace(/\/+$/, '');
    if (!v || !v.includes('=')) { $('#lg-err').textContent = 'Встав значення заголовка cookie (виглядає як name=value; name2=value2).'; return; }
    S.cookie = v; store.set('cookie', v); store.set('base', S.base);
    $('#lg-cookie').value = '';
    await start();
  }
  function logout() {
    // вихід лише з панелі: сесію на сайті не закриваємо, щоб не викинути тебе з браузера
    if (S.cookie) store.set('badCookie', S.cookie);
    S.cookie = ''; S.me = null; store.set('cookie', ''); $('#menu').hidden = true; showLogin();
  }

  // ---------- завантаження даних ----------
  async function start() {
    if (!S.cookie) return showLogin();
    try { S.me = await api('GET', '/api/auth/me'); } catch (e) { if (e.message !== 'unauthorized') showLogin('Немає зʼєднання з сервером: ' + e.message); return; }
    $('#login').hidden = true; $('#main').hidden = false;
    $('#menu-user').textContent = S.me.displayName || '';
    await loadSpaces();
  }
  async function loadSpaces() {
    status('Завантажую спейси…', false, true);
    const [mine, team] = await Promise.all([api('GET', '/api/spaces?scope=mine').catch(() => []), api('GET', '/api/spaces?scope=team').catch(() => [])]);
    const seen = new Set(); S.spaces = [];
    for (const [group, list] of [['Мої', mine], ['Команда', team]]) for (const s of list || []) if (!seen.has(s.id)) { seen.add(s.id); S.spaces.push({ ...s, group }); }
    const sel = $('#sel-space'); sel.innerHTML = '';
    for (const g of ['Мої', 'Команда']) {
      const list = S.spaces.filter((s) => s.group === g); if (!list.length) continue;
      const og = document.createElement('optgroup'); og.label = g;
      for (const s of list) { const o = document.createElement('option'); o.value = s.id; o.textContent = s.title || 'Без назви'; og.appendChild(o); }
      sel.appendChild(og);
    }
    if (!S.spaces.length) { status(''); return renderEmpty('Спейсів поки немає. Створи спейс на сайті й онови панель.'); }
    if (!S.spaces.some((s) => s.id === S.spaceId)) S.spaceId = S.spaces[0].id;
    sel.value = S.spaceId;
    await loadSpace();
  }
  async function loadSpace() {
    store.set('spaceId', S.spaceId);
    const sp = await api('GET', '/api/spaces/' + S.spaceId);
    S.sheets = (sp.sheets || []).slice().sort((a, b) => (a.position || 0) - (b.position || 0));
    S.spaceTitle = sp.title || 'Спейс';
    const sel = $('#sel-sheet'); sel.innerHTML = '';
    if (S.sheets.length > 1) { const o = document.createElement('option'); o.value = '*'; o.textContent = `Усі аркуші (${S.sheets.length})`; sel.appendChild(o); }
    for (const sh of S.sheets) { const o = document.createElement('option'); o.value = sh.id; o.textContent = sh.title || 'Аркуш'; sel.appendChild(o); }
    if (!(S.sheetId === '*' && S.sheets.length > 1) && !S.sheets.some((s) => s.id === S.sheetId)) S.sheetId = S.sheets[0] && S.sheets[0].id;
    sel.value = S.sheetId || '';
    await loadSheet();
  }
  async function loadSheet() {
    if (!S.sheetId) return renderEmpty('У цьому спейсі немає аркушів.');
    store.set('sheetId', S.sheetId);
    const list = S.sheetId === '*' ? S.sheets : S.sheets.filter((s) => s.id === S.sheetId);
    const seen = store.get('lastSeen', {}), loaded = [];
    let done = 0; status(`Завантажую ${list.length > 1 ? 'аркуші' : 'аркуш'}…`, false, true);
    const queue = list.slice();
    const worker = async () => { while (queue.length) { const sh = queue.shift(); const state = await api('GET', '/api/sheets/' + sh.id + '/state');
      loaded.push({ id: sh.id, title: sh.title || 'Аркуш', state, lastSeen: seen[sh.id] || 0 }); done++; if (list.length > 1) status(`Завантажую аркуші… ${done} / ${list.length}`, false, true); } };
    await Promise.all([worker(), worker(), worker(), worker()]);
    loaded.sort((a, b) => list.findIndex((x) => x.id === a.id) - list.findIndex((x) => x.id === b.id));
    for (const sh of loaded) seen[sh.id] = Date.now(); store.set('lastSeen', seen);
    S.sheet = S.sheetId === '*' ? null : loaded[0].state;
    S.sheetTitle = S.sheetId === '*' ? 'Усі аркуші' : loaded[0].title;
    buildData(loaded); S.selected.clear(); S.mapView = null; closePv(); render(); status('');
  }

  // ================= ПЕРЕГЛЯД МАТЕРІАЛІВ =================
  // Дані аркуша(ів) зводяться в граф нод: S.N (ключ "аркуш|нода") + плаский список медіа S.items.
  // Три режими: сітка, ланцюжки (ієрархія нод, як на полотні), мапа (зменшене полотно).
  const TYPE_NAME = { upload: 'Файл', image_gen: 'Генерація фото', video_gen: 'Генерація відео', music: 'Музика', audio_tts: 'Озвучка', assistant: 'Асистент', text: 'Текст', jira: 'Jira', lipsync: 'Ліпсинк', voice_clone: 'Клон голосу' };
  const KIND_NAME = { video: 'Відео', image: 'Фото', audio: 'Аудіо' };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const favs = new Set(store.get('favs', []));
  const saveFavs = () => store.set('favs', [...favs].slice(-3000));
  const fmtDur = (ms) => { const s = Math.round(ms / 100) / 10; return s < 60 ? s + ' с' : Math.floor(s / 60) + ':' + String(Math.round(s % 60)).padStart(2, '0'); };
  const fmtDate = (d) => { const t = new Date(d); return isNaN(t) ? '' : t.toLocaleDateString('uk-UA', { day: 'numeric', month: 'short' }) + ', ' + t.toLocaleTimeString('uk-UA', { hour: '2-digit', minute: '2-digit' }); };

  function nodeOwnText(n, outs) {
    const p = n.params || {}, parts = [n.title, TYPE_NAME[n.type], n.type, n.inline_prompt, p.text, p.system_prompt, p.prompt, n.skill, n.preset];
    if (p.issue) parts.push(p.issue.key, p.issue.summary);
    for (const o of outs) { if (o.asset) parts.push(o.asset.originalName, o.asset.isActive ? o.asset.text : null); }
    const act = outs.find((o) => o.isActive) || outs[outs.length - 1];
    if (act && act.asset && act.asset.text) parts.push(act.asset.text);
    return parts.filter(Boolean).join('\n');
  }
  // текст, з якого «виростає» нода: її власний промпт або текст/відповідь асистента на вході prompt
  function promptOf(N) {
    if (N.node.inline_prompt) return N.node.inline_prompt;
    for (const k of N.ins) { const M = S.N.get(k); if (!M) continue; if (M.node.type === 'text' && M.node.params && M.node.params.text) return M.node.params.text; if (M.answer) return M.answer; }
    return (N.node.params && (N.node.params.text || N.node.params.prompt)) || '';
  }

  function buildData(sheets) {
    S.N = new Map(); S.items = []; S.sheetOrder = sheets.map((s) => s.id);
    for (const sh of sheets) {
      const g = (sh.state && sh.state.graph) || { nodes: [], edges: [] }, outsAll = (sh.state && sh.state.outputs) || {};
      const lastSeen = sh.lastSeen || 0;
      for (const n of g.nodes || []) {
        const key = sh.id + '|' + n.id;
        const outs = (outsAll[n.id] || []).slice().sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
        const N = { key, sid: sh.id, sheetTitle: sh.title, node: n, ins: [], outs: [], items: [], answer: '' };
        const act = outs.find((o) => o.isActive) || outs[outs.length - 1];
        if (act && act.asset && act.asset.text) N.answer = act.asset.text;
        const media = outs.filter((o) => o.asset && KIND_NAME[o.asset.kind] && !o.asset.expired);
        media.forEach((o, i) => {
          const it = { key: sh.id + '|' + (o.id || (n.id + ':' + o.asset.id)), nkey: key, sid: sh.id, sheetTitle: sh.title, node: n, out: o, asset: o.asset,
            version: i + 1, versions: media.length, active: !!o.isActive || media.length === 1 || (!media.some((x) => x.isActive) && i === media.length - 1),
            isNew: lastSeen && new Date(o.createdAt).getTime() > lastSeen };
          N.items.push(it); S.items.push(it);
        });
        N.own = nodeOwnText(n, outs);
        S.N.set(key, N);
      }
      for (const e of g.edges || []) {
        const a = S.N.get(sh.id + '|' + e.source), b = S.N.get(sh.id + '|' + e.target);
        if (a && b) { a.outs.push(b.key); b.ins.push(a.key); }
      }
    }
    for (const N of S.N.values()) {
      N.prompt = promptOf(N);
      N.hay = (N.own + '\n' + N.prompt + '\n' + N.sheetTitle + '\n' + N.ins.map((k) => (S.N.get(k).node.title || '')).join(' ')).toLowerCase();
    }
    S.activeItem = null;
  }

  // ---------- фільтри ----------
  const terms = () => S.query.toLowerCase().split(/\s+/).filter(Boolean);
  const nodeMatches = (N, t = terms()) => !t.length || t.every((w) => N.hay.includes(w));
  function itemPass(it, { versions = !S.activeOnly } = {}) {
    if (S.kind !== 'all' && it.asset.kind !== S.kind) return false;
    if (!versions && !it.active) return false;
    if (S.onlyFav && !favs.has(it.asset.id)) return false;
    if (S.onlyNew && S.imported.has(it.asset.id)) return false;
    return true;
  }
  function visibleItems() {
    const t = terms();
    const list = S.items.filter((it) => itemPass(it) && nodeMatches(S.N.get(it.nkey), t));
    const sheetIdx = (sid) => S.sheetOrder.indexOf(sid);
    if (S.sort === 'new') list.sort((a, b) => new Date(b.out.createdAt) - new Date(a.out.createdAt));
    else if (S.sort === 'name') list.sort((a, b) => String(a.node.title).localeCompare(String(b.node.title), 'uk', { numeric: true }) || a.version - b.version);
    else list.sort((a, b) => sheetIdx(a.sid) - sheetIdx(b.sid) || (a.node.position.y - b.node.position.y) || (a.node.position.x - b.node.position.x) || a.version - b.version);
    return list;
  }
  function renderCounts() {
    const vis = S.mode === 'grid' ? visibleItems().length : null;
    $('#count').textContent = vis == null ? '' : `${vis} з ${S.items.length}`;
  }

  // ---------- загальний рендер ----------
  function render() {
    for (const m of ['grid', 'tree', 'map']) $('#' + m).hidden = S.mode !== m;
    $('#sort').hidden = S.mode !== 'grid';
    $('#empty').hidden = true;
    if (!S.items.length && S.mode !== 'map') { renderEmpty('На цьому аркуші ще немає готових файлів.'); return; }
    if (S.mode === 'grid') renderGrid(); else if (S.mode === 'tree') renderTree(); else renderMap();
    renderCounts(); updateFoot();
  }
  function renderEmpty(text) {
    for (const m of ['grid', 'tree', 'map']) $('#' + m).hidden = true;
    for (const m of ['grid', 'tree']) $('#' + m).innerHTML = '';
    $('#empty').hidden = false; $('#empty').textContent = text; renderCounts(); updateFoot();
  }

  function thumbHTML(it, cls = 'thumb') {
    return `<div class="${cls}" data-thumb="${esc(it.key)}">${it.asset.kind === 'audio' ? '♪' : ''}</div>`;
  }
  function hookThumbs(root) {
    root.querySelectorAll('[data-thumb]').forEach((el) => { const it = itemByKey(el.dataset.thumb); if (it) queueThumb(it, el); });
  }
  const itemByKey = (k) => S.items.find((x) => x.key === k);
  function badges(it) {
    return `${it.versions > 1 ? `<span class="ver${it.active ? ' on' : ''}" title="${it.active ? 'Активна версія' : 'Неактивна версія'}">${it.active ? '●' : '○'} ${it.version}/${it.versions}</span>` : ''}`
      + `${S.imported.has(it.asset.id) ? '<span class="done" title="Вже в проєкті">✓</span>' : ''}`
      + `${it.isNew ? '<span class="new" title="Зʼявилось після попереднього відкриття">нове</span>' : ''}`
      + `<span class="fav${favs.has(it.asset.id) ? ' on' : ''}" data-fav="${esc(it.asset.id)}" title="Обране">★</span>`;
  }

  // ---------- 1. Сітка ----------
  function renderGrid() {
    const items = visibleItems(), grid = $('#grid');
    grid.style.setProperty('--cell', S.cell + 'px');
    if (!items.length) {
      const t = terms(), other = t.length ? [...S.N.values()].filter((N) => !N.items.length && nodeMatches(N, t)).length : 0;
      return renderEmpty(other ? `Файлів не знайдено, але є ${other} нод(и) без файлів (асистенти, тексти). Подивись у режимі «Ланцюжки» — там видно, що з них згенеровано.` : 'Нічого не підходить під пошук і фільтри.');
    }
    grid.innerHTML = items.map((it, idx) => {
      const a = it.asset, dims = a.width && a.height ? a.width + '×' + a.height : '', dur = a.durationMs ? fmtDur(a.durationMs) : '';
      const sub = [S.sheetId === '*' ? it.sheetTitle : TYPE_NAME[it.node.type] || it.node.type, dims, dur].filter(Boolean).join(' · ');
      return `<div class="card${S.selected.has(it.key) ? ' sel' : ''}${it.active ? '' : ' inactive'}" data-key="${esc(it.key)}" data-idx="${idx}" tabindex="0" title="${esc(it.node.title)}${it.active ? '' : ' (неактивна версія)'}">
        ${thumbHTML(it)}<span class="kind">${KIND_NAME[a.kind]}</span>${badges(it)}
        <div class="meta"><div class="name">${esc(it.node.title || 'нода')}</div><div class="sub">${esc(sub)}</div></div></div>`;
    }).join('');
    hookThumbs(grid);
  }

  // ---------- 2. Ланцюжки (ієрархія) ----------
  function components() {
    const seen = new Set(), comps = [];
    for (const sid of S.sheetOrder) for (const N of S.N.values()) {
      if (N.sid !== sid || seen.has(N.key)) continue;
      const comp = [], st = [N.key]; seen.add(N.key);
      while (st.length) { const k = st.pop(), M = S.N.get(k); comp.push(M); for (const x of [...M.ins, ...M.outs]) if (!seen.has(x)) { seen.add(x); st.push(x); } }
      comps.push(comp);
    }
    return comps;
  }
  function renderTree() {
    const t = terms(), box = $('#tree');
    const pos = (N) => N.node.position || { x: 0, y: 0 };
    const comps = components().map((c) => {
      const media = c.reduce((s, N) => s + N.items.filter((it) => itemPass(it, { versions: true })).length, 0);
      const hit = !t.length || c.some((N) => nodeMatches(N, t));
      return { c, media, hit, top: Math.min(...c.map((N) => pos(N).y)), left: Math.min(...c.map((N) => pos(N).x)) };
    }).filter((x) => x.media && x.hit);
    if (!comps.length) return renderEmpty('Нічого не підходить під пошук і фільтри.');
    const chains = comps.filter((x) => x.c.length > 1), singles = comps.filter((x) => x.c.length === 1);
    chains.sort((a, b) => S.sheetOrder.indexOf(a.c[0].sid) - S.sheetOrder.indexOf(b.c[0].sid) || a.top - b.top || a.left - b.left);
    const shown = new Set(); let html = '', lastSheet = null;
    const sheetHead = (sid, title) => { if (S.sheetId !== '*' || sid === lastSheet) return ''; lastSheet = sid; return `<div class="t-sheet">${esc(title)}</div>`; };

    const row = (N, depth, path) => {
      if (shown.has(N.key)) {
        return `<div class="t-row t-ref" style="--d:${depth}"><span class="t-tw"></span><a href="#" data-goto="${esc(N.key)}">↪ ${esc(N.node.title || N.node.type)}</a> <span class="muted">(вище)</span></div>`;
      }
      shown.add(N.key);
      const kids = N.outs.map((k) => S.N.get(k)).sort((a, b) => pos(a).y - pos(b).y || pos(a).x - pos(b).x);
      const collapsed = S.collapsed.has(N.key) && !t.length;
      const items = N.items.filter((it) => itemPass(it, { versions: true }));
      const act = items.find((it) => it.active) || items[items.length - 1];
      const hit = t.length && nodeMatches(N, t) && N.own.toLowerCase().includes(t[0]);
      const showVers = items.length > 1 && (S.openNodes.has(N.key) || !S.activeOnly);
      const snippet = !items.length ? (N.node.type === 'text' ? (N.node.params || {}).text : N.answer || N.node.inline_prompt || '') : '';
      let h = `<div class="t-row${hit ? ' hit' : ''}${items.length ? ' media' : ''}" style="--d:${depth}" data-node="${esc(N.key)}">
        <span class="t-tw">${kids.length ? `<button class="t-fold" data-fold="${esc(N.key)}" title="${collapsed ? 'Розгорнути' : 'Згорнути'}">${collapsed ? '▸' : '▾'}</button>` : '<span class="t-dot">•</span>'}</span>
        ${act ? `<div class="t-pick${S.selected.has(act.key) ? ' sel' : ''}" data-key="${esc(act.key)}">${thumbHTML(act, 't-thumb')}</div>` : `<span class="t-ico">${N.node.type === 'assistant' ? '✦' : N.node.type === 'text' ? '¶' : '◇'}</span>`}
        <div class="t-body" data-open="${esc(N.key)}"><div class="t-title">${esc(N.node.title || N.node.type)} <span class="muted">${esc(TYPE_NAME[N.node.type] || N.node.type)}</span></div>
          ${snippet ? `<div class="t-snip">${esc(String(snippet).slice(0, 140))}</div>` : ''}</div>
        ${items.length > 1 ? `<button class="t-vers${showVers ? ' on' : ''}" data-vers="${esc(N.key)}" title="Показати всі версії">${items.length} вер.</button>` : ''}
      </div>`;
      if (showVers) h += `<div class="t-strip" style="--d:${depth}">${items.map((it) => `<div class="t-pick v${it.active ? ' act' : ''}${S.selected.has(it.key) ? ' sel' : ''}" data-key="${esc(it.key)}" title="Версія ${it.version}${it.active ? ' (активна)' : ' (неактивна)'} · ${fmtDate(it.out.createdAt)}">${thumbHTML(it, 't-thumb')}<span>${it.active ? '●' : ''}${it.version}</span></div>`).join('')}</div>`;
      if (!collapsed) for (const k of kids) h += row(k, depth + 1, path);
      else if (kids.length) h += `<div class="t-row t-more" style="--d:${depth + 1}"><span class="t-tw"></span><span class="muted">…ще ${countDown(N)} нод нижче</span></div>`;
      return h;
    };
    const countDown = (N) => { const s = new Set(), st = [...N.outs]; while (st.length) { const k = st.pop(); if (s.has(k)) continue; s.add(k); st.push(...S.N.get(k).outs); } return s.size; };

    for (const x of chains) {
      const roots = x.c.filter((N) => !N.ins.length).sort((a, b) => pos(a).y - pos(b).y);
      const start = roots.length ? roots : [x.c[0]];
      const name = start.map((N) => N.node.title || N.node.type).slice(0, 3).join(', ') + (start.length > 3 ? '…' : '');
      html += sheetHead(x.c[0].sid, x.c[0].sheetTitle);
      html += `<section class="t-chain"><div class="t-head"><b>${esc(name)}</b><span class="muted">${x.c.length} нод · ${x.media} файлів</span></div>`;
      for (const r of start) html += row(r, 0);
      for (const N of x.c) if (!shown.has(N.key)) html += row(N, 0); // цикли
      html += '</section>';
    }
    if (singles.length) {
      html += `<section class="t-chain"><div class="t-head"><b>Окремі ноди</b><span class="muted">без зʼєднань · ${singles.length}</span></div>`;
      for (const x of singles.sort((a, b) => a.top - b.top)) html += row(x.c[0], 0);
      html += '</section>';
    }
    box.innerHTML = html; hookThumbs(box);
  }

  // ---------- 3. Мапа (зменшене полотно) ----------
  const NODE_SIZE = { upload: [280, 300], image_gen: [340, 420], video_gen: [400, 420], assistant: [340, 300], text: [340, 260], music: [320, 260] };
  const nsize = (n) => [(n.size && n.size.width) || (NODE_SIZE[n.type] || [320, 260])[0], (n.size && n.size.height) || (NODE_SIZE[n.type] || [320, 260])[1]];
  function renderMap() {
    const box = $('#map'), t = terms();
    // аркуші одне під одним, кожен зі своєю рамкою
    let offY = 0; const place = new Map(), frames = [];
    for (const sid of S.sheetOrder) {
      const nodes = [...S.N.values()].filter((N) => N.sid === sid); if (!nodes.length) continue;
      const minX = Math.min(...nodes.map((N) => N.node.position.x)), minY = Math.min(...nodes.map((N) => N.node.position.y));
      let maxY = 0, maxX = 0;
      for (const N of nodes) { const [w, h] = nsize(N.node); const x = N.node.position.x - minX, y = N.node.position.y - minY + offY + 120; place.set(N.key, { x, y, w, h }); maxY = Math.max(maxY, y + h); maxX = Math.max(maxX, x + w); }
      frames.push({ title: nodes[0].sheetTitle, y: offY, h: maxY - offY, w: maxX });
      offY = maxY + 400;
    }
    if (!place.size) return renderEmpty('Аркуш порожній.');
    let lines = '';
    for (const N of S.N.values()) for (const k of N.outs) {
      const a = place.get(N.key), b = place.get(k); if (!a || !b) continue;
      const x1 = a.x + a.w, y1 = a.y + a.h / 2, x2 = b.x, y2 = b.y + b.h / 2, dx = Math.max(60, Math.abs(x2 - x1) / 2);
      lines += `<path d="M${x1},${y1} C${x1 + dx},${y1} ${x2 - dx},${y2} ${x2},${y2}"/>`;
    }
    const W = Math.max(...frames.map((f) => f.w)) + 200, H = offY;
    let nodesHtml = '';
    for (const N of S.N.values()) {
      const p = place.get(N.key), items = N.items.filter((it) => itemPass(it, { versions: true }));
      const act = items.find((it) => it.active) || items[items.length - 1];
      const hit = t.length && nodeMatches(N, t), dim = (t.length && !hit) || (S.kind !== 'all' && !items.length);
      nodesHtml += `<div class="m-node${hit ? ' hit' : ''}${dim ? ' dim' : ''}${act && S.selected.has(act.key) ? ' sel' : ''}" data-open="${esc(N.key)}" style="left:${p.x}px;top:${p.y}px;width:${p.w}px;height:${p.h}px">
        <div class="m-title">${esc(N.node.title || N.node.type)}${items.length > 1 ? ` <span>${items.length}</span>` : ''}</div>
        ${act ? thumbHTML(act, 'm-thumb') : `<div class="m-txt">${esc(String(N.prompt || N.answer || TYPE_NAME[N.node.type] || '').slice(0, 220))}</div>`}</div>`;
    }
    box.innerHTML = `<div class="m-world" style="width:${W}px;height:${H}px">
      ${frames.map((f) => `<div class="m-frame" style="top:${f.y}px;width:${f.w + 120}px;height:${f.h + 60}px"><span>${esc(f.title)}</span></div>`).join('')}
      <svg class="m-edges" width="${W}" height="${H}">${lines}</svg>${nodesHtml}</div>
      <div class="m-tools"><button data-zoom="in" title="Наблизити">+</button><button data-zoom="out" title="Віддалити">−</button><button data-zoom="fit" title="Показати все">⤢</button></div>`;
    S.mapWorld = { W, H };
    if (!S.mapView || S.mapView.sheet !== S.sheetId) mapFit(); else mapApply();
    // при пошуку — переліт до першої знайденої ноди
    if (t.length) { const first = [...S.N.values()].find((N) => nodeMatches(N, t)); if (first) mapFocus(place.get(first.key)); }
    hookThumbs(box);
  }
  function mapApply() { const w = $('#map .m-world'); if (w) w.style.transform = `translate(${S.mapView.x}px,${S.mapView.y}px) scale(${S.mapView.k})`; }
  function mapFit() {
    const box = $('#map'), r = box.getBoundingClientRect(), { W, H } = S.mapWorld;
    const k = Math.min((r.width || 360) / W, (r.height || 400) / H) * 0.95;
    S.mapView = { sheet: S.sheetId, k, x: ((r.width || 360) - W * k) / 2, y: 10 }; mapApply();
  }
  function mapFocus(p) {
    if (!p) return; const r = $('#map').getBoundingClientRect(), k = Math.max(S.mapView.k, Math.min(0.5, (r.width * 0.8) / p.w));
    S.mapView = { ...S.mapView, k, x: r.width / 2 - (p.x + p.w / 2) * k, y: r.height / 2 - (p.y + p.h / 2) * k }; mapApply();
  }
  function mapZoom(f, cx, cy) {
    const v = S.mapView, k = Math.min(3, Math.max(0.02, v.k * f));
    S.mapView = { ...v, k, x: cx - (cx - v.x) * (k / v.k), y: cy - (cy - v.y) * (k / v.k) }; mapApply();
  }

  // ---------- перегляд ноди (усі версії, промпт, звідки/куди) ----------
  let pvVideoToken = 0;
  function openNode(nkey, itemKey) {
    const N = S.N.get(nkey); if (!N) return;
    const items = N.items.filter((it) => S.kind === 'all' || it.asset.kind === S.kind);
    const cur = (itemKey && items.find((it) => it.key === itemKey)) || items.find((it) => it.active) || items[items.length - 1];
    S.pv = { nkey, itemKey: cur && cur.key };
    const chip = (k) => { const M = S.N.get(k); return `<button class="chip" data-open="${esc(k)}">${esc(M.node.title || M.node.type)}</button>`; };
    const a = cur && cur.asset;
    const txt = N.answer && N.node.type === 'assistant' ? N.answer : N.prompt;
    $('#pv').innerHTML = `<div class="pv-head"><div><b>${esc(N.node.title || N.node.type)}</b> <span class="muted">${esc(TYPE_NAME[N.node.type] || N.node.type)}${S.sheetId === '*' ? ' · ' + esc(N.sheetTitle) : ''}</span></div>
        <button class="icon" data-pv="close" title="Закрити (Esc)">✕</button></div>
      ${cur ? `<div class="pv-media" id="pv-media"></div>
        <div class="pv-info muted">Версія ${cur.version}/${cur.versions}${cur.active ? ' · активна' : ' · неактивна'} · ${fmtDate(cur.out.createdAt)}${a.width ? ' · ' + a.width + '×' + a.height : ''}${a.durationMs ? ' · ' + fmtDur(a.durationMs) : ''}</div>` : ''}
      ${items.length > 1 ? `<div class="pv-strip">${items.map((it) => `<div class="t-pick v${it.active ? ' act' : ''}${it.key === cur.key ? ' cur' : ''}${S.selected.has(it.key) ? ' sel' : ''}" data-pvitem="${esc(it.key)}" title="Версія ${it.version}${it.active ? ' (активна)' : ''}">${thumbHTML(it, 't-thumb')}<span>${it.active ? '●' : ''}${it.version}</span></div>`).join('')}</div>` : ''}
      ${cur ? `<div class="pv-actions">
        <button data-pv="select">${S.selected.has(cur.key) ? '✓ Вибрано' : 'Вибрати'}</button>
        <button data-pv="fav" class="${favs.has(a.id) ? 'on' : ''}">★</button>
        <span class="grow"></span>
        <button data-pv="project">У проєкт</button><button data-pv="comp" class="primary">${T.target}</button></div>` : ''}
      ${txt ? `<div class="pv-sec"><div class="pv-label">${N.answer && N.node.type === 'assistant' ? 'Відповідь' : 'Промпт'} <a href="#" data-pv="copy">копіювати</a></div><div class="pv-text">${esc(txt)}</div></div>` : ''}
      ${N.ins.length ? `<div class="pv-sec"><div class="pv-label">Звідки</div>${N.ins.map(chip).join('')}</div>` : ''}
      ${N.outs.length ? `<div class="pv-sec"><div class="pv-label">Куди</div>${N.outs.map(chip).join('')}</div>` : ''}
      <div class="pv-sec"><a href="#" data-pv="tree">Показати в ланцюжках</a> · <a href="#" data-pv="map">Показати на мапі</a></div>`;
    $('#pv').hidden = false; $('#pv').scrollTop = 0;
    hookThumbs($('#pv'));
    if (cur) showMedia(cur);
  }
  function cachePath(asset) {
    const ext = (EXT[asset.mime] || (asset.mime || '').split('/')[1] || 'bin').replace(/[^a-z0-9]/gi, '');
    return path.join(cacheDir, asset.id + '.' + ext);
  }
  async function showMedia(it) {
    const box = $('#pv-media'), a = it.asset, tok = ++pvVideoToken;
    if (a.kind === 'image') {
      box.innerHTML = '<div class="pv-load muted">Завантажую…</div>';
      const p = cachePath(a);
      if (!fs.existsSync(p)) await request('GET', a.url, { toFile: p }).catch(() => {});
      if (tok !== pvVideoToken) return;
      box.innerHTML = fs.existsSync(p) ? `<img src="${fileUrl(p)}" alt="">` : '<div class="pv-load">Не вдалося завантажити.</div>';
      return;
    }
    const poster = a.derived && a.derived.first_frame;
    let posterUrl = '';
    if (poster) { const pp = cachePath(poster); if (!fs.existsSync(pp)) await request('GET', poster.url, { toFile: pp }).catch(() => {}); if (fs.existsSync(pp)) posterUrl = fileUrl(pp); }
    if (tok !== pvVideoToken) return;
    const p = cachePath(a);
    const play = async () => {
      if (!fs.existsSync(p)) { box.querySelector('.pv-play').textContent = 'Завантажую…'; await request('GET', a.url, { toFile: p }).catch(() => {}); }
      if (tok !== pvVideoToken) return;
      box.innerHTML = a.kind === 'video' ? `<video src="${fileUrl(p)}" controls autoplay loop playsinline ${posterUrl ? `poster="${posterUrl}"` : ''}></video>` : `<audio src="${fileUrl(p)}" controls autoplay></audio>`;
    };
    if (fs.existsSync(p) || a.kind === 'audio' || (a.sizeBytes || 0) < 15e6) return play();
    box.innerHTML = `${posterUrl ? `<img src="${posterUrl}" alt="">` : ''}<button class="pv-play">▶ Відтворити (${Math.round(a.sizeBytes / 1e6)} МБ)</button>`;
    box.querySelector('.pv-play').onclick = play;
  }
  function closePv() { $('#pv').hidden = true; pvVideoToken++; $('#pv').innerHTML = ''; S.pv = null; }

  function revealInTree(nkey) {
    S.collapsed.clear(); setMode('tree');
    requestAnimationFrame(() => { const el = $('#tree').querySelector(`[data-node="${CSS.escape(nkey)}"]`); if (el) { el.scrollIntoView({ block: 'center' }); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 1400); } });
  }
  function revealInMap(nkey) {
    setMode('map');
    requestAnimationFrame(() => { const el = $('#map').querySelector(`[data-open="${CSS.escape(nkey)}"]`); if (el) { mapFocus({ x: el.offsetLeft, y: el.offsetTop, w: el.offsetWidth, h: el.offsetHeight }); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 1400); } });
  }
  function setMode(m) {
    S.mode = m; store.set('mode', m);
    document.querySelectorAll('#modes button').forEach((b) => b.classList.toggle('on', b.dataset.mode === m));
    render();
  }
  function updateFoot() {
    const n = S.selected.size;
    $('#sel-count').textContent = n ? 'Вибрано: ' + n : 'Нічого не вибрано';
    $('#btn-project').disabled = $('#btn-comp').disabled = !n;
    if (!$('#send').hidden) refreshSendForm();
  }
  function syncSelectionMarks() {
    document.querySelectorAll('[data-key]').forEach((c) => c.classList.toggle('sel', S.selected.has(c.dataset.key)));
    updateFoot();
  }

  // ---------- прев'ю (кеш у тимчасовій папці) ----------
  const cacheDir = path.join(os.tmpdir(), 'iyo-spaces-cache');
  try { fs.mkdirSync(cacheDir, { recursive: true }); } catch {}
  const thumbQueue = []; let thumbActive = 0;
  const fileUrl = (p) => encodeURI('file:///' + p.replace(/\\/g, '/').replace(/^\/+/, '')).replace(/#/g, '%23');
  function queueThumb(it, el) {
    const a = it.asset;
    const src = a.kind === 'image' ? a : a.kind === 'video' && a.derived && a.derived.first_frame ? a.derived.first_frame : null;
    if (!src) return;
    const p = cachePath(src);
    if (fs.existsSync(p)) { el.style.backgroundImage = `url("${fileUrl(p)}")`; return; }
    thumbQueue.push({ url: src.url, p, el }); pumpThumbs();
  }
  function pumpThumbs() {
    while (thumbActive < 4 && thumbQueue.length) {
      const job = thumbQueue.shift();
      if (!job.el.isConnected) continue; // картка вже зникла (змінився фільтр) — не тягнемо зайве
      if (fs.existsSync(job.p)) { job.el.style.backgroundImage = `url("${fileUrl(job.p)}")`; continue; }
      thumbActive++;
      request('GET', job.url, { toFile: job.p }).then((r) => { if (r.file && job.el.isConnected) job.el.style.backgroundImage = `url("${fileUrl(job.p)}")`; })
        .catch(() => {}).finally(() => { thumbActive--; pumpThumbs(); });
    }
  }

  // ---------- вибір ----------
  function pick(key, e, list) {
    if (e.shiftKey && S.lastClick != null && list) {
      const i1 = list.indexOf(S.lastClick), i2 = list.indexOf(key);
      if (i1 >= 0 && i2 >= 0) for (let i = Math.min(i1, i2); i <= Math.max(i1, i2); i++) S.selected.add(list[i]);
    } else if (e.ctrlKey || e.metaKey) {
      S.selected.has(key) ? S.selected.delete(key) : S.selected.add(key);
    } else {
      const only = S.selected.size === 1 && S.selected.has(key);
      S.selected.clear(); if (!only) S.selected.add(key);
    }
    S.lastClick = key; S.focusKey = key;
    syncSelectionMarks();
  }
  function onBrowseClick(e) {
    const fav = e.target.closest('[data-fav]');
    if (fav) { e.stopPropagation(); const id = fav.dataset.fav; favs.has(id) ? favs.delete(id) : favs.add(id); saveFavs(); document.querySelectorAll(`[data-fav="${CSS.escape(id)}"]`).forEach((x) => x.classList.toggle('on', favs.has(id))); if (S.onlyFav) render(); return; }
    const fold = e.target.closest('[data-fold]');
    if (fold) { const k = fold.dataset.fold; S.collapsed.has(k) ? S.collapsed.delete(k) : S.collapsed.add(k); renderTree(); return; }
    const vers = e.target.closest('[data-vers]');
    if (vers) { const k = vers.dataset.vers; S.openNodes.has(k) ? S.openNodes.delete(k) : S.openNodes.add(k); renderTree(); return; }
    const gt = e.target.closest('[data-goto]');
    if (gt) { e.preventDefault(); revealInTree(gt.dataset.goto); return; }
    const card = e.target.closest('[data-key]');
    if (card) { pick(card.dataset.key, e, S.mode === 'grid' ? visibleItems().map((x) => x.key) : null); return; }
    const op = e.target.closest('[data-open]');
    if (op && !S.mapDragged) openNode(op.dataset.open);
  }
  function onBrowseDbl(e) {
    const card = e.target.closest('[data-key]');
    if (card) { S.selected = new Set([card.dataset.key]); importSelected(true); }
  }
  function onPvClick(e) {
    const b = e.target.closest('[data-pv]'), vi = e.target.closest('[data-pvitem]'), op = e.target.closest('[data-open]');
    if (vi) { openNode(S.pv.nkey, vi.dataset.pvitem); return; }
    if (op) { openNode(op.dataset.open); return; }
    if (!b) return; e.preventDefault();
    const it = S.pv && itemByKey(S.pv.itemKey), act = b.dataset.pv;
    if (act === 'close') closePv();
    else if (act === 'select' && it) { S.selected.has(it.key) ? S.selected.delete(it.key) : S.selected.add(it.key); syncSelectionMarks(); openNode(S.pv.nkey, it.key); }
    else if (act === 'fav' && it) { favs.has(it.asset.id) ? favs.delete(it.asset.id) : favs.add(it.asset.id); saveFavs(); b.classList.toggle('on'); }
    else if ((act === 'project' || act === 'comp') && it) { S.selected = new Set([it.key]); syncSelectionMarks(); importSelected(act === 'comp'); }
    else if (act === 'copy') { const N = S.N.get(S.pv.nkey); const txt = N.answer && N.node.type === 'assistant' ? N.answer : N.prompt; try { navigator.clipboard.writeText(txt); status('Скопійовано.'); } catch { status('Не вдалося скопіювати.', true); } }
    else if (act === 'tree') { const k = S.pv.nkey; closePv(); revealInTree(k); }
    else if (act === 'map') { const k = S.pv.nkey; closePv(); revealInMap(k); }
  }
  function onKey(e) {
    const typing = /INPUT|TEXTAREA|SELECT/.test(document.activeElement && document.activeElement.tagName);
    if (e.key === 'Escape') { if (!$('#pv').hidden) return closePv(); if (typing && S.query) { $('#search').value = ''; S.query = ''; render(); } return; }
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') { e.preventDefault(); $('#search').focus(); $('#search').select(); return; }
    if (typing) return;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'a') { e.preventDefault(); visibleItems().forEach((it) => S.selected.add(it.key)); syncSelectionMarks(); return; }
    if (e.key === ' ') {
      e.preventDefault();
      if (!$('#pv').hidden) return closePv();
      const it = itemByKey(S.focusKey) || itemByKey([...S.selected][0]); if (it) openNode(it.nkey, it.key);
      return;
    }
    if (!$('#pv').hidden && (e.key === 'ArrowLeft' || e.key === 'ArrowRight')) {
      const N = S.N.get(S.pv.nkey), list = N.items, i = list.findIndex((x) => x.key === S.pv.itemKey);
      const j = i + (e.key === 'ArrowRight' ? 1 : -1); if (list[j]) openNode(N.key, list[j].key);
    }
  }
  function initMapInteractions() {
    const box = $('#map'); let drag = null;
    box.addEventListener('wheel', (e) => { if (S.mode !== 'map' || !S.mapView) return; e.preventDefault(); const r = box.getBoundingClientRect(); mapZoom(e.deltaY < 0 ? 1.15 : 1 / 1.15, e.clientX - r.left, e.clientY - r.top); }, { passive: false });
    box.addEventListener('mousedown', (e) => { if (e.button !== 0 || e.target.closest('.m-tools')) return; drag = { x: e.clientX, y: e.clientY, vx: S.mapView.x, vy: S.mapView.y }; S.mapDragged = false; });
    window.addEventListener('mousemove', (e) => { if (!drag) return; const dx = e.clientX - drag.x, dy = e.clientY - drag.y; if (Math.abs(dx) + Math.abs(dy) > 4) S.mapDragged = true; S.mapView = { ...S.mapView, x: drag.vx + dx, y: drag.vy + dy }; mapApply(); });
    window.addEventListener('mouseup', () => { drag = null; setTimeout(() => (S.mapDragged = false), 0); });
    box.addEventListener('click', (e) => { const z = e.target.closest('[data-zoom]'); if (!z) return; e.stopPropagation(); const r = box.getBoundingClientRect(); if (z.dataset.zoom === 'fit') mapFit(); else mapZoom(z.dataset.zoom === 'in' ? 1.4 : 1 / 1.4, r.width / 2, r.height / 2); }, true);
  }

  // ---------- перевірка реального формату файлу ----------
  // Сервер іноді віддає файл з іншим форматом, ніж у назві (наприклад, AVIF/WebP з Magnific під виглядом PNG),
  // а After Effects імпортує за розширенням. Тому визначаємо формат за першими байтами.
  function sniff(p) {
    const fd = fs.openSync(p, 'r'), b = Buffer.alloc(32); fs.readSync(fd, b, 0, 32, 0); fs.closeSync(fd);
    const a = (i, s) => b.toString('latin1', i, i + s.length) === s;
    if (b[0] === 0x89 && a(1, 'PNG')) return 'png';
    if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return 'jpg';
    if (a(0, 'GIF8')) return 'gif';
    if (a(0, 'RIFF') && a(8, 'WEBP')) return 'webp';
    if (a(0, 'RIFF') && a(8, 'WAVE')) return 'wav';
    if (a(4, 'ftyp')) { const br = b.toString('latin1', 8, 12); if (/^avi[fs]/.test(br)) return 'avif'; if (/^(heic|heix|mif1|msf1)/.test(br)) return 'heic'; if (br === 'qt  ') return 'mov'; if (/^M4A/.test(br)) return 'm4a'; return 'mp4'; }
    if (b[0] === 0x1a && b[1] === 0x45 && b[2] === 0xdf && b[3] === 0xa3) return 'webm';
    if (a(0, 'ID3') || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0)) return 'mp3';
    if (a(0, 'OggS')) return 'ogg';
    if (a(0, '8BPS')) return 'psd';
    if (a(0, 'II*\u0000') || a(0, 'MM\u0000*')) return 'tif';
    const t = b.toString('utf8').trimStart().toLowerCase();
    if (t.startsWith('<') || t.startsWith('{')) return 'html';
    return '';
  }
  async function toPng(src, dst) {
    const blob = new Blob([fs.readFileSync(src)]);
    const bmp = await createImageBitmap(blob);
    const c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height;
    c.getContext('2d').drawImage(bmp, 0, 0);
    const out = await new Promise((ok, bad) => c.toBlob((x) => (x ? ok(x) : bad(new Error('png'))), 'image/png'));
    fs.writeFileSync(dst, Buffer.from(await out.arrayBuffer()));
  }
  // повертає шлях до файлу з правильним розширенням (і конвертує AVIF/WebP/HEIC у PNG — AE їх не читає)
  async function fixFormat(p) {
    const real = sniff(p);
    if (real === 'html') { try { fs.unlinkSync(p); } catch {} throw new Error('замість файлу сервер повернув сторінку — схоже, закінчилась сесія. Онови вхід і спробуй ще раз'); }
    if (!real) return p;
    const base = p.replace(/\.[^.\\/]+$/, ''), cur = path.extname(p).slice(1).toLowerCase().replace('jpeg', 'jpg').replace('tiff', 'tif');
    if (['avif', 'webp', 'heic'].includes(real)) {
      const png = base + '.png';
      if (png !== p || real !== 'png') { await toPng(p, png + '.tmp'); try { fs.unlinkSync(p); } catch {} fs.renameSync(png + '.tmp', png); }
      return png;
    }
    if (real === cur) return p;
    const np = base + '.' + real;
    try { if (fs.existsSync(np)) fs.unlinkSync(np); } catch {}
    fs.renameSync(p, np);
    return np;
  }

  // ---------- імпорт ----------
  const safe = (s) => String(s || '').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 80) || 'untitled';
  const EXT = { 'video/mp4': 'mp4', 'video/quicktime': 'mov', 'video/webm': 'webm', 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif', 'audio/mpeg': 'mp3', 'audio/wav': 'wav', 'audio/x-wav': 'wav', 'audio/mp4': 'm4a', 'audio/ogg': 'ogg' };
  async function importSelected(toComp) {
    // один і той самий файл може бути в кількох нодах (скопійовані ноди ділять результат) — імпортуємо його один раз
    const seenAssets = new Set();
    const items = S.items.filter((it) => S.selected.has(it.key) && !seenAssets.has(it.asset.id) && seenAssets.add(it.asset.id));
    if (!items.length) return;
    $('#btn-project').disabled = $('#btn-comp').disabled = true;
    try {
      let root = decodeURIComponent(await evalES('iyo_projectDir()') || '');
      let note = '';
      if (!root || root === 'undefined') { root = path.join(os.homedir(), 'Documents', 'iyo-spaces'); note = ' Проєкт не збережено, тому файли лежать у Documents/iyo-spaces.'; }
      const payload = [];
      let n = 0;
      for (const it of items) {
        n++; status(`Завантажую ${n} / ${items.length}…`, false, true);
        const folders = ['iyo', safe(S.spaceTitle), safe(it.sheetTitle)];
        const dir = path.join(root, ...folders);
        fs.mkdirSync(dir, { recursive: true });
        const a = it.asset, ext = EXT[a.mime] || (a.mime || '').split('/')[1] || (a.kind === 'video' ? 'mp4' : a.kind === 'audio' ? 'mp3' : 'png');
        const name = `${safe(it.node && it.node.title)}${it.versions > 1 ? '_v' + it.version : ''}_${a.id.slice(0, 8)}.${ext}`;
        let p = path.join(dir, name);
        // файл могли вже завантажити й виправити розширення раніше — шукаємо за тією ж основою назви
        const stem = name.replace(/\.[^.]+$/, '');
        const prev = fs.existsSync(dir) ? fs.readdirSync(dir).find((f) => f.replace(/\.[^.]+$/, '') === stem && !f.endsWith('.part') && !f.endsWith('.tmp')) : null;
        if (prev) p = path.join(dir, prev);
        else {
          const r = await request('GET', a.url, { toFile: p });
          if (!r.file) throw new Error(`файл ${name}: HTTP ${r.status}`);
        }
        p = await fixFormat(p);
        payload.push({ path: p, folders, name: path.basename(p), kind: a.kind });
      }
      status('Імпортую в ' + T.host + '…', false, true);
      const json = JSON.stringify({ toTarget: toComp, items: payload }).replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
      const res = await evalES('iyo_import(' + esStr(json) + ')');
      if (res === 'ERR|notarget') return status(T.noTarget, true);
      if (!res || !res.startsWith('OK|')) return status(T.host + ' повернув помилку: ' + res, true);
      const [, imp, reused, layers, errs] = res.split('|');
      items.forEach((it) => S.imported.add(it.asset.id)); store.set('imported', [...S.imported].slice(-5000));
      const parts = [];
      if (+imp) parts.push('імпортовано ' + imp); if (+reused) parts.push('вже були в проєкті ' + reused); if (+layers) parts.push(T.placed + layers);
      const errText = decodeURIComponent(errs || '');
      status((parts.join(', ') || 'Готово') + '.' + note + (errText ? ' Помилки: ' + errText : ''), !!errText);
      render();
    } catch (e) {
      if (e.message !== 'unauthorized') status('Не вдалося: ' + e.message, true);
    } finally { updateFoot(); }
  }


  // ---------- відправка з AE в iyo ----------
  function uploadFile(sheetId, nodeId, file, meta) {
    return new Promise((resolve, reject) => {
      const qs = new URLSearchParams();
      for (const k of ['width', 'height', 'durationMs']) if (meta[k]) qs.set(k, String(Math.round(meta[k])));
      const u = new URL(`/api/sheets/${sheetId}/nodes/${encodeURIComponent(nodeId)}/upload?${qs}`, S.base);
      const boundary = '----iyo' + Math.random().toString(16).slice(2);
      const fname = path.basename(file).replace(/"/g, '');
      const head = Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${fname}"\r\nContent-Type: ${meta.mime}\r\n\r\n`);
      const tail = Buffer.from(`\r\n--${boundary}--\r\n`);
      const size = fs.statSync(file).size;
      const o = new URL(S.base).origin;
      const lib = u.protocol === 'http:' ? http : https;
      const rq = lib.request(u, { method: 'POST', headers: {
        'content-type': `multipart/form-data; boundary=${boundary}`, 'content-length': head.length + size + tail.length,
        cookie: S.cookie, origin: o, referer: o + '/', 'user-agent': 'Mozilla/5.0 (iyo Spaces AE panel)' } }, (res) => {
        const chunks = []; res.on('data', (c) => chunks.push(c));
        res.on('end', () => { const t = Buffer.concat(chunks).toString('utf8'); let j = null; try { j = JSON.parse(t); } catch {}
          if (res.statusCode === 401) { showLogin('Сесія закінчилась. Увійди ще раз.'); return reject(new Error('unauthorized')); }
          res.statusCode >= 400 ? reject(new Error((j && j.error) || 'HTTP ' + res.statusCode)) : resolve(j); });
      });
      rq.on('error', reject);
      rq.write(head);
      const rs = fs.createReadStream(file);
      rs.on('data', (c) => rq.write(c));
      rs.on('end', () => { rq.write(tail); rq.end(); });
      rs.on('error', reject);
    });
  }
  const MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', tif: 'image/tiff', tiff: 'image/tiff', psd: 'image/vnd.adobe.photoshop',
    mp4: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm', m4v: 'video/mp4', mp3: 'audio/mpeg', wav: 'audio/wav', m4a: 'audio/mp4', aac: 'audio/aac', ogg: 'audio/ogg' };
  const mimeOf = (p, kind) => MIME[path.extname(p).slice(1).toLowerCase()] || (kind === 'video' ? 'video/mp4' : kind === 'audio' ? 'audio/mpeg' : 'image/png');
  const titleFrom = (name, taken) => {
    let base = String(name || '').replace(/\.[a-z0-9]{2,4}$/i, '').trim().replace(/\s+/g, '_').replace(/[^\p{L}\p{N}_]/gu, '').slice(0, 60) || 'upload';
    let t = base, i = 2; while (taken.has(t.toLowerCase())) t = base + i++;
    taken.add(t.toLowerCase()); return t;
  };
  const waitFile = async (p, ms = 15000) => { const t0 = Date.now(); let last = -1;
    while (Date.now() - t0 < ms) { try { const sz = fs.statSync(p).size; if (sz > 0 && sz === last) return true; last = sz; } catch {} await new Promise((r) => setTimeout(r, 250)); }
    return fs.existsSync(p); };

  function selectedUploadItem() {
    if (S.selected.size !== 1) return null;
    const it = S.items.find((x) => S.selected.has(x.key));
    return it && it.node && it.node.type === 'upload' ? it : null;
  }
  function refreshSendForm() {
    $('#send-sheet').textContent = S.sheetId === '*' ? '(вибери конкретний аркуш)' : '«' + (S.sheetTitle || '') + '»';
    const it = selectedUploadItem();
    $('#dst-replace').disabled = !it; $('#dst-replace').closest('label').classList.toggle('off', !it);
    $('#send-node').textContent = it ? '(' + it.node.title + ')' : '(вибери одну upload-ноду)';
    if (!it && $('#dst-replace').checked) document.querySelector('input[name=dst][value=new]').checked = true;
  }
  async function sendToIyo() {
    if (!S.sheetId || S.sheetId === '*') return status('Для відправки вибери конкретний аркуш (не «Усі аркуші»).', true);
    const src = document.querySelector('input[name=src]:checked').value;
    const dst = document.querySelector('input[name=dst]:checked').value;
    const tmp = path.join(os.tmpdir(), 'iyo-spaces-send'); fs.mkdirSync(tmp, { recursive: true });
    $('#send-go').disabled = true;
    try {
      let files = [];
      if (src === 'selected') {
        const r = await evalES('iyo_selectedFiles()');
        if (!r.startsWith('OK|')) throw new Error(r);
        files = JSON.parse(decodeURIComponent(r.slice(3)));
        if (!files.length) return status('Вибери в панелі Project ' + (IS_PPRO ? 'кліпи' : 'футажі') + ' з файлами на диску (зображення, відео чи аудіо).', true);
      } else {
        status(src === 'render' ? `Рендерю ${IS_PPRO ? 'послідовність' : 'композицію'}… ${T.host} буде зайнятий до кінця рендеру.` : 'Зберігаю кадр…', false, true);
        const r = await evalES((src === 'render' ? 'iyo_renderComp(' : 'iyo_saveFrame(') + esStr(tmp) + ')');
        if (r === 'ERR|nocomp') return status(IS_PPRO ? 'Відкрий послідовність, з якої треба надіслати.' : 'Відкрий композицію, з якої треба надіслати.', true);
        if (r === 'ERR|noh264') return status((IS_PPRO ? 'Не знайшов пресет H.264 Premiere.' : 'Не знайшов шаблон H.264 у Output Module.') + ' Відрендер вручну й надішли файл через «Вибране в Project».', true);
        if (!r.startsWith('OK|')) throw new Error(r);
        const f = JSON.parse(decodeURIComponent(r.slice(3)));
        // exportFramePNG у деяких версіях Premiere сам дописує .png
        if (!(await waitFile(f.path, IS_PPRO ? 4000 : 15000)) && (await waitFile(f.path + '.png', 6000))) f.path += '.png';
        if (!fs.existsSync(f.path)) throw new Error('файл не зʼявився: ' + f.path);
        files = [f];
      }
      if (dst === 'replace' && files.length > 1) return status('У вибрану ноду можна надіслати лише один файл.', true);
      const target = dst === 'replace' ? selectedUploadItem() : null;
      if (dst === 'replace' && !target) return status('Вибери в сітці одну upload-ноду.', true);

      // місце для нових нод: праворуч від усього, що є на аркуші
      const nodes = (S.sheet.graph && S.sheet.graph.nodes) || [];
      const taken = new Set(nodes.map((n) => String(n.title || '').toLowerCase()));
      let x = nodes.length ? Math.max(...nodes.map((n) => n.position.x + ((n.size && n.size.width) || 400))) + 120 : 0;
      let y = nodes.length ? Math.min(...nodes.map((n) => n.position.y)) : 0;
      const client = 'ae-' + Math.random().toString(16).slice(2);
      let n = 0;
      for (const f of files) {
        n++; status(`Надсилаю ${n} / ${files.length}: ${f.name}…`, false, true);
        const mime = mimeOf(f.path, f.kind);
        let nodeId;
        if (target) nodeId = target.node.id;
        else {
          const h = f.kind === 'audio' ? 200 : f.width && f.height ? Math.round(280 * Math.min(2.2, Math.max(0.4, f.height / f.width))) : 498;
          const node = { id: 'n_' + Math.random().toString(16).slice(2, 10), type: 'upload', title: titleFrom(f.name, taken), position: { x, y }, params: { kind: f.kind }, size: { width: 280, height: h } };
          await api('POST', `/api/sheets/${S.sheetId}/ops`, { ops: [{ op: 'upsertNode', node }], clientId: client });
          nodeId = node.id; y += h + 60;
        }
        await uploadFile(S.sheetId, nodeId, f.path, { mime, width: f.width, height: f.height, durationMs: f.durationMs });
      }
      await loadSheet();
      status(`Надіслано: ${files.length} на аркуш «${S.sheetTitle}». Якщо аркуш відкритий у браузері, онови сторінку.`);
    } catch (e) {
      if (e.message !== 'unauthorized') status('Не вдалося надіслати: ' + e.message, true);
    } finally { $('#send-go').disabled = false; }
  }


  // ---------- міст із розширенням Chrome (iyo Bridge) ----------
  // Розширення надсилає сюди куки spaces.iyo.gg. Приймаємо тільки запити від розширень Chrome
  // і запам'ятовуємо перше розширення, що підключилось.
  const BRIDGE_PORTS = [47831, 47832, 47833, 47834, 47835];
  let bridgeServer = null, bridgePort = null;
  function startBridge(i = 0) {
    if (i >= BRIDGE_PORTS.length) { setBridgeInfo('Не вдалося відкрити локальний порт для розширення.'); return; }
    const srv = http.createServer((req, res) => {
      const origin = req.headers.origin || '';
      const allowed = origin === 'chrome-extension://glflmmillmjamlpgpjhekbfohjllmpfn'; // ID фіксований ключем у manifest.json розширення
      if (!allowed) { res.writeHead(403); return res.end(); }
      if (req.method === 'OPTIONS') { res.writeHead(204, { 'access-control-allow-origin': origin, 'access-control-allow-headers': 'content-type', 'access-control-allow-methods': 'POST' }); return res.end(); }
      if (req.method !== 'POST' || req.url !== '/session') { res.writeHead(404); return res.end(); }
      let body = '';
      req.on('data', (c) => { body += c; if (body.length > 1e6) req.destroy(); });
      req.on('end', () => {
        let j = {}; try { j = JSON.parse(body); } catch {}
        store.set('bridgeExt', origin);
        res.writeHead(200, { 'content-type': 'application/json', 'access-control-allow-origin': origin });
        res.end(JSON.stringify({ ok: true, app: HOST, user: S.me ? S.me.displayName || '' : '' }));
        onBridgeSession(String(j.cookie || ''), String(j.base || ''));
      });
    });
    srv.on('error', () => startBridge(i + 1));
    srv.listen(BRIDGE_PORTS[i], '127.0.0.1', () => { bridgeServer = srv; bridgePort = BRIDGE_PORTS[i]; setBridgeInfo(); });
  }
  function setBridgeInfo(err) {
    const el = $('#lg-bridge'); if (!el) return;
    el.textContent = err || (store.get('bridgeExt') ? 'Розширення iyo Bridge підключене. Увійди на spaces.iyo.gg у Chrome — вхід підхопиться сам.' : 'Чекаю на розширення iyo Bridge… Встанови його в Chrome і увійди на spaces.iyo.gg.');
  }
  let bridgeBusy = false;
  async function onBridgeSession(cookie, base) {
    if (base && /^https:\/\//.test(base)) S.base = base.replace(/\/+$/, '');
    if (!cookie || !/iyo_uid=/.test(cookie)) return; // у браузері ще не залогінений
    if (cookie === S.cookie && S.me) return;
    if (cookie === store.get('badCookie')) return; // ця сесія вже відхилена або з неї вийшли — чекаємо нову
    S.cookie = cookie; store.set('cookie', cookie); store.set('base', S.base);
    if (bridgeBusy) return; bridgeBusy = true;
    try { if (!$('#login').hidden || !S.me) await start(); } finally { bridgeBusy = false; }
  }
  window.addEventListener('beforeunload', () => { try { bridgeServer && bridgeServer.close(); } catch {} });

  // ---------- події ----------
  $('#btn-comp').textContent = T.target;
  $('#btn-project').title = 'Імпорт у ' + T.place + ' iyo / Спейс / Аркуш';
  $('#lg-go').addEventListener('click', doLogin);
  $('#lg-token').addEventListener('keydown', (e) => e.key === 'Enter' && doLogin());
  $('#lg-cookie-go').addEventListener('click', sessionLogin);
  $('#lg-tokenlink').addEventListener('click', (e) => { e.preventDefault(); window.cep.util.openURLInDefaultBrowser('https://id.atlassian.com/manage-profile/security/api-tokens'); });
  $('#sel-space').addEventListener('change', (e) => { S.spaceId = e.target.value; S.sheetId = ''; loadSpace().catch((er) => status(er.message, true)); });
  $('#sel-sheet').addEventListener('change', (e) => { S.sheetId = e.target.value; loadSheet().catch((er) => status(er.message, true)); });
  $('#btn-refresh').addEventListener('click', () => loadSheet().catch((er) => status(er.message, true)));
  $('#btn-menu').addEventListener('click', () => ($('#menu').hidden = !$('#menu').hidden));
  $('#btn-logout').addEventListener('click', logout);
  document.querySelectorAll('#kinds button').forEach((b) => b.addEventListener('click', () => {
    document.querySelectorAll('#kinds button').forEach((x) => x.classList.toggle('on', x === b)); S.kind = b.dataset.kind; render();
  }));
  document.querySelectorAll('#modes button').forEach((b) => b.addEventListener('click', () => setMode(b.dataset.mode)));
  $('#chk-active').addEventListener('change', (e) => { S.activeOnly = !e.target.checked; render(); });
  $('#chk-fav').addEventListener('change', (e) => { S.onlyFav = e.target.checked; render(); });
  $('#chk-new').addEventListener('change', (e) => { S.onlyNew = e.target.checked; render(); });
  $('#sort').value = S.sort;
  $('#sort').addEventListener('change', (e) => { S.sort = e.target.value; store.set('sort', S.sort); render(); });
  $('#cell').value = S.cell;
  $('#cell').addEventListener('input', (e) => { S.cell = +e.target.value; store.set('cell', S.cell); $('#grid').style.setProperty('--cell', S.cell + 'px'); });
  let searchTimer = null;
  $('#search').addEventListener('input', (e) => { clearTimeout(searchTimer); searchTimer = setTimeout(() => { S.query = $('#search').value.trim(); render(); }, 150); });
  for (const id of ['#grid', '#tree', '#map']) { $(id).addEventListener('click', onBrowseClick); $(id).addEventListener('dblclick', onBrowseDbl); }
  $('#pv').addEventListener('click', onPvClick);
  document.addEventListener('keydown', onKey);
  initMapInteractions();
  document.querySelectorAll('#modes button').forEach((b) => b.classList.toggle('on', b.dataset.mode === S.mode));
  $('#btn-project').addEventListener('click', () => importSelected(false));
  if (IS_PPRO) {
    document.querySelector('#send b').textContent = 'Надіслати з Premiere Pro в iyo';
    document.querySelector('input[name=src][value=frame]').parentElement.lastChild.textContent = ' Поточний кадр послідовності (PNG)';
    document.querySelector('input[name=src][value=render]').parentElement.lastChild.textContent = ' Рендер послідовності (H.264, уся послідовність)';
    $('#btn-send').title = 'Надіслати файл, кадр або рендер з Premiere Pro на аркуш';
  }
  $('#btn-send').addEventListener('click', () => { const sh = $('#send'); sh.hidden = !sh.hidden; if (!sh.hidden) refreshSendForm(); });
  $('#send-x').addEventListener('click', () => ($('#send').hidden = true));
  $('#send-go').addEventListener('click', sendToIyo);
  $('#btn-comp').addEventListener('click', () => importSelected(true));
  document.addEventListener('click', (e) => { if (!e.target.closest('#menu') && e.target.id !== 'btn-menu') $('#menu').hidden = true; });

  startBridge();
  start();
})();
