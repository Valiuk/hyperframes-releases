/*
  Hyperframes Library - ExtendScript host (ES3).
  Keep this file ASCII-only. All strings travel URI-encoded in both directions,
  so Cyrillic paths and names survive evalScript.
*/
var HFL = (function () {

    // ---------- tiny JSON ----------
    var ESC = { '"': '\\"', '\\': '\\\\', '\n': '\\n', '\r': '\\r', '\t': '\\t' };
    function q(s) {
        return '"' + String(s).replace(/["\\\u0000-\u001f]/g, function (c) {
            return ESC[c] || ('\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4));
        }) + '"';
    }
    function stringify(v) {
        if (v === null || v === undefined) return 'null';
        var t = typeof v, i, parts;
        if (t === 'number') return isFinite(v) ? String(v) : 'null';
        if (t === 'boolean') return String(v);
        if (t === 'string') return q(v);
        if (v instanceof Array) {
            parts = [];
            for (i = 0; i < v.length; i++) parts.push(stringify(v[i]));
            return '[' + parts.join(',') + ']';
        }
        parts = [];
        for (var k in v) if (v.hasOwnProperty(k)) parts.push(q(k) + ':' + stringify(v[k]));
        return '{' + parts.join(',') + '}';
    }
    function out(o) { return encodeURIComponent(stringify(o)); }
    function ok(d) { return out({ ok: true, data: d === undefined ? null : d }); }
    function fail(e) { return out({ ok: false, error: String(e && e.message ? e.message : e) }); }
    function args(s) { return eval('(' + decodeURIComponent(s) + ')'); }

    // ---------- helpers ----------
    var IMG_EXT = /\.(png|jpe?g|tiff?|psd|exr|tga|bmp|dpx|cin|webp|sgi|rla|rpf|iff)$/i;

    function isFileFootage(it) {
        return (it instanceof FootageItem) && (it.mainSource instanceof FileSource) && it.file;
    }
    function looksLikeSequence(it) {
        if (!isFileFootage(it)) return false;
        return IMG_EXT.test(it.file.fsName) && !it.mainSource.isStill;
    }
    function byId(id) {
        try { var r = app.project.itemByID(id); if (r) return r; } catch (e) {}
        var items = app.project.items;
        for (var i = 1; i <= items.length; i++) if (items[i].id === id) return items[i];
        return null;
    }
    function clampDim(v) { v = Math.round(v || 0); return v < 4 ? 4 : (v > 30000 ? 30000 : v); }

    function saveFrame(comp, time, fsPath) {
        try {
            var f = new File(fsPath);
            if (f.exists) f.remove();
            comp.saveFrameToPng(time, f);
            for (var k = 0; k < 60; k++) {
                if (f.exists && f.length > 0) return true;
                $.sleep(50);
            }
            return f.exists;
        } catch (e) { return false; }
    }

    function pad(n) { return (n < 10 ? '00' : (n < 100 ? '0' : '')) + n; }

    // Renders `count` frames evenly spread over [start, start+span] into outDir/f_000.png ...
    function renderFramesCore(comp, start, span, count, outDir) {
        var dir = new Folder(outDir);
        if (!dir.exists) dir.create();
        var n = Math.max(1, Math.round(count || 1)), saved = 0;
        if (!(span > 0)) { span = comp.frameDuration; n = 1; }
        for (var i = 0; i < n; i++) {
            var t = start + span * (i + 0.5) / n;
            if (saveFrame(comp, t, dir.fsName + '/f_' + pad(i) + '.png')) saved++;
        }
        return saved;
    }

    function footageComp(it) {
        var still = it.mainSource.isStill;
        var fps = it.frameRate > 0 ? it.frameRate : 25;
        var dur = (still || !(it.duration > 0)) ? 1 : it.duration;
        var c = app.project.items.addComp('__hfl_preview', clampDim(it.width), clampDim(it.height), it.pixelAspect || 1, dur, fps);
        c.layers.add(it);
        return { comp: c, still: still, span: still ? 0 : dur };
    }

    function inside(it, folderId) {
        var rootId = app.project.rootFolder.id, p;
        try { p = it.parentFolder; } catch (e) { return false; }
        while (p) {
            if (p.id === folderId) return true;
            if (p.id === rootId) return false;
            try { p = p.parentFolder; } catch (e2) { return false; }
        }
        return false;
    }

    function libFolder() {
        var items = app.project.items, rootId = app.project.rootFolder.id;
        for (var i = 1; i <= items.length; i++) {
            var it = items[i];
            if (it instanceof FolderItem && it.name === 'HF Library' && it.parentFolder.id === rootId) return it;
        }
        return items.addFolder('HF Library');
    }

    function findComp(folder, name) {
        var items = app.project.items, i, it, fallback = null;
        for (i = 1; i <= items.length; i++) {
            it = items[i];
            if (!(it instanceof CompItem) || !inside(it, folder.id)) continue;
            if (name && it.name === name) return it;
            if (!fallback && it.usedIn.length === 0) fallback = it;
        }
        return fallback;
    }

    function findFootage(fsName) {
        var items = app.project.items, low = fsName.toLowerCase();
        for (var i = 1; i <= items.length; i++) {
            var it = items[i];
            if (isFileFootage(it) && it.file.fsName.toLowerCase() === low) return it;
        }
        return null;
    }

    // Copies every file-based footage of the (already reduced) project into dir/footage
    // and relinks it, so the saved .aep is self-contained.
    function collectFootage(dir) {
        var fdir = new Folder(dir + '/footage');
        if (!fdir.exists) fdir.create();
        var used = {}, copied = 0, skipped = 0, items = app.project.items;
        for (var i = 1; i <= items.length; i++) {
            var it = items[i];
            if (!isFileFootage(it)) continue;
            if (it.footageMissing || looksLikeSequence(it)) { skipped++; continue; }
            var src = new File(it.file.fsName);
            if (!src.exists) { skipped++; continue; }
            var base = src.displayName, name = base, n = 1, dot = base.lastIndexOf('.');
            while (used[name.toLowerCase()]) {
                name = (dot > 0 ? base.substring(0, dot) : base) + '_' + (n++) + (dot > 0 ? base.substring(dot) : '');
            }
            used[name.toLowerCase()] = true;
            var dst = new File(fdir.fsName + '/' + name);
            if (src.copy(dst.fsName)) {
                try { it.replace(dst); copied++; } catch (e) { skipped++; }
            } else {
                skipped++;
            }
        }
        return { copied: copied, skipped: skipped };
    }

    // ---------- API ----------
    function ping() {
        return ok({ version: app.version });
    }

    function getSelection() {
        try {
            var p = app.project;
            if (!p) return fail('NO_PROJECT');
            var sel = p.selection, res = [];
            for (var i = 0; i < sel.length; i++) {
                var it = sel[i], o = { id: it.id, name: it.name, type: 'other' };
                if (it instanceof CompItem) {
                    o.type = 'comp';
                    o.width = it.width; o.height = it.height; o.duration = it.duration; o.fps = it.frameRate;
                } else if (isFileFootage(it)) {
                    o.type = 'footage';
                    o.path = it.file.fsName;
                    o.hasVideo = it.hasVideo; o.hasAudio = it.hasAudio;
                    o.isStill = it.mainSource.isStill;
                    o.isSeq = looksLikeSequence(it);
                    o.width = it.width; o.height = it.height; o.duration = it.duration;
                }
                res.push(o);
            }
            return ok({ items: res, projectSaved: !!p.file });
        } catch (e) { return fail(e); }
    }

    // items: [{aeId, outDir, aep, dir}], collect: bool, count: preview frames
    function saveComps(s) {
        var a, p = app.project, orig, i, results = [];
        try {
            a = args(s);
            if (!p.file) return fail('NOT_SAVED');
            orig = new File(p.file.fsName);
            for (i = 0; i < a.items.length; i++) {
                var job = a.items[i], c = byId(job.aeId);
                if (!(c instanceof CompItem)) { job.err = 'NOT_FOUND'; continue; }
                job.span = c.workAreaDuration;
                job.count = renderFramesCore(c, c.workAreaStart, c.workAreaDuration, a.count, job.outDir);
            }
            p.save();
        } catch (e) { return fail(e); }

        app.beginSuppressDialogs();
        try {
            for (i = 0; i < a.items.length; i++) {
                var j = a.items[i];
                if (j.err) { results.push({ aeId: j.aeId, ok: false, error: j.err }); continue; }
                try {
                    var comp = byId(j.aeId);
                    app.project.reduceProject([comp]);
                    var col = a.collect ? collectFootage(j.dir) : { copied: 0, skipped: 0 };
                    app.project.save(new File(j.aep));
                    results.push({ aeId: j.aeId, ok: true, count: j.count, span: j.span, copied: col.copied, skipped: col.skipped });
                } catch (e2) {
                    results.push({ aeId: j.aeId, ok: false, error: String(e2.message || e2) });
                }
                try { app.project.close(CloseOptions.DO_NOT_SAVE_CHANGES); } catch (e3) {}
                app.open(orig);
            }
        } catch (e4) {
            try { app.project.close(CloseOptions.DO_NOT_SAVE_CHANGES); app.open(orig); } catch (e5) {}
            app.endSuppressDialogs(false);
            return fail(e4);
        }
        app.endSuppressDialogs(false);
        return ok({ results: results });
    }

    // items: [{aeId, outDir}], count - preview frames for footage already in the project.
    function framesForItems(s) {
        var a, res = [];
        try { a = args(s); } catch (e) { return fail(e); }
        app.beginUndoGroup('HF Library preview');
        try {
            for (var i = 0; i < a.items.length; i++) {
                var job = a.items[i], it = byId(job.aeId), n = 0, span = 0, fc = null;
                try {
                    if (it instanceof FootageItem && it.hasVideo) {
                        fc = footageComp(it);
                        span = fc.span;
                        n = renderFramesCore(fc.comp, 0, fc.span, fc.still ? 1 : a.count, job.outDir);
                    }
                } catch (e1) { n = 0; }
                if (fc) { try { fc.comp.remove(); } catch (e2) {} }
                res.push({ aeId: job.aeId, count: n, span: span });
            }
        } finally {
            app.endUndoGroup();
        }
        return ok({ results: res });
    }

    // {type, file, mainComp, outDir, count} - preview frames for an item already in the library.
    // Imports it temporarily and removes it afterwards.
    function renderFrames(s) {
        var a;
        try { a = args(s); } catch (e) { return fail(e); }
        if (!app.project) app.newProject();
        var f = new File(a.file);
        if (!f.exists) return fail('FILE_MISSING');
        var temp = null, fc = null, n = 0, span = 0;
        app.beginSuppressDialogs();
        app.beginUndoGroup('HF Library preview');
        try {
            if (a.type === 'comp') {
                temp = app.project.importFile(new ImportOptions(f));
                var c = findComp(temp, a.mainComp);
                if (!c) return fail('NOT_FOUND');
                span = c.workAreaDuration;
                n = renderFramesCore(c, c.workAreaStart, c.workAreaDuration, a.count, a.outDir);
            } else {
                var it = findFootage(f.fsName);
                if (!it) { it = app.project.importFile(new ImportOptions(f)); temp = it; }
                if (!it.hasVideo) return fail('NO_VIDEO');
                fc = footageComp(it);
                span = fc.span;
                n = renderFramesCore(fc.comp, 0, fc.span, fc.still ? 1 : a.count, a.outDir);
            }
            return ok({ count: n, span: span });
        } catch (e2) {
            return fail(e2);
        } finally {
            if (fc) { try { fc.comp.remove(); } catch (x1) {} }
            if (temp) { try { temp.remove(); } catch (x2) {} }
            app.endUndoGroup();
            app.endSuppressDialogs(false);
        }
    }

    // {type: comp|footage|preset, file, name, mainComp, target: comp|project}
    function importItem(s) {
        var a;
        try { a = args(s); } catch (e) { return fail(e); }
        if (!app.project) app.newProject();
        var f = new File(a.file);
        if (!f.exists) return fail('FILE_MISSING');
        var active = app.project.activeItem;
        var comp = (active instanceof CompItem) ? active : null;

        app.beginUndoGroup('HF Library: ' + a.name);
        try {
            if (a.type === 'preset') {
                if (!comp) return fail('NO_ACTIVE_COMP');
                var layers = comp.selectedLayers;
                if (!layers.length) return fail('NO_LAYERS');
                for (var i = 0; i < layers.length; i++) layers[i].applyPreset(f);
                return ok({ message: 'PRESET_APPLIED', count: layers.length });
            }

            var item;
            if (a.type === 'comp') {
                var folder = app.project.importFile(new ImportOptions(f));
                folder.name = a.name;
                folder.parentFolder = libFolder();
                item = findComp(folder, a.mainComp);
                if (!item) return ok({ message: 'IMPORTED_PROJECT' });
            } else {
                item = findFootage(f.fsName);
                if (!item) {
                    item = app.project.importFile(new ImportOptions(f));
                    item.parentFolder = libFolder();
                }
            }

            if (a.target === 'comp') {
                if (!comp) return ok({ message: 'NO_COMP_IMPORTED' });
                if (item.id === comp.id) return ok({ message: 'IMPORTED' });
                var layer = comp.layers.add(item);
                layer.startTime = comp.time;
                return ok({ message: 'ADDED_TO_COMP' });
            }
            return ok({ message: 'IMPORTED' });
        } catch (e2) {
            return fail(e2);
        } finally {
            app.endUndoGroup();
        }
    }

    return {
        ping: ping,
        getSelection: getSelection,
        saveComps: saveComps,
        framesForItems: framesForItems,
        renderFrames: renderFrames,
        importItem: importItem
    };
})();
