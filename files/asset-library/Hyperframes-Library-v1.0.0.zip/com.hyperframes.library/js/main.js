(function () {
  'use strict';

  const $ = s => document.querySelector(s);
  const req = (window.cep_node && window.cep_node.require) || window.require;
  if (!req || !window.__adobe_cep__) {
    $('#empty').hidden = false;
    $('#empty').textContent = 'Відкрийте панель в After Effects: Window → Extensions → Hyperframes Library.';
    return;
  }
  const fs = req('fs');
  const path = req('path');
  const os = req('os');
  const cp = req('child_process');
  const IS_WIN = os.platform() === 'win32';

  // ---------- texts ----------
  const TEXT = {
    HOST_DOWN: 'Скрипт After Effects не відповідає. Перезапустіть панель.',
    NO_PROJECT: 'Немає відкритого проєкту.',
    NOT_SAVED: 'Спершу збережіть поточний проєкт (File → Save).',
    NOT_FOUND: 'Композицію не знайдено.',
    FILE_MISSING: 'Файл елемента відсутній у папці бібліотеки.',
    NO_ACTIVE_COMP: 'Відкрийте композицію, до якої застосувати пресет.',
    NO_LAYERS: 'Виділіть шари, до яких застосувати пресет.',
    ADDED_TO_COMP: 'Додано в композицію.',
    IMPORTED: 'Імпортовано в проєкт.',
    NO_COMP_IMPORTED: 'Активної композиції немає — імпортовано в проєкт.',
    IMPORTED_PROJECT: 'Імпортовано в проєкт. Основну композицію не знайдено.',
    NOTHING_SELECTED: 'Виділіть композиції або футаж у панелі Project.',
    NO_VIDEO: 'У цього файлу немає зображення.',
    SEQ_SKIPPED: 'Секвенції зображень поки не підтримуються — додайте їх як відео.'
  };
  const t = code => TEXT[code] || code;

  // ---------- file types ----------
  const EXT = {
    image: ['png', 'jpg', 'jpeg', 'tif', 'tiff', 'psd', 'ai', 'eps', 'gif', 'webp', 'exr', 'tga', 'bmp', 'svg', 'heic'],
    video: ['mp4', 'mov', 'avi', 'mxf', 'm4v', 'mpg', 'mpeg', 'wmv', 'webm'],
    audio: ['wav', 'mp3', 'aif', 'aiff', 'm4a', 'aac'],
    preset: ['ffx'],
    comp: ['aep', 'aet']
  };
  const ALL_EXT = [].concat(...Object.values(EXT));
  function kindOf(file) {
    const e = path.extname(file).slice(1).toLowerCase();
    for (const k in EXT) if (EXT[k].indexOf(e) !== -1) return k;
    return null;
  }

  // ---------- settings ----------
  const LS = {
    get(k, d) { try { const v = localStorage.getItem('hfl.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('hfl.' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  };
  let root = LS.get('root', path.join(os.homedir(), 'Documents', 'Hyperframes Library'));
  const state = {
    lib: null,
    libMtime: 0,
    cat: LS.get('cat', '*'),
    types: LS.get('types', { comp: true, footage: true, preset: true }),
    q: '',
    tile: LS.get('tile', 110),
    collect: LS.get('collect', true),
    frames: LS.get('frames', 24),
    sel: null,
    busy: false
  };

  // ---------- host bridge ----------
  function host(fn, args) {
    return new Promise((resolve, reject) => {
      const a = args === undefined ? '' : JSON.stringify(encodeURIComponent(JSON.stringify(args)));
      window.__adobe_cep__.evalScript('HFL.' + fn + '(' + a + ')', r => {
        let o;
        try { o = JSON.parse(decodeURIComponent(r)); } catch (e) { return reject(new Error(t('HOST_DOWN'))); }
        if (o.ok) resolve(o.data); else reject(new Error(t(o.error)));
      });
    });
  }

  // ---------- fs helpers ----------
  function mkdirp(d) { if (!fs.existsSync(d)) { mkdirp(path.dirname(d)); fs.mkdirSync(d); } }
  function rmrf(p) {
    if (!fs.existsSync(p)) return;
    if (fs.lstatSync(p).isDirectory()) {
      fs.readdirSync(p).forEach(f => rmrf(path.join(p, f)));
      fs.rmdirSync(p);
    } else fs.unlinkSync(p);
  }
  const copyFile = (a, b) => new Promise((res, rej) => fs.copyFile(a, b, e => (e ? rej(e) : res())));
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const libFile = () => path.join(root, 'library.json');
  const itemDir = id => path.join(root, 'items', id);
  const rel = p => path.relative(root, p).split(path.sep).join('/');
  const abs = r => path.join(root, ...r.split('/'));
  const newId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const safeName = s => (String(s).replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').trim().slice(0, 80) || 'comp');
  function fileUrl(p) {
    let s = p.replace(/\\/g, '/');
    if (s[0] !== '/') s = '/' + s;
    return 'file://' + s.split('/').map((seg, i) => (i === 1 && /^[A-Za-z]:$/.test(seg) ? seg : encodeURIComponent(seg))).join('/');
  }

  function loadLib() {
    mkdirp(path.join(root, 'items'));
    const f = libFile();
    try {
      const d = JSON.parse(fs.readFileSync(f, 'utf8'));
      d.items = d.items || [];
      d.categories = d.categories || [];
      state.libMtime = fs.statSync(f).mtimeMs;
      return d;
    } catch (e) {
      if (fs.existsSync(f)) fs.copyFileSync(f, f + '.broken-' + Date.now());
      return { version: 1, categories: [], items: [] };
    }
  }
  function saveLib() {
    const f = libFile(), tmp = f + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(state.lib, null, 1), 'utf8');
    fs.renameSync(tmp, f);
    state.libMtime = fs.statSync(f).mtimeMs;
  }

  // ---------- previews ----------
  // thumb.webp   - one still frame (max 360px), shown in the grid
  // preview.webp - horizontal strip of N frames (max 240px each), played only on hover
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  function writeCanvas(c, dest) {
    fs.writeFileSync(dest, Buffer.from(c.toDataURL('image/webp', 0.8).split(',')[1], 'base64'));
  }
  function writeThumb(src, w, h, dest) {
    if (!w || !h) throw new Error('no size');
    const k = Math.min(1, 360 / Math.max(w, h));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w * k));
    c.height = Math.max(1, Math.round(h * k));
    c.getContext('2d').drawImage(src, 0, 0, c.width, c.height);
    writeCanvas(c, dest);
  }
  function loadImg(file) {
    return new Promise(res => {
      let url;
      try {
        if (fs.statSync(file).size > 120 * 1024 * 1024) return res(null);
        url = URL.createObjectURL(new Blob([fs.readFileSync(file)]));
      } catch (e) { return res(null); }
      const img = new Image();
      img.onload = () => res({ img, url });
      img.onerror = () => { URL.revokeObjectURL(url); res(null); };
      img.src = url;
    });
  }
  async function imageThumb(src, dest) {
    const r = await loadImg(src);
    if (!r) return false;
    try { writeThumb(r.img, r.img.naturalWidth, r.img.naturalHeight, dest); return true; } catch (e) { return false; } finally { URL.revokeObjectURL(r.url); }
  }
  function setStrip(it, dir, canvas, n, span) {
    const pv = path.join(dir, 'preview.webp');
    writeCanvas(canvas, pv);
    it.preview = rel(pv);
    it.frames = n;
    it.pfps = +clamp(span > 0 ? n / span : 12, 6, 24).toFixed(2);
  }
  function clearStrip(it, dir) {
    delete it.preview; delete it.frames; delete it.pfps;
    try { fs.unlinkSync(path.join(dir, 'preview.webp')); } catch (e) { /* none */ }
  }

  const listFrames = dir => {
    try { return fs.readdirSync(dir).filter(f => /^f_\d+\.png$/.test(f)).sort().map(f => path.join(dir, f)); } catch (e) { return []; }
  };
  async function waitFrames(dir, expected) {
    for (let i = 0; i < 50 && listFrames(dir).length < expected; i++) await sleep(100);
    await sleep(80);
    return listFrames(dir);
  }
  // PNG frames rendered by AE -> thumb + strip
  async function framesToPreview(files, it, dir, span) {
    const imgs = [];
    for (const f of files) { const r = await loadImg(f); if (r) imgs.push(r); }
    if (!imgs.length) return false;
    try {
      const mid = imgs[Math.floor((imgs.length - 1) / 2)].img;
      const th = path.join(dir, 'thumb.webp');
      writeThumb(mid, mid.naturalWidth, mid.naturalHeight, th);
      it.thumb = rel(th);
      if (imgs.length > 1) {
        const w0 = imgs[0].img.naturalWidth, h0 = imgs[0].img.naturalHeight, k = Math.min(1, 240 / Math.max(w0, h0));
        const fw = Math.max(1, Math.round(w0 * k)), fh = Math.max(1, Math.round(h0 * k));
        const c = document.createElement('canvas');
        c.width = fw * imgs.length;
        c.height = fh;
        const ctx = c.getContext('2d');
        imgs.forEach((r, i) => ctx.drawImage(r.img, i * fw, 0, fw, fh));
        setStrip(it, dir, c, imgs.length, span);
      } else clearStrip(it, dir);
      it.pv = Date.now();
      return true;
    } catch (e) {
      return false;
    } finally {
      imgs.forEach(r => URL.revokeObjectURL(r.url));
    }
  }
  // Browser-decodable video (H.264 mp4 etc.) -> thumb + strip without touching AE
  function videoPreview(src, it, dir, count) {
    return new Promise(res => {
      const v = document.createElement('video');
      let done = false, times = [], i = 0, c, ctx, fw, fh;
      const finish = okk => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        v.removeAttribute('src');
        v.load();
        res(okk);
      };
      const timer = setTimeout(() => finish(false), 30000);
      v.muted = true;
      v.preload = 'auto';
      v.onloadedmetadata = () => {
        const d = v.duration, w = v.videoWidth, h = v.videoHeight;
        if (!w || !h || !isFinite(d) || d <= 0) return finish(false);
        const n = Math.max(1, count);
        times = Array.from({ length: n }, (_, k) => d * (k + 0.5) / n);
        const k = Math.min(1, 240 / Math.max(w, h));
        fw = Math.max(1, Math.round(w * k));
        fh = Math.max(1, Math.round(h * k));
        c = document.createElement('canvas');
        c.width = fw * n;
        c.height = fh;
        ctx = c.getContext('2d');
        if (!it.dur) it.dur = d;
        if (!it.w) { it.w = w; it.h = h; }
        v.currentTime = times[0];
      };
      v.onseeked = () => {
        try {
          ctx.drawImage(v, i * fw, 0, fw, fh);
          if (i === Math.floor((times.length - 1) / 2)) {
            const th = path.join(dir, 'thumb.webp');
            writeThumb(v, v.videoWidth, v.videoHeight, th);
            it.thumb = rel(th);
          }
          i++;
          if (i < times.length) { v.currentTime = times[i]; return; }
          if (times.length > 1) setStrip(it, dir, c, times.length, v.duration); else clearStrip(it, dir);
          it.pv = Date.now();
          finish(true);
        } catch (e) { finish(false); }
      };
      v.onerror = () => finish(false);
      v.src = fileUrl(src);
    });
  }
  // Anything else (comps, ProRes, PSD...) -> let AE render the frames
  async function aeFileFrames(it, dir) {
    const fd = path.join(dir, '_frames');
    rmrf(fd);
    mkdirp(fd);
    try {
      const count = it.type === 'footage' && it.media === 'image' ? 1 : state.frames;
      const r = await host('renderFrames', { type: it.type, file: abs(it.file), mainComp: it.mainComp || '', outDir: fd, count });
      return await framesToPreview(await waitFrames(fd, r.count), it, dir, r.span);
    } catch (e) {
      status(e.message, true);
      return false;
    } finally {
      rmrf(fd);
    }
  }
  async function makePreview(it) {
    const dir = itemDir(it.id), f = abs(it.file);
    if (it.type === 'preset' || (it.type === 'footage' && it.media === 'audio')) return false;
    if (it.type === 'footage' && it.media === 'video' && await videoPreview(f, it, dir, state.frames)) return true;
    if (it.type === 'footage' && it.media === 'image') {
      const th = path.join(dir, 'thumb.webp');
      if (await imageThumb(f, th)) { it.thumb = rel(th); it.pv = Date.now(); return true; }
    }
    return aeFileFrames(it, dir);
  }

  // ---------- UI helpers ----------
  let statusTimer = 0;
  function status(msg, err) {
    const el = $('#status');
    el.textContent = msg || '';
    el.title = msg || '';
    el.classList.toggle('err', !!err);
    clearTimeout(statusTimer);
    if (msg && !state.busy) statusTimer = setTimeout(() => { el.textContent = ''; el.title = ''; }, 7000);
  }
  function setBusy(b) { state.busy = b; document.body.classList.toggle('busy', b); }

  function modal(opts) {
    return new Promise(resolve => {
      const ov = document.createElement('div');
      ov.className = 'overlay';
      const dlg = document.createElement('div');
      dlg.className = 'dlg';
      dlg.setAttribute('role', 'dialog');
      if (opts.title) { const h = document.createElement('h2'); h.textContent = opts.title; dlg.appendChild(h); }
      const body = document.createElement('div');
      if (opts.text) { const p = document.createElement('p'); p.textContent = opts.text; body.appendChild(p); }
      if (opts.build) opts.build(body);
      dlg.appendChild(body);
      const act = document.createElement('div');
      act.className = 'dlg-actions';
      const buttons = opts.buttons || [{ label: 'OK', value: true, primary: true }];
      const close = v => { document.removeEventListener('keydown', onKey, true); ov.remove(); resolve({ value: v, body }); };
      buttons.forEach(b => {
        const btn = document.createElement('button');
        btn.textContent = b.label;
        btn.className = 'btn' + (b.primary ? ' primary' : '') + (b.danger ? ' danger' : '');
        btn.onclick = () => close(b.value);
        act.appendChild(btn);
      });
      dlg.appendChild(act);
      ov.appendChild(dlg);
      ov.addEventListener('mousedown', e => { if (e.target === ov) close(null); });
      const onKey = e => {
        if (e.key === 'Escape') { e.stopPropagation(); close(null); }
        else if (e.key === 'Enter') {
          const p = buttons.find(b => b.primary);
          if (p) { e.preventDefault(); close(p.value); }
        }
      };
      document.addEventListener('keydown', onKey, true);
      document.body.appendChild(ov);
      const f = dlg.querySelector('input[type=text], select') || act.querySelector('.primary');
      if (f) { f.focus(); if (f.select) f.select(); }
    });
  }
  const confirmBox = (title, text, label, danger) =>
    modal({ title, text, buttons: [{ label: 'Скасувати', value: false }, { label, value: true, primary: !danger, danger }] })
      .then(r => r.value === true);
  function askText(title, value, label) {
    return modal({
      title,
      build: b => { const i = document.createElement('input'); i.type = 'text'; i.value = value || ''; i.spellcheck = false; b.appendChild(i); },
      buttons: [{ label: 'Скасувати', value: false }, { label: label || 'Зберегти', value: true, primary: true }]
    }).then(r => (r.value ? r.body.querySelector('input').value.trim() : null));
  }

  let menuEl = null;
  function closeMenu() { if (menuEl) { menuEl.remove(); menuEl = null; } }
  function showMenu(x, y, entries) {
    closeMenu();
    const m = document.createElement('div');
    m.className = 'menu';
    entries.forEach(e => {
      if (e === '-') { const s = document.createElement('div'); s.className = 'sep'; m.appendChild(s); return; }
      const b = document.createElement('button');
      b.textContent = e.label;
      if (e.danger) b.classList.add('danger');
      b.onclick = () => { closeMenu(); e.run(); };
      m.appendChild(b);
    });
    document.body.appendChild(m);
    const r = m.getBoundingClientRect();
    m.style.left = Math.max(4, Math.min(x, innerWidth - r.width - 4)) + 'px';
    m.style.top = Math.max(4, Math.min(y, innerHeight - r.height - 4)) + 'px';
    menuEl = m;
  }
  document.addEventListener('mousedown', e => { if (menuEl && !menuEl.contains(e.target)) closeMenu(); });
  window.addEventListener('blur', closeMenu);
  document.addEventListener('contextmenu', e => { if (!e.target.closest('input')) e.preventDefault(); });

  function reveal(p) {
    if (IS_WIN) cp.exec('explorer /select,"' + p + '"');
    else cp.exec('open -R "' + p.replace(/"/g, '\\"') + '"');
  }
  function openFolder(p) {
    if (IS_WIN) cp.exec('explorer "' + p + '"');
    else cp.exec('open "' + p.replace(/"/g, '\\"') + '"');
  }

  // ---------- render ----------
  const TYPE_LABEL = { comp: 'Композиція', footage: 'Футаж', preset: 'Пресет' };
  const byId = id => state.lib.items.find(i => i.id === id);

  function filtered() {
    const q = state.q.trim().toLowerCase();
    return state.lib.items
      .filter(it => state.types[it.type] &&
        (state.cat === '*' || (it.category || '') === state.cat) &&
        (!q || it.name.toLowerCase().indexOf(q) !== -1))
      .sort((a, b) => b.added - a.added);
  }
  function tooltip(it) {
    const lines = [it.name, TYPE_LABEL[it.type]];
    if (it.w && it.h) lines.push(it.w + '×' + it.h);
    if (it.dur) lines.push(it.dur.toFixed(1) + ' с');
    lines.push(it.type === 'preset' ? 'Подвійний клік — застосувати до виділених шарів' : 'Подвійний клік — додати в композицію');
    return lines.join('\n');
  }
  function extLabel(it) {
    const s = document.createElement('span');
    s.className = 'ext';
    s.textContent = path.extname(it.file).slice(1).toUpperCase() || TYPE_LABEL[it.type];
    return s;
  }
  function tileEl(it) {
    const d = document.createElement('div');
    d.className = 'tile k-' + it.type + (state.sel === it.id ? ' sel' : '');
    d.dataset.id = it.id;
    d.tabIndex = 0;
    d.title = tooltip(it);
    const th = document.createElement('div');
    th.className = 'thumb';
    if (it.thumb) {
      const img = document.createElement('img');
      img.loading = 'lazy';
      img.decoding = 'async';
      img.alt = '';
      img.onerror = () => { img.remove(); th.appendChild(extLabel(it)); };
      img.src = fileUrl(abs(it.thumb)) + (it.pv ? '?v=' + it.pv : '');
      th.appendChild(img);
    } else th.appendChild(extLabel(it));
    const n = document.createElement('div');
    n.className = 'name';
    n.appendChild(document.createElement('i'));
    const s = document.createElement('span');
    s.textContent = it.name;
    n.appendChild(s);
    d.appendChild(th);
    d.appendChild(n);
    return d;
  }
  function renderCats() {
    if (state.cat !== '*' && state.lib.categories.indexOf(state.cat) === -1) state.cat = '*';
    const nav = $('#cats');
    nav.textContent = '';
    const mk = (label, val, cls, title) => {
      const b = document.createElement('button');
      b.className = 'cat' + (cls ? ' ' + cls : '');
      b.textContent = label;
      b.dataset.cat = val;
      if (title) b.title = title;
      nav.appendChild(b);
    };
    mk('Усі', '*', state.cat === '*' ? 'on' : '');
    state.lib.categories.forEach(c => mk(c, c, state.cat === c ? 'on' : '', 'Правий клік — перейменувати або видалити'));
    mk('+', '+', 'add', 'Нова категорія');
  }
  function renderGrid() {
    const g = $('#grid'), empty = $('#empty'), list = filtered();
    stopAnim();
    g.textContent = '';
    empty.hidden = list.length > 0;
    if (!list.length) {
      empty.textContent = state.lib.items.length
        ? 'Тут нічого немає. Змініть пошук, категорію або фільтр типів.'
        : 'Бібліотека порожня. Виділіть композицію чи футаж у панелі Project і натисніть «Додати з проєкту» — або перетягніть файли сюди.';
      return;
    }
    const frag = document.createDocumentFragment();
    list.forEach(it => frag.appendChild(tileEl(it)));
    g.appendChild(frag);
  }
  function render() { renderCats(); renderGrid(); }
  function select(id) {
    state.sel = id;
    document.querySelectorAll('.tile.sel').forEach(el => el.classList.remove('sel'));
    if (id) { const el = document.querySelector('.tile[data-id="' + id + '"]'); if (el) el.classList.add('sel'); }
  }
  const targetCat = () => (state.cat === '*' ? '' : state.cat);

  // ---------- adding ----------
  async function addFromProject() {
    if (state.busy) return;
    let sel;
    try { sel = await host('getSelection'); } catch (e) { return status(e.message, true); }
    const comps = sel.items.filter(i => i.type === 'comp');
    const foot = sel.items.filter(i => i.type === 'footage');
    const seqCount = foot.filter(i => i.isSeq).length;
    const files = foot.filter(i => !i.isSeq);
    if (!comps.length && !files.length) return status(t(seqCount ? 'SEQ_SKIPPED' : 'NOTHING_SELECTED'), true);

    if (comps.length) {
      if (!sel.projectSaved) return status(t('NOT_SAVED'), true);
      const go = await confirmBox(
        comps.length === 1 ? 'Зберегти «' + comps[0].name + '»' : 'Зберегти композиції: ' + comps.length,
        'Щоб забрати композицію разом з усіма вкладеними прекомпами та футажем, панель збереже поточний проєкт і перевідкриє його. Історія Undo очиститься.',
        'Зберегти'
      );
      if (!go) return;
    }

    const cat = targetCat(), added = [];
    let failed = 0, partial = 0, jobs = [];
    setBusy(true);
    try {
      if (files.length) {
        status('Копіюю футаж…');
        const aeJobs = [];
        for (const f of files) {
          const id = newId(), dir = itemDir(id);
          mkdirp(dir);
          const dest = path.join(dir, path.basename(f.path));
          try { await copyFile(f.path, dest); } catch (e) { rmrf(dir); failed++; continue; }
          const media = kindOf(dest) || (f.hasVideo ? (f.isStill ? 'image' : 'video') : 'audio');
          const it = { id, type: 'footage', media, name: f.name, category: cat, added: Date.now(), file: rel(dest), w: f.width, h: f.height, dur: f.isStill ? 0 : f.duration };
          const th = path.join(dir, 'thumb.webp');
          if (media === 'image' && await imageThumb(dest, th)) it.thumb = rel(th);
          else if (f.hasVideo) aeJobs.push({ aeId: f.id, dir, fd: path.join(dir, '_frames'), it });
          added.push(it);
        }
        if (aeJobs.length) {
          status('Роблю превʼю…');
          aeJobs.forEach(j => mkdirp(j.fd));
          let res = null;
          try { res = await host('framesForItems', { count: state.frames, items: aeJobs.map(j => ({ aeId: j.aeId, outDir: j.fd })) }); } catch (e) { /* icons instead */ }
          for (const j of aeJobs) {
            const r = res && res.results.find(x => x.aeId === j.aeId);
            if (r && r.count) await framesToPreview(await waitFrames(j.fd, r.count), j.it, j.dir, r.span);
            rmrf(j.fd);
          }
        }
      }

      if (comps.length) {
        status('Зберігаю композиції…');
        jobs = comps.map(c => {
          const id = newId(), dir = itemDir(id);
          mkdirp(dir);
          return { id, dir, c, aeId: c.id, fd: path.join(dir, '_frames'), aep: path.join(dir, safeName(c.name) + '.aep') };
        });
        const res = await host('saveComps', {
          collect: state.collect,
          count: state.frames,
          items: jobs.map(j => ({ aeId: j.aeId, outDir: j.fd, aep: j.aep, dir: j.dir }))
        });
        for (const j of jobs) {
          const r = res.results.find(x => x.aeId === j.aeId);
          if (!r || !r.ok || !fs.existsSync(j.aep)) { rmrf(j.dir); failed++; continue; }
          if (r.skipped) partial++;
          const it = { id: j.id, type: 'comp', name: j.c.name, mainComp: j.c.name, category: cat, added: Date.now(), file: rel(j.aep), w: j.c.width, h: j.c.height, dur: j.c.duration, fps: j.c.fps };
          status('Роблю превʼю…');
          if (r.count) await framesToPreview(await waitFrames(j.fd, r.count), it, j.dir, r.span);
          rmrf(j.fd);
          added.push(it);
        }
        jobs = [];
      }
    } catch (e) {
      jobs.forEach(j => rmrf(j.dir));
      status(e.message, true);
    }

    if (added.length) {
      state.lib.items.push(...added);
      saveLib();
      render();
    }
    setBusy(false);
    let msg = 'Додано: ' + added.length;
    if (failed) msg += '. Не вдалося: ' + failed;
    if (seqCount) msg += '. Секвенції пропущено: ' + seqCount;
    if (partial) msg += '. Частина футажу (секвенції або відсутні файли) лишилась за старими шляхами';
    if (added.length || failed) status(msg + '.', !!failed && !added.length);
  }

  function expandPaths(paths) {
    const out = [];
    const walk = p => {
      if (out.length >= 500) return;
      let st;
      try { st = fs.statSync(p); } catch (e) { return; }
      if (st.isDirectory()) fs.readdirSync(p).forEach(n => walk(path.join(p, n)));
      else if (kindOf(p)) out.push(p);
    };
    paths.forEach(walk);
    return out;
  }

  async function addFiles(paths) {
    if (state.busy) return;
    const list = expandPaths(paths);
    if (!list.length) return status('Серед цих файлів немає підтримуваних форматів.', true);
    const cat = targetCat();
    let added = 0, failed = 0;
    setBusy(true);
    for (let n = 0; n < list.length; n++) {
      const p = list[n], kind = kindOf(p);
      status('Додаю ' + (n + 1) + ' з ' + list.length + '…');
      const id = newId(), dir = itemDir(id);
      mkdirp(dir);
      const dest = path.join(dir, path.basename(p));
      try { await copyFile(p, dest); } catch (e) { rmrf(dir); failed++; continue; }
      const it = { id, name: path.basename(p, path.extname(p)), category: cat, added: Date.now(), file: rel(dest) };
      if (kind === 'comp') { it.type = 'comp'; it.mainComp = ''; }
      else if (kind === 'preset') it.type = 'preset';
      else { it.type = 'footage'; it.media = kind; }
      await makePreview(it);
      state.lib.items.push(it);
      added++;
    }
    saveLib();
    render();
    setBusy(false);
    status('Додано: ' + added + (failed ? '. Не вдалося скопіювати: ' + failed : '') + '.', failed && !added);
  }

  function addFilesDialog() {
    const r = window.cep.fs.showOpenDialogEx(true, false, 'Додати в бібліотеку', '', ALL_EXT);
    if (r && !r.err && r.data && r.data.length) addFiles(r.data);
  }

  // ---------- using ----------
  async function useItem(it, target) {
    if (!it || state.busy) return;
    const f = abs(it.file);
    if (!fs.existsSync(f)) return status(t('FILE_MISSING'), true);
    try {
      const r = await host('importItem', { type: it.type, file: f, name: it.name, mainComp: it.mainComp || '', target });
      status(r.message === 'PRESET_APPLIED' ? 'Пресет застосовано до шарів: ' + r.count + '.' : t(r.message));
    } catch (e) { status(e.message, true); }
  }

  // ---------- editing ----------
  async function renameItem(it) {
    const v = await askText('Перейменувати', it.name);
    if (!v || v === it.name) return;
    it.name = v;
    saveLib();
    renderGrid();
  }
  async function newCategory() {
    const v = await askText('Нова категорія', '', 'Створити');
    if (!v) return null;
    if (state.lib.categories.indexOf(v) === -1) { state.lib.categories.push(v); saveLib(); }
    return v;
  }
  async function moveItem(it) {
    const r = await modal({
      title: 'Категорія для «' + it.name + '»',
      build: b => {
        const s = document.createElement('select');
        [['', 'Без категорії']].concat(state.lib.categories.map(c => [c, c])).forEach(([v, l]) => {
          const o = document.createElement('option'); o.value = v; o.textContent = l; s.appendChild(o);
        });
        s.value = it.category || '';
        const i = document.createElement('input');
        i.type = 'text'; i.placeholder = 'Або назва нової категорії'; i.spellcheck = false;
        b.appendChild(s); b.appendChild(i);
      },
      buttons: [{ label: 'Скасувати', value: false }, { label: 'Перемістити', value: true, primary: true }]
    });
    if (!r.value) return;
    const fresh = r.body.querySelector('input').value.trim();
    const cat = fresh || r.body.querySelector('select').value;
    if (fresh && state.lib.categories.indexOf(fresh) === -1) state.lib.categories.push(fresh);
    it.category = cat;
    saveLib();
    render();
  }
  async function removeItem(it) {
    const go = await confirmBox('Видалити «' + it.name + '»?', 'Файли елемента буде видалено з папки бібліотеки. У вже відкритих проєктах нічого не зміниться.', 'Видалити', true);
    if (!go) return;
    try { rmrf(itemDir(it.id)); } catch (e) { return status('Не вдалося видалити файли: ' + e.message, true); }
    state.lib.items = state.lib.items.filter(i => i !== it);
    if (state.sel === it.id) state.sel = null;
    saveLib();
    renderGrid();
    status('Видалено.');
  }
  async function renameCategory(c) {
    const v = await askText('Перейменувати категорію', c);
    if (!v || v === c) return;
    if (state.lib.categories.indexOf(v) !== -1) return status('Категорія з такою назвою вже є.', true);
    state.lib.categories = state.lib.categories.map(x => (x === c ? v : x));
    state.lib.items.forEach(i => { if (i.category === c) i.category = v; });
    if (state.cat === c) { state.cat = v; LS.set('cat', v); }
    saveLib();
    render();
  }
  async function deleteCategory(c) {
    const go = await confirmBox('Видалити категорію «' + c + '»?', 'Елементи з неї залишаться в бібліотеці — у розділі «Усі».', 'Видалити', true);
    if (!go) return;
    state.lib.categories = state.lib.categories.filter(x => x !== c);
    state.lib.items.forEach(i => { if (i.category === c) i.category = ''; });
    saveLib();
    render();
  }
  function itemMenu(it) {
    const m = [];
    if (it.type === 'preset') m.push({ label: 'Застосувати до виділених шарів', run: () => useItem(it, 'comp') });
    else m.push(
      { label: 'Додати в композицію', run: () => useItem(it, 'comp') },
      { label: 'Імпортувати в проєкт', run: () => useItem(it, 'project') }
    );
    m.push('-',
      { label: 'Перейменувати…', run: () => renameItem(it) },
      { label: 'Категорія…', run: () => moveItem(it) },
      ...(it.type === 'preset' || it.media === 'audio' ? [] : [{ label: 'Оновити превʼю', run: () => regenPreviews([it]) }]),
      { label: IS_WIN ? 'Показати в провіднику' : 'Показати у Finder', run: () => reveal(abs(it.file)) },
      '-',
      { label: 'Видалити з бібліотеки', danger: true, run: () => removeItem(it) });
    return m;
  }

  async function regenPreviews(list) {
    if (state.busy) return;
    list = list.filter(it => it.type !== 'preset' && it.media !== 'audio');
    if (!list.length) return;
    setBusy(true);
    let okCount = 0;
    for (let i = 0; i < list.length; i++) {
      status('Превʼю ' + (i + 1) + ' з ' + list.length + '…');
      if (await makePreview(list[i])) okCount++;
    }
    saveLib();
    renderGrid();
    setBusy(false);
    status('Превʼю оновлено: ' + okCount + ' з ' + list.length + '.', okCount < list.length && !okCount);
  }

  function setRoot(p) {
    root = p;
    LS.set('root', p);
    state.lib = loadLib();
    state.sel = null;
    render();
    status('Бібліотека: ' + p);
  }
  let closeDlg = () => {};
  function openSettings() {
    closeDlg = () => { const ov = document.querySelector('.overlay'); if (ov) ov.querySelector('.dlg-actions .btn').click(); };
    modal({
      title: 'Налаштування',
      build: b => {
        const p = document.createElement('p'); p.textContent = 'Папка бібліотеки'; b.appendChild(p);
        const pathEl = document.createElement('div'); pathEl.className = 'path'; pathEl.textContent = root; b.appendChild(pathEl);
        const row = document.createElement('div'); row.className = 'row';
        const change = document.createElement('button'); change.className = 'btn'; change.textContent = 'Змінити…';
        const open = document.createElement('button'); open.className = 'btn'; open.textContent = 'Відкрити';
        row.appendChild(change); row.appendChild(open); b.appendChild(row);
        change.onclick = () => {
          const r = window.cep.fs.showOpenDialogEx(false, true, 'Папка бібліотеки', root);
          if (r && !r.err && r.data && r.data[0]) { setRoot(r.data[0]); pathEl.textContent = root; }
        };
        open.onclick = () => openFolder(root);
        const lab = document.createElement('label'); lab.className = 'check';
        const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = state.collect;
        cb.onchange = () => { state.collect = cb.checked; LS.set('collect', cb.checked); };
        const txt = document.createElement('span');
        txt.textContent = 'Копіювати футаж композицій у бібліотеку. Якщо вимкнути, композиції посилатимуться на файли за їхніми поточними шляхами.';
        lab.appendChild(cb); lab.appendChild(txt); b.appendChild(lab);

        const p2 = document.createElement('p'); p2.className = 'gap'; p2.textContent = 'Кадрів в анімованому превʼю'; b.appendChild(p2);
        const sel = document.createElement('select');
        [[12, '12 — швидше зберігається'], [24, '24'], [36, '36 — плавніше']].forEach(([v, l]) => {
          const o = document.createElement('option'); o.value = v; o.textContent = l; sel.appendChild(o);
        });
        sel.value = String(state.frames);
        sel.onchange = () => { state.frames = +sel.value; LS.set('frames', state.frames); };
        b.appendChild(sel);
        const regen = document.createElement('button'); regen.className = 'btn'; regen.textContent = 'Оновити всі превʼю';
        regen.title = 'Перерендерить превʼю всіх композицій і відео в бібліотеці';
        regen.onclick = () => { closeDlg(); regenPreviews(state.lib.items.slice()); };
        b.appendChild(regen);
      },
      buttons: [{ label: 'Готово', value: true, primary: true }]
    });
  }

  // ---------- hover playback (one strip at a time, only while hovered) ----------
  let anim = null;
  function stopAnim() {
    if (!anim) return;
    cancelAnimationFrame(anim.raf);
    anim.el.remove();
    anim.thumb.classList.remove('playing');
    anim = null;
  }
  function startAnim(tile, it) {
    const thumb = tile.querySelector('.thumb');
    const el = document.createElement('div');
    el.className = 'anim';
    const me = { tile, thumb, el, raf: 0 };
    anim = me;
    const img = new Image();
    img.onload = () => {
      if (anim !== me) return;
      const n = it.frames, fw = img.naturalWidth / n, fh = img.naturalHeight;
      if (fw >= fh) { el.style.width = '100%'; el.style.height = (fh / fw * 100) + '%'; }
      else { el.style.height = '100%'; el.style.width = (fw / fh * 100) + '%'; }
      el.style.backgroundImage = 'url("' + img.src + '")';
      el.style.backgroundSize = (n * 100) + '% 100%';
      thumb.appendChild(el);
      thumb.classList.add('playing');
      const step = 1000 / (it.pfps || 12);
      let i = 0, last = -Infinity;
      const tick = ts => {
        if (anim !== me) return;
        if (ts - last >= step) {
          last = ts;
          el.style.backgroundPosition = (n > 1 ? (i / (n - 1)) * 100 : 0) + '% 0';
          i = (i + 1) % n;
        }
        me.raf = requestAnimationFrame(tick);
      };
      me.raf = requestAnimationFrame(tick);
    };
    img.src = fileUrl(abs(it.preview)) + (it.pv ? '?v=' + it.pv : '');
  }

  // ---------- events ----------
  const grid = $('#grid');
  const tileOf = e => e.target.closest('.tile');
  grid.addEventListener('click', e => { const tl = tileOf(e); select(tl ? tl.dataset.id : null); });
  grid.addEventListener('dblclick', e => { const tl = tileOf(e); if (tl) useItem(byId(tl.dataset.id), 'comp'); });
  grid.addEventListener('contextmenu', e => {
    const tl = tileOf(e);
    if (!tl) return;
    select(tl.dataset.id);
    showMenu(e.clientX, e.clientY, itemMenu(byId(tl.dataset.id)));
  });
  grid.addEventListener('mouseover', e => {
    const tl = tileOf(e);
    if (anim && anim.tile === tl) return;
    stopAnim();
    if (!tl || state.busy) return;
    const it = byId(tl.dataset.id);
    if (it && it.preview && it.frames > 1) startAnim(tl, it);
  });
  grid.addEventListener('mouseleave', stopAnim);
  window.addEventListener('blur', stopAnim);
  grid.addEventListener('keydown', e => {
    const tl = tileOf(e);
    if (!tl) return;
    if (e.key === 'Enter') useItem(byId(tl.dataset.id), 'comp');
    else if (e.key === 'Delete') removeItem(byId(tl.dataset.id));
  });
  grid.addEventListener('focusin', e => { const tl = tileOf(e); if (tl) select(tl.dataset.id); });
  $('#main').addEventListener('click', e => { if (e.target.id === 'main' || e.target.id === 'grid') select(null); });

  $('#cats').addEventListener('click', async e => {
    const b = e.target.closest('.cat');
    if (!b) return;
    let c = b.dataset.cat;
    if (c === '+') { c = await newCategory(); if (!c) return; }
    state.cat = c;
    LS.set('cat', c);
    render();
  });
  $('#cats').addEventListener('contextmenu', e => {
    const b = e.target.closest('.cat');
    if (!b || b.dataset.cat === '*' || b.dataset.cat === '+') return;
    const c = b.dataset.cat;
    showMenu(e.clientX, e.clientY, [
      { label: 'Перейменувати…', run: () => renameCategory(c) },
      { label: 'Видалити категорію', danger: true, run: () => deleteCategory(c) }
    ]);
  });

  $('#search').addEventListener('input', e => { state.q = e.target.value; renderGrid(); });
  document.querySelectorAll('.type').forEach(b => {
    b.setAttribute('aria-pressed', String(!!state.types[b.dataset.type]));
    b.addEventListener('click', () => {
      state.types[b.dataset.type] = !state.types[b.dataset.type];
      b.setAttribute('aria-pressed', String(state.types[b.dataset.type]));
      LS.set('types', state.types);
      renderGrid();
    });
  });
  const size = $('#size');
  size.value = state.tile;
  document.documentElement.style.setProperty('--tile', state.tile + 'px');
  size.addEventListener('input', () => {
    state.tile = +size.value;
    document.documentElement.style.setProperty('--tile', state.tile + 'px');
    LS.set('tile', state.tile);
  });

  $('#addProject').addEventListener('click', addFromProject);
  $('#addFiles').addEventListener('click', addFilesDialog);
  $('#settings').addEventListener('click', openSettings);

  // drag & drop from Explorer / Finder
  let dragDepth = 0;
  const hasFiles = e => e.dataTransfer && Array.prototype.indexOf.call(e.dataTransfer.types || [], 'Files') !== -1;
  document.addEventListener('dragenter', e => { if (hasFiles(e)) { dragDepth++; document.body.classList.add('dragging'); } });
  document.addEventListener('dragleave', () => { if (--dragDepth <= 0) { dragDepth = 0; document.body.classList.remove('dragging'); } });
  document.addEventListener('dragover', e => e.preventDefault());
  document.addEventListener('drop', e => {
    e.preventDefault();
    dragDepth = 0;
    document.body.classList.remove('dragging');
    let paths = Array.prototype.map.call(e.dataTransfer.files || [], f => f.path).filter(Boolean);
    if (!paths.length) {
      paths = (e.dataTransfer.getData('text/uri-list') || '').split(/\r?\n/)
        .filter(u => u.indexOf('file://') === 0)
        .map(u => {
          let p = decodeURIComponent(u.replace(/^file:\/\//, ''));
          if (IS_WIN) p = p.replace(/^\/([A-Za-z]:)/, '$1').replace(/\//g, '\\');
          return p;
        });
    }
    if (paths.length) addFiles(paths);
  });

  // pick up changes made from another AE window / machine (shared folder) — checked only on focus
  window.addEventListener('focus', () => {
    if (state.busy) return;
    try {
      const m = fs.statSync(libFile()).mtimeMs;
      if (m !== state.libMtime) { state.lib = loadLib(); render(); }
    } catch (e) { /* ignore */ }
  });

  // ---------- init ----------
  try { state.lib = loadLib(); } catch (e) {
    state.lib = { version: 1, categories: [], items: [] };
    status('Не вдалося відкрити папку бібліотеки: ' + e.message, true);
  }
  render();
  host('ping').catch(() => status(t('HOST_DOWN'), true));
})();
