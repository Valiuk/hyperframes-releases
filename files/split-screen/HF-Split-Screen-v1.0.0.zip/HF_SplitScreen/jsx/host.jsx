/*  HF Split Screen - host script (ExtendScript, ES3)
    Keep this file ASCII-only: all user-facing text lives in the panel. */

var HFSplit = (function () {

    // ---------- helpers ----------
    function getComp() {
        var c = app.project.activeItem;
        return (c && c instanceof CompItem) ? c : null;
    }

    function layerNameExists(comp, name) {
        for (var i = 1; i <= comp.numLayers; i++) {
            if (comp.layer(i).name === name) return true;
        }
        return false;
    }

    function uniqueCtrlName(comp) {
        var n = 1;
        while (layerNameExists(comp, "SPLIT CTRL " + n)) n++;
        return { ctrl: "SPLIT CTRL " + n, n: n };
    }

    function addFx(layer, matchName, name, value) {
        var fx = layer.property("ADBE Effect Parade").addProperty(matchName);
        fx.name = name;
        if (value !== undefined) fx.property(1).setValue(value);
        return fx;
    }

    function findProp(group, name) {
        for (var i = 1; i <= group.numProperties; i++) {
            var p = group.property(i);
            if (p.name === name) return p;
            if (p.propertyType !== PropertyType.PROPERTY) {
                var r = findProp(p, name);
                if (r) return r;
            }
        }
        return null;
    }

    function findSaberMatchName() {
        for (var i = 0; i < app.effects.length; i++) {
            var e = app.effects[i];
            if (/saber/i.test(e.displayName) || /saber/i.test(e.matchName)) return e.matchName;
        }
        return null;
    }

    function setSpan(layer, inP, outP) {
        layer.startTime = 0;
        layer.inPoint = inP;
        layer.outPoint = outP;
    }

    function hasKeys(prop) {
        return prop.numKeys > 0;
    }

    // ---------- expressions ----------
    // Common header: reads controls from the CTRL null.
    function head(ctrl) {
        return [
            'var c=thisComp.layer("' + ctrl + '");',
            'var r=c.effect("Split %")(1)/100;',
            'var t=Math.tan(degreesToRadians(clamp(c.effect("Tilt")(1),-60,60)));',
            'var W=thisComp.width,H=thisComp.height,m=Math.max(W,H),E=m*6;'
        ].join('\n');
    }

    var TO_LAYER =
        'var o=[];for(var i=0;i<p.length;i++){var q=fromComp(p[i]);o.push([q[0],q[1]]);}';

    // Closed polygon for side "A" (top/left) or "B" (bottom/right), in comp space.
    // "Swap Sides" checkbox on CTRL flips which polygon each layer gets.
    function polyExpr(ctrl, vertical, side) {
        var body = 'var A=(c.effect("Swap Sides")(1)==1)!=' + (side === "A" ? 'true' : 'false') + ';\n';
        if (!vertical) {
            body += 'var y0=H*r,yL=y0+(-m-W/2)*t,yR=y0+(W+m-W/2)*t;\n' +
                'var p=A?[[-m,-E],[W+m,-E],[W+m,yR],[-m,yL]]:[[-m,yL],[W+m,yR],[W+m,H+E],[-m,H+E]];';
        } else {
            body += 'var x0=W*r,xT=x0-(-m-H/2)*t,xB=x0-(H+m-H/2)*t;\n' +
                'var p=A?[[-E,-m],[xT,-m],[xB,H+m],[-E,H+m]]:[[xT,-m],[W+E,-m],[W+E,H+m],[xB,H+m]];';
        }
        return head(ctrl) + '\n' + body + '\n' + TO_LAYER + '\ncreatePath(o,[],[],true);';
    }

    // Open 2-point path along the split line, slightly past the comp edges.
    function lineExpr(ctrl, vertical) {
        var body;
        if (!vertical) {
            body = 'var P=m*0.05,y0=H*r;\n' +
                'var p=[[-P,y0+(-P-W/2)*t],[W+P,y0+(W+P-W/2)*t]];';
        } else {
            body = 'var P=m*0.05,x0=W*r;\n' +
                'var p=[[x0-(-P-H/2)*t,-P],[x0-(H+P-H/2)*t,H+P]];';
        }
        return head(ctrl) + '\n' + body + '\n' + TO_LAYER + '\ncreatePath(o,[],[],false);';
    }

    function dummyShape(closed) {
        var s = new Shape();
        s.vertices = closed ? [[0, 0], [100, 0], [100, 100], [0, 100]] : [[0, 0], [100, 0]];
        s.closed = closed;
        return s;
    }

    // ---------- building blocks ----------
    function maskLayer(layer, ctrl, vertical, side) {
        var masks = layer.property("ADBE Mask Parade");
        var mk = masks.addProperty("ADBE Mask Atom");
        mk.name = "SPLIT " + side;
        mk.maskMode = MaskMode.ADD;
        var shp = mk.property("ADBE Mask Shape");
        shp.setValue(dummyShape(true));
        shp.expression = polyExpr(ctrl, vertical, side);
        mk.property("ADBE Mask Feather").expression =
            'var f=thisComp.layer("' + ctrl + '").effect("Edge Feather")(1);[f,f];';
    }

    function sourceRect(layer, time) {
        if (layer.source && layer.source.width && !(layer instanceof TextLayer) && !(layer instanceof ShapeLayer)) {
            return { left: 0, top: 0, width: layer.source.width, height: layer.source.height };
        }
        return layer.sourceRectAtTime(time, false);
    }

    // Scale-to-cover and centre the layer in its region (static, done once).
    function fitLayer(layer, region, comp, warnings) {
        var tr = layer.property("ADBE Transform Group");
        var anc = tr.property("ADBE Anchor Point");
        var pos = tr.property("ADBE Position");
        var scl = tr.property("ADBE Scale");
        if (hasKeys(anc) || hasKeys(scl) || pos.dimensionsSeparated || hasKeys(pos)) {
            warnings.push("KEYS:" + layer.index);
            return;
        }
        var rc = sourceRect(layer, comp.time);
        if (!rc || rc.width <= 0 || rc.height <= 0) return;

        var s = Math.max(region.w / rc.width, region.h / rc.height) * 100;
        var ax = rc.left + rc.width / 2, ay = rc.top + rc.height / 2;
        var cx = region.x + region.w / 2, cy = region.y + region.h / 2;

        if (layer.threeDLayer) {
            var az = anc.value[2], pz = pos.value[2];
            anc.setValue([ax, ay, az]);
            scl.setValue([s, s, s]);
            pos.setValue([cx, cy, pz]);
        } else {
            anc.setValue([ax, ay]);
            scl.setValue([s, s]);
            pos.setValue([cx, cy]);
        }
    }

    // When "Swap Sides" is on, the layer jumps to the other half (centres differ by
    // exactly H/2 or W/2) and, if it was fitted, rescales to cover the new region.
    // Expressions add to the current value, so manual framing and keyframes survive.
    function swapFollow(layer, ctrl, vertical, side, fitted, warnings) {
        var tr = layer.property("ADBE Transform Group");
        var pos = tr.property("ADBE Position");
        var sgn = (side === "A") ? 1 : -1;
        var on = 'var s=thisComp.layer("' + ctrl + '").effect("Swap Sides")(1)==1;';
        if (layer.parent) { warnings.push("PARENT:" + layer.index); return; }

        var target, expr;
        if (pos.dimensionsSeparated) {
            target = tr.property(vertical ? "ADBE Position_0" : "ADBE Position_1");
            expr = on + '\nvalue+(s?' + sgn + '*thisComp.' + (vertical ? 'width' : 'height') + '/2:0);';
        } else {
            target = pos;
            expr = on + '\nvar d=s?' + sgn + '/2:0;\n' +
                (vertical ? 'value+[thisComp.width*d,0' : 'value+[0,thisComp.height*d') +
                (layer.threeDLayer ? ',0];' : '];');
        }
        if (target.expression !== "") warnings.push("EXPR:" + layer.index);
        else target.expression = expr;

        if (!fitted) return;
        var scl = tr.property("ADBE Scale");
        if (scl.expression !== "") { warnings.push("EXPR:" + layer.index); return; }
        // own region = A when side A; cover factor ratio other/own
        scl.expression = [
            on,
            'if(!s){value}else{',
            'var c=thisComp.layer("' + ctrl + '"),r=c.effect("Split %")(1)/100;',
            'var W=thisComp.width,H=thisComp.height,b=sourceRectAtTime(time,false);',
            vertical ? 'var a=[W*r,H],o=[W*(1-r),H];' : 'var a=[W,H*r],o=[W,H*(1-r)];',
            side === "A" ? '' : 'var x=a;a=o;o=x;',
            'function cv(R){return Math.max(R[0]/b.width,R[1]/b.height);}',
            'value*(cv(o)/cv(a));}'
        ].join('\n');
    }

    function buildCtrl(comp, names, o, topLayer, inP, outP) {
        var nl = comp.layers.addNull(comp.duration);
        nl.name = names.ctrl;
        nl.label = 9;
        nl.moveBefore(topLayer);
        setSpan(nl, inP, outP);
        addFx(nl, "ADBE Slider Control", "Split %", o.ratio);
        addFx(nl, "ADBE Angle Control", "Tilt", o.tilt);
        addFx(nl, "ADBE Slider Control", "Edge Feather", 0);
        addFx(nl, "ADBE Color Control", "Line Color", o.color);
        addFx(nl, "ADBE Slider Control", "Line Width", o.width);
        addFx(nl, "ADBE Checkbox Control", "Swap Sides", 0);
        return nl;
    }

    function buildLine(comp, names, o, placeBefore, inP, outP) {
        var sl = comp.layers.addShape();
        sl.name = "SPLIT LINE " + names.n;
        sl.label = 9;
        sl.moveBefore(placeBefore);
        setSpan(sl, inP, outP);

        var grp = sl.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
        grp.name = "Divider";
        var vecs = grp.property("ADBE Vectors Group");
        var path = vecs.addProperty("ADBE Vector Shape - Group");
        path.property("ADBE Vector Shape").setValue(dummyShape(false));
        path.property("ADBE Vector Shape").expression = lineExpr(names.ctrl, o.vertical);

        var st = vecs.addProperty("ADBE Vector Graphic - Stroke");
        st.property("ADBE Vector Stroke Color").expression =
            'thisComp.layer("' + names.ctrl + '").effect("Line Color")(1)';
        st.property("ADBE Vector Stroke Width").expression =
            'thisComp.layer("' + names.ctrl + '").effect("Line Width")(1)';
        try { st.property("ADBE Vector Stroke Line Cap").setValue(1); } catch (e) {}

        if (o.glow) {
            var g = sl.property("ADBE Effect Parade").addProperty("ADBE Glo2");
            try { findProp(g, "Glow Threshold").setValue(10); } catch (e1) {}
            try { findProp(g, "Glow Radius").setValue(Math.max(20, o.width * 6)); } catch (e2) {}
            try { findProp(g, "Glow Intensity").setValue(2); } catch (e3) {}
        }
        return sl;
    }

    function buildSaber(comp, names, o, placeBefore, inP, outP, matchName) {
        var sd = comp.layers.addSolid([0, 0, 0], "SPLIT SABER " + names.n,
            comp.width, comp.height, comp.pixelAspect, comp.duration);
        sd.label = 9;
        sd.moveBefore(placeBefore);
        setSpan(sd, inP, outP);
        sd.blendingMode = BlendingMode.ADD;

        var mk = sd.property("ADBE Mask Parade").addProperty("ADBE Mask Atom");
        mk.name = "SABER PATH";
        mk.maskMode = MaskMode.NONE;
        var shp = mk.property("ADBE Mask Shape");
        shp.setValue(dummyShape(false));
        shp.expression = lineExpr(names.ctrl, o.vertical);

        var fx = sd.property("ADBE Effect Parade").addProperty(matchName);
        // Core Type -> Layer Masks (2). Wrapped: property names may differ between Saber versions.
        try {
            var ct = findProp(fx, "Core Type");
            if (ct) ct.setValue(2);
        } catch (e) {}
        return sd;
    }

    // ---------- main ----------
    function run(o) {
        var comp = getComp();
        if (!comp) return "ERR:NO_COMP";

        var sel = comp.selectedLayers;
        if (sel.length !== 2) return "ERR:NEED_TWO";
        for (var i = 0; i < sel.length; i++) {
            if (!sel[i].property("ADBE Mask Parade")) return "ERR:BAD_LAYER";
        }

        var a = sel[0].index < sel[1].index ? sel[0] : sel[1];
        var b = (a === sel[0]) ? sel[1] : sel[0];
        if (o.swap) { var tmp = a; a = b; b = tmp; }

        var warnings = [];
        var saberMN = null;
        if (o.divider === "saber") {
            saberMN = findSaberMatchName();
            if (!saberMN) { warnings.push("NO_SABER"); o.divider = "line"; o.glow = true; }
        }

        app.beginUndoGroup("HF Split Screen");
        try {
            var names = uniqueCtrlName(comp);
            var topIndex = Math.min(a.index, b.index);
            var inP = Math.min(a.inPoint, b.inPoint);
            var outP = Math.max(a.outPoint, b.outPoint);

            // Remember the layer objects; indices shift as we add layers.
            var topLayer = comp.layer(topIndex);

            if (o.fit) {
                var W = comp.width, H = comp.height, r = o.ratio / 100;
                var ra, rb;
                if (!o.vertical) {
                    ra = { x: 0, y: 0, w: W, h: H * r };
                    rb = { x: 0, y: H * r, w: W, h: H * (1 - r) };
                } else {
                    ra = { x: 0, y: 0, w: W * r, h: H };
                    rb = { x: W * r, y: 0, w: W * (1 - r), h: H };
                }
                fitLayer(a, ra, comp, warnings);
                fitLayer(b, rb, comp, warnings);
            }

            var ctrl = buildCtrl(comp, names, o, topLayer, inP, outP);

            maskLayer(a, names.ctrl, o.vertical, "A");
            maskLayer(b, names.ctrl, o.vertical, "B");
            swapFollow(a, names.ctrl, o.vertical, "A", o.fit, warnings);
            swapFollow(b, names.ctrl, o.vertical, "B", o.fit, warnings);

            if (o.divider === "line") buildLine(comp, names, o, topLayer, inP, outP);
            else if (o.divider === "saber") buildSaber(comp, names, o, topLayer, inP, outP, saberMN);

            // Divider was inserted directly above the top layer, so CTRL stays above everything.
            for (var k = 1; k <= comp.numLayers; k++) comp.layer(k).selected = false;
            ctrl.selected = true;
        } catch (err) {
            app.endUndoGroup();
            return "ERR:EXC:" + err.toString() + " (line " + err.line + ")";
        }
        app.endUndoGroup();
        return "OK" + (warnings.length ? "|" + warnings.join(",") : "");
    }

    function selectionInfo() {
        var comp = getComp();
        if (!comp) return "NO_COMP";
        return String(comp.selectedLayers.length);
    }

    return { run: run, selectionInfo: selectionInfo };
})();
