/*
  apply_spin_plan.jsx (v2, на ключах) — план із «Конструктора прокрутів» у логіці оригінального шаблону.

  Що будується:
   • Null plan (у Slot) — копія Null 2 з ефектом Offset. Прокрути = звичайні ключі Shift Center To
     (старт → пік із відскоком → зупинка, далі HOLD). Їх можна рухати й правити руками.
   • ColumnPlan_N — стрічка барабана, де КОЖЕН КАДР = результат одного прокруту:
       кадр 0 — стартовий екран, кадр 1 — після 1-го прокруту, кадр 2 — після 2-го …
     Ряди — звичайні шари Symbol_M без виразів. Щоб змінити символ — заміни джерело шару (Alt+перетягнути).
   • Шари ColumnPlan_N у Slot (копії колонок) мають ключі Time Remap з HOLD: посеред кожного прокруту
     стрічка перемикається на наступний кадр — так само, як в оригіналі підміняється WIN.
     Вираз лишається лише той, що був в оригіналі: колонка повторює Offset нула з затримкою.
   • Оригінальні колонки просто вимикаються (око), Null 2 з його ключами не чіпається —
     повернутись до оригіналу = увімкнути Column_N і вимкнути ColumnPlan_N.

  Якщо раніше запускалась версія на виразах — скрипт сам її прибирає.
  Повторний запуск перебудовує план. Усе — один крок Undo.
*/
(function () {
    var proj = app.project;
    if (!proj) { alert("Відкрий проєкт."); return; }

    function compNamed(n) {
        for (var i = 1; i <= proj.numItems; i++) {
            var it = proj.item(i);
            if (it instanceof CompItem && it.name === n && it.numLayers > 0) return it;
        }
        return null;
    }
    function compAny(n) {
        for (var i = 1; i <= proj.numItems; i++) if (proj.item(i) instanceof CompItem && proj.item(i).name === n) return proj.item(i);
        return null;
    }
    function tr(l) { return l.property("ADBE Transform Group"); }
    function fxByName(l, n) {
        var fx = l.property("ADBE Effect Parade");
        for (var i = 1; i <= fx.numProperties; i++) if (fx.property(i).name === n) return fx.property(i);
        return null;
    }
    function fxByMatch(l, m) {
        var fx = l.property("ADBE Effect Parade");
        for (var i = 1; i <= fx.numProperties; i++) if (fx.property(i).matchName === m) return fx.property(i);
        return null;
    }
    function mod(a, n) { return ((a % n) + n) % n; }
    function clearKeys(p) { while (p.numKeys > 0) p.removeKey(p.numKeys); }
    function unwrap(ex) {                      // знімає обгортку версії на виразах
        var m = "} else {\n", i = ex.indexOf(m);
        if (i === -1) return ex;
        var body = ex.substring(i + m.length);
        return body.substring(0, body.lastIndexOf("}")).replace(/\n$/, "");
    }

    // ---------------- план ----------------
    var dlg = new Window("dialog", "Застосувати план прокрутів (на ключах)");
    dlg.alignChildren = "fill";
    dlg.add("statictext", undefined, "Встав план із конструктора (кнопка «Скопіювати план»):");
    var et = dlg.add("edittext", undefined, "", { multiline: true, scrolling: true });
    et.preferredSize = [520, 220];
    var gb = dlg.add("group"); gb.alignment = "right";
    var bFile = gb.add("button", undefined, "З файлу…");
    gb.add("button", undefined, "Скасувати", { name: "cancel" });
    gb.add("button", undefined, "Застосувати", { name: "ok" });
    bFile.onClick = function () {
        var f = File.openDialog("Файл плану (.json / .txt)");
        if (f && f.open("r")) { f.encoding = "UTF-8"; et.text = f.read(); f.close(); }
    };
    if (dlg.show() !== 1) return;
    var plan;
    try { plan = eval("(" + et.text + ")"); } catch (e) { alert("Не вдалося прочитати план: " + e.toString()); return; }
    if (!plan || !plan.init || !plan.spins || !plan.reels || !plan.rows) { alert("У плані немає reels / rows / init / spins."); return; }
    var REELS = plan.reels, ROWS = plan.rows, SP = plan.spins;
    SP.sort(function (a, b) { return a.t - b.t; });

    // ---------------- сцена ----------------
    var render = compNamed("render"), slot = compNamed("Slot");
    if (!render || !slot) { alert("Не знайдено render або Slot."); return; }
    var ctl = render.layer(1);
    var nul = null; try { nul = slot.layer("Null 2"); } catch (e) {}
    if (!nul) { alert("У Slot немає Null 2."); return; }

    var colLayers = [];
    for (var i = 1; i <= slot.numLayers; i++) {
        var L = slot.layer(i);
        if (L.source && /^Column_\d+$/.test(L.source.name)) colLayers.push(L);
    }
    if (REELS > colLayers.length) { alert("План на " + REELS + " барабанів, а в Slot лише " + colLayers.length + ". Спершу встанови систему сіток."); return; }

    function findOffset(c, target, depth) {
        if (c === target) return 0;
        if (depth > 8) return null;
        for (var i = 1; i <= c.numLayers; i++) {
            var L = c.layer(i);
            if (L.source instanceof CompItem) { var r = findOffset(L.source, target, depth + 1); if (r !== null) return r + L.startTime; }
        }
        return null;
    }
    var OFF = findOffset(render, slot, 0); if (OFF === null) OFF = 0;

    app.beginUndoGroup("Apply spin plan (keys)");
    var log = [];

    // ---------------- 0. прибрати версію на виразах ----------------
    var cleaned = 0;
    for (var i = slot.numLayers; i >= 1; i--) {
        var o = tr(slot.layer(i)).property("ADBE Opacity");
        if (o.expression.indexOf("Use spin plan") !== -1) { o.expression = unwrap(o.expression); cleaned++; }
    }
    var sh0 = fxByMatch(nul, "ADBE Offset").property("ADBE Offset-0001");
    if (sh0.expression.indexOf("//PLAN_END") !== -1) {
        var ex = sh0.expression; ex = ex.substring(ex.indexOf("//PLAN_END\n") + 11);
        sh0.expression = ex.substring(0, ex.lastIndexOf("}")).replace(/\n$/, "");
        cleaned++;
    }
    var fxp = ctl.property("ADBE Effect Parade");
    for (var i = fxp.numProperties; i >= 1; i--) {
        var nm = fxp.property(i).name;
        if (nm === "Use spin plan" || nm === "Plan glows") { fxp.property(i).remove(); cleaned++; }
    }
    var oldSheet = compAny("Symbol_sheet");
    if (cleaned || oldSheet) {
        for (var i = slot.numLayers; i >= 1; i--) {
            var L = slot.layer(i);
            if (L.source && /^ColumnPlan_\d+$/.test(L.source.name) && L.timeRemapEnabled &&
                L.property("ADBE Time Remapping").expression.indexOf("time") === 0) L.remove();
        }
        if (oldSheet) oldSheet.remove();
        log.push("Прибрано попередню версію на виразах");
    }

    // ---------------- 1. символи ----------------
    // Symbol_WIN у шаблоні — не окремий символ, а стек із 4 рядів (переможна комбінація для підміни),
    // тому в клітинках використовуються тільки Symbol_1…N (до 20). Невідомі id (у т.ч. старий WIN = 0) → Symbol_7.
    function fixGrid(g) { if (g) for (var a = 0; a < g.length; a++) for (var b = 0; b < g[a].length; b++) if (!(g[a][b] >= 1 && g[a][b] <= 20)) g[a][b] = 7; }
    fixGrid(plan.init); for (var s = 0; s < SP.length; s++) fixGrid(SP[s].grid);
    var maxId = 9;
    function scan(g) { if (g) for (var a = 0; a < g.length; a++) for (var b = 0; b < g[a].length; b++) if (g[a][b] > maxId) maxId = g[a][b]; }
    scan(plan.init); for (var s = 0; s < SP.length; s++) scan(SP[s].grid);

    var symComps = [];
    for (var k = 1; k <= maxId; k++) symComps[k] = compAny("Symbol_" + k);
    var donor = null; for (var k = 1; k <= maxId; k++) if (symComps[k]) { donor = k; break; }
    if (donor === null) { alert("Не знайдено жодного компа Symbol_N."); app.endUndoGroup(); return; }
    var lost = [];
    for (var k = 1; k <= maxId; k++) {
        if (symComps[k]) continue;
        var target = compAny("pragmatic_symbol_" + k);
        if (!target) { lost.push(k); continue; }
        // обгортки немає, але є pragmatic_symbol_k — робимо Symbol_k з сусідньої обгортки
        var copy = symComps[donor].duplicate(); copy.name = "Symbol_" + k; copy.parentFolder = symComps[donor].parentFolder;
        for (var j = 1; j <= copy.numLayers; j++) {
            var L = copy.layer(j);
            if (L.source && /^pragmatic_symbol_\d+$/.test(L.source.name)) L.replaceSource(target, false);
        }
        symComps[k] = copy; log.push("Створено обгортку Symbol_" + k);
    }
    if (lost.length) {
        // символів, яких немає в проєкті взагалі, — замінюємо на 7
        var isLost = {}; for (var q = 0; q < lost.length; q++) isLost[lost[q]] = true;
        var remap = function (g) { if (g) for (var a = 0; a < g.length; a++) for (var b = 0; b < g[a].length; b++) if (isLost[g[a][b]]) g[a][b] = 7; };
        remap(plan.init); for (var s = 0; s < SP.length; s++) remap(SP[s].grid);
        log.push("У проєкті немає символів " + lost.join(", ") + " — замінено на 7 (додай їх скриптом символів скіна)");
    }

    // ---------------- 2. параметри стрічки ----------------
    var col1 = colLayers[0].source, STEP = 266, START = -138;
    try {
        var c0 = col1.layer("Control");
        START = fxByName(c0, "Start Position").property(1).value;
        STEP = fxByName(c0, "Base Offset").property(1).value + fxByName(c0, "Offset Adjustment").property(1).value;
    } catch (e) {}
    var H = col1.height, NROWS = Math.round(H / STEP), Y1 = START + STEP, fd = col1.frameDuration;
    var rf = fxByName(ctl, "Reels"), rw = fxByName(ctl, "Rows");
    if (rf) rf.property(1).setValue(REELS);
    if (rw) rw.property(1).setValue(ROWS);

    // ---------------- 3. Null plan: ключі прокрутів ----------------
    var np = null; try { np = slot.layer("Null plan"); } catch (e) {}
    if (!np) { np = nul.duplicate(); np.moveToEnd(); np.name = "Null plan"; }
    var nOff = fxByMatch(np, "ADBE Offset"), shift = nOff.property("ADBE Offset-0001");
    var delayFx = fxByName(np, "Delay");
    if (delayFx && plan.delay !== undefined) delayFx.property(1).setValue(plan.delay);
    var DELAY = delayFx ? delayFx.property(1).value : 0.1;
    shift.expression = "";
    var base = fxByMatch(nul, "ADBE Offset").property("ADBE Offset-0001").valueAtTime(0, true);
    clearKeys(shift);
    var spatial = shift.propertyValueType === PropertyValueType.TwoD_SPATIAL;
    function E(speed, infl) { return new KeyframeEase(speed, infl); }
    function setEase(p, k, inE, outE) {
        try { p.setTemporalEaseAtKey(k, spatial ? [inE] : [inE, inE], spatial ? [outE] : [outE, outE]); } catch (e) {}
    }
    var y = base[1], cumN = [0], T = [], D = [];
    for (var s = 0; s < SP.length; s++) {
        var t = SP[s].t - OFF, d = SP[s].d, n = Math.max(ROWS + 1, Math.round(SP[s].n));
        var pk = SP[s].pk || 0.7, ov = (SP[s].ov || 0) * STEP, a = y + n * STEP;
        var k0 = shift.addKey(t);            shift.setValueAtKey(k0, [base[0], y]);
        var k1 = shift.addKey(t + d * pk);   shift.setValueAtKey(k1, [base[0], a + ov]);
        var k2 = shift.addKey(t + d);        shift.setValueAtKey(k2, [base[0], a]);
        T.push(t); D.push(d); cumN.push(cumN[cumN.length - 1] + n);
        y = a;
    }
    for (var k = 1; k <= shift.numKeys; k++) {
        var role = (k - 1) % 3;              // 0 — старт, 1 — пік, 2 — зупинка
        if (spatial) { try { shift.setSpatialAutoBezierAtKey(k, false); shift.setSpatialContinuousAtKey(k, false);
            shift.setSpatialTangentsAtKey(k, [0, 0], [0, 0]); } catch (e) {} }
        if (role === 0) { shift.setInterpolationTypeAtKey(k, KeyframeInterpolationType.HOLD, KeyframeInterpolationType.BEZIER); setEase(shift, k, E(0, 33), E(0, 55)); }
        if (role === 1) { shift.setInterpolationTypeAtKey(k, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER); setEase(shift, k, E(0, 25), E(0, 33)); }
        if (role === 2) { shift.setInterpolationTypeAtKey(k, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.HOLD); setEase(shift, k, E(0, 60), E(0, 33)); }
    }
    log.push("Null plan: " + shift.numKeys + " ключів (" + SP.length + " прокрутів), зсув render→Slot " + OFF.toFixed(2) + " с");

    // вираз колонок — як в оригіналі: повторити Offset нула із затримкою за номером колонки
    var COL_EXPR =
        'var n = thisComp.layer("' + np.name + '");\n' +
        'var ctrl = n.effect("' + nOff.name + '")("Shift Center To");\n' +
        'var delaySec = n.effect("Delay")("Slider");\n' +
        'var col = parseInt(thisLayer.source.name.replace(/[^0-9]/g, ""), 10);\n' +
        'var delay = (col - 2) * delaySec;\n' +
        'value + (ctrl.valueAtTime(time - delay) - ctrl.valueAtTime(0));';

    // ---------------- 4. ColumnPlan_N: кадр = результат прокруту ----------------
    var built = 0;
    for (var ci = 0; ci < colLayers.length; ci++) {
        var CL = colLayers[ci], src = CL.source;
        var n = parseInt(src.name.replace(/[^0-9]/g, ""), 10);
        var pname = "ColumnPlan_" + n, NST = SP.length + 1;
        var pc = compAny(pname);
        if (pc) { while (pc.numLayers) pc.layer(1).remove(); pc.duration = NST * fd; }
        else pc = proj.items.addComp(pname, src.width, src.height, src.pixelAspect, NST * fd, src.frameRate);

        var refSym = null;
        for (var j = 1; j <= src.numLayers; j++) if (src.layer(j).name !== "Control" && src.layer(j).source) { refSym = src.layer(j); break; }
        var colBase = fxByMatch(CL, "ADBE Offset").property("ADBE Offset-0001").valueAtTime(0, true)[1];

        // ids[кадр][ряд] — що стоїть у кожному ряду стрічки в кожному кадрі
        var ids = [], cur = [];
        for (var r = 0; r < NROWS; r++) cur.push(mod(n * 4 + r * 7, 9) + 1);
        for (var s = 0; s < NST; s++) {
            var yl = colBase + STEP * cumN[s];
            var yin = mod(H - yl, H);
            var rc = mod(Math.round((yin - Y1) / STEP), NROWS);
            var g = (s === 0 ? plan.init : SP[s - 1].grid)[n - 1];
            for (var gi = 0; gi < ROWS; gi++) {
                var jj = (ROWS % 2) ? gi - (ROWS - 1) / 2 : gi - ROWS / 2;
                cur[mod(rc + jj, NROWS)] = g ? g[gi] : 1;
            }
            ids.push(cur.slice(0));
        }
        // шари: однаковий символ у сусідніх кадрах = один шар
        for (var r = NROWS - 1; r >= 0; r--) {
            var s = 0;
            while (s < NST) {
                var id = ids[s][r], e = s;
                while (e + 1 < NST && ids[e + 1][r] === id) e++;
                var rl = pc.layers.add(symComps[id]);
                rl.startTime = s * fd; rl.inPoint = s * fd; rl.outPoint = (e + 1) * fd;
                rl.name = "Ряд " + (r + 1) + " · кадри " + s + (e > s ? "–" + e : "");
                tr(rl).property("ADBE Position").setValue([src.width / 2, Y1 + r * STEP]);
                if (refSym) {
                    var rs = tr(refSym).property("ADBE Scale");
                    tr(rl).property("ADBE Scale").setValue(rs.valueAtTime(0, true));
                    if (rs.expression) tr(rl).property("ADBE Scale").expression = rs.expression;   // компенсація Gap Y, якщо є
                }
                s = e + 1;
            }
        }

        // шар у Slot
        var PL = null;
        for (var i = 1; i <= slot.numLayers; i++) if (slot.layer(i).source === pc) PL = slot.layer(i);
        if (!PL) { PL = CL.duplicate(); PL.replaceSource(pc, false); PL.moveToEnd(); PL.name = pname; }
        PL.enabled = true;
        CL.enabled = false;
        fxByMatch(PL, "ADBE Offset").property("ADBE Offset-0001").expression = COL_EXPR;

        // Time Remap: HOLD-ключі — посеред кожного прокруту стрічка переходить на наступний кадр
        // AE вимикає Time Remap, якщо видалити всі його ключі, тому: вмикаємо заново,
        // додаємо свої ключі, а потім прибираємо автоматичні
        PL.timeRemapEnabled = false;
        PL.timeRemapEnabled = true;
        PL.inPoint = 0; PL.outPoint = slot.duration;
        var TR = PL.property("ADBE Time Remapping");
        TR.expression = "";
        var delayN = (n - 2) * DELAY;
        var want = [[0, 0]];
        for (var s = 0; s < SP.length; s++) want.push([T[s] + delayN + D[s] * 0.35, (s + 1) * fd]);
        var mine = [];
        for (var w = 0; w < want.length; w++) { var kw = TR.addKey(want[w][0]); TR.setValueAtKey(kw, want[w][1]); }
        for (var w = 0; w < want.length; w++) mine.push(want[w][0]);
        for (var q = TR.numKeys; q >= 1 && TR.numKeys > want.length; q--) {
            var tq = TR.keyTime(q), ok = false;
            for (var w = 0; w < mine.length; w++) if (Math.abs(mine[w] - tq) < fd / 4) ok = true;
            if (!ok) TR.removeKey(q);
        }
        for (var q = 1; q <= TR.numKeys; q++) TR.setInterpolationTypeAtKey(q, KeyframeInterpolationType.HOLD, KeyframeInterpolationType.HOLD);

        // «відскок» масштабу на фінальній зупинці (як в оригіналі) замість старих ключів
        var sc = tr(PL).property("ADBE Scale");
        var sv = sc.valueAtTime(0, true); clearKeys(sc); sc.setValue(sv);
        if (SP.length) {
            var te = T[SP.length - 1] + D[SP.length - 1] + delayN, big = [];
            for (var v = 0; v < sv.length; v++) big.push(v < 2 ? sv[v] * 1.0625 : sv[v]);
            var kk = sc.addKey(te - 0.2);   sc.setValueAtKey(kk, sv);
            kk = sc.addKey(te - 0.133);     sc.setValueAtKey(kk, big);
            kk = sc.addKey(te - 0.033);     sc.setValueAtKey(kk, sv);
        }
        built++;
    }
    log.push("ColumnPlan: " + built + " стрічок по " + (SP.length + 1) + " кадрів; оригінальні колонки вимкнено (око)");

    app.endUndoGroup();
    alert("План застосовано на ключах.\n\n" + log.join("\n") +
        "\n\nЯк правити руками:\n" +
        "• рух — ключі Shift Center To на «Null plan» у Slot;\n" +
        "• момент підміни комбінації — ключі Time Remap на шарах ColumnPlan_N;\n" +
        "• символ у клітинці — заміни джерело шару «Ряд … · кадри …» у ColumnPlan_N.\n" +
        "Повернути оригінал: увімкни Column_N і вимкни ColumnPlan_N у Slot.");
})();
