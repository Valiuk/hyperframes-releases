/*  Hyperframes Spine Export — host side (After Effects ExtendScript)
    Усі рядки між панеллю та AE передаються як encodeURIComponent, щоб кирилиця в шляхах не ламалась. */

function hfDec(s) { try { return decodeURIComponent(s); } catch (e) { return s; } }
function hfQ(s) { return '"' + encodeURIComponent(String(s)) + '"'; }

function hfInfo() {
    try {
        var p = app.project, r = '{';
        var pd = (p && p.file) ? p.file.parent.fsName : '';
        r += '"projectDir":' + hfQ(pd) + ',"docs":' + hfQ(Folder.myDocuments.fsName);
        var c = p ? p.activeItem : null;
        if (c && (c instanceof CompItem)) {
            r += ',"comp":{"id":' + c.id + ',"w":' + c.width + ',"h":' + c.height + ',"fps":' + c.frameRate +
                 ',"time":' + c.time + ',"name":' + hfQ(c.name) + '}';
        }
        return r + '}';
    } catch (e) { return '{"error":' + hfQ(e.toString()) + '}'; }
}

function hfBin(name) {
    var p = app.project;
    for (var i = 1; i <= p.numItems; i++) {
        var it = p.item(i);
        if (it instanceof FolderItem && it.name === name && it.parentFolder === p.rootFolder) return it;
    }
    return p.items.addFolder(name);
}

function hfFindFootage(file) {
    var p = app.project, target = file.fsName.toLowerCase();
    for (var i = 1; i <= p.numItems; i++) {
        var it = p.item(i);
        try {
            if (it instanceof FootageItem && it.mainSource && it.mainSource.file &&
                it.mainSource.file.fsName.toLowerCase() === target) return it;
        } catch (e) {}
    }
    return null;
}

/* encPath — перший кадр секвенції; compId — 0 = не додавати в композицію
   posMode: 0 — як є, 1 — центр композиції (повний кадр), 2 — обрізаний кадр, центр Spine у центрі композиції
   refresh: 1 — файли перерендерено, перечитати футаж */
function hfImportSequence(encPath, encName, fps, compId, posMode, ox, oy, w, h, refresh) {
    app.beginUndoGroup('Spine Export: import');
    try {
        var f = new File(hfDec(encPath));
        if (!f.exists) { app.endUndoGroup(); return '{"error":' + hfQ('файл не знайдено: ' + f.fsName) + '}'; }
        var item = hfFindFootage(f), reused = !!item;
        if (item) {
            if (refresh) item.replaceWithSequence(f, true);
        } else {
            var io = new ImportOptions(f);
            io.sequence = true;
            io.forceAlphabetical = true;
            item = app.project.importFile(io);
            item.parentFolder = hfBin('Spine Exports');
        }
        item.name = hfDec(encName);
        try { item.mainSource.conformFrameRate = fps; } catch (e) {}
        try { item.mainSource.alphaMode = AlphaMode.STRAIGHT; } catch (e) {}

        var added = false;
        if (compId) {
            var c = app.project.itemByID(compId);
            if (c && (c instanceof CompItem)) {
                var L = c.layers.add(item);
                L.startTime = c.time;
                var pos = L.property('ADBE Transform Group').property('ADBE Position');
                if (posMode == 1) pos.setValue([c.width / 2, c.height / 2]);
                else if (posMode == 2) pos.setValue([c.width / 2 + (w / 2 - ox), c.height / 2 + (h / 2 - oy)]);
                added = true;
            }
        }
        app.endUndoGroup();
        return '{"ok":true,"added":' + added + ',"reused":' + reused + '}';
    } catch (e) {
        app.endUndoGroup();
        return '{"error":' + hfQ(e.toString() + (e.line ? ' (line ' + e.line + ')' : '')) + '}';
    }
}
