/* Gemini Translate - panel logic (Hyperframes) */

(function () {
  'use strict';

  /* ------------------------------------------------------------ environment */

  var cep = window.__adobe_cep__;
  var nodeRequire = (typeof require === 'function')
    ? require
    : (window.cep_node && window.cep_node.require) || null;
  var https = nodeRequire ? nodeRequire('https') : null;

  var CHUNK_SIZE = 25;        // рядків в одному запиті
  var MAX_RETRIES = 3;
  var STORE = 'hf.gemini.translate.';

  var HOST_ERRORS = {
    NO_COMP: 'Активної композиції немає. Відкрий композицію у вікні Composition.',
    SCAN_FAILED: 'Не вдалося прочитати шари',
    APPLY_FAILED: 'Не вдалося записати текст',
    DUPLICATE_FAILED: 'Не вдалося продублювати композицію',
    STATUS_FAILED: 'Не вдалося прочитати стан проєкту'
  };

  var SKIP_REASONS = {
    EXPRESSION: 'на Source Text висить вираз'
  };

  var LANG_TAGS = {
    'англійську': 'EN', 'польську': 'PL', 'німецьку': 'DE',
    'іспанську': 'ES', 'французьку': 'FR', 'українську': 'UA',
    'італійську': 'IT', 'румунську': 'RO', 'чеську': 'CS'
  };

  /* ------------------------------------------------------------------- dom */

  var $ = function (id) { return document.getElementById(id); };
  var el = {
    apiKey: $('apiKey'), model: $('model'), lang: $('lang'), notes: $('notes'),
    selectedOnly: $('selectedOnly'), includePre: $('includePre'), makeCopy: $('makeCopy'),
    scan: $('scan'), run: $('run'), clear: $('clear'), refresh: $('refresh'),
    log: $('log'), meter: $('meterFill'), comp: $('compName')
  };

  /* ------------------------------------------------------------------- log */

  function log(msg, cls) {
    var d = new Date();
    var t = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2) +
            ':' + ('0' + d.getSeconds()).slice(-2);
    var line = document.createElement('div');
    line.innerHTML = '<span class="t">' + t + '</span>  <span class="' + (cls || '') + '"></span>';
    line.lastChild.textContent = msg;
    el.log.appendChild(line);
    el.log.scrollTop = el.log.scrollHeight;
  }

  function progress(v) { el.meter.style.width = Math.max(0, Math.min(1, v)) * 100 + '%'; }

  function busy(on) {
    el.run.disabled = on;
    el.scan.disabled = on;
    el.run.textContent = on ? 'Працюю…' : 'Перекласти';
  }

  /* --------------------------------------------------------- host bridge */

  /** ExtendScript надійно приймає лише ASCII, тому все поза ним екрануємо. */
  function toAscii(s) {
    return s.replace(/[\u007f-\uffff]/g, function (c) {
      var h = c.charCodeAt(0).toString(16);
      while (h.length < 4) { h = '0' + h; }
      return '\\u' + h;
    });
  }

  function evalScript(script) {
    return new Promise(function (resolve, reject) {
      if (!cep) { reject(new Error('Панель запущена поза After Effects')); return; }
      cep.evalScript(script, function (res) {
        if (res === 'EvalScript error.') { reject(new Error('Помилка виконання ExtendScript')); return; }
        resolve(res);
      });
    });
  }

  function host(fn, arg) {
    var payload = JSON.stringify(arg || {});
    var script = fn + '(' + toAscii(JSON.stringify(payload)) + ')';
    return evalScript(script).then(function (raw) {
      var data;
      try { data = JSON.parse(raw); }
      catch (e) { throw new Error('Незрозуміла відповідь хоста: ' + String(raw).slice(0, 140)); }
      if (!data.ok) {
        var base = HOST_ERRORS[data.code] || data.code;
        throw new Error(data.detail ? base + ' — ' + data.detail : base);
      }
      return data;
    });
  }

  /* ------------------------------------------------------------- settings */

  var FIELDS = ['apiKey', 'model', 'lang', 'notes'];
  var FLAGS = ['selectedOnly', 'includePre', 'makeCopy'];

  function loadSettings() {
    FIELDS.forEach(function (k) {
      var v = localStorage.getItem(STORE + k);
      if (v !== null) { el[k].value = v; }
    });
    FLAGS.forEach(function (k) {
      var v = localStorage.getItem(STORE + k);
      if (v !== null) { el[k].checked = v === '1'; }
    });
  }

  function saveSettings() {
    FIELDS.forEach(function (k) { localStorage.setItem(STORE + k, el[k].value); });
    FLAGS.forEach(function (k) { localStorage.setItem(STORE + k, el[k].checked ? '1' : '0'); });
  }

  /* --------------------------------------------------------------- gemini */

  function request(model, key, body) {
    return new Promise(function (resolve, reject) {
      if (!https) { reject(new Error('Node.js недоступний. Перевір --enable-nodejs у manifest.xml')); return; }
      var buf = Buffer.from(JSON.stringify(body), 'utf8');
      var req = https.request({
        hostname: 'generativelanguage.googleapis.com',
        path: '/v1beta/models/' + encodeURIComponent(model) + ':generateContent',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': key,
          'Content-Length': buf.length
        }
      }, function (res) {
        var chunks = [];
        res.on('data', function (d) { chunks.push(d); });
        res.on('end', function () {
          resolve({ status: res.statusCode, text: Buffer.concat(chunks).toString('utf8') });
        });
      });
      req.on('error', function (e) { reject(new Error('Мережа: ' + e.message)); });
      req.setTimeout(120000, function () { req.destroy(new Error('Тайм-аут запиту (120 с)')); });
      req.write(buf);
      req.end();
    });
  }

  function systemPrompt(cfg) {
    var s =
      'Ти — перекладач екранного тексту для рекламних відео та моушн-дизайну.\n' +
      'Переклади кожен рядок на ' + cfg.lang + '.\n\n' +
      'Правила:\n' +
      '- Зберігай переноси рядків (\\n) рівно там, де вони в оригіналі, і не додавай нових.\n' +
      '- Зберігай регістр за задумом: ВЕЛИКІ ЛІТЕРИ лишаються великими, Title Case — Title Case.\n' +
      '- Не чіпай цифри, ціни, дати, URL, хештеги, e-mail, назви брендів і плейсхолдери ({name}, %s, [X]).\n' +
      '- Тримай довжину близькою до оригіналу — текст має вміститися в той самий макет.\n' +
      '- Не додавай лапок, пояснень, крапок у кінці, якщо їх не було в оригіналі.\n' +
      '- Якщо рядок перекладати не треба (логотип, код, символ) — поверни його без змін.\n\n' +
      'Відповідай лише JSON-масивом об\'єктів {"i": <індекс з запиту>, "t": "<переклад>"}. ' +
      'Кількість елементів має точно збігатися з кількістю у запиті.';
    if (cfg.notes) { s += '\n\nДодаткові вимоги замовника:\n' + cfg.notes; }
    return s;
  }

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function translateChunk(texts, cfg, attempt) {
    attempt = attempt || 0;
    var input = texts.map(function (t, i) { return { i: i, t: t }; });

    var body = {
      systemInstruction: { parts: [{ text: systemPrompt(cfg) }] },
      contents: [{ role: 'user', parts: [{ text: JSON.stringify(input) }] }],
      generationConfig: {
        temperature: 0.2,
        maxOutputTokens: 16384,
        responseMimeType: 'application/json',
        responseSchema: {
          type: 'ARRAY',
          items: {
            type: 'OBJECT',
            properties: { i: { type: 'INTEGER' }, t: { type: 'STRING' } },
            required: ['i', 't']
          }
        }
      }
    };

    return request(cfg.model, cfg.key, body).then(function (res) {
      var retryable = res.status === 429 || res.status >= 500;
      if (res.status !== 200) {
        var msg = 'HTTP ' + res.status;
        try {
          var errJson = JSON.parse(res.text);
          if (errJson.error && errJson.error.message) { msg += ' — ' + errJson.error.message; }
        } catch (e) { msg += ' — ' + res.text.slice(0, 200); }

        if (retryable && attempt < MAX_RETRIES) {
          var wait = Math.pow(2, attempt) * 1500;
          log('Gemini: ' + msg + '. Повтор через ' + (wait / 1000) + ' с', 'warn');
          return sleep(wait).then(function () { return translateChunk(texts, cfg, attempt + 1); });
        }
        throw new Error(msg);
      }

      var json = JSON.parse(res.text);
      var cand = json.candidates && json.candidates[0];
      if (!cand) {
        var blocked = json.promptFeedback && json.promptFeedback.blockReason;
        throw new Error(blocked ? 'Запит відхилено фільтром: ' + blocked : 'Порожня відповідь моделі');
      }
      if (cand.finishReason === 'MAX_OUTPUT_TOKENS' || cand.finishReason === 'MAX_TOKENS') {
        throw new Error('Відповідь обрізано за лімітом токенів — зменш розмір пакета');
      }

      var parts = (cand.content && cand.content.parts) || [];
      var out = parts.map(function (p) { return p.text || ''; }).join('').trim();
      out = out.replace(/^```(?:json)?/, '').replace(/```$/, '').trim();

      var arr = JSON.parse(out);
      var result = texts.slice();
      arr.forEach(function (item) {
        if (typeof item.i === 'number' && item.i >= 0 && item.i < result.length &&
            typeof item.t === 'string') {
          result[item.i] = item.t;
        }
      });
      return result;
    });
  }

  /* ----------------------------------------------------------------- flow */

  function readConfig() {
    var cfg = {
      key: el.apiKey.value.trim(),
      model: el.model.value.trim(),
      lang: el.lang.value.trim(),
      notes: el.notes.value.trim(),
      selectedOnly: el.selectedOnly.checked,
      includePre: el.includePre.checked,
      makeCopy: el.makeCopy.checked
    };
    cfg.tag = LANG_TAGS[cfg.lang.toLowerCase()] || cfg.lang.slice(0, 2).toUpperCase();
    return cfg;
  }

  function reportSkipped(skipped) {
    skipped.forEach(function (s) {
      log('пропущено: ' + s.c + ' / ' + s.n + ' — ' + (SKIP_REASONS[s.r] || s.r), 'warn');
    });
  }

  function doScan() {
    var cfg = readConfig();
    busy(true);
    return host('hfScan', {
      compId: 0, includePre: cfg.includePre, selectedOnly: cfg.selectedOnly
    }).then(function (data) {
      el.comp.textContent = data.comp;
      log('«' + data.comp + '»: знайдено ' + data.items.length + ' текстових значень', 'hi');
      reportSkipped(data.skipped);
      if (!data.items.length) {
        log(cfg.selectedOnly ? 'Виділених текстових шарів немає.' : 'Текстових шарів немає.', 'warn');
      }
      return data;
    }).catch(function (e) {
      log(e.message, 'err');
      return null;
    }).then(function (r) { busy(false); return r; });
  }

  function run() {
    var cfg = readConfig();

    if (!cfg.key) { log('Вкажи API-ключ Gemini.', 'err'); el.apiKey.focus(); return; }
    if (!cfg.lang) { log('Вкажи мову перекладу.', 'err'); el.lang.focus(); return; }
    if (!cfg.model) { log('Вкажи модель.', 'err'); el.model.focus(); return; }

    busy(true);
    progress(0);

    var items, compLabel;

    host('hfScan', { compId: 0, includePre: cfg.includePre, selectedOnly: cfg.selectedOnly })
      .then(function (data) {
        items = data.items;
        compLabel = data.comp;
        el.comp.textContent = data.comp;
        reportSkipped(data.skipped);
        if (!items.length) { throw new Error('Нема чого перекладати.'); }
        log('«' + data.comp + '»: ' + items.length + ' текстових значень', 'hi');

        if (!cfg.makeCopy) {
          if (cfg.includePre) {
            log('Увага: прекомпи спільні для всього проєкту — правки зачеплять усі композиції, де вони стоять.', 'warn');
          }
          return null;
        }

        return host('hfDuplicate', {
          suffix: ' ' + cfg.tag,
          deep: cfg.includePre,
          folderName: 'Localized ' + cfg.tag
        }).then(function (dup) {
          items.forEach(function (it) {
            var mapped = dup.map[String(it.c)];
            if (mapped) { it.c = mapped; }
          });
          log('Копія: «' + dup.comp + '»' + (cfg.includePre ? ' (з прекомпами)' : ''), 'ok');
          compLabel = dup.comp;
          el.comp.textContent = dup.comp;
          return dup;
        });
      })
      .then(function () {
        // Однакові рядки перекладаємо один раз.
        var unique = [], index = {};
        items.forEach(function (it) {
          var norm = it.t.replace(/\r\n?/g, '\n');
          it.norm = norm;
          if (!(norm in index)) { index[norm] = unique.length; unique.push(norm); }
        });

        var dupSaved = items.length - unique.length;
        log('Унікальних рядків: ' + unique.length + (dupSaved ? ' (повторів пропущено: ' + dupSaved + ')' : ''));

        var chunks = [];
        for (var i = 0; i < unique.length; i += CHUNK_SIZE) {
          chunks.push(unique.slice(i, i + CHUNK_SIZE));
        }

        var translated = [];
        var chain = Promise.resolve();
        chunks.forEach(function (chunk, n) {
          chain = chain.then(function () {
            log('Пакет ' + (n + 1) + '/' + chunks.length + ' → ' + cfg.model + ' (' + chunk.length + ')');
            return translateChunk(chunk, cfg).then(function (res) {
              translated = translated.concat(res);
              progress((n + 1) / chunks.length);
            });
          });
        });

        return chain.then(function () { return { unique: unique, index: index, translated: translated }; });
      })
      .then(function (t) {
        var payload = items.map(function (it) {
          var out = t.translated[t.index[it.norm]];
          if (typeof out !== 'string') { out = it.t; }
          return { c: it.c, l: it.l, k: it.k, t: out.replace(/\r\n?|\n/g, '\r') };
        });
        return host('hfApply', { items: payload });
      })
      .then(function (res) {
        log('Записано ' + res.applied + ' з ' + items.length + ' — «' + compLabel + '»', 'ok');
        res.failed.forEach(function (f) { log('не записано: ' + f.n + ' — ' + f.r, 'err'); });
        log('Ctrl+Z / Cmd+Z скасовує всю правку одним кроком.');
      })
      .catch(function (e) {
        log(e.message, 'err');
      })
      .then(function () {
        busy(false);
        setTimeout(function () { progress(0); }, 900);
      });
  }

  /* ---------------------------------------------------------------- init */

  function refreshStatus() {
    host('hfActiveComp', {})
      .then(function (d) {
        el.comp.textContent = d.comp + ' · шарів: ' + d.layers +
          (d.selectedText ? ' · виділено тексту: ' + d.selectedText : '');
      })
      .catch(function () { el.comp.textContent = 'композицію не вибрано'; });
  }

  el.scan.addEventListener('click', doScan);
  el.run.addEventListener('click', run);
  el.refresh.addEventListener('click', refreshStatus);
  el.clear.addEventListener('click', function () { el.log.innerHTML = ''; });

  FIELDS.concat(FLAGS).forEach(function (k) {
    el[k].addEventListener('change', saveSettings);
  });

  loadSettings();
  refreshStatus();
  setInterval(refreshStatus, 4000);

  if (!https) {
    log('Node.js не піднявся — запити до Gemini не працюватимуть. Перевір CEFCommandLine у manifest.xml.', 'err');
  } else {
    log('Панель готова.', 'ok');
  }
})();
