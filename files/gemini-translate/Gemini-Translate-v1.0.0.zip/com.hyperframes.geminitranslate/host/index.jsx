/**
 * Gemini Translate - ExtendScript host
 * Hyperframes
 *
 * IMPORTANT: this file is intentionally 100% ASCII.
 * All UI strings live in the panel (client/main.js); the host returns only
 * machine codes. Every string that leaves the host is escaped to \uXXXX,
 * so Cyrillic layer/comp names survive the ExtendScript <-> CEP bridge.
 */

/* ---------------------------------------------------------------- utils */

function hfPad4(h) {
    while (h.length < 4) { h = '0' + h; }
    return h;
}

/** JSON string literal, ASCII-only. */
function hfQ(s) {
    if (s === null || s === undefined) { s = ''; }
    s = String(s);
    var out = '"';
    for (var i = 0; i < s.length; i++) {
        var ch = s.charAt(i);
        var code = s.charCodeAt(i);
        if (ch === '"') { out += '\\"'; }
        else if (ch === '\\') { out += '\\\\'; }
        else if (code < 32 || code > 126) { out += '\\u' + hfPad4(code.toString(16)); }
        else { out += ch; }
    }
    return out + '"';
}

function hfErr(code, detail) {
    return '{"ok":false,"code":' + hfQ(code) + ',"detail":' + hfQ(detail || '') + '}';
}

function hfBlank(s) {
    if (s === null || s === undefined) { return true; }
    return String(s).replace(/[\s\r\n\u00a0]/g, '') === '';
}

function hfSourceText(layer) {
    try {
        var g = layer.property('ADBE Text Properties');
        if (!g) { return null; }
        return g.property('ADBE Text Document');
    } catch (e) { return null; }
}

function hfCompById(id) {
    var it = app.project.itemByID(id);
    if (!it || !(it instanceof CompItem)) { return null; }
    return it;
}

/* -------------------------------------------------------------- reading */

function hfCollect(comp, includePre, selectedOnly, items, skipped, seen) {
    var key = 'c' + comp.id;
    if (seen[key]) { return; }
    seen[key] = true;

    for (var i = 1; i <= comp.numLayers; i++) {
        var lyr = comp.layer(i);

        if (lyr instanceof TextLayer) {
            if (selectedOnly && !lyr.selected) { continue; }
            var sp = hfSourceText(lyr);
            if (!sp) { continue; }

            if (sp.expressionEnabled) {
                skipped.push({ c: comp.name, n: lyr.name, r: 'EXPRESSION' });
                continue;
            }

            if (sp.numKeys > 0) {
                for (var k = 1; k <= sp.numKeys; k++) {
                    var tk = sp.keyValue(k).text;
                    if (hfBlank(tk)) { continue; }
                    items.push({ c: comp.id, l: i, k: k, n: lyr.name, cn: comp.name, t: tk });
                }
            } else {
                var tv = sp.value.text;
                if (hfBlank(tv)) { continue; }
                items.push({ c: comp.id, l: i, k: -1, n: lyr.name, cn: comp.name, t: tv });
            }
            continue;
        }

        if (includePre) {
            var src = null;
            try { src = lyr.source; } catch (e) { src = null; }
            if (src && (src instanceof CompItem)) {
                if (selectedOnly && !lyr.selected) { continue; }
                hfCollect(src, includePre, false, items, skipped, seen);
            }
        }
    }
}

/**
 * @param {string} payload JSON: {compId:0|id, includePre:bool, selectedOnly:bool}
 */
function hfScan(payload) {
    try {
        var o = eval('(' + payload + ')');
        var comp = o.compId ? hfCompById(o.compId) : app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) { return hfErr('NO_COMP'); }

        var items = [], skipped = [], seen = {};
        hfCollect(comp, !!o.includePre, !!o.selectedOnly, items, skipped, seen);

        var parts = [];
        for (var i = 0; i < items.length; i++) {
            var it = items[i];
            parts.push('{"c":' + it.c + ',"l":' + it.l + ',"k":' + it.k +
                       ',"n":' + hfQ(it.n) + ',"cn":' + hfQ(it.cn) + ',"t":' + hfQ(it.t) + '}');
        }
        var sk = [];
        for (var j = 0; j < skipped.length; j++) {
            sk.push('{"c":' + hfQ(skipped[j].c) + ',"n":' + hfQ(skipped[j].n) +
                    ',"r":' + hfQ(skipped[j].r) + '}');
        }

        return '{"ok":true,"comp":' + hfQ(comp.name) + ',"compId":' + comp.id +
               ',"items":[' + parts.join(',') + '],"skipped":[' + sk.join(',') + ']}';
    } catch (e) {
        return hfErr('SCAN_FAILED', e.toString());
    }
}

/* ------------------------------------------------------------ duplicate */

function hfDeepDup(comp, suffix, map, folder) {
    var dup = comp.duplicate();
    dup.name = comp.name + suffix;
    if (folder) { dup.parentFolder = folder; }
    map['c' + comp.id] = dup;

    for (var i = 1; i <= dup.numLayers; i++) {
        var lyr = dup.layer(i);
        var src = null;
        try { src = lyr.source; } catch (e) { src = null; }
        if (!src || !(src instanceof CompItem)) { continue; }

        var cached = map['c' + src.id];
        if (!cached) { cached = hfDeepDup(src, suffix, map, folder); }
        try { lyr.replaceSource(cached, false); } catch (e2) {}
    }
    return dup;
}

/**
 * @param {string} payload JSON: {suffix:string, deep:bool, folderName:string}
 */
function hfDuplicate(payload) {
    try {
        var o = eval('(' + payload + ')');
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) { return hfErr('NO_COMP'); }

        app.beginUndoGroup('Gemini Translate: duplicate comp');
        var folder = null;
        try { folder = app.project.items.addFolder(o.folderName || 'Localized'); } catch (e) {}

        var map = {};
        var dup;
        if (o.deep) {
            dup = hfDeepDup(comp, o.suffix || ' COPY', map, folder);
        } else {
            dup = comp.duplicate();
            dup.name = comp.name + (o.suffix || ' COPY');
            if (folder) { dup.parentFolder = folder; }
            map['c' + comp.id] = dup;
        }
        dup.openInViewer();
        app.endUndoGroup();

        var pairs = [];
        for (var key in map) {
            if (!map.hasOwnProperty(key)) { continue; }
            pairs.push('"' + key.substring(1) + '":' + map[key].id);
        }

        return '{"ok":true,"compId":' + dup.id + ',"comp":' + hfQ(dup.name) +
               ',"map":{' + pairs.join(',') + '}}';
    } catch (e) {
        try { app.endUndoGroup(); } catch (e2) {}
        return hfErr('DUPLICATE_FAILED', e.toString());
    }
}

/* -------------------------------------------------------------- writing */

/**
 * @param {string} payload JSON: {items:[{c,l,k,t}]}
 */
function hfApply(payload) {
    var applied = 0;
    var failed = [];
    try {
        var o = eval('(' + payload + ')');
        var items = o.items || [];

        app.beginUndoGroup('Gemini Translate');
        for (var i = 0; i < items.length; i++) {
            var it = items[i];
            var wasLocked = false;
            var lyr = null;
            try {
                var comp = hfCompById(it.c);
                if (!comp) { throw new Error('comp not found'); }
                lyr = comp.layer(it.l);
                wasLocked = lyr.locked;
                if (wasLocked) { lyr.locked = false; }

                var sp = hfSourceText(lyr);
                if (!sp) { throw new Error('no source text'); }

                if (it.k > 0) {
                    var tdk = sp.keyValue(it.k);
                    tdk.text = it.t;
                    sp.setValueAtKey(it.k, tdk);
                } else {
                    var td = sp.value;
                    td.text = it.t;
                    sp.setValue(td);
                }
                applied++;
            } catch (e) {
                failed.push({ n: (lyr ? lyr.name : ('#' + it.l)), r: e.toString() });
            }
            try { if (lyr && wasLocked) { lyr.locked = true; } } catch (e3) {}
        }
        app.endUndoGroup();

        var f = [];
        for (var j = 0; j < failed.length; j++) {
            f.push('{"n":' + hfQ(failed[j].n) + ',"r":' + hfQ(failed[j].r) + '}');
        }
        return '{"ok":true,"applied":' + applied + ',"failed":[' + f.join(',') + ']}';
    } catch (e) {
        try { app.endUndoGroup(); } catch (e4) {}
        return hfErr('APPLY_FAILED', e.toString());
    }
}

/* --------------------------------------------------------------- status */

function hfActiveComp() {
    try {
        var comp = app.project.activeItem;
        if (!comp || !(comp instanceof CompItem)) { return hfErr('NO_COMP'); }
        var sel = 0;
        var ls = comp.selectedLayers;
        for (var i = 0; i < ls.length; i++) {
            if (ls[i] instanceof TextLayer) { sel++; }
        }
        return '{"ok":true,"comp":' + hfQ(comp.name) + ',"compId":' + comp.id +
               ',"layers":' + comp.numLayers + ',"selectedText":' + sel + '}';
    } catch (e) {
        return hfErr('STATUS_FAILED', e.toString());
    }
}
