/*
 * HF Text Styles — ExtendScript engine (ES3).
 * Applies a style object (see js/styles.js) to selected text layers.
 *
 * Effects added by the panel are named "HFS ..." so they can be replaced cleanly.
 * Layer styles are added via menu commands (the only way AE exposes them to scripts).
 */

var HFS_TAG = "HFS ";
var HFS_WARN = [];
var HFS_PREV = null;
var HFS_FXCOUNT = 0;
var HFS_LSFAIL = {};

// Layer-style group key -> [menu command id, English menu name]
var HFS_LS = {
    dropShadow:   [9000, "Drop Shadow"],
    innerShadow:  [9001, "Inner Shadow"],
    outerGlow:    [9002, "Outer Glow"],
    innerGlow:    [9003, "Inner Glow"],
    bevelEmboss:  [9004, "Bevel and Emboss"],
    chromeFX:     [9005, "Satin"],
    solidFill:    [9006, "Color Overlay"],
    gradientFill: [9007, "Gradient Overlay"],
    frameFX:      [9008, "Stroke"]
};
var HFS_LS_KEYS = ["dropShadow", "innerShadow", "outerGlow", "innerGlow", "bevelEmboss", "chromeFX", "solidFill", "gradientFill", "frameFX"];

// ---------------- helpers ----------------
function hfs__rgb(h) {
    h = String(h).replace("#", "");
    return [parseInt(h.substr(0, 2), 16) / 255, parseInt(h.substr(2, 2), 16) / 255, parseInt(h.substr(4, 2), 16) / 255];
}
function hfs__rgba(h) { var c = hfs__rgb(h); c.push(1); return c; }
function hfs__lerpHex(a, b, t) {
    var x = hfs__rgb(a), y = hfs__rgb(b);
    return [x[0] + (y[0] - x[0]) * t, x[1] + (y[1] - x[1]) * t, x[2] + (y[2] - x[2]) * t, 1];
}
function hfs__deg(r) { return r * 180 / Math.PI; }
function hfs__rad(d) { return d * Math.PI / 180; }
// Shadow direction (clockwise from up) -> Photoshop-style light angle used by layer styles
function hfs__psFromShadow(s) { var a = hfs__rad(s); return hfs__deg(Math.atan2(-Math.cos(a), -Math.sin(a))); }
// Light-from direction (clockwise from up) -> Photoshop-style light angle
function hfs__psFromLight(l) { var a = hfs__rad(l); return hfs__deg(Math.atan2(Math.cos(a), Math.sin(a))); }

function hfs__warn(msg) { HFS_WARN.push(msg); }

function hfs__clamp(p, v) {
    try { if (p.hasMin && v < p.minValue) v = p.minValue; } catch (e) {}
    try { if (p.hasMax && v > p.maxValue) v = p.maxValue; } catch (e) {}
    return v;
}
function hfs__set(p, v, label) {
    if (!p) { hfs__warn("missing " + label); return; }
    try { p.setValue(v); } catch (e) { hfs__warn(label + ": " + e.message); }
}
function hfs__num(p, v, label) {
    if (!p) { hfs__warn("missing " + label); return; }
    try { p.setValue(hfs__clamp(p, v)); } catch (e) { hfs__warn(label + ": " + e.message); }
}
// Percent value. Some old effects (e.g. Drop Shadow opacity) are 0..255 internally but do not
// report a max, so callers pass the right fallback scale for properties without hasMax.
function hfs__pct(p, pct, label, noMaxScale) {
    if (!p) { hfs__warn("missing " + label); return; }
    var max = noMaxScale || 100;
    try { if (p.hasMax) max = p.maxValue; } catch (e) {}
    if (max > 100.5 && max < 256) max = 255; else if (max <= 1.0001) max = 1; else max = (max > 100.5 ? 255 : 100);
    try { p.setValue(pct / 100 * max); } catch (e2) { hfs__warn(label + ": " + e2.message); }
}
function hfs__fxProp(fx, matchName, idx) {
    var p = null;
    try { p = fx.property(matchName); } catch (e) {}
    if (!p) { try { p = fx.property(idx); } catch (e2) {} }
    return p;
}

function hfs__isText(l) { return l instanceof TextLayer; }

function hfs__selectOnly(layer) {
    var comp = layer.containingComp, sel = comp.selectedLayers;
    for (var i = 0; i < sel.length; i++) sel[i].selected = false;
    // clear selected properties too (an effect left selected changes what menu commands act on)
    try { var sp = comp.selectedProperties; for (var j = 0; j < sp.length; j++) sp[j].selected = false; } catch (e) {}
    layer.selected = true;
}

// ---------------- text document ----------------
function hfs__textProp(layer) { return layer.property("ADBE Text Properties").property("ADBE Text Document"); }

function hfs__baseFontSize(layer) {
    var p = hfs__textProp(layer);
    var td = p.numKeys > 0 ? p.keyValue(1) : p.value;
    return td.fontSize || 100;
}

function hfs__editTD(layer, fn) {
    var p = hfs__textProp(layer), td, k;
    if (p.numKeys > 0) {
        for (k = 1; k <= p.numKeys; k++) { td = p.keyValue(k); fn(td); p.setValueAtKey(k, td); }
    } else {
        td = p.value; fn(td); p.setValue(td);
    }
}

// ---------------- effects ----------------
function hfs__fx(layer) { return layer.property("ADBE Effect Parade"); }

function hfs__removeTagged(layer) {
    var fx = hfs__fx(layer);
    for (var i = fx.numProperties; i >= 1; i--) {
        if (fx.property(i).name.indexOf(HFS_TAG) === 0) fx.property(i).remove();
    }
}

function hfs__addFx(layer, matchName, name) {
    var fx = hfs__fx(layer);
    if (!fx.canAddProperty(matchName)) { hfs__warn("cannot add " + matchName); return null; }
    var e = fx.addProperty(matchName);
    var idx = e.propertyIndex;
    try { e.name = HFS_TAG + name; } catch (er) {}
    // re-fetch: never keep a reference across a rename
    return hfs__fx(layer).property(idx);
}

// Gradient end points: static values from the current text bounds, plus an expression that
// keeps them glued to the text when it changes. If the expression fails, the static values stay.
function hfs__rampPoints(layer, ramp, ang) {
    // Text layers are continuously rasterized: After Effects reads their effect point
    // parameters in COMPOSITION space, while sourceRectAtTime() is in LAYER space.
    // So the text bounds are converted with toComp() (expression) / position+scale (static).
    var comp = layer.containingComp, t = comp.time;
    var r = layer.sourceRectAtTime(t, false);
    var a = ang * Math.PI / 180, dx = Math.cos(a), dy = Math.sin(a);
    var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    var h = Math.abs(dx) * r.width / 2 + Math.abs(dy) * r.height / 2;
    var tr = layer.property("ADBE Transform Group");
    var pos = tr.property("ADBE Position").valueAtTime(t, false);
    var anc = tr.property("ADBE Anchor Point").valueAtTime(t, false);
    var sc = tr.property("ADBE Scale").valueAtTime(t, false);
    function toC(x, y) { return [pos[0] + (x - anc[0]) * sc[0] / 100, pos[1] + (y - anc[1]) * sc[1] / 100]; }
    var p1 = hfs__fxProp(ramp, "ADBE Ramp-0001", 1), p3 = hfs__fxProp(ramp, "ADBE Ramp-0003", 3);
    hfs__set(p1, toC(cx - dx * h, cy - dy * h), "ramp start point");
    hfs__set(p3, toC(cx + dx * h, cy + dy * h), "ramp end point");
    var pre = "var r=thisLayer.sourceRectAtTime(time,false);var a=" + ang + "*Math.PI/180;" +
        "var dx=Math.cos(a),dy=Math.sin(a);var cx=r.left+r.width/2,cy=r.top+r.height/2;" +
        "var h=Math.abs(dx)*r.width/2+Math.abs(dy)*r.height/2;";
    var pairs = [[p1, pre + "thisLayer.toComp([cx-dx*h,cy-dy*h])", "start"], [p3, pre + "thisLayer.toComp([cx+dx*h,cy+dy*h])", "end"]];
    for (var i = 0; i < pairs.length; i++) {
        var p = pairs[i][0];
        if (!p) continue;
        try {
            p.expression = pairs[i][1];
            p.valueAtTime(t, false); // force evaluation
            if (p.expressionError) { hfs__warn("ramp " + pairs[i][2] + " expr: " + p.expressionError); p.expression = ""; }
        } catch (e) { hfs__warn("ramp " + pairs[i][2] + " expr: " + e.message); try { p.expression = ""; } catch (e2) {} }
    }
}

function hfs__addDropShadowFx(layer, name, color, opacityPct, dir, dist, soft) {
    var e = hfs__addFx(layer, "ADBE Drop Shadow", name);
    if (!e) return;
    hfs__set(hfs__fxProp(e, "ADBE Drop Shadow-0001", 1), color, name + " color");
    hfs__pct(hfs__fxProp(e, "ADBE Drop Shadow-0002", 2), opacityPct, name + " opacity", 255);
    hfs__num(hfs__fxProp(e, "ADBE Drop Shadow-0003", 3), dir, name + " direction");
    hfs__num(hfs__fxProp(e, "ADBE Drop Shadow-0004", 4), dist, name + " distance");
    hfs__num(hfs__fxProp(e, "ADBE Drop Shadow-0005", 5), soft, name + " softness");
}

// Multi-stop gradient: CC Toner in Pentone mode maps brightness to 5 colours.
// cols[0] = top of the gradient (white in the ramp) ... cols[4] = bottom (black).
function hfs__resample5(cols) {
    var out = [], n = cols.length - 1, i, t, k, a, b, f;
    for (i = 0; i < 5; i++) {
        t = i / 4 * n; k = Math.min(n - 1, Math.floor(t)); f = t - k;
        a = hfs__rgb(cols[k]); b = hfs__rgb(cols[k + 1]);
        out.push([a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f, 1]);
    }
    return out;
}
function hfs__byName(fx, names, idx) {
    for (var i = 1; i <= fx.numProperties; i++) {
        var p = fx.property(i);
        for (var j = 0; j < names.length; j++) if (p.name === names[j]) return p;
    }
    try { return fx.property(idx); } catch (e) { return null; }
}
function hfs__addToner(layer, c5) {
    var t = hfs__addFx(layer, "CC Toner", "Gradient Colors");
    if (!t) { hfs__warn("CC Toner unavailable"); return; }
    hfs__set(hfs__byName(t, ["Tones"], 1), 3, "toner mode (Pentone)");
    hfs__set(hfs__byName(t, ["Highlights"], 2), c5[0], "toner highlights");
    hfs__set(hfs__byName(t, ["Brights"], 3), c5[1], "toner brights");
    hfs__set(hfs__byName(t, ["Midtones"], 4), c5[2], "toner midtones");
    hfs__set(hfs__byName(t, ["Darktones"], 5), c5[3], "toner darktones");
    hfs__set(hfs__byName(t, ["Shadows"], 6), c5[4], "toner shadows");
    hfs__set(hfs__byName(t, ["Blend w. Original", "Blend with Original"], 7), 0, "toner blend");
}

// ---------------- face textures ----------------
var HFS_TEX_DEFAULTS = {
    glitter: { amount: 45, size: 0.022 },
    live:    { amount: 45, size: 0.022, speed: 8 },
    flakes:  { amount: 35, size: 0.045 },
    brushed: { amount: 30, size: 0.35 }
};
// opts.texture: undefined / "style" = use the style's own texture, "none" = no texture,
// otherwise a texture type that overrides the style.
function hfs__textureFor(st, opts) {
    var o = opts.texture;
    if (o === "none") return null;
    if (!o || o === "style") return st.texture || null;
    var d = HFS_TEX_DEFAULTS[o];
    if (!d) return null;
    return { type: o, amount: d.amount, size: d.size, speed: d.speed };
}

function hfs__addNoiseHLS(layer, animated, kind, amount, grainPx, speed) {
    // Always the plain Noise HLS (Noise HLS Auto rendered as huge black/white blobs).
    // "Live" glitter = the same effect with an expression that re-seeds Noise Phase ~12x per second.
    var e = null, names = ["ADBE Noise HLS2", "ADBE Noise HLS"];
    for (var i = 0; i < names.length && !e; i++) {
        if (hfs__fx(layer).canAddProperty(names[i])) e = hfs__addFx(layer, names[i], "Texture Noise");
    }
    if (!e) { hfs__warn("Noise HLS unavailable"); return; }
    hfs__set(hfs__byName(e, ["Noise"], 1), kind, "noise type");          // 1 Uniform, 2 Squared, 3 Grain
    hfs__num(hfs__byName(e, ["Hue"], 2), 0, "noise hue");
    hfs__num(hfs__byName(e, ["Lightness"], 3), amount, "noise lightness");
    hfs__num(hfs__byName(e, ["Saturation"], 4), 0, "noise saturation");
    hfs__num(hfs__byName(e, ["Grain Size"], 5), Math.max(0.5, grainPx), "noise grain size");
    if (animated) {
        var ph = hfs__byName(e, ["Noise Phase"], 6);
        if (!ph) { hfs__warn("missing noise phase"); return; }
        try {
            ph.expression = "Math.floor(time*" + Math.round((speed || 8) * 1.5) + ")*47";
            ph.valueAtTime(layer.containingComp.time, false);
            if (ph.expressionError) { hfs__warn("noise phase expr: " + ph.expressionError); ph.expression = ""; }
        } catch (e1) { hfs__warn("noise phase expr: " + e1.message); }
    }
}

function hfs__addTexture(layer, tex, E, mult) {
    var comp = layer.containingComp;
    var sc = layer.property("ADBE Transform Group").property("ADBE Scale").value;
    var k = Math.abs(sc[0]) / 100 || 1;  // effects on text layers render in comp space
    var px = Math.max(1, E(tex.size) / (mult || 1) * k);
    if (tex.type === "glitter" || tex.type === "live") {
        // crisp sparkles: per-pixel Uniform noise ("Grain" gives soft film-grain blobs).
        // On larger text the cells are enlarged with Mosaic; it averages each block, so the
        // noise amount is boosted to keep the same contrast.
        // Sparkle cell: ~1.3% of the font size, independent of the decor multiplier, 1..4 px.
        // Mosaic with Sharp Colors picks one pixel per cell (no averaging), so no amount boost.
        px = Math.max(1, Math.min(4, (E(tex.size) / (mult || 1)) * 0.6 * k));
        var big = px >= 1.8;
        hfs__addNoiseHLS(layer, tex.type === "live", 1, tex.amount, 1, tex.speed);
        if (big) {
            var gm = hfs__addFx(layer, "ADBE Mosaic", "Texture Cells");
            if (gm) {
                hfs__num(hfs__byName(gm, ["Horizontal Blocks"], 1), Math.max(2, Math.round(comp.width / px)), "glitter mosaic h");
                hfs__num(hfs__byName(gm, ["Vertical Blocks"], 2), Math.max(2, Math.round(comp.height / px)), "glitter mosaic v");
                hfs__set(hfs__byName(gm, ["Sharp Colors"], 3), true, "glitter mosaic sharp");
            }
        }
    } else if (tex.type === "flakes") {
        hfs__addNoiseHLS(layer, false, 1, tex.amount, 1, 0);
        var m = hfs__addFx(layer, "ADBE Mosaic", "Texture Flakes");
        if (m) {
            hfs__num(hfs__byName(m, ["Horizontal Blocks"], 1), Math.max(2, Math.round(comp.width / px)), "mosaic h");
            hfs__num(hfs__byName(m, ["Vertical Blocks"], 2), Math.max(2, Math.round(comp.height / px)), "mosaic v");
            hfs__set(hfs__byName(m, ["Sharp Colors"], 3), true, "mosaic sharp");
        }
    } else if (tex.type === "brushed") {
        // Short streaks (8% of the font size, 4..16 px): a long blur averages the noise away and
        // leaves only a soft smear. Blurring over L px weakens noise ~sqrt(L) times, so boost it.
        var bl = Math.max(4, Math.min(16, (E(1) / (mult || 1)) * 0.08 * k));
        hfs__addNoiseHLS(layer, false, 1, Math.min(100, tex.amount * Math.sqrt(bl) * 0.75), 1, 0);
        var b = hfs__addFx(layer, "ADBE Motion Blur", "Texture Brushed");
        if (b) {
            hfs__num(hfs__byName(b, ["Direction"], 1), 90, "brushed direction");
            hfs__num(hfs__byName(b, ["Blur Length"], 2), bl, "brushed length");
        }
    }
}

// ---------------- gloss (CC Light Sweep) ----------------
// Sweeps: position along the text width (0..1), width (em), intensity, sharp edges or not.
var HFS_GLOSS = {
    streaks: { angle: 30, sweeps: [[0.17, 0.16, 55, true], [0.44, 0.05, 65, true], [0.52, 0.025, 50, true], [0.78, 0.22, 40, true]] },
    soft:    { angle: 30, sweeps: [[0.35, 0.4, 40, false]] },
    stripes: { angle: 30, auto: true }   // candy stripes, count follows the text width
};
function hfs__glossFor(st, opts) {
    var o = opts.gloss;
    if (o === "none") return null;
    if (!o || o === "style") return st.gloss ? (HFS_GLOSS[st.gloss.type] ? { type: st.gloss.type, color: st.gloss.color } : null) : null;
    return HFS_GLOSS[o] ? { type: o } : null;
}
function hfs__addGloss(layer, g, E, faceHex) {
    var def = HFS_GLOSS[g.type], t = layer.containingComp.time;
    var r = layer.sourceRectAtTime(t, false), tr = layer.property("ADBE Transform Group");
    var pos = tr.property("ADBE Position").valueAtTime(t, false), anc = tr.property("ADBE Anchor Point").valueAtTime(t, false);
    var sc = tr.property("ADBE Scale").valueAtTime(t, false), k = Math.abs(sc[0]) / 100 || 1;
    // light colour: given, or the face colour pushed towards white
    var lc = g.color ? hfs__rgba(g.color) : (function () { var c = hfs__rgb(faceHex); return [c[0] + (1 - c[0]) * 0.45, c[1] + (1 - c[1]) * 0.45, c[2] + (1 - c[2]) * 0.45, 1]; })();
    var sweeps = def.sweeps;
    if (def.auto) {
        var sn = Math.max(3, Math.min(14, Math.round(r.width / (E(1) * 0.32))));
        sweeps = [];
        for (var si = 0; si < sn; si++) sweeps.push([(si + 0.5) / sn, 0.09, 100, true]);
    }
    for (var i = 0; i < sweeps.length; i++) {
        var sw = sweeps[i];
        var e = hfs__addFx(layer, "CC Light Sweep", "Gloss " + (i + 1));
        if (!e) { hfs__warn("CC Light Sweep unavailable"); return; }
        var cx = r.left + r.width * sw[0], cy = r.top + r.height / 2;
        var pc = hfs__byName(e, ["Center"], 1);
        hfs__set(pc, [pos[0] + (cx - anc[0]) * sc[0] / 100, pos[1] + (cy - anc[1]) * sc[1] / 100], "gloss center");
        try {
            pc.expression = "var r=thisLayer.sourceRectAtTime(time,false);thisLayer.toComp([r.left+r.width*" + sw[0] + ",r.top+r.height/2])";
            pc.valueAtTime(t, false);
            if (pc.expressionError) pc.expression = "";
        } catch (e1) { try { pc.expression = ""; } catch (e2) {} }
        hfs__num(hfs__byName(e, ["Direction"], 2), def.angle, "gloss direction");
        if (sw[3]) hfs__set(hfs__byName(e, ["Shape"], 3), 3, "gloss shape");   // 1 Linear, 2 Smooth, 3 Sharp
        hfs__num(hfs__byName(e, ["Width"], 4), Math.max(1, E(sw[1]) * k), "gloss width");
        hfs__num(hfs__byName(e, ["Sweep Intensity"], 5), sw[2], "gloss intensity");
        hfs__num(hfs__byName(e, ["Edge Intensity"], 6), 0, "gloss edge intensity");
        hfs__set(hfs__byName(e, ["Light Color"], 8), lc, "gloss color");
    }
}

// ---------------- glossy rim / chrome horizon helpers ----------------
var HFS_RIM_PRESETS = { gold: { w: 0.04, hi: "#fff6b8", mid: "#f0b429", lo: "#6b3d00" }, silver: { w: 0.04, hi: "#ffffff", mid: "#aab4c0", lo: "#39424d" } };
var HFS_RIM_DIRS = [315, 135, 0, 270, 90, 180, 45, 225];
function hfs__rimFor(st, opts) {
    var o = opts.rim;
    if (o === "none") return null;
    if (!o || o === "style") return st.rim || null;
    return HFS_RIM_PRESETS[o] || null;
}
function hfs__rimColor(rim, dir, invert) {
    var t = (Math.cos((dir - 315) * Math.PI / 180) + 1) / 2;
    if (invert) t = 1 - t;
    return t < 0.5 ? hfs__lerpHex(rim.lo, rim.mid, t * 2) : hfs__lerpHex(rim.mid, rim.hi, (t - 0.5) * 2);
}
function hfs__multiStop(stops, f) {
    var n = stops.length - 1, q = Math.max(0, Math.min(1, f)) * n, k = Math.min(n - 1, Math.floor(q));
    return hfs__lerpHex(stops[k], stops[k + 1], q - k);
}
function hfs__horizonPoints(layer, ramp, hz) {
    var t = layer.containingComp.time, r = layer.sourceRectAtTime(t, false), tr = layer.property("ADBE Transform Group");
    var pos = tr.property("ADBE Position").valueAtTime(t, false), anc = tr.property("ADBE Anchor Point").valueAtTime(t, false);
    var sc = tr.property("ADBE Scale").valueAtTime(t, false);
    var cx = r.left + r.width / 2, y = r.top + r.height * hz;
    function toC(x, yy) { return [pos[0] + (x - anc[0]) * sc[0] / 100, pos[1] + (yy - anc[1]) * sc[1] / 100]; }
    var ps = [[hfs__fxProp(ramp, "ADBE Ramp-0001", 1), -0.5], [hfs__fxProp(ramp, "ADBE Ramp-0003", 3), 0.5]];
    for (var i = 0; i < 2; i++) {
        var p = ps[i][0];
        hfs__set(p, toC(cx, y + ps[i][1]), "horizon point");
        try {
            p.expression = "var r=thisLayer.sourceRectAtTime(time,false);thisLayer.toComp([r.left+r.width/2,r.top+r.height*" + hz + "+(" + ps[i][1] + ")])";
            p.valueAtTime(t, false);
            if (p.expressionError) p.expression = "";
        } catch (e) { try { p.expression = ""; } catch (e2) {} }
    }
}

// ---------------- layer styles ----------------
function hfs__lsRoot(layer) { return layer.property("ADBE Layer Styles"); }

function hfs__lsFind(layer, key) {
    var g = null;
    try { g = hfs__lsRoot(layer).property(key + "/enabled"); } catch (e) {}
    return g;
}

// All 9 layer-style groups always exist on a layer (hidden until added), so "found" does not
// mean "added": success is checked by the group's enabled state.
function hfs__lsOn(layer, key) {
    var g = hfs__lsFind(layer, key);
    if (!g) return null;
    try { g.enabled = true; } catch (e) {}
    var on = false;
    try { on = g.enabled === true; } catch (e2) {}
    return on ? g : null;
}

function hfs__lsAdd(layer, key) {
    var cmd = HFS_LS[key], g, before, fx;
    // 1) already added earlier (e.g. re-applying a style)
    g = hfs__lsOn(layer, key);
    if (g) return g;
    // 2) known command id (verified in AE 26: 9000-9008 = Layer > Layer Styles > ...)
    // Layer-menu commands only work while the comp viewer / timeline has focus, not a floating panel.
    try { layer.containingComp.openInViewer(); } catch (ef1) {}
    try { if (app.activeViewer) app.activeViewer.setActive(); } catch (ef2) {}
    hfs__selectOnly(layer);
    before = hfs__fx(layer).numProperties;
    try { app.executeCommand(cmd[0]); } catch (e1) {}
    fx = hfs__fx(layer);
    while (fx.numProperties > before) fx.property(fx.numProperties).remove();
    g = hfs__lsOn(layer, key);
    if (g) return g;
    // 3) fallback: menu name (English UI). "Drop Shadow"/"Stroke" can resolve to the effects
    //    of the same name — those are removed again.
    var id = 0;
    try { id = app.findMenuCommandId(cmd[1]); } catch (e2) {}
    if (id && id !== cmd[0]) {
        hfs__selectOnly(layer);
        before = hfs__fx(layer).numProperties;
        try { app.executeCommand(id); } catch (e3) {}
        fx = hfs__fx(layer);
        while (fx.numProperties > before) fx.property(fx.numProperties).remove();
        g = hfs__lsOn(layer, key);
        if (g) return g;
    }
    HFS_LSFAIL[key] = true;
    hfs__warn("note: layer style " + cmd[1] + " unavailable, built from effects instead");
    return null;
}

function hfs__lsP(g, key, sub) {
    var p = null;
    try { p = g.property(key + "/" + sub); } catch (e) {}
    if (!p) {
        for (var i = 1; i <= g.numProperties; i++) {
            var c = g.property(i);
            if (c.matchName && c.matchName.indexOf("/" + sub) > 0) { p = c; break; }
        }
    }
    return p;
}

function hfs__lsDisableAll(layer, except) {
    for (var i = 0; i < HFS_LS_KEYS.length; i++) {
        var k = HFS_LS_KEYS[i];
        if (except && except[k]) continue;
        var g = hfs__lsFind(layer, k);
        if (g) { try { g.enabled = false; } catch (e) {} }
    }
}

// ---------------- apply ----------------
function hfs__applyToLayer(layer, st, opts) {
    var mult = opts.mult || 1;
    var em = hfs__baseFontSize(layer) * mult;
    // Effects on a text layer work in COMPOSITION pixels and do not scale with the layer, while the
    // glyphs, the text stroke and layer styles do. So effect sizes are multiplied by the layer scale.
    var lk = 1;
    try { lk = Math.abs(layer.property("ADBE Transform Group").property("ADBE Scale").valueAtTime(layer.containingComp.time, false)[0]) / 100 || 1; } catch (ek) {}
    var ELS = function (v) { return v * em; };          // layer units: text stroke, layer styles
    var E = function (v) { return v * em * lk; };       // comp units: every effect
    var face = st.face || { fill: "#ffffff" };
    var solid = face.fill || (face.gradient ? face.gradient[0] : "#ffffff");
    var ls = st.ls || {};
    var i;

    // 1. text fill / text stroke / font
    hfs__editTD(layer, function (td) {
        if (opts.applyFont && st.font && st.font.ps) {
            try { td.font = st.font.ps; } catch (e) { hfs__warn("font " + st.font.ps); }
        }
        if (st.hollow) { td.applyFill = false; }
        else { td.applyFill = true; td.fillColor = hfs__rgb(solid); }
        if (st.tstroke) {
            td.applyStroke = true;
            td.strokeColor = hfs__rgb(st.tstroke.color);
            td.strokeWidth = Math.max(0.1, 2 * ELS(st.tstroke.w));
            td.strokeOverFill = false;
            try { td.lineJoinType = LineJoinType.LINE_JOIN_ROUND; } catch (e2) {}
        } else {
            td.applyStroke = false;
        }
    });

    // 2. effects
    hfs__removeTagged(layer);

    if (face.gradient) {
        var ang = (face.angle === undefined || face.angle === null) ? 90 : face.angle;
        var multi = face.gradient.length > 2;
        var ramp = hfs__addFx(layer, "ADBE Ramp", "Gradient");
        if (ramp) {
            // multi-stop: a white -> black brightness ramp that CC Toner then colourises
            hfs__set(hfs__fxProp(ramp, "ADBE Ramp-0002", 2), multi ? [1, 1, 1, 1] : hfs__rgba(face.gradient[0]), "ramp start color");
            hfs__set(hfs__fxProp(ramp, "ADBE Ramp-0004", 4), multi ? [0, 0, 0, 1] : hfs__rgba(face.gradient[1]), "ramp end color");
            hfs__set(hfs__fxProp(ramp, "ADBE Ramp-0005", 5), 1, "ramp shape");
            hfs__rampPoints(layer, ramp, ang);
        }
        if (multi && face.horizon && face.gradient.length === 4) {
            // chrome horizon: a 1px step ramp blended 50% over the linear one makes luminance jump
            // from 0.75 to 0.25 at the horizon, so CC Toner switches colour with a hard edge there
            var hr = hfs__addFx(layer, "ADBE Ramp", "Gradient Horizon");
            if (hr) {
                hfs__set(hfs__fxProp(hr, "ADBE Ramp-0002", 2), [1, 1, 1, 1], "horizon start color");
                hfs__set(hfs__fxProp(hr, "ADBE Ramp-0004", 4), [0, 0, 0, 1], "horizon end color");
                hfs__set(hfs__fxProp(hr, "ADBE Ramp-0005", 5), 1, "horizon shape");
                hfs__pct(hfs__fxProp(hr, "ADBE Ramp-0007", 7), 50, "horizon blend");
                hfs__horizonPoints(layer, hr, face.horizon);
            }
            var G4 = face.gradient;
            hfs__addToner(layer, [hfs__rgba(G4[0]), hfs__rgba(G4[1]), hfs__lerpHex(G4[1], G4[2], 0.5), hfs__rgba(G4[2]), hfs__rgba(G4[3])]);
        } else if (multi) hfs__addToner(layer, hfs__resample5(face.gradient));
    }

    // face texture (glitter / flakes / brushed), confined to the letters by the Set Matte below
    var tex = hfs__textureFor(st, opts);
    if (tex && !face.gradient) {
        // Flat-colour face: give the texture an opaque full-frame backing first. Without it the
        // blur / mosaic inside the texture pulls transparency in from outside the letters
        // (smeared, ghosted edges); Set Matte below cuts everything back to the glyphs.
        var backHex = (st.hollow && st.tstroke) ? st.tstroke.color : solid;
        var back = hfs__addFx(layer, "ADBE Ramp", "Texture Base");
        if (back) {
            hfs__set(hfs__fxProp(back, "ADBE Ramp-0002", 2), hfs__rgba(backHex), "texture base color 1");
            hfs__set(hfs__fxProp(back, "ADBE Ramp-0004", 4), hfs__rgba(backHex), "texture base color 2");
        }
    }
    if (tex) hfs__addTexture(layer, tex, ELS, mult);

    if (face.gradient || tex) {
        var matte = hfs__addFx(layer, "ADBE Set Matte3", "Gradient Matte");
        if (matte) {
            hfs__set(hfs__fxProp(matte, "ADBE Set Matte3-0001", 1), layer.index, "set matte layer");
            hfs__set(hfs__fxProp(matte, "ADBE Set Matte3-0002", 2), 4, "set matte channel"); // Alpha
        }
    }

    var gloss = hfs__glossFor(st, opts);
    if (gloss) hfs__addGloss(layer, gloss, ELS, face.gradient ? face.gradient[Math.floor(face.gradient.length / 2)] : solid);

    if (st.bevelFx) {
        var bev = hfs__addFx(layer, "ADBE Bevel Alpha", "Bevel");
        if (bev) {
            hfs__num(hfs__fxProp(bev, "ADBE Bevel Alpha-0001", 1), E(st.bevelFx.t), "bevel thickness");
            hfs__num(hfs__fxProp(bev, "ADBE Bevel Alpha-0002", 2), st.bevelFx.light, "bevel angle");
            hfs__num(hfs__fxProp(bev, "ADBE Bevel Alpha-0004", 4), st.bevelFx.intensity, "bevel intensity");
        }
    }

    if (ls.innerShadow) {
        // Pressed-in look without the Inner Shadow layer style: Bevel Alpha lit from the side the
        // shadow falls to, so the opposite inner edges go dark and the near ones catch light.
        var isd = ls.innerShadow;
        var ib = hfs__addFx(layer, "ADBE Bevel Alpha", "Inner Shadow");
        if (ib) {
            hfs__num(hfs__fxProp(ib, "ADBE Bevel Alpha-0001", 1), Math.max(1, E(isd.dist + isd.size * 0.5)), "inner shadow thickness");
            hfs__num(hfs__fxProp(ib, "ADBE Bevel Alpha-0002", 2), isd.dir, "inner shadow angle");
            hfs__set(hfs__fxProp(ib, "ADBE Bevel Alpha-0003", 3), [1, 1, 1, 1], "inner shadow light color");
            hfs__num(hfs__fxProp(ib, "ADBE Bevel Alpha-0004", 4), Math.min(1, isd.opacity / 100 * 0.75), "inner shadow intensity");
        }
    }

    // rim: one definition or a list (outline after outline, inner first)
    var rimSrc = hfs__rimFor(st, opts), rimList = rimSrc ? (rimSrc instanceof Array ? rimSrc : [rimSrc]) : [];
    var rn = 0;
    for (var rl = 0; rl < rimList.length; rl++) {
        var rim = rimList[rl];
        // thick flat outline: two half-width rings, the second turned 22.5 deg -> 16-sided, no notches
        var rings = (rim.flat && rim.w > 0.05 && !opts.lite) ? [{ w: rim.w * 0.5, invert: false, rot: 0 }, { w: rim.w * 0.5, invert: false, rot: 22.5 }]
            : ((opts.lite || rim.flat) ? [{ w: rim.w, invert: false }] : [{ w: rim.w * 0.45, invert: true }, { w: rim.w * 0.55, invert: false }]);
        for (var ri = 0; ri < rings.length; ri++) {
            for (var di = 0; di < HFS_RIM_DIRS.length; di++) {
                rn++;
                hfs__addDropShadowFx(layer, "Rim " + rn, hfs__rimColor(rim, HFS_RIM_DIRS[di], rings[ri].invert), 100, HFS_RIM_DIRS[di] + (rings[ri].rot || 0), Math.max(0.5, E(rings[ri].w)), 0);
            }
        }
    }

    if (st.extrude) {
        var ex = st.extrude, depth = E(ex.depth);
        // lite mode: coarser steps -> far fewer Drop Shadow effects
        var N = opts.lite ? Math.max(2, Math.min(12, Math.ceil(depth / 3.5))) : Math.max(3, Math.min(40, Math.ceil(depth / 1.5)));
        var step = depth / N;
        for (i = 1; i <= N; i++) {
            var col = hfs__multiStop(ex.stops || [ex.near, ex.far], N > 1 ? (i - 1) / (N - 1) : 0);
            hfs__addDropShadowFx(layer, "Extrude " + i, col, 100, ex.dir, step, 0);
        }
    }

    if (st.hard) {
        for (i = 0; i < st.hard.length; i++) {
            var h = st.hard[i];
            hfs__addDropShadowFx(layer, "Shadow " + (i + 1), hfs__rgba(h.color),
                (h.opacity === undefined ? 100 : h.opacity), h.dir, E(h.dist), E(h.soft || 0));
        }
    }

    // post stack: more outlines / extrusions around everything built so far (applied in order)
    if (st.post) {
        var pn = 0;
        for (var pi = 0; pi < st.post.length; pi++) {
            var it = st.post[pi], q;
            if (it.depth) {
                var pdepth = E(it.depth);
                var PN = opts.lite ? Math.max(2, Math.min(12, Math.ceil(pdepth / 3.5))) : Math.max(3, Math.min(40, Math.ceil(pdepth / 1.5)));
                for (q = 1; q <= PN; q++) {
                    pn++;
                    hfs__addDropShadowFx(layer, "Post " + pn, hfs__multiStop(it.stops || [it.near, it.far], PN > 1 ? (q - 1) / (PN - 1) : 0), 100, it.dir, pdepth / PN, 0);
                }
            } else {
                var prs = (it.flat && it.w > 0.05 && !opts.lite) ? [{ w: it.w * 0.5, invert: false, rot: 0 }, { w: it.w * 0.5, invert: false, rot: 22.5 }]
                    : ((opts.lite || it.flat) ? [{ w: it.w, invert: false }] : [{ w: it.w * 0.45, invert: true }, { w: it.w * 0.55, invert: false }]);
                for (var pr = 0; pr < prs.length; pr++) {
                    for (q = 0; q < HFS_RIM_DIRS.length; q++) {
                        pn++;
                        hfs__addDropShadowFx(layer, "Post " + pn, hfs__rimColor(it, HFS_RIM_DIRS[q], prs[pr].invert), 100, HFS_RIM_DIRS[q] + (prs[pr].rot || 0), Math.max(0.5, E(prs[pr].w)), 0);
                    }
                }
            }
        }
    }

    // 3. layer styles
    HFS_LSFAIL = {};
    var used = {};
    if (ls.shadow) used.dropShadow = true;
    if (ls.glow) used.outerGlow = true;
    if (ls.innerGlow) used.innerGlow = true;
    if (ls.bevel) used.bevelEmboss = true;
    if (ls.stroke) used.frameFX = true;
    hfs__lsDisableAll(layer, used);

    var g, K;
    if (ls.shadow) {
        K = "dropShadow"; g = hfs__lsAdd(layer, K);
        if (g) {
            hfs__set(hfs__lsP(g, K, "color"), hfs__rgba(ls.shadow.color), "shadow color");
            hfs__pct(hfs__lsP(g, K, "opacity"), ls.shadow.opacity, "shadow opacity");
            hfs__set(hfs__lsP(g, K, "useGlobalAngle"), false, "shadow global");
            hfs__num(hfs__lsP(g, K, "localLightingAngle"), hfs__psFromShadow(ls.shadow.dir), "shadow angle");
            hfs__num(hfs__lsP(g, K, "distance"), ELS(ls.shadow.dist), "shadow distance");
            hfs__num(hfs__lsP(g, K, "chokeMatte"), ls.shadow.spread || 0, "shadow spread");
            hfs__num(hfs__lsP(g, K, "blur"), ELS(ls.shadow.size), "shadow size");
        }
    }
    if (ls.glow) {
        K = "outerGlow"; g = hfs__lsAdd(layer, K);
        if (g) {
            hfs__set(hfs__lsP(g, K, "AEColorChoice"), 1, "glow color type");
            hfs__set(hfs__lsP(g, K, "color"), hfs__rgba(ls.glow.color), "glow color");
            hfs__pct(hfs__lsP(g, K, "opacity"), ls.glow.opacity, "glow opacity");
            hfs__num(hfs__lsP(g, K, "chokeMatte"), ls.glow.spread || 0, "glow spread");
            hfs__num(hfs__lsP(g, K, "blur"), ELS(ls.glow.size), "glow size");
        }
    }
    if (ls.innerGlow) {
        K = "innerGlow"; g = hfs__lsAdd(layer, K);
        if (g) {
            hfs__set(hfs__lsP(g, K, "AEColorChoice"), 1, "inner glow color type");
            hfs__set(hfs__lsP(g, K, "color"), hfs__rgba(ls.innerGlow.color), "inner glow color");
            hfs__pct(hfs__lsP(g, K, "opacity"), ls.innerGlow.opacity, "inner glow opacity");
            hfs__num(hfs__lsP(g, K, "chokeMatte"), ls.innerGlow.choke || 0, "inner glow choke");
            hfs__num(hfs__lsP(g, K, "blur"), ELS(ls.innerGlow.size), "inner glow size");
            hfs__set(hfs__lsP(g, K, "innerGlowSource"), 1, "inner glow source"); // 1 = Edge in AE (2 = Center)
        }
    }
    if (false && ls.innerShadow) { // replaced by the Bevel Alpha emulation above (the layer style would not add)
        K = "innerShadow"; g = hfs__lsAdd(layer, K);
        if (g) {
            hfs__set(hfs__lsP(g, K, "color"), hfs__rgba(ls.innerShadow.color), "inner shadow color");
            hfs__pct(hfs__lsP(g, K, "opacity"), ls.innerShadow.opacity, "inner shadow opacity");
            hfs__set(hfs__lsP(g, K, "useGlobalAngle"), false, "inner shadow global");
            hfs__num(hfs__lsP(g, K, "localLightingAngle"), hfs__psFromShadow(ls.innerShadow.dir), "inner shadow angle");
            hfs__num(hfs__lsP(g, K, "distance"), ELS(ls.innerShadow.dist), "inner shadow distance");
            hfs__num(hfs__lsP(g, K, "chokeMatte"), 0, "inner shadow choke");
            hfs__num(hfs__lsP(g, K, "blur"), ELS(ls.innerShadow.size), "inner shadow size");
        }
    }
    if (ls.bevel) {
        K = "bevelEmboss"; g = hfs__lsAdd(layer, K);
        if (g) {
            var b = ls.bevel;
            hfs__set(hfs__lsP(g, K, "bevelStyle"), 2, "bevel style");                      // Inner Bevel
            hfs__set(hfs__lsP(g, K, "bevelTechnique"), b.chisel ? 2 : 1, "bevel technique"); // Chisel Hard / Smooth
            hfs__num(hfs__lsP(g, K, "strengthRatio"), b.depth || 100, "bevel depth");
            hfs__set(hfs__lsP(g, K, "bevelDirection"), 1, "bevel direction");             // Up
            hfs__num(hfs__lsP(g, K, "blur"), ELS(b.size), "bevel size");
            hfs__num(hfs__lsP(g, K, "softness"), 0, "bevel softness");
            hfs__set(hfs__lsP(g, K, "useGlobalAngle"), false, "bevel global");
            hfs__num(hfs__lsP(g, K, "localLightingAngle"), hfs__psFromLight(b.light), "bevel angle");
            hfs__num(hfs__lsP(g, K, "localLightingAltitude"), 30, "bevel altitude");
            hfs__set(hfs__lsP(g, K, "highlightColor"), [1, 1, 1, 1], "bevel hl color");
            hfs__pct(hfs__lsP(g, K, "highlightOpacity"), b.hlOp, "bevel hl opacity");
            hfs__set(hfs__lsP(g, K, "shadowColor"), [0, 0, 0, 1], "bevel sh color");
            hfs__pct(hfs__lsP(g, K, "shadowOpacity"), b.shOp, "bevel sh opacity");
        }
    }
    if (ls.stroke) {
        K = "frameFX"; g = hfs__lsAdd(layer, K);
        if (g) {
            hfs__set(hfs__lsP(g, K, "color"), hfs__rgba(ls.stroke.color), "stroke color");
            hfs__num(hfs__lsP(g, K, "size"), Math.max(1, ELS(ls.stroke.w)), "stroke size");
            hfs__pct(hfs__lsP(g, K, "opacity"), ls.stroke.opacity === undefined ? 100 : ls.stroke.opacity, "stroke opacity");
            hfs__set(hfs__lsP(g, K, "style"), 1, "stroke position");                       // Outside
        }
    }

    // Effect fallbacks for layer styles that could not be added. Order matters: every Drop Shadow
    // goes behind what is already there, so: bevel, stroke ring, glow, soft shadow.
    var fi;
    if (HFS_LSFAIL.bevelEmboss && ls.bevel) {
        var fb = hfs__addFx(layer, "ADBE Bevel Alpha", "LS Bevel");
        if (fb) {
            hfs__num(hfs__fxProp(fb, "ADBE Bevel Alpha-0001", 1), Math.max(1, E(ls.bevel.size)), "fb bevel thickness");
            hfs__num(hfs__fxProp(fb, "ADBE Bevel Alpha-0002", 2), ls.bevel.light, "fb bevel angle");
            hfs__num(hfs__fxProp(fb, "ADBE Bevel Alpha-0004", 4), Math.min(1, ls.bevel.hlOp / 100 * 0.7), "fb bevel intensity");
        }
    }
    if (HFS_LSFAIL.frameFX && ls.stroke) {
        var sdirs = [0, 45, 90, 135, 180, 225, 270, 315];
        for (fi = 0; fi < sdirs.length; fi++) {
            hfs__addDropShadowFx(layer, "LS Stroke " + (fi + 1), hfs__rgba(ls.stroke.color),
                ls.stroke.opacity === undefined ? 100 : ls.stroke.opacity, sdirs[fi], Math.max(1, E(ls.stroke.w)), 0);
        }
    }
    if (HFS_LSFAIL.outerGlow && ls.glow) {
        for (fi = 0; fi < 2; fi++) {
            hfs__addDropShadowFx(layer, "LS Glow " + (fi + 1), hfs__rgba(ls.glow.color), ls.glow.opacity, 0, 0, Math.max(2, E(ls.glow.size) * 1.6));
        }
    }
    if (HFS_LSFAIL.dropShadow && ls.shadow) {
        hfs__addDropShadowFx(layer, "LS Shadow", hfs__rgba(ls.shadow.color), ls.shadow.opacity, ls.shadow.dir,
            E(ls.shadow.dist), ls.shadow.spread >= 100 ? 0 : E(ls.shadow.size) * 1.4);
    }

    try { layer.comment = "HFS:" + st.id; } catch (e5) {}
    HFS_FXCOUNT = hfs__fx(layer).numProperties;
}

function hfs__textLayersInSelection() {
    var comp = app.project.activeItem;
    if (!(comp instanceof CompItem)) return null;
    var sel = comp.selectedLayers, out = [];
    for (var i = 0; i < sel.length; i++) if (hfs__isText(sel[i])) out.push(sel[i]);
    return out;
}

function hfs__result(prefix, n) {
    var w = HFS_WARN.length ? encodeURIComponent(HFS_WARN.join("; ")) : "";
    return prefix + "|" + n + "|" + w; // (+ "|" + effect count is appended by hfs_apply)
}

// ---------------- public API (called from the panel) ----------------
function hfs_apply(st, opts) {
    HFS_WARN = [];
    var comp = app.project.activeItem;
    if (!(comp instanceof CompItem)) return "err|nocomp|";
    var layers = hfs__textLayersInSelection();
    if (!layers.length) return "err|notext|";
    var allSel = comp.selectedLayers, i;
    app.beginUndoGroup("HF Text Style");
    try {
        for (i = 0; i < layers.length; i++) hfs__applyToLayer(layers[i], st, opts || {});
    } catch (e) {
        hfs__warn("fatal: " + e.message + " (line " + e.line + ")");
    }
    // restore selection
    try {
        var cur = comp.selectedLayers;
        for (i = 0; i < cur.length; i++) cur[i].selected = false;
        for (i = 0; i < allSel.length; i++) allSel[i].selected = true;
    } catch (e2) {}
    app.endUndoGroup();
    return hfs__result("ok", layers.length) + "|" + HFS_FXCOUNT;
}

function hfs_clear() {
    HFS_WARN = [];
    var layers = hfs__textLayersInSelection();
    if (layers === null) return "err|nocomp|";
    if (!layers.length) return "err|notext|";
    app.beginUndoGroup("HF Text Style: clear");
    for (var i = 0; i < layers.length; i++) {
        hfs__removeTagged(layers[i]);
        hfs__lsDisableAll(layers[i], null);
        hfs__editTD(layers[i], function (td) { td.applyStroke = false; td.applyFill = true; });
    }
    app.endUndoGroup();
    return hfs__result("ok", layers.length);
}

function hfs_selection() {
    var layers = hfs__textLayersInSelection();
    if (layers === null) return "nocomp";
    return String(layers.length);
}

// ---- AE-rendered previews ----
function hfs__prevDir() {
    var root = new Folder(Folder.userData.fsName + "/HF Text Styles");
    if (!root.exists) root.create();
    var d = new Folder(root.fsName + "/previews");
    if (!d.exists) d.create();
    return d;
}

function hfs_listPreviews() {
    var d = hfs__prevDir(), files = d.getFiles("*.png"), names = [];
    for (var i = 0; i < files.length; i++) names.push(files[i].name);
    return encodeURIComponent(d.fsName) + "|" + names.join("/");
}

function hfs_previewBegin(sample) {
    HFS_WARN = [];
    var user = (app.project.activeItem instanceof CompItem) ? app.project.activeItem : null;
    var c = app.project.items.addComp("HFS preview (temp)", 900, 375, 1, 1, 30);
    c.bgColor = [0.16, 0.16, 0.16];
    try { c.resolutionFactor = [1, 1]; } catch (e) {}
    var t = c.layers.addText(sample || "HYPER");
    HFS_PREV = { comp: c, layer: t, user: user };
    c.openInViewer();
    return "ok";
}

function hfs_previewOne(st, fileName) {
    HFS_WARN = [];
    if (!HFS_PREV) return "err|nosession|";
    var L = HFS_PREV.layer;
    hfs__editTD(L, function (td) {
        td.fontSize = 140;
        try { td.font = (st.font && st.font.ps) ? st.font.ps : "Arial-Black"; } catch (e) {}
        try { td.justification = ParagraphJustification.CENTER_JUSTIFY; } catch (e2) {}
    });
    hfs__applyToLayer(L, st, { mult: 1, applyFont: true });
    var r = L.sourceRectAtTime(0, false);
    var ext = (st.extent || 0) * 140 * 2;
    var s = Math.min(1, 800 / (r.width + ext), 310 / (r.height + ext));
    L.property("ADBE Transform Group").property("ADBE Anchor Point").setValue([r.left + r.width / 2, r.top + r.height / 2]);
    L.property("ADBE Transform Group").property("ADBE Position").setValue([450, 187.5]);
    L.property("ADBE Transform Group").property("ADBE Scale").setValue([s * 100, s * 100]);
    var f = new File(hfs__prevDir().fsName + "/" + fileName);
    if (f.exists) f.remove();
    HFS_PREV.comp.saveFrameToPng(0, f);
    return hfs__result("ok", 1);
}

function hfs_fileReady(fileName) {
    var f = new File(hfs__prevDir().fsName + "/" + fileName);
    return (f.exists && f.length > 0) ? "1" : "0";
}

function hfs_previewEnd() {
    if (!HFS_PREV) return "ok";
    try { HFS_PREV.comp.remove(); } catch (e) {}
    try { if (HFS_PREV.user) HFS_PREV.user.openInViewer(); } catch (e2) {}
    HFS_PREV = null;
    return "ok";
}

// ---- diagnostics: what is actually on the first selected text layer ----
function hfs__val(p, t) {
    try {
        var v = p.valueAtTime(t, false);
        if (v instanceof Array) { var o = []; for (var i = 0; i < v.length; i++) o.push(Math.round(v[i] * 1000) / 1000); return "[" + o.join(", ") + "]"; }
        return String(v);
    } catch (e) { return "?"; }
}
function hfs_diag() {
    var out = [];
    out.push("AE " + app.version + " | " + $.os);
    var comp = app.project.activeItem;
    if (!(comp instanceof CompItem)) return encodeURIComponent("no comp");
    var layers = hfs__textLayersInSelection();
    if (!layers.length) return encodeURIComponent("no text layer selected");
    var L = layers[0], t = comp.time;
    out.push("layer: " + L.name + " #" + L.index + " comment=" + L.comment);
    try { var r = L.sourceRectAtTime(t, false); out.push("rect: left " + r.left + " top " + r.top + " w " + r.width + " h " + r.height); } catch (e) { out.push("rect err " + e.message); }
    try {
        var td = hfs__textProp(L).value;
        out.push("text: size " + td.fontSize + " font " + td.font + " fill " + td.applyFill + " stroke " + td.applyStroke);
    } catch (e2) { out.push("td err " + e2.message); }
    var fx = hfs__fx(L);
    out.push("effects: " + fx.numProperties);
    for (var i = 1; i <= fx.numProperties; i++) {
        var e = fx.property(i);
        out.push("  " + i + ". " + e.name + " [" + e.matchName + "] enabled=" + e.enabled);
        if (e.name.indexOf(HFS_TAG + "Gradient") === 0 || e.name.indexOf(HFS_TAG + "Texture") === 0 || e.name.indexOf(HFS_TAG + "Gloss") === 0 || e.matchName === "ADBE Set Matte3" || e.matchName === "CC Toner") {
            for (var k = 1; k <= e.numProperties; k++) {
                var p = e.property(k), line = "      " + p.name + " = " + hfs__val(p, t);
                try { if (p.expression) line += " | expr " + (p.expressionEnabled ? "on" : "off") + (p.expressionError ? " ERR: " + p.expressionError : ""); } catch (e3) {}
                out.push(line);
            }
        }
    }
    var ls = hfs__lsRoot(L), act = [];
    for (var j = 0; j < HFS_LS_KEYS.length; j++) {
        var g = hfs__lsFind(L, HFS_LS_KEYS[j]);
        if (g) { var cs = "?"; try { cs = g.canSetEnabled ? "" : "(hidden)"; } catch (e4) {} act.push(HFS_LS_KEYS[j] + (g.enabled ? "+" : "-") + cs); }
    }
    var ids = [];
    for (var m = 0; m < HFS_LS_KEYS.length; m++) { var c = HFS_LS[HFS_LS_KEYS[m]]; var fid = 0; try { fid = app.findMenuCommandId(c[1]); } catch (e5) {} ids.push(c[1] + "=" + fid); }
    out.push("menu ids: " + ids.join(", "));
    out.push("layer styles: " + act.join(", "));
    return encodeURIComponent(out.join("\n"));
}

// ---- background colour behind the selected text (for the contrast checker) ----
// Samples every visible layer below the text with sampleImage() (via a temporary Color Control
// expression) over the text's area, then composites them bottom -> top (normal blending).
function hfs__hex2(v) { var n = Math.round(Math.max(0, Math.min(1, v)) * 255).toString(16); return n.length < 2 ? "0" + n : n; }

function hfs_sampleBehind() {
    var comp = app.project.activeItem;
    if (!(comp instanceof CompItem)) return "err|nocomp";
    var t = comp.time, sel = comp.selectedLayers, L = null, i;
    for (i = 0; i < sel.length; i++) if (hfs__isText(sel[i])) { L = sel[i]; break; }
    var cx, cy, hw, hh, topIndex;
    if (L) {
        var r = L.sourceRectAtTime(t, false), tr = L.property("ADBE Transform Group");
        var pos = tr.property("ADBE Position").valueAtTime(t, false), anc = tr.property("ADBE Anchor Point").valueAtTime(t, false);
        var sc = tr.property("ADBE Scale").valueAtTime(t, false);
        cx = pos[0] + (r.left + r.width / 2 - anc[0]) * sc[0] / 100;
        cy = pos[1] + (r.top + r.height / 2 - anc[1]) * sc[1] / 100;
        hw = Math.max(2, Math.abs(r.width * sc[0] / 100) * 0.6);
        hh = Math.max(2, Math.abs(r.height * sc[1] / 100) * 0.8);
        topIndex = L.index;
    } else {
        cx = comp.width / 2; cy = comp.height / 2; hw = comp.width / 4; hh = comp.height / 4; topIndex = 0;
    }
    var host = L || (sel.length ? sel[0] : null);
    var tempLayer = null;
    if (!host) { tempLayer = comp.layers.addNull(); host = tempLayer; }
    var col = [comp.bgColor[0], comp.bgColor[1], comp.bgColor[2]], used = 0;
    app.beginUndoGroup("HF sample background");
    var fx = hfs__fx(host);
    var cc = fx.addProperty("ADBE Color Control");
    var ccIdx = cc.propertyIndex;
    try {
        for (i = comp.numLayers; i > topIndex; i--) {
            var l = comp.layer(i);
            if (l === tempLayer || !l.enabled || !l.hasVideo || l.guideLayer || l.adjustmentLayer) continue;
            if (t < l.inPoint || t >= l.outPoint) continue;
            var s = 1; try { var lsc = l.property("ADBE Transform Group").property("ADBE Scale").valueAtTime(t, false); s = Math.abs(lsc[0]) / 100 || 1; } catch (e0) {}
            var p = hfs__fx(host).property(ccIdx).property(1);
            p.expression = "var l=thisComp.layer(" + i + ");var q=l.fromComp([" + cx + "," + cy + "]);" +
                "l.sampleImage(q,[" + (hw / s) + "," + (hh / s) + "],true,time)";
            var v = p.valueAtTime(t, false);
            if (p.expressionError) continue;
            var op = 1; try { op = l.property("ADBE Transform Group").property("ADBE Opacity").valueAtTime(t, false) / 100; } catch (e1) {}
            var a = Math.max(0, Math.min(1, v[3])) * op;
            if (a <= 0.001) continue;
            col = [v[0] * a + col[0] * (1 - a), v[1] * a + col[1] * (1 - a), v[2] * a + col[2] * (1 - a)];
            used++;
        }
    } catch (e) {
        hfs__warn("sample: " + e.message);
    }
    try { hfs__fx(host).property(ccIdx).remove(); } catch (e2) {}
    if (tempLayer) { try { tempLayer.remove(); } catch (e3) {} }
    app.endUndoGroup();
    return "ok|#" + hfs__hex2(col[0]) + hfs__hex2(col[1]) + hfs__hex2(col[2]) + "|" + used + "|" + (L ? "text" : "center");
}

// ---- text shape: italic skew and arc (Text Animators, independent from styles) ----
// Animators change the glyphs themselves, so gradient, Set Matte, extrusion and layer styles
// all follow the slanted / curved letters. Re-running replaces the previous HFS animators.
function hfs__animators(layer) { return layer.property("ADBE Text Properties").property("ADBE Text Animators"); }

function hfs__removeShape(layer) {
    var an = hfs__animators(layer);
    for (var i = an.numProperties; i >= 1; i--) if (an.property(i).name.indexOf(HFS_TAG) === 0) an.property(i).remove();
}

function hfs__findAnimator(layer, name) {
    var an = hfs__animators(layer);
    for (var i = 1; i <= an.numProperties; i++) if (an.property(i).name === HFS_TAG + name) return an.property(i);
    return null;
}

// adds an animator with one property (value) and either a full range selector or an expression selector
function hfs__addAnimator(layer, name, propMatch, value, selectorExpr) {
    var an = hfs__animators(layer);
    var a = an.addProperty("ADBE Text Animator");
    try { a.name = HFS_TAG + name; } catch (e0) {}
    a = hfs__findAnimator(layer, name);
    var pr = a.property("ADBE Text Animator Properties").addProperty(propMatch);
    hfs__set(pr, value, name + " value");
    a = hfs__findAnimator(layer, name);
    if (selectorExpr) {
        var sel = a.property("ADBE Text Selectors").addProperty("ADBE Text Expressible Selector");
        var amt = null;
        try { amt = sel.property("ADBE Text Expressible Amount"); } catch (e1) {}
        if (!amt) { try { amt = sel.property(sel.numProperties); } catch (e2) {} }
        try { amt.expression = selectorExpr; } catch (e3) { hfs__warn(name + " selector expr: " + e3.message); }
    } else {
        a.property("ADBE Text Selectors").addProperty("ADBE Text Selector");
    }
}

function hfs__applyShape(layer, o) {
    hfs__removeShape(layer);
    var t = layer.containingComp.time;
    if (o.skew) {
        // positive UI value = letters lean right
        hfs__addAnimator(layer, "Skew", "ADBE Text Skew", -o.skew, null);
    }
    if (o.arc) {
        var rect = layer.sourceRectAtTime(t, false);
        var W = Math.max(1, rect.width);
        var rad = Math.abs(o.arc) * Math.PI / 180, sgn = o.arc > 0 ? 1 : -1;
        var R = (W / 2) / rad, drop = R * (1 - Math.cos(rad));
        var u = "var u=((textIndex-0.5)/textTotal)*2-1;";
        // rotation: each letter turns to its angle on the arc
        hfs__addAnimator(layer, "Arc Rotate", "ADBE Text Rotation", o.arc, u + "u*100");
        // lift: letters move along the circle (edges down for an arch, up for a smile)
        hfs__addAnimator(layer, "Arc Lift", "ADBE Text Position 3D", [0, sgn * drop, 0],
            u + "var a=" + rad + ";(1-Math.cos(u*a))/(1-Math.cos(a))*100");
    }
}

// o: { skew: degrees or 0, arc: degrees (+ arch, - smile) or 0 }
function hfs_shape(o) {
    HFS_WARN = [];
    var layers = hfs__textLayersInSelection();
    if (layers === null) return "err|nocomp|";
    if (!layers.length) return "err|notext|";
    app.beginUndoGroup("HF Text Shape");
    for (var i = 0; i < layers.length; i++) {
        try { hfs__applyShape(layers[i], o || {}); } catch (e) { hfs__warn("shape: " + e.message + " (line " + e.line + ")"); }
    }
    app.endUndoGroup();
    return hfs__result("ok", layers.length);
}

// ---- frame capture for the Gemini advisor ----
// Saves the current frame of the active comp with the selected text layers hidden, so the image
// shows only the background. The panel waits for the file, then calls hfs_captureEnd() to restore.
var HFS_CAP = null;
function hfs_captureBegin() {
    var comp = app.project.activeItem;
    if (!(comp instanceof CompItem)) return "err|nocomp";
    var t = comp.time, sel = comp.selectedLayers, hidden = [], info = [], i;
    for (i = 0; i < sel.length; i++) {
        if (!hfs__isText(sel[i])) continue;
        var L = sel[i];
        try {
            var r = L.sourceRectAtTime(t, false), tr = L.property("ADBE Transform Group");
            var pos = tr.property("ADBE Position").valueAtTime(t, false), anc = tr.property("ADBE Anchor Point").valueAtTime(t, false);
            var sc = tr.property("ADBE Scale").valueAtTime(t, false);
            var x0 = pos[0] + (r.left - anc[0]) * sc[0] / 100, y0 = pos[1] + (r.top - anc[1]) * sc[1] / 100;
            var x1 = x0 + r.width * sc[0] / 100, y1 = y0 + r.height * sc[1] / 100;
            var txt = ""; try { txt = hfs__textProp(L).value.text; } catch (e0) {}
            info.push(encodeURIComponent(txt) + "," + Math.round(x0) + "," + Math.round(y0) + "," + Math.round(x1) + "," + Math.round(y1));
        } catch (e1) {}
        if (L.enabled) { L.enabled = false; hidden.push(L); }
    }
    var dir = new Folder(Folder.userData.fsName + "/HF Text Styles");
    if (!dir.exists) dir.create();
    var f = new File(dir.fsName + "/gemini_frame.png");
    if (f.exists) f.remove();
    HFS_CAP = { hidden: hidden, file: f };
    comp.saveFrameToPng(t, f);
    return "ok|" + encodeURIComponent(f.fsName) + "|" + comp.width + "x" + comp.height + "|" + info.join(";");
}
function hfs_captureReady() {
    if (!HFS_CAP) return "0";
    return (HFS_CAP.file.exists && HFS_CAP.file.length > 0) ? "1" : "0";
}
function hfs_captureEnd() {
    if (!HFS_CAP) return "ok";
    for (var i = 0; i < HFS_CAP.hidden.length; i++) { try { HFS_CAP.hidden[i].enabled = true; } catch (e) {} }
    HFS_CAP = null;
    return "ok";
}
