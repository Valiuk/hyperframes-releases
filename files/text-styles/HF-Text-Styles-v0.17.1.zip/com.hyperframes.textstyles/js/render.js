/*
 * HF Text Styles — canvas preview renderer.
 * Mirrors the After Effects pipeline from hfs.jsx so the panel can show
 * every style instantly, before any AE-rendered PNG exists.
 */
(function (root) {
  'use strict';

  // Temporary canvases are pooled and shrunk after every render: CEP's Chromium runs out of
  // canvas memory when hundreds of previews each allocate dozens of scratch canvases.
  var POOL = [], LIVE = null;
  function mk(w, h) {
    var c = POOL.pop() || document.createElement('canvas');
    c.width = w; c.height = h; // (re)setting the size clears the canvas and resets its state
    if (LIVE) LIVE.push(c);
    return c;
  }

  function tint(src, color) {
    var c = mk(src.width, src.height), x = c.getContext('2d');
    x.drawImage(src, 0, 0);
    x.globalCompositeOperation = 'source-in';
    x.fillStyle = color;
    x.fillRect(0, 0, c.width, c.height);
    return c;
  }

  // Approximate morphological dilation by stamping the image around rings.
  function dilate(src, r) {
    var c = mk(src.width, src.height), x = c.getContext('2d');
    x.drawImage(src, 0, 0);
    if (r < 0.4) return c;
    var rings = r > 5 ? [r, r * 0.66, r * 0.33] : (r > 2 ? [r, r * 0.5] : [r]);
    rings.forEach(function (rr) {
      var n = Math.min(72, Math.max(12, Math.ceil(2 * Math.PI * rr / 1.6)));
      for (var i = 0; i < n; i++) {
        var a = i / n * Math.PI * 2;
        x.drawImage(src, Math.cos(a) * rr, Math.sin(a) * rr);
      }
    });
    return c;
  }

  function blurred(src, sigma) {
    if (sigma < 0.3) return src;
    var c = mk(src.width, src.height), x = c.getContext('2d');
    x.filter = 'blur(' + sigma.toFixed(2) + 'px)';
    x.drawImage(src, 0, 0);
    return c;
  }

  // AE Drop Shadow convention: degrees clockwise from up.
  function dirVec(deg, d) { var a = deg * Math.PI / 180; return [Math.sin(a) * d, -Math.cos(a) * d]; }

  // Highlight/shadow rims for bevels, painted onto `img` (source-atop).
  function rim(img, d, lightDeg, hiColor, hiOp, shColor, shOp, soft) {
    if (d < 0.3) return;
    var l = dirVec(lightDeg, d), x = img.getContext('2d');
    function band(ox, oy, color, op) {
      if (op <= 0) return;
      var c = mk(img.width, img.height), b = c.getContext('2d');
      b.drawImage(img, 0, 0);
      b.globalCompositeOperation = 'destination-out';
      b.drawImage(img, ox, oy);
      var t = blurred(tint(c, color), soft);
      x.save();
      x.globalCompositeOperation = 'source-atop';
      x.globalAlpha = Math.min(1, op);
      x.drawImage(t, 0, 0);
      x.restore();
    }
    band(-l[0], -l[1], hiColor, hiOp);
    band(l[0], l[1], shColor, shOp);
  }

  // ---- face textures (mirror AE: Noise HLS [+ Mosaic | + Directional Blur], then Set Matte) ----
  var TEX_DEFAULTS = {
    glitter: { amount: 45, size: 0.022 }, live: { amount: 45, size: 0.022 },
    flakes: { amount: 35, size: 0.045 }, brushed: { amount: 30, size: 0.35 }
  };
  function textureFor(st, o) {
    if (o === 'none') return null;
    if (!o || o === 'style') return st.texture || null;
    var d = TEX_DEFAULTS[o]; return d ? { type: o, amount: d.amount, size: d.size } : null;
  }
  function rnd(x, y, s) {
    var h = Math.imul(x, 374761393) + Math.imul(y, 668265263) + Math.imul(s, 982451653);
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
  }
  function applyTexture(F, tex, px, seed) {
    var W = F.width, H = F.height, x = F.getContext('2d');
    var img = x.getImageData(0, 0, W, H), d = img.data;
    var amt = tex.amount / 100 * 255, i, xx, yy, v;
    if (tex.type === 'glitter' || tex.type === 'live') {
      var g = Math.max(1, px);
      for (yy = 0; yy < H; yy++) for (xx = 0; xx < W; xx++) {
        i = (yy * W + xx) * 4; if (!d[i + 3]) continue;
        v = rnd(Math.floor(xx / g), Math.floor(yy / g), seed) - 0.5;
        v = v * Math.abs(v) * 4 * amt; // "grain": most cells subtle, a few bright/dark flecks
        d[i] += v; d[i + 1] += v; d[i + 2] += v;
      }
    } else if (tex.type === 'flakes') {
      var b = Math.max(2, Math.round(px));
      for (var by = 0; by < H; by += b) for (var bx = 0; bx < W; bx += b) {
        var r = 0, gg = 0, bb = 0, n = 0, ex = Math.min(W, bx + b), ey = Math.min(H, by + b);
        for (yy = by; yy < ey; yy++) for (xx = bx; xx < ex; xx++) { i = (yy * W + xx) * 4; if (d[i + 3]) { r += d[i]; gg += d[i + 1]; bb += d[i + 2]; n++; } }
        if (!n) continue;
        v = (rnd(bx, by, seed) - 0.5) * 2 * amt;
        r = r / n + v; gg = gg / n + v; bb = bb / n + v;
        for (yy = by; yy < ey; yy++) for (xx = bx; xx < ex; xx++) { i = (yy * W + xx) * 4; d[i] = r; d[i + 1] = gg; d[i + 2] = bb; }
      }
    } else if (tex.type === 'brushed') {
      var L = Math.max(4, Math.min(16, Math.round(px))), row = new Float32Array(W);
      var gain = Math.min(100 / tex.amount, Math.sqrt(L) * 0.75);
      for (yy = 0; yy < H; yy++) {
        for (xx = 0; xx < W; xx++) row[xx] = (rnd(xx, yy, seed) - 0.5) * 2 * amt;
        var acc = 0, out = new Float32Array(W);
        for (xx = 0; xx < W + L; xx++) { if (xx < W) acc += row[xx]; if (xx - L >= 0) acc -= row[xx - L]; var c = xx - (L >> 1); if (c >= 0 && c < W) out[c] = acc / L * gain; }
        for (xx = 0; xx < W; xx++) { i = (yy * W + xx) * 4; if (d[i + 3]) { d[i] += out[xx]; d[i + 1] += out[xx]; d[i + 2] += out[xx]; } }
      }
    }
    x.putImageData(img, 0, 0);
  }

  function alphaBox(c) {
    var w = c.width, h = c.height, d = c.getContext('2d').getImageData(0, 0, w, h).data;
    var x0 = w, y0 = h, x1 = -1, y1 = -1;
    for (var y = 0; y < h; y++) for (var x = 0; x < w; x++) if (d[(y * w + x) * 4 + 3] > 20) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
    return x1 < 0 ? null : [x0, y0, x1 + 1, y1 + 1];
  }

  // ---- gloss: CC Light Sweep bands (additive, only on existing pixels) ----
  var GLOSS = {
    streaks: { angle: 30, sweeps: [[0.17, 0.16, 55, true], [0.44, 0.05, 65, true], [0.52, 0.025, 50, true], [0.78, 0.22, 40, true]] },
    soft: { angle: 30, sweeps: [[0.35, 0.4, 40, false]] },
    stripes: { angle: 30, auto: true }
  };
  // candy stripes: evenly spaced bands, count follows the text width (one per ~0.32 em)
  function autoSweeps(widthPx, emPx) {
    var n = Math.max(3, Math.min(14, Math.round(widthPx / (emPx * 0.32)))), out = [];
    for (var i = 0; i < n; i++) out.push([(i + 0.5) / n, 0.09, 100, true]);
    return out;
  }
  function glossFor(st, o) {
    if (o === 'none') return null;
    if (!o || o === 'style') return st.gloss && GLOSS[st.gloss.type] ? { type: st.gloss.type, color: st.gloss.color } : null;
    return GLOSS[o] ? { type: o } : null;
  }
  function applyGloss(F, g, box, emPx, lightHex) {
    var def = GLOSS[g.type], W = F.width, H = F.height;
    var a = def.angle * Math.PI / 180, nx = Math.cos(a), ny = Math.sin(a); // band normal (band line tilted by angle from vertical)
    var band = mk(W, H), b = band.getContext('2d');
    (def.auto ? autoSweeps(box[2] - box[0], emPx) : def.sweeps).forEach(function (sw) {
      var cx = box[0] + (box[2] - box[0]) * sw[0], cy = (box[1] + box[3]) / 2, hw = sw[1] * emPx / 2;
      var gr = b.createLinearGradient(cx - nx * hw, cy - ny * hw, cx + nx * hw, cy + ny * hw);
      var op = sw[2] / 100;
      var col = lightHex;
      if (sw[3]) { // sharp
        gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.06, col); gr.addColorStop(0.94, col); gr.addColorStop(1, 'rgba(0,0,0,0)');
      } else {
        gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.5, col); gr.addColorStop(1, 'rgba(0,0,0,0)');
      }
      b.globalAlpha = op; b.fillStyle = gr; b.fillRect(0, 0, W, H);
    });
    b.globalAlpha = 1; b.globalCompositeOperation = 'destination-in'; b.drawImage(F, 0, 0);
    var x = F.getContext('2d'); x.save(); x.globalCompositeOperation = 'lighter'; x.drawImage(band, 0, 0); x.restore();
  }

  function multiStop(stops, f) {
    var n = stops.length - 1, q = Math.max(0, Math.min(1, f)) * n, k = Math.min(n - 1, Math.floor(q));
    return root.HFS_COLOR.mix(stops[k], stops[k + 1], q - k);
  }
  // ---- glossy rim (shared logic with hfs.jsx) ----
  var RIM_PRESETS = { gold: { w: 0.04, hi: '#fff6b8', mid: '#f0b429', lo: '#6b3d00' }, silver: { w: 0.04, hi: '#ffffff', mid: '#aab4c0', lo: '#39424d' } };
  var RIM_DIRS = [315, 135, 0, 270, 90, 180, 45, 225];
  function rimFor(st, o) {
    if (o === 'none') return null;
    if (!o || o === 'style') return st.rim || null;
    return RIM_PRESETS[o] || null;
  }
  function rimRings(rim) { return rim.flat ? (rim.w > 0.05 ? [{ w: rim.w * 0.5, invert: false, rot: 0 }, { w: rim.w * 0.5, invert: false, rot: 22.5 }] : [{ w: rim.w, invert: false }]) : [{ w: rim.w * 0.45, invert: true }, { w: rim.w * 0.55, invert: false }]; }
  function rimColor(rim, dir, invert) {
    var t = (Math.cos((dir - 315) * Math.PI / 180) + 1) / 2; if (invert) t = 1 - t;
    return t < 0.5 ? root.HFS_COLOR.mix(rim.lo, rim.mid, t * 2) : root.HFS_COLOR.mix(rim.mid, rim.hi, (t - 0.5) * 2);
  }

  function lerpColor(a, b, t) { return root.HFS_COLOR.mix(a, b, t); }

  /**
   * renderStyle(canvas, style, text, opts)
   * opts.mult — decoration size multiplier (same as the panel slider)
   */
  function renderStyleInner(canvas, st, text, opts) {
    opts = opts || {};
    var mult = opts.mult || 1;
    var W = canvas.width, H = canvas.height;
    var out = canvas.getContext('2d');
    out.clearRect(0, 0, W, H);
    text = text || 'HYPER';

    var fontCss = (st.font && st.font.css) || '"Arial Black", sans-serif';
    var fontStr = function (px) { return '900 ' + px + 'px ' + fontCss; };

    // --- fit text into the card ---
    var m = mk(4, 4).getContext('2d');
    m.font = fontStr(100);
    var tm = m.measureText(text);
    var w100 = tm.width / 100;
    var asc = (tm.actualBoundingBoxAscent || 72) / 100, desc = (tm.actualBoundingBoxDescent || 2) / 100;
    var ext = (st.extent || 0) * mult;
    // text shape (mirrors hfs__applyShape): skew in degrees, arc = half-angle in degrees
    var skew = opts.skew || 0, arc = opts.arc || 0;
    var arcRad = Math.abs(arc) * Math.PI / 180;
    var dropRel = arcRad > 0.001 ? (w100 / 2) / arcRad * (1 - Math.cos(arcRad)) : 0; // per px of font size
    var skewRel = Math.abs(Math.tan(skew * Math.PI / 180)) * asc;
    var px = Math.min(W * 0.9 / (w100 + skewRel + 2 * ext), H * 0.86 / (asc + desc + dropRel + 2 * ext));
    px = Math.max(6, px);
    var em = px, E = function (v) { return v * em * mult; };

    // centre, compensating for one-sided extrusion / offsets
    var shift = [0, 0];
    if (st.extrude) { var ev = dirVec(st.extrude.dir, E(st.extrude.depth)); shift[0] += ev[0]; shift[1] += ev[1]; }
    (st.post || []).forEach(function (it) { if (it.depth) { var pe = dirVec(it.dir, E(it.depth)); shift[0] += pe[0]; shift[1] += pe[1]; } });
    (st.hard || []).forEach(function (h) { var v = dirVec(h.dir, E(h.dist)); shift[0] += v[0]; shift[1] += v[1]; });
    var cx = W / 2 - shift[0] / 2, by = H / 2 + (asc - desc) / 2 * px - shift[1] / 2;
    if (arc > 0) by -= dropRel * px / 2; else if (arc < 0) by += dropRel * px / 2;

    // --- 1. face: text fill + text stroke ---
    var F = mk(W, H), f = F.getContext('2d');
    f.font = fontStr(px);
    f.textAlign = 'center';
    f.textBaseline = 'alphabetic';
    f.lineJoin = 'round';
    f.miterLimit = 2;
    var face = st.face || { fill: '#ffffff' };
    var solid = face.fill || (face.gradient && face.gradient[0]) || '#ffffff';
    var shaped = !!(skew || arc);
    var chars = shaped ? Array.from(text) : null, cw = [], totalW = 0;
    if (shaped) { chars.forEach(function (ch) { var w = f.measureText(ch).width; cw.push(w); totalW += w; }); }
    // draws the text plainly, or letter by letter with skew + arc (index-based like AE's expression selectors)
    function drawText(mode) {
      if (!shaped) { if (mode === 'stroke') f.strokeText(text, cx, by); else f.fillText(text, cx, by); return; }
      var n = chars.length, x = -totalW / 2, R = arcRad > 0.001 ? (totalW / 2) / arcRad : 0;
      var drop = R * (1 - Math.cos(arcRad)), sgn = arc >= 0 ? 1 : -1, tsk = Math.tan(skew * Math.PI / 180);
      f.save(); f.textAlign = 'center';
      for (var i = 0; i < n; i++) {
        var u = ((i + 0.5) / n) * 2 - 1, xc = x + cw[i] / 2, yoff = 0, rot = 0;
        if (arcRad > 0.001) { yoff = sgn * drop * (1 - Math.cos(u * arcRad)) / (1 - Math.cos(arcRad)); rot = u * arc * Math.PI / 180; }
        f.save();
        f.translate(cx + xc, by + yoff);
        f.rotate(rot);
        if (tsk) f.transform(1, 0, -tsk, 1, 0, 0);
        if (mode === 'stroke') f.strokeText(chars[i], 0, 0); else f.fillText(chars[i], 0, 0);
        f.restore();
        x += cw[i];
      }
      f.restore();
    }
    if (st.tstroke) {
      f.lineWidth = 2 * E(st.tstroke.w);
      f.strokeStyle = st.tstroke.color;
      drawText('stroke');
    }
    if (!st.hollow) { f.fillStyle = solid; drawText('fill'); }

    // --- 2. gradient (AE: Ramp + Set Matte over the whole source alpha) ---
    if (face.gradient) {
      var tw = w100 * px, th = (asc + desc) * px, gx = cx, gy = by - asc * px + th / 2;
      if (shaped) { // gradient spans the real (curved) text bounds, like sourceRectAtTime in AE
        var bb = alphaBox(F); if (bb) { tw = bb[2] - bb[0]; th = bb[3] - bb[1]; gx = (bb[0] + bb[2]) / 2; gy = (bb[1] + bb[3]) / 2; }
      }
      var a = (face.angle == null ? 90 : face.angle) * Math.PI / 180, dx = Math.cos(a), dy = Math.sin(a);
      var hh = Math.abs(dx) * tw / 2 + Math.abs(dy) * th / 2;
      var g = f.createLinearGradient(gx - dx * hh, gy - dy * hh, gx + dx * hh, gy + dy * hh);
      // 3+ colours are resampled to 5 evenly spaced stops — exactly what CC Toner (Pentone) does in AE
      if (face.horizon && face.gradient.length === 4) {
        // chrome horizon (AE: linear ramp + 50% step ramp -> CC Toner): sharp break at face.horizon
        var G4 = face.gradient, MX = root.HFS_COLOR.mix, hz = face.horizon;
        var c5 = [G4[0], G4[1], MX(G4[1], G4[2], 0.5), G4[2], G4[3]];
        var tone = function (l) { var q = (1 - l) * 4, k = Math.min(3, Math.floor(q)); return MX(c5[k], c5[k + 1], q - k); };
        var lum = function (t) { return t < hz ? 1 - t / 2 : 0.5 * (1 - t); };
        for (var ti = 0; ti <= 20; ti++) { var tt = ti / 20; if (Math.abs(tt - hz) > 0.02) g.addColorStop(tt, tone(lum(tt))); }
        g.addColorStop(hz - 0.004, tone(lum(hz - 0.004))); g.addColorStop(hz + 0.004, tone(lum(hz + 0.004)));
      } else {
        var stops = face.gradient.length > 2 ? root.HFS_COLOR.resample5(face.gradient) : face.gradient;
        stops.forEach(function (c, i) { g.addColorStop(i / (stops.length - 1), c); });
      }
      f.globalCompositeOperation = 'source-in';
      f.fillStyle = g;
      f.fillRect(0, 0, W, H);
      f.globalCompositeOperation = 'source-over';
    }

    // --- 2b. face texture ---
    var tex = textureFor(st, opts.texture);
    if (tex) {
      var seed = 0; for (var si = 0; si < st.id.length; si++) seed = (seed * 31 + st.id.charCodeAt(si)) | 0;
      applyTexture(F, tex, (tex.type === 'glitter' || tex.type === 'live') ? Math.max(1, Math.min(4, tex.size * em * 0.6)) : (tex.type === 'brushed' ? em * 0.08 : tex.size * em), seed);
    }

    // --- 2c. gloss (after Set Matte in AE) ---
    var gl = glossFor(st, opts.gloss);
    if (gl) {
      var gb = alphaBox(F);
      if (gb) {
        var mid = face.gradient ? face.gradient[Math.floor(face.gradient.length / 2)] : solid;
        applyGloss(F, gl, gb, em * mult, gl.color || root.HFS_COLOR.mix(mid, '#ffffff', 0.45));
      }
    }

    // --- 3. Bevel Alpha on the face ---
    if (st.bevelFx) {
      var bt = E(st.bevelFx.t), bi = st.bevelFx.intensity;
      rim(F, bt, st.bevelFx.light, '#ffffff', bi, '#000000', bi * 0.7, bt * 0.35);
    }

    // --- 3b. glossy rim: two rings of 8 tiny drop shadows, shaded by direction ---
    [].concat(rimFor(st, opts.rim) || []).forEach(function (rimDef) {
      rimRings(rimDef).forEach(function (ring) {
        RIM_DIRS.forEach(function (d) {
          var T = mk(W, H), tx = T.getContext('2d'), v = dirVec(d + (ring.rot || 0), E(ring.w));
          tx.drawImage(tint(F, rimColor(rimDef, d, ring.invert)), v[0], v[1]);
          tx.drawImage(F, 0, 0);
          F = T;
        });
      });
    });

    // --- 4. extrusion (stacked drop shadows, far → near) ---
    var S = F;
    if (st.extrude) {
      var ex = st.extrude, depth = E(ex.depth);
      var N = Math.max(3, Math.min(48, Math.ceil(depth / 1.2)));
      var step = depth / N;
      var S2 = mk(W, H), s2 = S2.getContext('2d');
      for (var k = N; k >= 1; k--) {
        var col = multiStop(ex.stops || [ex.near, ex.far], N > 1 ? (k - 1) / (N - 1) : 0);
        var v = dirVec(ex.dir, step * k);
        s2.drawImage(tint(F, col), v[0], v[1]);
      }
      s2.drawImage(F, 0, 0);
      S = S2;
    }

    // --- 5. hard shadows (Drop Shadow effects, each one behind everything so far) ---
    (st.hard || []).forEach(function (h) {
      var T = mk(W, H), t = T.getContext('2d'), v = dirVec(h.dir, E(h.dist));
      t.globalAlpha = (h.opacity == null ? 100 : h.opacity) / 100;
      t.drawImage(blurred(tint(S, h.color), E(h.soft || 0) / 2), v[0], v[1]);
      t.globalAlpha = 1;
      t.drawImage(S, 0, 0);
      S = T;
    });

    // --- 5b. post stack: more outlines / extrusions built around everything so far ---
    (st.post || []).forEach(function (it) {
      if (it.depth) {
        var pd = E(it.depth), PN = Math.max(3, Math.min(48, Math.ceil(pd / 1.2))), pstep = pd / PN;
        var P2 = mk(W, H), p2 = P2.getContext('2d');
        for (var pk = PN; pk >= 1; pk--) {
          var pv = dirVec(it.dir, pstep * pk);
          p2.drawImage(tint(S, multiStop(it.stops || [it.near, it.far], PN > 1 ? (pk - 1) / (PN - 1) : 0)), pv[0], pv[1]);
        }
        p2.drawImage(S, 0, 0); S = P2;
      } else {
        rimRings(it).forEach(function (ring) {
          RIM_DIRS.forEach(function (d) {
            var T = mk(W, H), tx = T.getContext('2d'), v = dirVec(d + (ring.rot || 0), E(ring.w));
            tx.drawImage(tint(S, rimColor(it, d, ring.invert)), v[0], v[1]);
            tx.drawImage(S, 0, 0); S = T;
          });
        });
      }
    });

    // --- 6. layer styles ---
    var ls = st.ls || {};
    var strokeImg = ls.stroke ? dilate(tint(S, ls.stroke.color), E(ls.stroke.w)) : null;
    var base = strokeImg || S; // silhouette incl. outside stroke, used by shadow & glow

    if (ls.shadow) {
      var sh = ls.shadow, size = E(sh.size), spread = (sh.spread || 0) / 100;
      var sv = dirVec(sh.dir, E(sh.dist));
      var sImg = blurred(dilate(tint(base, sh.color), size * spread), size * (1 - spread) / 2);
      out.save(); out.globalAlpha = sh.opacity / 100; out.drawImage(sImg, sv[0], sv[1]); out.restore();
    }
    if (ls.glow) {
      var gl = ls.glow, gs = E(gl.size), gsp = (gl.spread || 0) / 100;
      var gImg = blurred(dilate(tint(base, gl.color), gs * gsp), gs * (1 - gsp) / 2);
      out.save(); out.globalCompositeOperation = 'screen'; out.globalAlpha = gl.opacity / 100;
      out.drawImage(gImg, 0, 0); out.drawImage(gImg, 0, 0); out.restore();
    }
    if (strokeImg) {
      out.save(); out.globalAlpha = (ls.stroke.opacity == null ? 100 : ls.stroke.opacity) / 100; out.drawImage(strokeImg, 0, 0); out.restore();
    }

    // content with inner effects
    var C = mk(W, H), c = C.getContext('2d');
    c.drawImage(S, 0, 0);
    if (ls.innerShadow) {
      var is = ls.innerShadow, iv = dirVec(is.dir, E(is.dist));
      var inv = mk(W, H), ix = inv.getContext('2d');
      ix.fillStyle = is.color; ix.fillRect(0, 0, W, H);
      ix.globalCompositeOperation = 'destination-out'; ix.drawImage(S, iv[0], iv[1]);
      c.save(); c.globalCompositeOperation = 'source-atop'; c.globalAlpha = is.opacity / 100;
      c.drawImage(blurred(inv, E(is.size) / 2), 0, 0); c.restore();
    }
    if (ls.innerGlow) {
      var ig = ls.innerGlow;
      var inv2 = mk(W, H), jx = inv2.getContext('2d');
      jx.fillStyle = ig.color; jx.fillRect(0, 0, W, H);
      jx.globalCompositeOperation = 'destination-out'; jx.drawImage(S, 0, 0);
      c.save(); c.globalCompositeOperation = 'source-atop'; c.globalAlpha = ig.opacity / 100;
      var ch = (ig.choke || 0) / 100;
      var igImg = blurred(ch > 0 ? dilate(inv2, E(ig.size) * ch) : inv2, E(ig.size) * (1 - ch) / 2);
      c.drawImage(igImg, 0, 0); c.drawImage(igImg, 0, 0); c.restore();
    }
    if (ls.bevel) {
      var bv = ls.bevel, bs = E(bv.size), dm = Math.max(0.5, Math.min(1.6, (bv.depth || 100) / 100));
      rim(C, bs, bv.light, '#ffffff', (bv.hlOp / 100) * dm, '#000000', (bv.shOp / 100) * dm, bv.chisel ? bs * 0.15 : bs * 0.45);
    }
    out.drawImage(C, 0, 0);
  }

  function renderStyle(canvas, st, text, opts) {
    var prev = LIVE; LIVE = [];
    try { renderStyleInner(canvas, st, text, opts); }
    finally {
      for (var i = 0; i < LIVE.length; i++) { LIVE[i].width = 1; LIVE[i].height = 1; if (POOL.length < 96) POOL.push(LIVE[i]); }
      LIVE = prev;
    }
  }
  root.HFS_RENDER = { renderStyle: renderStyle };
})(window);
