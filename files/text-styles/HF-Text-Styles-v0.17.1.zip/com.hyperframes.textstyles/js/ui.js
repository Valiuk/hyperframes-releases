/* HF Text Styles — shell UI: filter panel, bottom dock with drawers, indicators.
   Works on top of main.js through the same DOM controls (no shared state). */
(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  function fire(el, type) { el.dispatchEvent(new Event(type, { bubbles: true })); }
  function ls(k, d) { try { var v = localStorage.getItem('hfs.' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function lsSet(k, v) { try { localStorage.setItem('hfs.' + k, JSON.stringify(v)); } catch (e) {} }

  // ---- drawers ----
  var drawers = document.querySelectorAll('.drawer'), tabs = document.querySelectorAll('.dock button');
  var current = '';
  function open(name) {
    current = name || '';
    Array.prototype.forEach.call(drawers, function (d) { d.hidden = d.getAttribute('data-d') !== current; });
    Array.prototype.forEach.call(tabs, function (t) { t.classList.toggle('on', t.getAttribute('data-d') === current); });
    setTimeout(function () { fire($('grid'), 'scroll'); }, 30); // grid height changed -> paint newly visible cards
  }
  Array.prototype.forEach.call(tabs, function (t) {
    t.addEventListener('click', function () { var n = t.getAttribute('data-d'); open(current === n ? '' : n); });
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && current) open(''); });

  // ---- filters ----
  $('filterTog').addEventListener('click', function () {
    var h = !$('filters').hidden; $('filters').hidden = h; $('filterTog').classList.toggle('open', !h);
    setTimeout(function () { fire($('grid'), 'scroll'); }, 30);
  });
  $('filtersReset').addEventListener('click', function () {
    $('q').value = ''; fire($('q'), 'input');
    $('dim').firstElementChild.click(); $('weight').firstElementChild.click();
    var any = document.querySelector('#colors .dot.any'); if (any) any.click();
    var all = document.querySelector('#cats .chip'); if (all) all.click();
    if ($('favOnly').classList.contains('on')) $('favOnly').click();
    if ($('readOnly').checked) { $('readOnly').checked = false; fire($('readOnly'), 'change'); }
  });
  // horizontal wheel scroll for the category row
  $('cats').addEventListener('wheel', function (e) { if (e.deltaY) { $('cats').scrollLeft += e.deltaY; e.preventDefault(); } }, { passive: false });

  // ---- look reset ----
  $('lookReset').addEventListener('click', function () {
    ['texture', 'gloss', 'rim'].forEach(function (id) { if ($(id).value !== 'style') { $(id).value = 'style'; fire($(id), 'change'); } });
    if ($('mult').value !== '100') { $('mult').value = 100; fire($('mult'), 'input'); fire($('mult'), 'change'); }
    ['skewOn', 'arcOn', 'lite', 'applyFont'].forEach(function (id) { if ($(id).checked) { $(id).checked = false; fire($(id), 'change'); } });
  });

  // ---- card size ----
  function setCard(v) {
    document.documentElement.style.setProperty('--card', v + 'px');
    Array.prototype.forEach.call($('cardSize').children, function (b) { b.classList.toggle('on', b.getAttribute('data-v') === String(v)); });
    lsSet('cardSize', v);
    setTimeout(function () { fire($('grid'), 'scroll'); }, 30);
  }
  $('cardSize').addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) setCard(+b.getAttribute('data-v')); });
  setCard(ls('cardSize', 150));

  // ---- indicators (derived from the controls, refreshed on interaction and on a slow timer) ----
  function refresh() {
    var n = 0;
    var d = document.querySelector('#dim button.on'), w = document.querySelector('#weight button.on'), c = document.querySelector('#colors .dot.on');
    if (d && d.getAttribute('data-v')) n++;
    if (w && w.getAttribute('data-v')) n++;
    if (c && !c.classList.contains('any')) n++;
    if ($('sort').value !== 'default') n++;
    if ($('readOnly').checked && !$('bgOpts').hidden) n++;
    $('filterCount').hidden = n === 0; $('filterCount').textContent = n;

    var look = $('texture').value !== 'style' || $('gloss').value !== 'style' || $('rim').value !== 'style' || $('mult').value !== '100' ||
      $('skewOn').checked || $('arcOn').checked || $('lite').checked;
    $('pipLook').hidden = !look;

    var bg = /^#[0-9a-f]{6}$/i.test($('bgHex').value.trim()) ? $('bgHex').value.trim() : '';
    $('pipBg').hidden = !bg; if (bg) $('pipBg').style.background = bg;
    $('pipAi').hidden = $('aiBox').hidden;

    var st = $('status'), dot = $('sdot'), t = st.textContent;
    dot.className = 'sdot ' + (st.classList.contains('err') ? 'err' : (/Виділіть|Відкрийте|Поза After/.test(t) ? 'wait' : 'ready'));
  }
  ['click', 'change', 'input'].forEach(function (ev) { document.addEventListener(ev, function () { setTimeout(refresh, 0); }, true); });
  setInterval(refresh, 700);
  refresh();

  window.HFS_UI = { open: open, refresh: refresh };
})();
