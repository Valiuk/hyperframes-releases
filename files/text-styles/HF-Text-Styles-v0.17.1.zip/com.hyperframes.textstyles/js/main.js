/* HF Text Styles — panel logic */
(function () {
  'use strict';

  var LIB = window.HFS_LIB, CATS = window.HFS_CATS;
  var $ = function (id) { return document.getElementById(id); };
  var inCEP = !!(window.__adobe_cep__ && window.__adobe_cep__.evalScript);

  // ---------- persistence ----------
  function load(k, d) { try { var v = localStorage.getItem('hfs.' + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function save(k, v) { try { localStorage.setItem('hfs.' + k, JSON.stringify(v)); } catch (e) {} }

  var state = {
    q: '', cat: '', color: '', dim: '', weight: '', favOnly: false,
    sort: load('sort', 'default'),
    sample: load('sample', 'HYPER'),
    mult: load('mult', 100),
    applyFont: load('applyFont', false), lite: load('lite', false),
    showAE: load('showAE', false),
    texture: load('texture', 'style'), gloss: load('gloss', 'style'), rim: load('rim', 'style'),
    skewOn: load('skewOn', false), skew: load('skew', 12),
    arcOn: load('arcOn', false), arc: load('arc', 20),
    bg: load('bg', ''),
    bgPreview: load('bgPreview', true),
    readOnly: false, aiOnly: false,
    fg: load('fg', '#ffffff'),
    fav: load('fav', []),
    use: load('use', {}),
    recent: load('recent', [])
  };
  var aeDir = null, aeHave = {};
  var busy = false, cancelPreviews = false;

  // ---------- ExtendScript bridge ----------
  function asciiJSON(o) {
    return JSON.stringify(o).replace(/[\u007f-￿]/g, function (c) { return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4); });
  }
  function jsx(code) {
    return new Promise(function (res) {
      if (!inCEP) { res('nocep'); return; }
      window.__adobe_cep__.evalScript(code, function (r) { res(r); });
    });
  }
  function payload(st) {
    var o = {};
    ['id', 'face', 'hollow', 'tstroke', 'texture', 'gloss', 'rim', 'post', 'bevelFx', 'extrude', 'hard', 'ls', 'font', 'extent'].forEach(function (k) { if (st[k] !== undefined) o[k] = st[k]; });
    return asciiJSON(o);
  }
  function hash(s) { var h = 5381; for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(16); }
  function aeFile(st) { return st.id + '_' + hash(payload(st) + '|' + state.sample) + '.png'; }
  function fileUrl(dir, name) { return 'file:///' + encodeURI(dir.replace(/\\/g, '/')) + '/' + name; }

  // ---------- status ----------
    function status(msg, kind) {
    var el = $('status');
    el.textContent = msg; el.className = 'status' + (kind ? ' ' + kind : '');
  }
  function refreshSelection() {
    if (busy) return;
    jsx('hfs_selection()').then(function (r) {
      if (busy || Date.now() - lastMsg < 4000) return;
      if (r === 'nocep') status('Поза After Effects — лише перегляд');
      else if (r === 'nocomp') status('Відкрийте композицію');
      else if (r === '0') status('Виділіть текстовий шар');
      else status('Текстових шарів виділено: ' + r);
    });
  }
  var lastMsg = 0, lastWarn = '';

  // ---------- filtering & sorting ----------
  var CAT_ORDER = Object.keys(CATS);
  var COLORS = [['red', '#ff3b3b'], ['orange', '#ff8a00'], ['yellow', '#ffd400'], ['green', '#22c55e'], ['cyan', '#22d3ee'], ['blue', '#2f6bff'], ['purple', '#8b5cf6'], ['pink', '#ff4fb4'], ['white', '#f2f2f2'], ['silver', '#8f99a3'], ['black', '#111111']];

  function matches(st) {
    if (state.cat && st.cat !== state.cat) return false;
    if (state.color && st.color !== state.color) return false;
    if (state.dim && st.dim !== state.dim) return false;
    if (state.weight && String(st.weight) !== state.weight) return false;
    if (state.favOnly && state.fav.indexOf(st.id) < 0) return false;
    if (state.bg && state.readOnly && crOf(st) < 3) return false;
    if (state.aiOnly && ai.picks.indexOf(st.id) < 0) return false;
    if (state.sort === 'recent' && state.recent.indexOf(st.id) < 0) return false;
    if (state.q) {
      var hay = (st.name + ' ' + st.tags.join(' ') + ' ' + CATS[st.cat] + ' ' + st.dim).toLowerCase();
      var words = state.q.toLowerCase().split(/\s+/).filter(Boolean);
      for (var i = 0; i < words.length; i++) if (hay.indexOf(words[i]) < 0) return false;
    }
    return true;
  }
  function sorted(list) {
    if (state.aiOnly) return list.slice().sort(function (a, b) { return ai.picks.indexOf(a.id) - ai.picks.indexOf(b.id); });
    var s = state.sort, idx = function (st) { return LIB.indexOf(st); };
    var cmp = {
      default: function (a, b) { return CAT_ORDER.indexOf(a.cat) - CAT_ORDER.indexOf(b.cat) || idx(a) - idx(b); },
      name: function (a, b) { return a.name.localeCompare(b.name, 'uk'); },
      popular: function (a, b) { return (state.use[b.id] || 0) - (state.use[a.id] || 0) || idx(a) - idx(b); },
      recent: function (a, b) { return state.recent.indexOf(a.id) - state.recent.indexOf(b.id); },
      light: function (a, b) { return a.weight - b.weight || idx(a) - idx(b); },
      contrast: function (a, b) { return crOf(b) - crOf(a) || idx(a) - idx(b); },
      hue: function (a, b) { return (a.color === 'white' || a.color === 'silver' || a.color === 'black' ? 999 : a.hue) - (b.color === 'white' || b.color === 'silver' || b.color === 'black' ? 999 : b.hue); }
    }[s];
    return list.slice().sort(cmp);
  }

  // ---------- text shape (skew / arc) ----------
  function shapeKey() { return (state.skewOn ? state.skew : 0) + '/' + (state.arcOn ? state.arc : 0); }
  function sendShape() {
    var o = { skew: state.skewOn ? state.skew : 0, arc: state.arcOn ? state.arc : 0 };
    if (!inCEP) return;
    jsx('hfs_shape(' + asciiJSON(o) + ')').then(function (r) {
      var p = String(r).split('|'); lastMsg = Date.now();
      if (p[0] === 'ok') {
        var w = p[2] ? decodeURIComponent(p[2]) : '';
        lastWarn = w ? 'Форма: ' + w : lastWarn;
        status(w ? 'Форму застосовано з попередженнями — «Діагностика»' : ((o.skew || o.arc) ? 'Форма: ' + (o.skew ? 'нахил ' + o.skew + '° ' : '') + (o.arc ? 'вигин ' + o.arc + '°' : '') : 'Форму прибрано') + ' → ' + p[1] + ' шар(и)', w ? 'err' : 'ok');
      } else if (p[1] !== 'notext') status(explain(p[1]), 'err');
    });
  }
  var sendShapeLater = debounce(sendShape, 250);
  function shapeChanged(apply) {
    $('skewVal').textContent = state.skew + '°'; $('arcVal').textContent = state.arc + '°';
    save('skewOn', state.skewOn); save('skew', state.skew); save('arcOn', state.arcOn); save('arc', state.arc);
    repaintVisible();
    if (apply) sendShapeLater();
  }

  // ---------- Gemini advisor ----------
  var ai = { key: load('aiKey', ''), model: load('aiModel', ''), mode: load('aiMode', 'fast'), picks: [], reasons: {}, cache: {} };
  var AI_BASE = 'https://generativelanguage.googleapis.com/v1beta/';

  function describe(st) {
    var f = st.face || {}, ls = st.ls || {}, parts = [];
    parts.push(st.hollow ? 'без заливки, контур ' + (st.tstroke ? st.tstroke.color : '') : (f.gradient ? 'градієнт ' + f.gradient.join('→') : 'заливка ' + f.fill));
    if (st.tstroke && !st.hollow) parts.push('внутр. обводка ' + st.tstroke.color);
    if (ls.stroke) parts.push('контур ' + ls.stroke.color + ' ' + (ls.stroke.w >= 0.05 ? 'товстий' : 'тонкий'));
    if (st.extrude) parts.push('3D-обʼєм ' + st.extrude.near + '→' + st.extrude.far + (st.extrude.depth > 0.2 ? ' глибокий' : ''));
    if (st.hard) parts.push('жорсткі тіні ' + st.hard.map(function (h) { return h.color; }).join(','));
    if (ls.glow) parts.push('сяйво ' + ls.glow.color);
    if (ls.shadow) parts.push('м’яка тінь');
    if (ls.bevel || st.bevelFx) parts.push('фаска');
    if (st.texture) parts.push('текстура ' + st.texture.type);
    if (st.gloss) parts.push('глянцеві відблиски');
    if (st.rim) parts.push('кант ' + [].concat(st.rim).map(function (r) { return r.mid; }).join('+'));
    if (f.horizon) parts.push('хром-горизонт');
    return parts.join('; ');
  }

  function pickDefaultModel(names) {
    function ver(n) { var m = n.match(/gemini-(\d+(?:\.\d+)?)/); return m ? parseFloat(m[1]) : 0; }
    var flash = names.filter(function (n) { return /flash/.test(n) && !/lite|image|tts|audio|live|thinking-exp/.test(n); });
    var pool = flash.length ? flash : names;
    pool.sort(function (a, b) { return ver(b) - ver(a) || (/preview|exp/.test(a) ? 1 : 0) - (/preview|exp/.test(b) ? 1 : 0); });
    return pool[0] || '';
  }
  function loadModels() {
    var key = $('aiKey').value.trim() || ai.key;
    if (!key) { $('aiCfgStatus').textContent = 'Спершу вставте ключ'; return Promise.resolve([]); }
    $('aiCfgStatus').textContent = 'Завантажую моделі…';
    return fetch(AI_BASE + 'models?pageSize=200&key=' + encodeURIComponent(key)).then(function (r) { return r.json(); }).then(function (j) {
      if (j.error) throw new Error(j.error.message);
      var names = (j.models || []).filter(function (m) {
        return (m.supportedGenerationMethods || []).indexOf('generateContent') >= 0 && /gemini/.test(m.name) && !/embedding|tts|image-generation|native-audio/.test(m.name);
      }).map(function (m) { return m.name; });
      var sel = $('aiModel'); sel.innerHTML = '';
      names.forEach(function (n) { var o = document.createElement('option'); o.value = n; o.textContent = n.replace('models/', ''); sel.appendChild(o); });
      var cur = ai.model && names.indexOf(ai.model) >= 0 ? ai.model : pickDefaultModel(names);
      sel.value = cur;
      $('aiCfgStatus').textContent = names.length + ' моделей';
      return names;
    }).catch(function (e) { $('aiCfgStatus').textContent = 'Помилка: ' + e.message; return []; });
  }
  function openAiCfg() {
    $('aiKey').value = ai.key; $('aiMode').value = ai.mode; $('aiCfgBox').hidden = false;
    if (ai.model) { $('aiModel').innerHTML = '<option value="' + ai.model + '">' + ai.model.replace('models/', '') + '</option>'; }
    if (ai.key) loadModels();
  }
  function saveAiCfg() {
    ai.key = $('aiKey').value.trim(); ai.model = $('aiModel').value || ai.model;
    ai.mode = $('aiMode').value; save('aiKey', ai.key); save('aiModel', ai.model); save('aiMode', ai.mode);
    $('aiCfgBox').hidden = true;
  }

  function readFileB64(path) {
    var r = window.cep && window.cep.fs ? window.cep.fs.readFile(path, window.cep.encoding.Base64) : { err: -1 };
    if (r.err) throw new Error('не вдалося прочитати кадр (' + r.err + ')');
    return r.data;
  }
  // downscale to JPEG and draw a dashed box where the text will sit
  function prepImage(b64png, boxes, compW, compH, maxSide) {
    return new Promise(function (res, rej) {
      var img = new Image();
      img.onload = function () {
        var k = Math.min(1, (maxSide || 1024) / Math.max(img.width, img.height));
        var c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        var x = c.getContext('2d'); x.drawImage(img, 0, 0, c.width, c.height);
        var sx = c.width / compW, sy = c.height / compH;
        x.setLineDash([8, 6]); x.lineWidth = 2; x.strokeStyle = '#ff00ff';
        boxes.forEach(function (b) { x.strokeRect(b.x0 * sx, b.y0 * sy, (b.x1 - b.x0) * sx, (b.y1 - b.y0) * sy); });
        res(c.toDataURL('image/jpeg', 0.8).split(',')[1]);
      };
      img.onerror = function () { rej(new Error('кадр не відкрився')); };
      img.src = 'data:image/png;base64,' + b64png;
    });
  }

  function captureFrame() {
    return jsx('hfs_captureBegin()').then(async function (r) {
      var p = String(r).split('|');
      if (p[0] !== 'ok') throw new Error(explain(p[1] || r));
      try {
        for (var i = 0; i < 80; i++) { if ((await jsx('hfs_captureReady()')) === '1') break; await sleep(100); }
        await sleep(120);
        var path = decodeURIComponent(p[1]), wh = p[2].split('x');
        var boxes = (p[3] || '').split(';').filter(Boolean).map(function (t) {
          var q = t.split(','); return { text: decodeURIComponent(q[0]), x0: +q[1], y0: +q[2], x1: +q[3], y1: +q[4] };
        });
        return { b64: readFileB64(path), w: +wh[0], h: +wh[1], boxes: boxes };
      } finally {
        await jsx('hfs_captureEnd()');
      }
    });
  }

  // fast mode: the 45 most readable styles on this background, max 3 per recipe
  function aiCandidates() {
    if (ai.mode !== 'fast' || !state.bg) return LIB;
    var per = {}, out = [];
    LIB.slice().sort(function (a, b) { return crOf(b) - crOf(a); }).forEach(function (st) {
      if (out.length >= 45) return;
      per[st.recipe] = (per[st.recipe] || 0) + 1;
      if (per[st.recipe] <= 3) out.push(st);
    });
    return out;
  }
  function thinkingFor(model) {
    if (ai.mode !== 'fast') return null;
    if (/gemini-2\.5-flash/.test(model)) return { thinkingBudget: 0 };
    if (/gemini-2\.5-pro/.test(model)) return { thinkingBudget: 128 };
    if (/gemini-(\d+)/.test(model) && +model.match(/gemini-(\d+)/)[1] >= 3) return { thinkingLevel: 'low' };
    return null;
  }

  function buildPrompt(frame) {
    var texts = frame.boxes.map(function (b) { return '«' + b.text.replace(/\r/g, ' ') + '»'; }).join(', ') || '(текст не виділено — оцінюй центр кадру)';
    var lines = aiCandidates().map(function (st) {
      return st.id + ' | ' + st.name + ' | ' + CATS[st.cat] + ' | контраст ' + (state.bg ? crOf(st).toFixed(1) : '?') + ' | ' + describe(st);
    }).join('\n');
    return 'Ти — арт-директор перформанс-реклами (мобільні ігри, слоти, промо). На зображенні — кадр з After Effects ' + frame.w + '×' + frame.h +
      ', текст приховано. Пурпурова пунктирна рамка показує, де стоятиме текст ' + texts + ' (сама рамка не є частиною кадру).\n' +
      (state.bg ? 'Усереднений колір фону під текстом: ' + state.bg + '.\n' : '') +
      (ai.mode === 'fast' ? 'Список уже попередньо відібрано за читабельністю. ' : '') + 'Обери 6 стилів зі списку нижче, які найкраще підійдуть цьому тексту на цьому фоні.\n' +
      'Критерії за важливістю:\n1) Читабельність на телефоні в зоні рамки. «контраст» — WCAG-коефіцієнт стилю (край силуету або лице) з усередненим фоном: ≥4.5 відмінно, ≥3 прийнятно. Якщо фон у рамці строкатий або деталізований, віддавай перевагу стилям з товстим контуром, обʼємом або тінню.\n' +
      '2) Гармонія з палітрою, світлом і настроєм кадру (контрастний акцент або спорідненість кольорів — поясни вибір).\n3) Відповідність жанру й посилу тексту.\n' +
      'Не обирай стилі, що зливаються з фоном. Не більше 2 варіантів одного рецепту (однакова назва до « · »). score — 1..10.\n' +
      'Пиши українською, коротко й конкретно (reason — одне речення).\n\nСтилі (id | назва | категорія | контраст | опис):\n' + lines;
  }

  var AI_SCHEMA = {
    type: 'OBJECT',
    properties: {
      background: { type: 'OBJECT', properties: {
        summary: { type: 'STRING' }, colors: { type: 'ARRAY', items: { type: 'STRING' } }, busy: { type: 'STRING' } }, required: ['summary', 'colors'] },
      picks: { type: 'ARRAY', items: { type: 'OBJECT', properties: {
        id: { type: 'STRING' }, score: { type: 'INTEGER' }, reason: { type: 'STRING' } }, required: ['id', 'reason'] } },
      avoid: { type: 'STRING' }
    },
    required: ['background', 'picks']
  };

  function callGemini(prompt, jpegB64, noThinking) {
    var model = ai.model.indexOf('models/') === 0 ? ai.model : 'models/' + ai.model;
    var gen = { temperature: 0.4, responseMimeType: 'application/json', responseSchema: AI_SCHEMA, maxOutputTokens: 2048 };
    var th = noThinking ? null : thinkingFor(model);
    if (th) gen.thinkingConfig = th;
    var body = {
      contents: [{ role: 'user', parts: [{ text: prompt }, { inline_data: { mime_type: 'image/jpeg', data: jpegB64 } }] }],
      generationConfig: gen
    };
    return fetch(AI_BASE + model + ':generateContent?key=' + encodeURIComponent(ai.key), {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
    }).then(function (r) { return r.json(); }).then(function (j) {
      // a model that does not accept this thinking setting -> retry once without it
      if (j.error && th && /thinking/i.test(j.error.message || '')) return callGemini(prompt, jpegB64, true);
      if (j.error) throw new Error(j.error.message);
      var c = j.candidates && j.candidates[0], t = c && c.content && c.content.parts && c.content.parts.map(function (p) { return p.text || ''; }).join('');
      if (!t) throw new Error('порожня відповідь' + (c && c.finishReason ? ' (' + c.finishReason + ')' : ''));
      return JSON.parse(t);
    });
  }

  function showAI(res) {
    var byId = {}; LIB.forEach(function (st) { byId[st.id] = st; });
    var picks = (res.picks || []).filter(function (p) { return byId[p.id]; });
    ai.picks = picks.map(function (p) { return p.id; });
    ai.reasons = {}; picks.forEach(function (p) { ai.reasons[p.id] = p.reason; });
    var bgc = (res.background && res.background.colors || []).map(function (c) { return '<span class="sw" style="background:' + c + '"></span>'; }).join('');
    $('aiSummary').innerHTML = bgc + ' ' + escapeHtml((res.background && res.background.summary) || '') +
      (res.background && res.background.busy ? ' <i>(' + escapeHtml(res.background.busy) + ')</i>' : '');
    var box = $('aiPicks'); box.innerHTML = '';
    picks.forEach(function (p, i) {
      var st = byId[p.id], row = document.createElement('div'); row.className = 'aipick';
      var cv = document.createElement('canvas'); cv.width = 240; cv.height = 100;
      if (state.bg) cv.style.background = state.bg;
      row.appendChild(cv);
      var t = document.createElement('div'); t.className = 't';
      t.innerHTML = '<div class="n"></div><div class="r"></div>';
      t.querySelector('.n').textContent = (i + 1) + '. ' + st.name;
      if (p.score) { var sc = document.createElement('span'); sc.className = 'sc'; sc.textContent = p.score + '/10'; t.querySelector('.n').appendChild(sc); }
      if (state.bg) { var cr = crOf(st), b = document.createElement('span'); b.className = 'cr ' + crClass(cr); b.style.marginLeft = '4px'; b.textContent = crLabel(cr); t.querySelector('.n').appendChild(b); }
      t.querySelector('.r').textContent = p.reason;
      row.appendChild(t);
      row.title = 'Клік — застосувати до виділених шарів';
      row.onclick = function () { fgFromStyle(st); applyStyle(st, cardById[st.id] || row); };
      box.appendChild(row);
      window.HFS_RENDER.renderStyle(cv, st, state.sample || 'HYPER', { mult: state.mult / 100, texture: state.texture, gloss: state.gloss, rim: state.rim, skew: state.skewOn ? state.skew : 0, arc: state.arcOn ? state.arc : 0 });
    });
    $('aiAvoid').textContent = res.avoid ? 'Уникати: ' + res.avoid : '';
    $('aiBox').hidden = false;
    if (window.HFS_UI) window.HFS_UI.open('ai');
    if ($('aiOnly').checked) renderGrid();
  }
  function escapeHtml(t) { return String(t).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  async function runGemini() {
    if (!ai.key) { openAiCfg(); return; }
    if (!inCEP && !window.__hfsMockFrame) { status(explain('nocep'), 'err'); lastMsg = Date.now(); return; }
    var btn = $('aiBtn');
    if (btn.classList.contains('busy')) return;
    btn.classList.add('busy'); busy = true;
    try {
      if (!ai.model) { var names = await loadModels(); ai.model = pickDefaultModel(names); save('aiModel', ai.model); if (!ai.model) throw new Error('немає доступних моделей для цього ключа'); }
      if (!state.bg && inCEP) {
        $('status').textContent = 'Читаю фон під текстом…';
        var r = String(await jsx('hfs_sampleBehind()')).split('|');
        if (r[0] === 'ok') setBg(r[1]);
      }
      var t0 = Date.now();
      $('status').textContent = 'Знімаю кадр…';
      var frame = window.__hfsMockFrame ? window.__hfsMockFrame : await captureFrame();
      var jpeg = await prepImage(frame.b64, frame.boxes, frame.w, frame.h, ai.mode === 'fast' ? 768 : 1024);
      var tCap = (Date.now() - t0) / 1000;
      var prompt = buildPrompt(frame);
      var ckey = hash(jpeg) + '|' + hash(prompt) + '|' + ai.model + '|' + ai.mode;
      var res = ai.cache[ckey], cached = !!res, t1 = Date.now();
      if (!res) {
        var tick = setInterval(function () {
          $('status').textContent = 'Gemini аналізує фон… ' + ((Date.now() - t1) / 1000).toFixed(0) + ' с (' + ai.model.replace('models/', '') + ', ' + (ai.mode === 'fast' ? 'швидкий' : 'ретельний') + ')';
        }, 250);
        try { res = window.__hfsMockAI ? window.__hfsMockAI : await callGemini(prompt, jpeg); }
        finally { clearInterval(tick); }
        ai.cache[ckey] = res;
      }
      var tAi = (Date.now() - t1) / 1000;
      showAI(res);
      lastMsg = Date.now() + 4000; busy = false;
      status('Gemini порадив ' + ai.picks.length + ' стилів · кадр ' + tCap.toFixed(1) + ' с · ' + (cached ? 'з кешу' : 'Gemini ' + tAi.toFixed(1) + ' с'), 'ok');
    } catch (e) {
      lastMsg = Date.now(); busy = false; status('Gemini: ' + e.message, 'err'); console.error(e);
    } finally {
      busy = false; btn.classList.remove('busy');
    }
  }

  // ---------- contrast ----------
  var crCache = {}, crBg = '';
  function crOf(st) {
    if (!state.bg) return 0;
    if (crBg !== state.bg) { crCache = {}; crBg = state.bg; }
    if (crCache[st.id] == null) crCache[st.id] = window.HFS_CONTRAST.styleRatio(st, state.bg).ratio;
    return crCache[st.id];
  }
  function crClass(r) { return r >= 4.5 ? 'good' : (r >= 3 ? 'ok' : 'bad'); }
  function crLabel(r) { return r.toFixed(1) + (r >= 4.5 ? ' AAA' : (r >= 3 ? ' AA' : ' ✗')); }
  function normHex(v) {
    v = String(v || '').trim().replace(/^#?/, '#');
    if (/^#[0-9a-fA-F]{3}$/.test(v)) v = '#' + v.slice(1).replace(/(.)/g, '$1$1');
    return /^#[0-9a-fA-F]{6}$/.test(v) ? v.toLowerCase() : null;
  }
  function updateBadges() {
    Object.keys(cardById).forEach(function (id) {
      var c = cardById[id], b = c.querySelector('.cr'), pv = c.querySelector('.pv');
      if (pv) pv.style.background = (state.bg && state.bgPreview) ? state.bg : '';
      if (!state.bg) { if (b) b.remove(); return; }
      if (!c.isConnected) return;
      if (!inView(c) && crCache[id] == null) return; // off-screen cards get their badge when painted
      var r; try { r = crOf(c._st); } catch (e) { noteErr(e); return; }
      if (!b) { b = document.createElement('span'); c.querySelector('.meta').insertBefore(b, c.querySelector('.w')); }
      b.className = 'cr ' + crClass(r); b.textContent = crLabel(r);
      b.title = 'Контраст стилю з фоном ' + state.bg + ' (WCAG): ' + r.toFixed(2) + ':1';
    });
  }
  function setBg(hex, why) {
    hex = hex ? normHex(hex) : '';
    if (hex === null) { status('Невірний HEX', 'err'); lastMsg = Date.now(); return; }
    state.bg = hex; save('bg', hex);
    $('bgHex').value = hex || ''; if (hex) { $('bgPick').value = hex; $('bg2Hex').value = hex; $('bg2Pick').value = hex; }
    $('bgOpts').hidden = !hex;
    renderGrid(); updateBadges(); updateChecker();
    if (hex && why) { status(why, 'ok'); lastMsg = Date.now(); }
  }
  function setFg(hex, st, part) {
    hex = normHex(hex); if (!hex) return;
    state.fg = hex; save('fg', hex); $('fgHex').value = hex; $('fgPick').value = hex;
    if (st) {
      $('fgHint').textContent = 'Стиль «' + st.name + '»: з фоном стикається ' + (part === 'edge' ? 'край силуету (контур / обʼєм / сяйво)' : 'лице') + ' кольору ' + hex + '.';
    } else {
      $('fgHint').textContent = 'Ручна перевірка двох кольорів.';
    }
    updateChecker();
  }
  // checker follows the style: the colour that meets the background, not just the face fill
  function fgFromStyle(st) {
    var bg = normHex($('bg2Hex').value) || state.bg;
    if (bg) { var r = window.HFS_CONTRAST.styleRatio(st, bg); setFg(r.color, st, r.part); }
    else setFg(window.HFS_CONTRAST.faceColor(st), st, 'face');
  }
  function cell(id, ok) { var e = $(id); e.innerHTML = ok ? '<span class="pass">Pass ✓</span>' : '<span class="fail">Fail ✗</span>'; }
  function updateChecker() {
    var bg = normHex($('bg2Hex').value) || state.bg || '#1e1e1e', fg = state.fg;
    var r = window.HFS_CONTRAST.ratio(fg, bg), g = window.HFS_CONTRAST.grade(r);
    var el = $('ratio'); el.textContent = r.toFixed(2) + ' : 1'; el.className = 'ratio ' + crClass(r);
    cell('gLA', g.largeAA); cell('gLAAA', g.largeAAA); cell('gSA', g.smallAA); cell('gSAAA', g.smallAAA); cell('gUI', g.ui);
  }
  function eyedrop(cb) {
    if (!('EyeDropper' in window)) { status('Піпетка з екрана недоступна в цій версії панелі — скористайтеся «З композиції» або HEX', 'err'); lastMsg = Date.now(); return; }
    new window.EyeDropper().open().then(function (r) { cb(r.sRGBHex); }).catch(function () {});
  }
  function sampleFromComp() {
    if (!inCEP) { status(explain('nocep'), 'err'); lastMsg = Date.now(); return; }
    status('Читаю фон під текстом…');
    jsx('hfs_sampleBehind()').then(function (r) {
      var p = String(r).split('|');
      if (p[0] !== 'ok') { status(explain(p[1] || r), 'err'); lastMsg = Date.now(); return; }
      setBg(p[1], 'Фон ' + p[1] + (p[3] === 'text' ? ' (під виділеним текстом' : ' (центр композиції') + ', шарів: ' + p[2] + ')');
    });
  }

  // ---------- UI build ----------
  function buildChips() {
    var el = $('cats'); el.innerHTML = '';
    var counts = {};
    LIB.forEach(function (st) { counts[st.cat] = (counts[st.cat] || 0) + 1; });
    var all = document.createElement('span');
    all.className = 'chip' + (state.cat ? '' : ' on');
    all.innerHTML = 'Усі<span class="n">' + LIB.length + '</span>';
    all.onclick = function () { state.cat = ''; buildChips(); renderGrid(); };
    el.appendChild(all);
    CAT_ORDER.forEach(function (c) {
      var b = document.createElement('span');
      b.className = 'chip' + (state.cat === c ? ' on' : '');
      b.innerHTML = CATS[c] + '<span class="n">' + (counts[c] || 0) + '</span>';
      b.onclick = function () { state.cat = state.cat === c ? '' : c; buildChips(); renderGrid(); };
      el.appendChild(b);
    });
  }
  function buildColors() {
    var el = $('colors'); el.innerHTML = '';
    var any = document.createElement('span');
    any.className = 'dot any' + (state.color ? '' : ' on'); any.title = 'Будь-який колір';
    any.onclick = function () { state.color = ''; buildColors(); renderGrid(); };
    el.appendChild(any);
    COLORS.forEach(function (c) {
      var d = document.createElement('span');
      d.className = 'dot' + (state.color === c[0] ? ' on' : '');
      d.style.background = c[1]; d.title = c[0];
      d.onclick = function () { state.color = state.color === c[0] ? '' : c[0]; buildColors(); renderGrid(); };
      el.appendChild(d);
    });
  }
  function seg(id, key) {
    var el = $(id);
    el.addEventListener('click', function (e) {
      var b = e.target.closest('button'); if (!b) return;
      state[key] = b.getAttribute('data-v');
      Array.prototype.forEach.call(el.children, function (x) { x.classList.toggle('on', x === b); });
      renderGrid();
    });
  }

  // ---------- grid ----------
  var observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (en) { if (en.isIntersecting) queuePaint(en.target); });
  }, { root: $('grid'), rootMargin: '200px' });

  var cardById = {};
  function makeCard(st) {
    var card = document.createElement('div');
    card.className = 'card'; card.dataset.id = st.id;
    card.title = st.name + '\n' + CATS[st.cat] + ' · ' + st.dim + ' · ' + st.tags.join(', ');
    var cv = document.createElement('canvas'); cv.className = 'pv'; cv.width = 360; cv.height = 150;
    card.appendChild(cv);
    var star = document.createElement('button'); star.className = 'star' + (state.fav.indexOf(st.id) >= 0 ? ' fav' : ''); star.textContent = '★';
    star.title = 'В обране';
    star.onclick = function (e) { e.stopPropagation(); toggleFav(st.id, star); };
    card.appendChild(star);
    var meta = document.createElement('div'); meta.className = 'meta';
    meta.innerHTML = '<span class="name"></span>' + (st.dim === '3D' ? '<span class="badge">3D</span>' : '') +
      '<span class="w" title="Навантаження">' + '●●●'.slice(0, st.weight) + '<span style="opacity:.3">' + '●●●'.slice(st.weight) + '</span></span>';
    meta.querySelector('.name').textContent = st.name;
    card.appendChild(meta);
    card.onclick = function () { try { fgFromStyle(st); } catch (e) { noteErr(e); } applyStyle(st, card); };
    card.onmouseenter = function () { if (!$('checker').hidden) { try { fgFromStyle(st); } catch (e) { noteErr(e); } } };
    card._st = st; card._painted = '';
    return card;
  }

  function noteErr(e) { lastWarn = 'JS: ' + (e && e.message ? e.message : e) + (e && e.stack ? ' @ ' + String(e.stack).split('\n')[1] : ''); console.error(e); }
  window.addEventListener('error', function (ev) { lastWarn = 'JS: ' + ev.message + ' @ ' + (ev.filename || '').split('/').pop() + ':' + ev.lineno; });
  function inView(c) {
    var r = c.getBoundingClientRect(), g = $('grid').getBoundingClientRect();
    return r.bottom > g.top - 200 && r.top < g.bottom + 200;
  }
  function badgeOne(c) {
    var b = c.querySelector('.cr');
    if (!state.bg) { if (b) b.remove(); return; }
    var r = crOf(c._st);
    if (!b) { b = document.createElement('span'); c.querySelector('.meta').insertBefore(b, c.querySelector('.w')); }
    b.className = 'cr ' + crClass(r); b.textContent = crLabel(r);
    b.title = 'Контраст стилю з фоном ' + state.bg + ' (WCAG): ' + r.toFixed(2) + ':1';
  }
  function paintCard(card) {
    try { paintCardInner(card); } catch (e) { card._painted = ''; noteErr(e); }
    if (state.bg) { try { badgeOne(card); } catch (e2) { noteErr(e2); } }
  }
  function paintCardInner(card) {
    var st = card._st, key = state.sample + '|' + state.mult + '|' + state.texture + '|' + state.gloss + '|' + state.rim + '|' + shapeKey();
    var file = aeFile(st);
    var useAE = state.showAE && aeDir && aeHave[file] && state.mult === 100 && state.texture === 'style' && state.gloss === 'style' && state.rim === 'style' && !state.skewOn && !state.arcOn;
    var cur = card.querySelector('.pv');
    if (useAE) {
      if (card._painted === 'ae:' + file) return;
      var img = document.createElement('img'); img.className = 'pv'; img.src = fileUrl(aeDir, file) + '?t=' + Date.now();
      card.replaceChild(img, cur); card._painted = 'ae:' + file;
      img.style.background = (state.bg && state.bgPreview) ? state.bg : '';
      if (!card.querySelector('.badge.ae')) {
        var b = document.createElement('span'); b.className = 'badge ae'; b.textContent = 'AE'; b.title = 'Справжнє превʼю з After Effects';
        card.querySelector('.meta').insertBefore(b, card.querySelector('.w'));
      }
      return;
    }
    if (card._painted === key) return;
    if (cur.tagName !== 'CANVAS') {
      var cv = document.createElement('canvas'); cv.className = 'pv'; cv.width = 360; cv.height = 150;
      card.replaceChild(cv, cur); cur = cv;
      cv.style.background = (state.bg && state.bgPreview) ? state.bg : '';
      var ab = card.querySelector('.badge.ae'); if (ab) ab.remove();
    }
    window.HFS_RENDER.renderStyle(cur, st, state.sample || 'HYPER', { mult: state.mult / 100, texture: state.texture, gloss: state.gloss, rim: state.rim, skew: state.skewOn ? state.skew : 0, arc: state.arcOn ? state.arc : 0 });
    card._painted = key;
  }

  function renderGrid() {
    var grid = $('grid');
    var list = sorted(LIB.filter(matches));
    grid.innerHTML = '';
    list.forEach(function (st) {
      var card = cardById[st.id] || (cardById[st.id] = makeCard(st));
      grid.appendChild(card);
      if (ai.reasons[st.id]) card.title = '✨ ' + ai.reasons[st.id] + '\n' + st.name; 
      observer.unobserve(card); observer.observe(card);
    });
    $('empty').hidden = list.length > 0;
    renderGrid.list = list;
    if (typeof updateBadges === 'function') updateBadges();
  }
  // Painting is queued and spread over animation frames (~10 ms per frame), so scrolling and
  // typing stay smooth. Off-screen cards keep their picture; a stale one is repainted when it
  // scrolls into view (paintCard compares the state key).
  var pq = [], pqOn = false;
  function queuePaint(c) {
    if (pq.indexOf(c) < 0) pq.push(c);
    if (!pqOn) { pqOn = true; requestAnimationFrame(drainPaint); }
  }
  function drainPaint() {
    var t0 = performance.now();
    while (pq.length && performance.now() - t0 < 10) { var c = pq.shift(); if (c.isConnected && inView(c)) paintCard(c); }
    if (pq.length) requestAnimationFrame(drainPaint); else pqOn = false;
  }
  function repaintVisible() {
    Object.keys(cardById).forEach(function (id) { var c = cardById[id]; if (c.isConnected && inView(c)) queuePaint(c); });
  }

  function toggleFav(id, btn) {
    var i = state.fav.indexOf(id);
    if (i >= 0) state.fav.splice(i, 1); else state.fav.push(id);
    save('fav', state.fav);
    btn.classList.toggle('fav', i < 0);
    if (state.favOnly) renderGrid();
  }

  // ---------- actions ----------
  function explain(code) {
    return { nocomp: 'Відкрийте композицію', notext: 'Виділіть текстовий шар', nocep: 'Поза After Effects — застосування недоступне' }[code] || code;
  }
  function applyStyle(st, card) {
    if (busy) return;
    if (!inCEP) { status(explain('nocep'), 'err'); lastMsg = Date.now(); return; }
    var opts = asciiJSON({ mult: state.mult / 100, applyFont: state.applyFont, lite: state.lite, texture: state.texture, gloss: state.gloss, rim: state.rim });
    status('Застосовую «' + st.name + '»…');
    jsx('hfs_apply(' + payload(st) + ',' + opts + ')').then(function (r) {
      var p = String(r).split('|');
      lastMsg = Date.now();
      if (p[0] === 'ok') {
        state.use[st.id] = (state.use[st.id] || 0) + 1; save('use', state.use);
        state.recent = [st.id].concat(state.recent.filter(function (x) { return x !== st.id; })).slice(0, 40); save('recent', state.recent);
        card.classList.add('applied'); setTimeout(function () { card.classList.remove('applied'); }, 700);
        if (state.skewOn || state.arcOn) sendShape();
        var warn = p[2] ? decodeURIComponent(p[2]) : '';
        lastWarn = warn ? st.name + ': ' + warn : '';
var soft = warn && warn.split('; ').every(function (x) { return x.indexOf('note:') === 0; });
        if (warn && !soft) { console.warn('[HF Text Styles]', warn); status('Застосовано (' + p[1] + '), є попередження — «Ще» → «Діагностика шару»', 'err'); }
        else status('Застосовано: ' + st.name + ' → ' + p[1] + ' шар(и)' + (p[3] ? ' · ефектів: ' + p[3] : '') + (soft ? ' · сяйво/контур зібрано ефектами' : ''), 'ok');
      } else if (p[0] === 'err') {
        status(explain(p[1]), 'err');
      } else {
        status('Помилка: ' + r, 'err'); console.error(r);
      }
    });
  }

  function clearStyle() {
    if (!inCEP) { status(explain('nocep'), 'err'); return; }
    jsx('hfs_clear()').then(function (r) {
      var p = String(r).split('|'); lastMsg = Date.now();
      if (p[0] === 'ok') status('Стиль прибрано з ' + p[1] + ' шар(ів)', 'ok'); else status(explain(p[1]), 'err');
    });
  }

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  function loadAEList() {
    return jsx('hfs_listPreviews()').then(function (r) {
      if (!r || r === 'nocep' || r.indexOf('|') < 0) return;
      var p = r.split('|');
      aeDir = decodeURIComponent(p[0]);
      aeHave = {};
      (p[1] || '').split('/').forEach(function (n) { if (n) aeHave[n] = true; });
    });
  }

  async function renderAEPreviews() {
    var btn = $('aePrev');
    if (busy) { cancelPreviews = true; return; }
    if (!inCEP) { status(explain('nocep'), 'err'); return; }
    var list = (renderGrid.list || []).filter(function (st) { return !aeHave[aeFile(st)]; });
    if (!list.length) { status('Усі показані стилі вже мають AE-превʼю', 'ok'); return; }
    busy = true; cancelPreviews = false; btn.textContent = 'Стоп'; btn.classList.add('on');
    if (!state.showAE) { state.showAE = true; save('showAE', true); $('showAE').checked = true; }
    try {
      await jsx('hfs_previewBegin(' + asciiJSON(state.sample || 'HYPER') + ')');
      for (var i = 0; i < list.length && !cancelPreviews; i++) {
        var st = list[i], file = aeFile(st);
        $('status').textContent = 'AE-превʼю ' + (i + 1) + '/' + list.length + ': ' + st.name;
        var r = await jsx('hfs_previewOne(' + payload(st) + ',"' + file + '")');
        if (String(r).indexOf('ok') !== 0) { console.warn('preview', st.id, r); continue; }
        for (var t = 0; t < 60; t++) { if ((await jsx('hfs_fileReady("' + file + '")')) === '1') break; await sleep(100); }
        await sleep(80);
        aeHave[file] = true;
        var card = cardById[st.id]; if (card && card.isConnected) { card._painted = ''; paintCard(card); }
      }
    } finally {
      await jsx('hfs_previewEnd()');
      busy = false; btn.textContent = 'Рендер AE'; btn.classList.remove('on');
      lastMsg = Date.now();
      status(cancelPreviews ? 'Зупинено' : 'AE-превʼю готові', 'ok');
    }
  }

  // ---------- wiring ----------
  function debounce(fn, ms) { var t; return function () { clearTimeout(t); t = setTimeout(fn, ms); }; }

  function init() {
    $('sample').value = state.sample;
    $('sort').value = state.sort;
    $('mult').value = state.mult; $('multVal').textContent = state.mult + '%';
    $('applyFont').checked = state.applyFont; $('lite').checked = state.lite;
    $('showAE').checked = state.showAE;
    $('texture').value = state.texture; $('gloss').value = state.gloss; $('rim').value = state.rim;

    $('q').addEventListener('input', debounce(function () { state.q = $('q').value.trim(); renderGrid(); }, 120));
    $('sample').addEventListener('input', debounce(function () { state.sample = $('sample').value; save('sample', state.sample); repaintVisible(); }, 200));
    $('sort').addEventListener('change', function () { state.sort = $('sort').value; save('sort', state.sort); renderGrid(); });
    $('mult').addEventListener('input', function () { state.mult = +$('mult').value; $('multVal').textContent = state.mult + '%'; });
    $('mult').addEventListener('change', function () { save('mult', state.mult); repaintVisible(); });
    $('bgHex').value = state.bg || '';
    if (state.bg) { $('bgPick').value = state.bg; $('bg2Hex').value = state.bg; $('bg2Pick').value = state.bg; }
    $('bgOpts').hidden = !state.bg;
    $('bgPreview').checked = state.bgPreview;
    $('fgHex').value = state.fg; $('fgPick').value = state.fg;
    $('bgPick').addEventListener('input', function () { setBg($('bgPick').value); });
    $('bgHex').addEventListener('change', function () { setBg($('bgHex').value); });
    $('bgEye').addEventListener('click', function () { eyedrop(function (h) { setBg(h, 'Фон ' + h); }); });
    $('bgComp').addEventListener('click', sampleFromComp);
    $('bgClear').addEventListener('click', function () { setBg(''); status('Фон прибрано'); lastMsg = Date.now(); });
    $('readOnly').addEventListener('change', function () { state.readOnly = $('readOnly').checked; renderGrid(); });
    $('bgPreview').addEventListener('change', function () { state.bgPreview = $('bgPreview').checked; save('bgPreview', state.bgPreview); updateBadges(); });
    $('checkerTog').addEventListener('click', function () { var h = !$('checker').hidden; $('checker').hidden = h; $('checkerTog').classList.toggle('on', !h); updateChecker(); });
    $('fgPick').addEventListener('input', function () { setFg($('fgPick').value); });
    $('fgHex').addEventListener('change', function () { setFg($('fgHex').value); });
    $('fgEye').addEventListener('click', function () { eyedrop(setFg); });
    $('bg2Pick').addEventListener('input', function () { $('bg2Hex').value = $('bg2Pick').value; updateChecker(); });
    $('bg2Hex').addEventListener('change', function () { var h = normHex($('bg2Hex').value); if (h) { $('bg2Pick').value = h; updateChecker(); } });
    $('swap').addEventListener('click', function () { var f = state.fg, b = normHex($('bg2Hex').value) || '#1e1e1e'; $('bg2Hex').value = f; $('bg2Pick').value = f; setFg(b); });
    $('skewOn').checked = state.skewOn; $('skew').value = state.skew; $('arcOn').checked = state.arcOn; $('arc').value = state.arc;
    $('skewVal').textContent = state.skew + '°'; $('arcVal').textContent = state.arc + '°';
    $('skewOn').addEventListener('change', function () { state.skewOn = $('skewOn').checked; shapeChanged(true); });
    $('arcOn').addEventListener('change', function () { state.arcOn = $('arcOn').checked; shapeChanged(true); });
    $('skew').addEventListener('input', function () { state.skew = +$('skew').value; $('skewVal').textContent = state.skew + '°'; });
    $('arc').addEventListener('input', function () { state.arc = +$('arc').value; $('arcVal').textContent = state.arc + '°'; });
    $('skew').addEventListener('change', function () { if (!state.skewOn) { state.skewOn = true; $('skewOn').checked = true; } shapeChanged(true); });
    $('arc').addEventListener('change', function () { if (!state.arcOn) { state.arcOn = true; $('arcOn').checked = true; } shapeChanged(true); });
    $('aiBtn').addEventListener('click', runGemini);
    $('aiCfg').addEventListener('click', openAiCfg);
    $('aiCfgClose').addEventListener('click', function () { $('aiCfgBox').hidden = true; });
    $('aiCfgSave').addEventListener('click', saveAiCfg);
    $('aiModels').addEventListener('click', loadModels);
    $('aiClose').addEventListener('click', function () { $('aiBox').hidden = true; if (state.aiOnly) { state.aiOnly = false; $('aiOnly').checked = false; renderGrid(); } });
    $('aiOnly').addEventListener('change', function () { state.aiOnly = $('aiOnly').checked; renderGrid(); });
    $('rim').addEventListener('change', function () { state.rim = $('rim').value; save('rim', state.rim); repaintVisible(); });
    $('gloss').addEventListener('change', function () { state.gloss = $('gloss').value; save('gloss', state.gloss); repaintVisible(); });
    $('texture').addEventListener('change', function () { state.texture = $('texture').value; save('texture', state.texture); repaintVisible(); });
    $('showAE').addEventListener('change', function () { state.showAE = $('showAE').checked; save('showAE', state.showAE); Object.keys(cardById).forEach(function (id) { cardById[id]._painted = ''; }); repaintVisible(); });
    $('lite').addEventListener('change', function () { state.lite = $('lite').checked; save('lite', state.lite); });
    $('applyFont').addEventListener('change', function () { state.applyFont = $('applyFont').checked; save('applyFont', state.applyFont); });
    $('favOnly').addEventListener('click', function () { state.favOnly = !state.favOnly; $('favOnly').classList.toggle('on', state.favOnly); renderGrid(); });
    $('clear').addEventListener('click', clearStyle);
    $('diag').addEventListener('click', function () {
      jsx('hfs_diag()').then(function (r) {
        $('diagText').value = (r === 'nocep' ? 'Поза After Effects' : decodeURIComponent(r)) + '\n\nwarnings: ' + (lastWarn || '—');
        $('diagBox').hidden = false;
      });
    });
    $('diagClose').addEventListener('click', function () { $('diagBox').hidden = true; });
    $('diagCopy').addEventListener('click', function () {
      $('diagText').select(); document.execCommand('copy'); $('diagCopy').textContent = 'Скопійовано';
      setTimeout(function () { $('diagCopy').textContent = 'Копіювати'; }, 1200);
    });
    $('aePrev').addEventListener('click', renderAEPreviews);
    $('grid').addEventListener('scroll', debounce(repaintVisible, 60));
    seg('dim', 'dim'); seg('weight', 'weight');

    buildChips(); buildColors(); renderGrid();
    loadAEList().then(function () { Object.keys(cardById).forEach(function (id) { cardById[id]._painted = ''; }); repaintVisible(); });
    refreshSelection();
    setInterval(function () { if (!document.hidden) refreshSelection(); }, 2500);
  }
  window.__hfsDebug = { thinkingFor: thinkingFor, aiCandidates: aiCandidates, ai: ai, buildPrompt: buildPrompt, describe: describe, pickDefaultModel: pickDefaultModel };
  init();
})();
