/*
 * HF Text Styles — style library.
 *
 * All sizes are in "em" = fraction of the text layer's font size, so a style looks
 * the same on 40 px and on 400 px text. Angles use the After Effects Drop Shadow
 * convention: degrees clockwise from "up" (135 = down-right, 180 = straight down).
 *   - extrude.dir / hard[].dir / ls.shadow.dir / ls.innerShadow.dir = direction the shadow goes
 *   - bevelFx.light / ls.bevel.light                                = direction the light comes FROM
 *
 * face.gradient: 2 colours -> Gradient Ramp; 3–5 colours (evenly spaced, top -> bottom) ->
 * Gradient Ramp (white -> black) + CC Toner in Pentone mode, which maps brightness to 5 colours.
 *
 * texture: { type: 'glitter' | 'live' | 'flakes' | 'brushed', amount: 0-100, size: em }
 *   AE: Noise HLS (Auto for 'live') [+ Mosaic for flakes | + Directional Blur for brushed],
 *   placed before Set Matte so it stays inside the letters.
 *
 * face.horizon (with exactly 4 colours: top, above horizon, below horizon, bottom): chrome horizon.
 * rim may also be a list of rims (outline after outline, inner first); flat: true = one plain ring.
 * rim: { w, hi, mid, lo } — glossy bevelled rim around the face: 2 rings × 8 Drop Shadows shaded by direction.
 * extrude.stops: optional colour bands along the extrusion (metal sides).
 * post: list applied after extrusion and hard shadows, in order — rims ({ w, ... }) and extrusions
 *   ({ depth, dir, near, far }) wrapped around everything built so far (outlined 3D lettering).
 * gloss: { type: 'streaks' | 'soft', color? } — CC Light Sweep bands on the face (after Set Matte).
 *
 * Render pipeline (identical in AE and in the panel preview):
 *   text fill + text stroke  ->  gradient (Ramp + Set Matte)  ->  Bevel Alpha (face only)
 *   ->  extrusion (stacked Drop Shadows)  ->  hard shadows (Drop Shadow effects)
 *   ->  layer styles: drop shadow, outer glow, inner glow/shadow, bevel, stroke (around everything)
 */
(function (root) {
  'use strict';

  // ---------- colour helpers ----------
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function hexToRgb(h) { h = h.replace('#', ''); return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)]; }
  function rgbToHex(r) { return '#' + r.map(function (v) { v = Math.round(clamp(v, 0, 255)).toString(16); return v.length < 2 ? '0' + v : v; }).join(''); }
  function mix(a, b, t) { var x = hexToRgb(a), y = hexToRgb(b); return rgbToHex([0, 1, 2].map(function (i) { return x[i] + (y[i] - x[i]) * t; })); }
  function dark(h, t) { return mix(h, '#000000', t); }
  function light(h, t) { return mix(h, '#ffffff', t); }
  function hueOf(h) {
    var c = hexToRgb(h).map(function (v) { return v / 255; });
    var mx = Math.max.apply(null, c), mn = Math.min.apply(null, c), d = mx - mn, hh = 0;
    var l = (mx + mn) / 2, s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1));
    if (d !== 0) {
      if (mx === c[0]) hh = ((c[1] - c[2]) / d) % 6;
      else if (mx === c[1]) hh = (c[2] - c[0]) / d + 2;
      else hh = (c[0] - c[1]) / d + 4;
      hh *= 60; if (hh < 0) hh += 360;
    }
    return { h: hh, s: s, l: l };
  }

  // Any list of evenly spaced colours -> 5 evenly spaced colours (CC Toner "Pentone" slots)
  function resample5(cols) {
    var out = [], n = cols.length - 1;
    for (var i = 0; i < 5; i++) {
      var t = i / 4 * n, k = Math.min(n - 1, Math.floor(t));
      out.push(mix(cols[k], cols[k + 1], t - k));
    }
    return out;
  }

  // Colour bucket for the colour filter
  function colorBucket(h) {
    var c = hueOf(h);
    if (c.s < 0.18 || c.l > 0.93 || c.l < 0.1) {
      if (c.l > 0.7) return 'white';
      if (c.l < 0.25) return 'black';
      return 'silver';
    }
    var x = c.h;
    if (x < 15 || x >= 340) return 'red';
    if (x < 38) return 'orange';
    if (x < 65) return 'yellow';
    if (x < 160) return 'green';
    if (x < 200) return 'cyan';
    if (x < 255) return 'blue';
    if (x < 295) return 'purple';
    return 'pink';
  }

  var FONTS = {
    black: { ps: 'Arial-Black', css: '"Arial Black", "Arial Bold", "DejaVu Sans", sans-serif', label: 'Arial Black' },
    impact: { ps: 'Impact', css: 'Impact, "Arial Black", "DejaVu Sans Condensed", sans-serif', label: 'Impact' },
    comic: { ps: 'ComicSansMS-Bold', css: '"Comic Sans MS", "Comic Sans", "Arial Black", "DejaVu Sans", sans-serif', label: 'Comic Sans MS Bold' },
    segoe: { ps: 'SegoeUI-Black', css: '"Segoe UI Black", "Arial Black", "DejaVu Sans", sans-serif', label: 'Segoe UI Black' }
  };

  // ---------- recipes ----------
  // Each recipe: (palette) -> partial style. Palettes are arrays of objects.
  var R = [];
  function recipe(id, name, cat, tags, font, palettes, fn) { R.push({ id: id, name: name, cat: cat, tags: tags, font: font, palettes: palettes, fn: fn }); }

  // ── Слоти / казино ───────────────────────────────────────
  var GOLD5 = ['#fff6c2', '#ffd03d', '#b8740a', '#ffdc6b', '#9a5a00'];
  recipe('slot-purple-gold', 'Фіолет із золотом', 'slots', ['слоти', 'казино', 'бонус', 'золото', 'фіолетовий', '3d'], 'black',
    [{ n: 'Аметист', g: ['#f1d6ff', '#b45cff', '#5b13b8'], o: '#1c0533' },
     { n: 'Рубін', g: ['#ffd6dc', '#ff3d5a', '#8a0018'], o: '#2e0008' },
     { n: 'Сапфір', g: ['#d6ecff', '#3d8bff', '#0b2f8a'], o: '#030f33' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.02, light: -40, intensity: 0.45 }, extrude: { depth: 0.11, dir: 170, near: '#ffc43d', far: '#7a4200' }, ls: { stroke: { color: '#ffd45a', w: 0.03 }, shadow: { color: '#000000', opacity: 55, dir: 170, dist: 0.06, size: 0.12, spread: 0 } } }; });

  recipe('slot-gold-purple', 'Золото на фіолетовому обʼємі', 'slots', ['слоти', 'казино', 'золото', 'shop now', '3d'], 'impact',
    [{ n: 'Фіолет', e: '#7a2fd6', f: '#24074f' }, { n: 'Червоний', e: '#d42a2a', f: '#4a0505' }, { n: 'Синій', e: '#2f5bd6', f: '#071a4f' }],
    function (p) { return { face: { gradient: ['#fff3b0', '#ffc533', '#d98a0a', '#ffd76b'], angle: 90 }, bevelFx: { t: 0.02, light: -45, intensity: 0.5 }, extrude: { depth: 0.15, dir: 160, near: p.e, far: p.f }, ls: { stroke: { color: '#2a1300', w: 0.015 }, shadow: { color: '#000000', opacity: 50, dir: 160, dist: 0.08, size: 0.14, spread: 0 } } }; });

  recipe('slot-lucky-gold', 'Lucky Gold', 'slots', ['слоти', 'казино', 'золото', 'метал', 'lucky'], 'impact',
    [{ n: 'Червоний край', e: '#c42200', f: '#4a0800' }, { n: 'Коричневий край', e: '#8a4a10', f: '#2e1300' }],
    function (p) { return { face: { gradient: GOLD5, angle: 90 }, extrude: { depth: 0.07, dir: 175, near: p.e, far: p.f }, ls: { bevel: { size: 0.035, depth: 180, light: -40, hlOp: 70, shOp: 40, chisel: true }, stroke: { color: '#2b1200', w: 0.02 }, shadow: { color: '#000000', opacity: 60, dir: 175, dist: 0.05, size: 0.1, spread: 0 } } }; });

  recipe('slot-win-magenta', 'WIN Маджента', 'slots', ['слоти', 'казино', 'виграш', 'win', 'рожевий', 'золото'], 'impact',
    [{ n: 'Маджента', g: ['#ffc4ff', '#e040ff', '#8f0fc0'] }, { n: 'Рожевий', g: ['#ffd1ea', '#ff4fa8', '#b0105a'] }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, extrude: { depth: 0.09, dir: 165, near: '#ffb02e', far: '#7a2e00' }, ls: { stroke: { color: '#ffd45a', w: 0.03 }, shadow: { color: '#000000', opacity: 55, dir: 165, dist: 0.07, size: 0.14, spread: 0 } } }; });

  recipe('slot-arcade', 'Аркадний неон', 'slots', ['слоти', 'аркада', 'неон', 'бонус', 'ретро'], 'segoe',
    [{ n: 'Лаванда', g: ['#fff0ff', '#e08cff', '#9a3dff'], gl: '#d14dff', e: '#3a0b6b' }, { n: 'Блакитний', g: ['#f0ffff', '#7fe8ff', '#2f8bff'], gl: '#2ee6ff', e: '#06265e' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, extrude: { depth: 0.06, dir: 175, near: p.e, far: dark(p.e, 0.5) }, ls: { innerGlow: { color: '#ffffff', opacity: 60, size: 0.035 }, glow: { color: p.gl, opacity: 85, size: 0.28, spread: 0 } } }; });

  recipe('slot-bubble', 'Бульбашковий бонус', 'slots', ['слоти', 'бонус', 'жовтий', 'мультяшний', '3d'], 'black',
    [{ n: 'Жовтий', g: ['#fffcc2', '#ffe81f', '#ffc400'], e: '#ff8a00', f: '#a34400' }, { n: 'Лайм', g: ['#f4ffc2', '#c8ff1f', '#7ad400'], e: '#3d9900', f: '#154400' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.03, light: -45, intensity: 0.5 }, extrude: { depth: 0.1, dir: 180, near: p.e, far: p.f }, ls: { shadow: { color: '#000000', opacity: 50, dir: 180, dist: 0.06, size: 0.14, spread: 0 } } }; });

  recipe('slot-red-gold', 'Червоний джекпот', 'slots', ['слоти', 'казино', 'джекпот', 'червоний', 'золото', '3d'], 'impact',
    [{ n: 'Класика', g: ['#ff8a7a', '#e01414', '#7a0000'] }, { n: 'Вишня', g: ['#ff9ac0', '#d4104f', '#5c0022'] }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.015, light: -45, intensity: 0.4 }, extrude: { depth: 0.1, dir: 165, near: '#ffbf3d', far: '#6b3500' }, ls: { stroke: { color: '#ffd45a', w: 0.03 }, shadow: { color: '#000000', opacity: 55, dir: 165, dist: 0.06, size: 0.12, spread: 0 } } }; });

  recipe('slot-coins', 'Монетний джекпот', 'slots', ['слоти', 'казино', 'джекпот', 'сяйво', 'помаранчевий'], 'black',
    [{ n: 'Помаранч', g: ['#fff6cc', '#ffc04d', '#ff7a00'], gl: '#ff9a1f' }, { n: 'Сонячний', g: ['#ffffe0', '#ffe14d', '#ffaa00'], gl: '#ffd21f' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, extrude: { depth: 0.13, dir: 178, near: '#8a3a00', far: '#2e1000' }, ls: { innerGlow: { color: '#ffffff', opacity: 55, size: 0.03 }, stroke: { color: '#fff2c4', w: 0.018 }, glow: { color: p.gl, opacity: 80, size: 0.3, spread: 0 } } }; });

  recipe('slot-emerald', 'Смарагд із золотом', 'slots', ['слоти', 'казино', 'lucky', 'зелений', 'золото'], 'black',
    [{ n: 'Смарагд', g: ['#d9ffb0', '#2fcf3a', '#0a6b1c'] }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, extrude: { depth: 0.05, dir: 175, near: '#0a4a14', far: '#021a06' }, ls: { stroke: { color: '#ffd45a', w: 0.03 }, glow: { color: '#5aff6a', opacity: 55, size: 0.22, spread: 0 } } }; });

  recipe('slot-combo', 'Жовтий на фіолеті', 'slots', ['слоти', 'комбо', 'жовтий', 'фіолетовий', 'гра'], 'impact',
    [{ n: 'Combo', e: '#c040ff', f: '#3a0b7a' }, { n: 'Синій низ', e: '#3d6bff', f: '#0b1f6b' }],
    function (p) { return { face: { gradient: ['#fff8b8', '#ffd21f', '#ffa600'], angle: 90 }, bevelFx: { t: 0.015, light: -45, intensity: 0.4 }, extrude: { depth: 0.08, dir: 170, near: p.e, far: p.f } }; });

  recipe('slot-vegas', 'Вегас-вивіска', 'slots', ['слоти', 'вегас', 'неон', 'сяйво', 'win'], 'impact',
    [{ n: 'Помаранч', g: ['#fff2a8', '#ffb01f', '#ff5a00'], gl: '#ff7a1a', e: '#8a1c00' }, { n: 'Рожевий', g: ['#ffe0f4', '#ff6bc8', '#d4108a'], gl: '#ff3db8', e: '#5c0040' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, extrude: { depth: 0.18, dir: 180, near: p.e, far: dark(p.e, 0.6) }, ls: { innerGlow: { color: '#ffffff', opacity: 50, size: 0.025 }, glow: { color: p.gl, opacity: 90, size: 0.25, spread: 0 } } }; });

  recipe('slot-deluxe', 'Deluxe', 'slots', ['слоти', 'казино', 'преміум', 'жовтий', 'сяйво'], 'black',
    [{ n: 'Золотий', g: ['#fffde6', '#ffe14d', '#ffb300'] }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, extrude: { depth: 0.05, dir: 175, near: '#b36b00', far: '#5a3000' }, ls: { stroke: { color: '#6b3400', w: 0.018 }, glow: { color: '#fff1a3', opacity: 70, size: 0.25, spread: 0 } } }; });

  recipe('slot-bonus-outline', 'Бонус з товстим контуром', 'slots', ['слоти', 'бонус', 'обводка', 'помаранчевий', 'фіолетовий'], 'black',
    [{ n: 'Фіолетовий контур', g: ['#ffe94d', '#ff8a00', '#ff4d00'], o: '#3a0a5c' }, { n: 'Синій контур', g: ['#ffe94d', '#ff8a00', '#ff4d00'], o: '#0a1f5c' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, extrude: { depth: 0.05, dir: 180, near: dark(p.o, 0.2), far: dark(p.o, 0.6) }, ls: { stroke: { color: p.o, w: 0.06 }, shadow: { color: '#000000', opacity: 50, dir: 180, dist: 0.05, size: 0.1, spread: 0 } } }; });

  recipe('slot-double-outline', 'Подвійний контур', 'slots', ['слоти', 'бонус', 'подвійна обводка', 'помаранчевий'], 'black',
    [{ n: 'Помаранч', g: ['#ffb84d'], i: '#3a1200', o: '#ff7a1a' }, { n: 'Рожевий', g: ['#ffa8d9'], i: '#3a0020', o: '#ff3d9a' }],
    function (p) { return { face: { fill: p.g[0] }, tstroke: { color: p.i, w: 0.035 }, bevelFx: { t: 0.02, light: -45, intensity: 0.35 }, ls: { stroke: { color: p.o, w: 0.05 }, shadow: { color: '#000000', opacity: 55, dir: 175, dist: 0.04, size: 0.1, spread: 0 } } }; });

  recipe('slot-jackpot-chrome', 'Золотий хром джекпот', 'slots', ['слоти', 'джекпот', 'золото', 'метал', 'хром'], 'impact',
    [{ n: 'Золото', g: ['#fffbe0', '#ffd66b', '#8a4a00', '#f2b33d', '#fff0c4'] }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, extrude: { depth: 0.06, dir: 175, near: '#6b3000', far: '#1f0c00' }, ls: { bevel: { size: 0.03, depth: 200, light: -40, hlOp: 80, shOp: 40, chisel: true }, innerGlow: { color: '#fff7d6', opacity: 45, size: 0.03 }, glow: { color: '#ffb84d', opacity: 55, size: 0.22, spread: 0 } } }; });

  recipe('slot-glitter', 'Блискітки з золотом', 'slots', ['слоти', 'казино', 'блискітки', 'глітер', 'текстура', 'золото', '3d'], 'black',
    [{ n: 'Фіолетові', g: ['#f0d1ff', '#a63dff', '#4a0c99'] }, { n: 'Червоні', g: ['#ffc4cc', '#ff2b48', '#7a0014'] },
     { n: 'Сині', g: ['#cfe6ff', '#2f7bff', '#0a2580'] }, { n: 'Рожеві', g: ['#ffd1f0', '#ff3db8', '#8a0a5c'] }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, texture: { type: 'glitter', amount: 55, size: 0.02 }, bevelFx: { t: 0.02, light: -40, intensity: 0.5 }, extrude: { depth: 0.1, dir: 170, near: '#ffc43d', far: '#7a4200' }, ls: { stroke: { color: '#ffd45a', w: 0.03 }, shadow: { color: '#000000', opacity: 55, dir: 170, dist: 0.06, size: 0.12, spread: 0 } } }; });

  recipe('slot-sequins', 'Пайетки', 'slots', ['слоти', 'казино', 'пайетки', 'блискітки', 'текстура', 'гламур'], 'black',
    [{ n: 'Золоті', g: ['#fff4c2', '#ffc93d', '#b8740a'], o: '#3d2300' }, { n: 'Рожеві', g: ['#ffe0f4', '#ff6bc8', '#b0105a'], o: '#3a0020' },
     { n: 'Срібні', g: ['#ffffff', '#c3ccd6', '#5c6878'], o: '#1c2128' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, texture: { type: 'flakes', amount: 40, size: 0.04 }, bevelFx: { t: 0.025, light: -40, intensity: 0.5 }, extrude: { depth: 0.06, dir: 175, near: dark(p.g[2], 0.3), far: p.o }, ls: { stroke: { color: p.o, w: 0.025 }, glow: { color: p.g[1], opacity: 45, size: 0.2, spread: 0 } } }; });

  recipe('slot-brushed', 'Брашований метал', 'slots', ['слоти', 'метал', 'брашований', 'текстура', 'преміум'], 'impact',
    [{ n: 'Золото', g: ['#fff6c9', '#f2c14e', '#9a6510', '#f7d57a', '#b07818'], o: '#3d2300' },
     { n: 'Сталь', g: ['#ffffff', '#c9d1da', '#4c5663', '#e3e8ee', '#7c8794'], o: '#1c2128' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, texture: { type: 'brushed', amount: 35, size: 0.4 }, extrude: { depth: 0.07, dir: 175, near: dark(p.g[2], 0.2), far: p.o }, ls: { bevel: { size: 0.03, depth: 160, light: -40, hlOp: 70, shOp: 40, chisel: true }, stroke: { color: p.o, w: 0.02 }, shadow: { color: '#000000', opacity: 55, dir: 175, dist: 0.05, size: 0.1, spread: 0 } } }; });

  recipe('slot-live-glitter', 'Живі блискітки', 'slots', ['слоти', 'казино', 'блискітки', 'анімація', 'мерехтіння', 'текстура'], 'black',
    [{ n: 'Золото', g: ['#fff8d2', '#ffd03d', '#c27c0a'], e: '#7a2fd6', f: '#24074f' }, { n: 'Маджента', g: ['#ffd1ff', '#e040ff', '#7a0fa8'], e: '#ffb02e', f: '#7a2e00' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, texture: { type: 'live', amount: 55, size: 0.02 }, bevelFx: { t: 0.02, light: -40, intensity: 0.45 }, extrude: { depth: 0.12, dir: 165, near: p.e, far: p.f }, ls: { shadow: { color: '#000000', opacity: 55, dir: 165, dist: 0.07, size: 0.14, spread: 0 } } }; });

  // ── Слоти, хвиля 2 ───────────────────────────────────────
  recipe('slot-deep-3d', 'Глибокий 3D', 'slots', ['слоти', 'акція', 'offer', 'глибокий', '3d', 'обʼєм'], 'impact',
    [{ n: 'Золото / маджента', g: ['#fff3a8', '#ffc21f', '#ff8a00'], rim: '#ff3db8', e: '#c2187a', f: '#3a0526' },
     { n: 'Помаранч / бордо', g: ['#fff0b0', '#ffb01f', '#ff6a00'], rim: '#ffe066', e: '#a3330a', f: '#2e0a00' },
     { n: 'Блакитний / синій', g: ['#e6ffff', '#5fe0ff', '#1f8bff'], rim: '#ffffff', e: '#1a3fb0', f: '#050f3a' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.015, light: -40, intensity: 0.35 }, extrude: { depth: 0.3, dir: 168, near: p.e, far: p.f }, ls: { stroke: { color: p.rim, w: 0.022 }, shadow: { color: '#000000', opacity: 50, dir: 168, dist: 0.08, size: 0.16, spread: 0 } } }; });

  recipe('slot-two-tone', 'Двоколірний обʼєм', 'slots', ['слоти', 'арена', 'гра', '3d', 'обʼєм', 'світлий край'], 'impact',
    [{ n: 'Жовтий / фіолет', g: ['#fffbd1', '#ffe94d', '#ffc21f'], e1: '#d9c2ff', e2: '#3d0f8a' },
     { n: 'Золото / лаванда', g: ['#fff6c9', '#f2c14e', '#b8740a'], e1: '#f2e6ff', e2: '#4a1f7a' },
     { n: 'Білий / синій', g: ['#ffffff', '#e6f0ff', '#b8d0ff'], e1: '#9ec2ff', e2: '#0b1f6b' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, extrude: { depth: 0.12, dir: 170, near: p.e1, far: p.e2 }, ls: { stroke: { color: '#ffffff', w: 0.015 }, shadow: { color: '#000000', opacity: 55, dir: 170, dist: 0.06, size: 0.12, spread: 0 } } }; });

  recipe('slot-glossy', 'Глянцевий хром', 'slots', ['слоти', 'казино', 'глянець', 'хром', 'багатоколірний', '3d'], 'black',
    [{ n: 'Рожевий', g: ['#ffe0f8', '#ff8ae0', '#b8178f', '#ff6fd0', '#ffd6f3'] },
     { n: 'Фіолетовий', g: ['#f6e0ff', '#c56bff', '#4a0f7a', '#b45cff', '#f0d1ff'] },
     { n: 'Червоний', g: ['#ffe0d6', '#ff6b4d', '#8a0a00', '#ff5a3d', '#ffd1c4'] },
     { n: 'Срібний', g: ['#ffffff', '#d6dde6', '#4c5663', '#c3ccd6', '#ffffff'] }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, extrude: { depth: 0.1, dir: 172, near: '#ffcf4d', far: '#6b3500' }, ls: { stroke: { color: '#ffd45a', w: 0.028 }, shadow: { color: '#000000', opacity: 55, dir: 172, dist: 0.06, size: 0.12, spread: 0 } } }; });

  recipe('slot-red-neon', 'Червоне сяйво', 'slots', ['слоти', 'казино', 'неон', 'сяйво', 'червоний'], 'impact',
    [{ n: 'Червоний', g: ['#ff8a5c', '#e01414', '#6b0000'], rim: '#ffd21f', gl: '#ff3d00' },
     { n: 'Маджента', g: ['#ff8ae0', '#d4108a', '#5c0040'], rim: '#ffd1f0', gl: '#ff3db8' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, extrude: { depth: 0.1, dir: 180, near: '#5c0000', far: '#1a0000' }, ls: { stroke: { color: p.rim, w: 0.02 }, glow: { color: p.gl, opacity: 90, size: 0.3, spread: 0 } } }; });

  recipe('slot-vegas-pink', 'Vegas рожевий із золотом', 'slots', ['слоти', 'вегас', 'джекпот', 'рожевий', 'золото', '3d'], 'impact',
    [{ n: 'Захід', g: ['#ffe0f6', '#ff7ad9', '#a32bb8'] }, { n: 'Аметист', g: ['#f2e0ff', '#b97aff', '#5a1fa8'] }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.02, light: -40, intensity: 0.4 }, extrude: { depth: 0.12, dir: 175, near: '#ffd45a', far: '#7a4200' }, ls: { stroke: { color: '#fff1b0', w: 0.018 }, shadow: { color: '#000000', opacity: 55, dir: 175, dist: 0.07, size: 0.14, spread: 0 } } }; });

  recipe('slot-cards', 'Карткова гра', 'slots', ['слоти', 'карти', 'пасьянс', 'гра', 'подвійна обводка'], 'black',
    [{ n: 'Фіолет / помаранч', a: '#8a3dff', i: '#ffffff', o: '#ff9a1f', s: '#3a0b7a' },
     { n: 'Темний / золото', a: '#2a2340', i: '#ffffff', o: '#ffc21f', s: '#120c24' },
     { n: 'Зелений / жовтий', a: '#1fae4a', i: '#ffffff', o: '#ffd21f', s: '#0a3a18' }],
    function (p) { return { face: { fill: p.a }, tstroke: { color: p.i, w: 0.045 }, bevelFx: { t: 0.02, light: -45, intensity: 0.35 }, ls: { stroke: { color: p.o, w: 0.06 } }, hard: [{ color: p.s, dir: 175, dist: 0.06, soft: 0, opacity: 100 }] }; });

  recipe('slot-sunset-3d', 'Захід 3D', 'slots', ['слоти', 'казино', 'коктейль', 'гра', 'градієнт', 'багатоколірний', '3d'], 'impact',
    [{ n: 'Помаранч / рожевий', g: ['#ffe066', '#ff9a3d', '#ff4fa3'], e: '#6b1fb8', f: '#1f0646', o: '#fff1d6' },
     { n: 'Жовтий / помаранч', g: ['#fff7a8', '#ffb01f', '#ff5a1f'], e: '#7a1fa8', f: '#22063a', o: '#3a0b4a' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.015, light: -40, intensity: 0.35 }, extrude: { depth: 0.1, dir: 168, near: p.e, far: p.f }, ls: { stroke: { color: p.o, w: 0.02 }, shadow: { color: '#000000', opacity: 50, dir: 168, dist: 0.06, size: 0.12, spread: 0 } } }; });

  recipe('slot-fire-3d', 'Вогняний 3D', 'slots', ['слоти', 'lucky', 'вогонь', 'червоний', 'градієнт', '3d'], 'black',
    [{ n: 'Класика', g: ['#ffe94d', '#ff9a1f', '#ff3d1f', '#c40a0a'] }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.02, light: -40, intensity: 0.4 }, extrude: { depth: 0.1, dir: 180, near: '#8a0a00', far: '#2a0000' }, ls: { stroke: { color: '#3a0000', w: 0.02 }, glow: { color: '#ff7a1a', opacity: 40, size: 0.2, spread: 0 } } }; });

  recipe('slot-cartoon', 'Мультяшний бонус', 'slots', ['слоти', 'бонус', 'нагорода', 'мультяшний', 'обводка', '3d'], 'black',
    [{ n: 'Фіолет / жовтий', g: ['#c9a8ff', '#8a4dff', '#5a1fd6'], o: '#ffd21f', e: '#2a0b6b' },
     { n: 'Помаранч / білий', g: ['#ffe066', '#ffa21f', '#ff6a00'], o: '#ffffff', e: '#a33a00' },
     { n: 'Блакитний / жовтий', g: ['#c4f5ff', '#3dc8ff', '#1f7aff'], o: '#ffe94d', e: '#0b2f80' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.03, light: -45, intensity: 0.45 }, extrude: { depth: 0.08, dir: 180, near: p.e, far: dark(p.e, 0.5) }, ls: { stroke: { color: p.o, w: 0.05 }, shadow: { color: '#000000', opacity: 45, dir: 180, dist: 0.06, size: 0.14, spread: 0 } } }; });

  recipe('slot-purple-iso', 'Фіолетовий ізометрик', 'slots', ['слоти', 'гра', 'фіолетовий', 'ізометрія', '3d'], 'impact',
    [{ n: 'Фіолет', g: ['#e6c4ff', '#b05cff', '#7a1fd6'], e: '#4a0f8a', f: '#1a0433' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.02, light: -45, intensity: 0.45 }, extrude: { depth: 0.16, dir: 150, near: p.e, far: p.f }, ls: { stroke: { color: '#f0d9ff', w: 0.012 }, shadow: { color: '#000000', opacity: 50, dir: 150, dist: 0.08, size: 0.15, spread: 0 } } }; });

  recipe('slot-gold-silver', 'Золото і срібло', 'slots', ['слоти', 'казино', 'джекпот', 'золото', 'срібло', 'метал'], 'black',
    [{ n: 'Золото', g: ['#fff3b8', '#ffc533', '#c27c0a', '#ffd76b', '#a35f00'], o: '#3d2300' },
     { n: 'Срібло', g: ['#ffffff', '#e1e6ec', '#7c8794', '#d6dde6', '#9aa4b0'], o: '#1c2128' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, extrude: { depth: 0.05, dir: 175, near: dark(p.g[2], 0.3), far: p.o }, ls: { innerGlow: { color: '#ffffff', opacity: 45, size: 0.025 }, stroke: { color: p.o, w: 0.015 }, shadow: { color: '#000000', opacity: 65, dir: 175, dist: 0.05, size: 0.12, spread: 0 } } }; });

  recipe('slot-gloss', 'Глянцевий казино', 'slots', ['слоти', 'казино', 'глянець', 'відблиски', 'золото', '3d'], 'impact',
    [{ n: 'Червоний', g: ['#ff3d2e', '#c40000', '#7a0000'] }, { n: 'Фіолетовий', g: ['#c86bff', '#7a1fd6', '#3d0a7a'] },
     { n: 'Синій', g: ['#5fa8ff', '#1f4fd6', '#0a1f7a'] }, { n: 'Зелений', g: ['#5fe07a', '#14a33a', '#065c1c'] },
     { n: 'Чорний', g: ['#5c5c66', '#1e1e24', '#08080a'] }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, gloss: { type: 'streaks' }, extrude: { depth: 0.13, dir: 172, near: '#ffe9a8', far: '#9a5a10' }, ls: { innerGlow: { color: '#ffd45a', opacity: 100, size: 0.016, choke: 100 }, stroke: { color: '#ffcf4d', w: 0.022 }, shadow: { color: '#000000', opacity: 60, dir: 172, dist: 0.07, size: 0.16, spread: 0 } } }; });

  recipe('gloss-candy', 'Глянцева карамель', 'game', ['глянець', 'відблиски', 'гра', 'мультяшний', '3d'], 'black',
    [{ n: 'Рожева', g: ['#ffb3e0', '#ff3da8', '#b0106a'] }, { n: 'Помаранчева', g: ['#ffd18a', '#ff8a1f', '#c44a00'] }, { n: 'Бірюзова', g: ['#a8fff0', '#1fd6c2', '#0a7a70'] }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, gloss: { type: 'soft' }, bevelFx: { t: 0.03, light: -45, intensity: 0.5 }, extrude: { depth: 0.08, dir: 180, near: dark(p.g[2], 0.3), far: dark(p.g[2], 0.65) }, ls: { stroke: { color: '#ffffff', w: 0.04 }, shadow: { color: '#000000', opacity: 45, dir: 180, dist: 0.05, size: 0.12, spread: 0 } } }; });

  // ── Хром з горизонтом і глянцевим кантом ─────────────────
  var GOLD_RIM = { w: 0.034, hi: '#fff6b8', mid: '#f0b429', lo: '#6b3d00' };
  var SILVER_RIM = { w: 0.034, hi: '#ffffff', mid: '#aab4c0', lo: '#39424d' };
  var GOLD_SIDE = ['#a86a08', '#5a3200', '#8a5206', '#3a1e00', '#1f0f00'];
  var SILVER_SIDE = ['#8792a0', '#39424d', '#6b7684', '#252c35', '#12161b'];
  recipe('lucky-chrome', 'Lucky хром', 'slots', ['слоти', 'казино', 'lucky', 'хром', 'глянець', 'горизонт', 'золотий кант', '3d'], 'black',
    [{ n: 'Червоний', g: ['#b80000', '#ff3434', '#9a0000', '#cc1a1a'], rim: GOLD_RIM, side: GOLD_SIDE },
     { n: 'Фіолетовий', g: ['#5a0fa8', '#c05cff', '#42087a', '#7a2fd6'], rim: GOLD_RIM, side: GOLD_SIDE },
     { n: 'Синій', g: ['#0a2fa8', '#4d8bff', '#061f7a', '#1f4fd6'], rim: GOLD_RIM, side: GOLD_SIDE },
     { n: 'Зелений', g: ['#0a7a24', '#4de06a', '#065c1a', '#14a33a'], rim: GOLD_RIM, side: GOLD_SIDE },
     { n: 'Чорний', g: ['#26262c', '#7a7a88', '#0c0c10', '#34343c'], rim: GOLD_RIM, side: GOLD_SIDE },
     { n: 'Синій зі сріблом', g: ['#0a2fa8', '#4d8bff', '#061f7a', '#1f4fd6'], rim: SILVER_RIM, side: SILVER_SIDE },
     { n: 'Золото', g: ['#d99a1a', '#fff3b0', '#9a5f00', '#e0a422'], rim: GOLD_RIM, side: GOLD_SIDE }],
    function (p) { return { face: { gradient: p.g, angle: 90, horizon: 0.54 }, rim: p.rim, extrude: { depth: 0.15, dir: 168, near: p.side[0], far: p.side[4], stops: p.side }, ls: { shadow: { color: '#000000', opacity: 65, dir: 168, dist: 0.07, size: 0.16, spread: 0 } } }; });

  // ── Преміум: горизонт + глянцевий кант + металева боковина ──
  var ROSE_RIM = { w: 0.034, hi: '#fff0ec', mid: '#e8998f', lo: '#6b2a24' };
  var BRONZE_RIM = { w: 0.034, hi: '#ffe2c4', mid: '#c97a3a', lo: '#4a1f08' };
  var DARK_RIM = { w: 0.034, hi: '#8a8a99', mid: '#33333d', lo: '#050507' };
  var ROSE_SIDE = ['#a85a52', '#5a2420', '#8a4640', '#3a1512', '#1f0a08'];
  var BRONZE_SIDE = ['#8a4a1c', '#4a2208', '#6b3812', '#2e1404', '#170a02'];
  function sideOf(hex) { return [dark(hex, 0.35), dark(hex, 0.7), dark(hex, 0.45), dark(hex, 0.8), dark(hex, 0.9)]; }
  var PSH = { color: '#000000', opacity: 65, dir: 168, dist: 0.07, size: 0.16, spread: 0 };

  recipe('prem-metal', 'Хром-метал', 'premium', ['преміум', 'метал', 'хром', 'горизонт', 'кант', '3d'], 'black',
    [{ n: 'Золото', g: ['#e0a422', '#fff6c2', '#9a5f00', '#d99a1a'], rim: GOLD_RIM, side: GOLD_SIDE },
     { n: 'Срібло', g: ['#aab4c0', '#ffffff', '#5c6878', '#9aa4b0'], rim: SILVER_RIM, side: SILVER_SIDE },
     { n: 'Рожеве золото', g: ['#e8998f', '#fff0ec', '#a3554c', '#d98479'], rim: ROSE_RIM, side: ROSE_SIDE },
     { n: 'Бронза', g: ['#c97a3a', '#ffe2c4', '#7a3c12', '#b8692c'], rim: BRONZE_RIM, side: BRONZE_SIDE },
     { n: 'Синя сталь', g: ['#4a6a9a', '#d6e6ff', '#1c2f52', '#3d5a8a'], rim: SILVER_RIM, side: SILVER_SIDE },
     { n: 'Чорний хром', g: ['#33333d', '#a8a8b8', '#0a0a0e', '#2a2a33'], rim: SILVER_RIM, side: SILVER_SIDE }],
    function (p) { return { face: { gradient: p.g, angle: 90, horizon: 0.52 }, rim: p.rim, extrude: { depth: 0.14, dir: 168, near: p.side[0], far: p.side[4], stops: p.side }, ls: { shadow: PSH } }; });

  recipe('prem-own-side', 'Кольоровий обʼєм у золоті', 'premium', ['преміум', 'горизонт', 'золотий кант', 'кольоровий обʼєм', '3d'], 'impact',
    [{ n: 'Рубін', g: ['#c40a0a', '#ff5a4d', '#8a0000', '#d42020'] }, { n: 'Аметист', g: ['#6a14c2', '#d07aff', '#45088a', '#8a3de0'] },
     { n: 'Сапфір', g: ['#0f3ac2', '#66a3ff', '#07228a', '#2a5ce0'] }, { n: 'Смарагд', g: ['#0a8a2a', '#5cf07a', '#045c18', '#18b340'] },
     { n: 'Маджента', g: ['#c20a8a', '#ff7ad6', '#8a0460', '#e02aa8'] }, { n: 'Бірюза', g: ['#0a9a9a', '#7af5f0', '#046060', '#18b8b3'] }],
    function (p) { var sd = sideOf(p.g[0]); return { face: { gradient: p.g, angle: 90, horizon: 0.54 }, rim: GOLD_RIM, extrude: { depth: 0.2, dir: 165, near: sd[0], far: sd[4], stops: sd }, ls: { stroke: { color: '#ffd45a', w: 0.012 }, shadow: PSH } }; });

  recipe('prem-black-gold', 'Чорне золото', 'premium', ['преміум', 'чорний', 'золото', 'vip', 'сяйво', 'кант'], 'black',
    [{ n: 'VIP', g: ['#2a2a30', '#8a8a96', '#050506', '#26262c'], gl: '#ffb81f' }, { n: 'Нічний синій', g: ['#101a3a', '#5a78c2', '#03060f', '#131f45'], gl: '#4d8bff' },
     { n: 'Бордо', g: ['#3a0810', '#b83a4d', '#0f0204', '#45101a'], gl: '#ff3d5a' }],
    function (p) { return { face: { gradient: p.g, angle: 90, horizon: 0.5 }, rim: GOLD_RIM, extrude: { depth: 0.1, dir: 172, near: GOLD_SIDE[0], far: GOLD_SIDE[4], stops: GOLD_SIDE }, ls: { glow: { color: p.gl, opacity: 70, size: 0.28, spread: 0 } } }; });

  recipe('prem-neon-chrome', 'Неон у хромі', 'premium', ['преміум', 'неон', 'сяйво', 'срібний кант', 'горизонт'], 'black',
    [{ n: 'Рожевий', g: ['#ff3db8', '#ffd1f0', '#b0107a', '#ff5fc8'], gl: '#ff3db8' }, { n: 'Блакитний', g: ['#1fb8ff', '#d6f5ff', '#0a6ab0', '#3dc8ff'], gl: '#2ee6ff' },
     { n: 'Лайм', g: ['#6adb1f', '#eaffc2', '#2f8a0a', '#7ae82a'], gl: '#7dff3d' }, { n: 'Помаранч', g: ['#ff8a1f', '#ffe9c2', '#b04a0a', '#ff9a3d'], gl: '#ff8a1f' }],
    function (p) { return { face: { gradient: p.g, angle: 90, horizon: 0.5 }, rim: SILVER_RIM, extrude: { depth: 0.07, dir: 175, near: SILVER_SIDE[0], far: SILVER_SIDE[4], stops: SILVER_SIDE }, ls: { glow: { color: p.gl, opacity: 90, size: 0.32, spread: 0 } } }; });

  recipe('prem-glitter-frame', 'Блискітки в золотій рамі', 'premium', ['преміум', 'блискітки', 'глітер', 'текстура', 'золотий кант', '3d'], 'black',
    [{ n: 'Фіолет', g: ['#e6b8ff', '#9a3dff', '#4a0c99'] }, { n: 'Червоний', g: ['#ffb8b8', '#ff2b2b', '#8a0000'] },
     { n: 'Синій', g: ['#b8d6ff', '#2f6bff', '#0a2580'] }, { n: 'Золото', g: ['#fff6c2', '#ffc93d', '#b8740a'] }, { n: 'Срібло', g: ['#ffffff', '#c3ccd6', '#5c6878'], silver: true }],
    function (p) { var sv = p.silver; return { face: { gradient: p.g, angle: 90 }, texture: { type: 'glitter', amount: 55, size: 0.02 }, rim: sv ? SILVER_RIM : GOLD_RIM, extrude: { depth: 0.13, dir: 168, near: (sv ? SILVER_SIDE : GOLD_SIDE)[0], far: (sv ? SILVER_SIDE : GOLD_SIDE)[4], stops: sv ? SILVER_SIDE : GOLD_SIDE }, ls: { shadow: PSH } }; });

  recipe('prem-glass', 'Скляний глянець', 'premium', ['преміум', 'глянець', 'відблиски', 'скло', 'горизонт', 'кант'], 'impact',
    [{ n: 'Червоний / золото', g: ['#a80000', '#f02020', '#7a0000', '#b81010'], rim: GOLD_RIM, side: GOLD_SIDE },
     { n: 'Синій / срібло', g: ['#0a2a9a', '#3d7af0', '#061a6b', '#1a45c2'], rim: SILVER_RIM, side: SILVER_SIDE },
     { n: 'Фіолет / золото', g: ['#4a0c99', '#a84df0', '#33076b', '#6a24c2'], rim: GOLD_RIM, side: GOLD_SIDE },
     { n: 'Зелений / золото', g: ['#066b1c', '#2fd04d', '#034a12', '#109a2f'], rim: GOLD_RIM, side: GOLD_SIDE }],
    function (p) { return { face: { gradient: p.g, angle: 90, horizon: 0.56 }, gloss: { type: 'streaks' }, rim: p.rim, extrude: { depth: 0.16, dir: 168, near: p.side[0], far: p.side[4], stops: p.side }, ls: { shadow: PSH } }; });

  recipe('prem-candy-chrome', 'Цукерковий хром', 'premium', ['преміум', 'мультяшний', 'гра', 'кант', 'горизонт', '3d'], 'black',
    [{ n: 'Полуниця', g: ['#ff5fa8', '#ffd6ea', '#e01a78', '#ff7ab8'], rim: { w: 0.04, hi: '#ffffff', mid: '#ffd1e8', lo: '#c2508a' } },
     { n: 'Лимон', g: ['#ffc81f', '#fffbd1', '#e09a00', '#ffd64d'], rim: { w: 0.04, hi: '#ffffff', mid: '#fff3b8', lo: '#c28a1f' } },
     { n: 'Мʼята', g: ['#1fd6a8', '#d6fff3', '#0a9a78', '#3de0b8'], rim: { w: 0.04, hi: '#ffffff', mid: '#c9fff0', lo: '#2a9a80' } },
     { n: 'Чорниця', g: ['#5a6bff', '#dce0ff', '#2a35c2', '#7a88ff'], rim: { w: 0.04, hi: '#ffffff', mid: '#d6dcff', lo: '#4a55b8' } }],
    function (p) { var sd = sideOf(p.g[2]); return { face: { gradient: p.g, angle: 90, horizon: 0.5 }, rim: p.rim, extrude: { depth: 0.1, dir: 180, near: sd[0], far: sd[3], stops: sd.slice(0, 4) }, ls: { shadow: { color: '#000000', opacity: 45, dir: 180, dist: 0.06, size: 0.14, spread: 0 } } }; });

  // ══ Хвиля 3: +108 стилів ════════════════════════════════
  function rimOf(hex, w) { return { w: w || 0.036, hi: light(hex, 0.8), mid: hex, lo: dark(hex, 0.65) }; }
  var WHITE_RIM = { w: 0.04, hi: '#ffffff', mid: '#f2f2f2', lo: '#9aa0a8' };
  var SOFT_SH = { color: '#000000', opacity: 50, dir: 170, dist: 0.05, size: 0.12, spread: 0 };

  recipe('toon-triple', 'Потрійний контур', 'comic', ['комікс', 'мультяшний', 'потрійна обводка', 'стікер'], 'black',
    [{ n: 'Жовтий', a: '#ffd21f', i: '#3a2200', s: '#ff5a1f' }, { n: 'Рожевий', a: '#ff5fb0', i: '#3a0026', s: '#7a3dff' }, { n: 'Блакитний', a: '#3dc8ff', i: '#05213a', s: '#ff4f8a' },
     { n: 'Лайм', a: '#b6ff3b', i: '#143000', s: '#1fa8ff' }, { n: 'Червоний', a: '#ff3b3b', i: '#3a0000', s: '#ffd21f' }],
    function (p) { return { face: { fill: p.a }, tstroke: { color: p.i, w: 0.035 }, bevelFx: { t: 0.02, light: -45, intensity: 0.3 }, ls: { stroke: { color: '#ffffff', w: 0.06 } }, hard: [{ color: p.s, dir: 140, dist: 0.07, soft: 0, opacity: 100 }] }; });

  recipe('pop-duo', 'Поп-арт подвійна тінь', 'comic', ['комікс', 'поп-арт', 'жорстка тінь', 'зсув'], 'impact',
    [{ n: 'Жовтий', a: '#ffe81f', b: '#ff2e8a', c: '#1fd0ff' }, { n: 'Білий', a: '#ffffff', b: '#ff3d3d', c: '#2a5cff' }, { n: 'Мʼята', a: '#7dffcf', b: '#7a3dff', c: '#ff4fb4' },
     { n: 'Помаранч', a: '#ff9a1f', b: '#1a1a1a', c: '#ffe81f' }, { n: 'Рожевий', a: '#ff8ad0', b: '#3d1fff', c: '#ffe81f' }],
    function (p) { return { face: { fill: p.a }, ls: { stroke: { color: '#000000', w: 0.035 } }, hard: [{ color: p.b, dir: 135, dist: 0.055, soft: 0, opacity: 100 }, { color: p.c, dir: 135, dist: 0.055, soft: 0, opacity: 100 }] }; });

  recipe('rainbow-side', 'Веселковий обʼєм', 'retro', ['ретро', 'веселка', '3d', 'обʼєм', 'смуги'], 'black',
    [{ n: 'Класика', a: '#fff7e0', st: ['#ff3b3b', '#ffb300', '#3ddc4a', '#2f8bff', '#a64dff'] }, { n: 'Захід', a: '#ffffff', st: ['#ffe259', '#ff8a3d', '#e8336d', '#7a2fb8', '#2a1466'] },
     { n: 'Океан', a: '#f0ffff', st: ['#a8fff0', '#3dd6e0', '#2f8bff', '#3a4fd6', '#1a1f6b'] }, { n: 'Цукерка', a: '#ffffff', st: ['#ffd1ea', '#ff8ac8', '#c58aff', '#8ab8ff', '#8affd6'] }],
    function (p) { return { face: { fill: p.a }, extrude: { depth: 0.3, dir: 140, near: p.st[0], far: p.st[4], stops: p.st }, ls: { stroke: { color: '#1a1a1a', w: 0.012 } } }; });

  recipe('vhs', 'VHS-глітч', 'glitch', ['глітч', 'vhs', 'rgb', 'сяйво', 'ретро'], 'impact',
    [{ n: 'Синій / рожевий', a: '#2f5bff', b: '#ff2e8a', g: '#7a8aff' }, { n: 'Бірюза / червоний', a: '#00e5d0', b: '#ff1f3d', g: '#ffffff' }, { n: 'Жовтий / фіолет', a: '#ffe81f', b: '#a03dff', g: '#ffd0ff' }],
    function (p) { return { face: { fill: '#ffffff' }, hard: [{ color: p.a, dir: 270, dist: 0.03, soft: 0, opacity: 100 }, { color: p.b, dir: 90, dist: 0.06, soft: 0, opacity: 100 }], ls: { glow: { color: p.g, opacity: 55, size: 0.2, spread: 0 } } }; });

  recipe('chrome-sky', 'Хром «небо і земля»', 'retro', ['80-ті', 'хром', 'горизонт', 'synthwave', 'кант'], 'black',
    [{ n: 'Класика', g: ['#1f4fd6', '#e6f5ff', '#4a2408', '#ffd66b'], gl: '#ff3dd0' }, { n: 'Захід', g: ['#7a1fb8', '#ffd1f0', '#3a0a2e', '#ff9a3d'], gl: '#ff7a1a' },
     { n: 'Лід', g: ['#0a6ab0', '#ffffff', '#062a4f', '#7fe7ff'], gl: '#3bd3ff' }, { n: 'Золото', g: ['#b8740a', '#fffbe0', '#3d2300', '#ffd03d'], gl: '#ffb81f' }],
    function (p) { return { face: { gradient: p.g, angle: 90, horizon: 0.5 }, rim: SILVER_RIM, extrude: { depth: 0.08, dir: 172, near: SILVER_SIDE[0], far: SILVER_SIDE[4], stops: SILVER_SIDE }, ls: { glow: { color: p.gl, opacity: 70, size: 0.26, spread: 0 } } }; });

  recipe('neon-double', 'Подвійний неон', 'neon', ['неон', 'контур', 'сяйво', 'зсув', 'вивіска'], 'segoe',
    [{ n: 'Рожевий / блакитний', a: '#ff4fd8', b: '#2ee6ff' }, { n: 'Блакитний / рожевий', a: '#2ee6ff', b: '#ff4fd8' }, { n: 'Жовтий / фіолет', a: '#ffe94d', b: '#a259ff' },
     { n: 'Зелений / помаранч', a: '#39ff6a', b: '#ff8a1f' }, { n: 'Білий / червоний', a: '#ffffff', b: '#ff2e4d' }],
    function (p) { return { hollow: true, face: { fill: light(p.a, 0.6) }, tstroke: { color: light(p.a, 0.6), w: 0.018 }, hard: [{ color: p.b, dir: 135, dist: 0.045, soft: 0.01, opacity: 90 }], ls: { glow: { color: p.a, opacity: 100, size: 0.26, spread: 6 } } }; });

  recipe('neon-rim', 'Неоновий кант', 'neon', ['неон', 'кант', 'сяйво', 'темний'], 'black',
    [{ n: 'Рожевий', c: '#ff3db8' }, { n: 'Блакитний', c: '#2ee6ff' }, { n: 'Лайм', c: '#7dff3d' }, { n: 'Помаранч', c: '#ff8a1f' }, { n: 'Фіолет', c: '#a259ff' }],
    function (p) { return { face: { gradient: [dark(p.c, 0.75), dark(p.c, 0.5), dark(p.c, 0.9), dark(p.c, 0.7)], angle: 90, horizon: 0.5 }, rim: rimOf(p.c, 0.04), ls: { glow: { color: p.c, opacity: 100, size: 0.3, spread: 4 } } }; });

  recipe('game-horizon', 'Ігровий глянець', 'game', ['ігровий', 'мобільна гра', 'горизонт', 'обводка', '3d', 'глянець'], 'black',
    [{ n: 'Помаранч', c: '#ff8a1f' }, { n: 'Блакитний', c: '#1fa8ff' }, { n: 'Зелений', c: '#2fcf3f' }, { n: 'Рожевий', c: '#ff4fa8' }, { n: 'Фіолет', c: '#8a4dff' }, { n: 'Жовтий', c: '#ffc81f' }],
    function (p) { var o = dark(p.c, 0.82); return { face: { gradient: [p.c, light(p.c, 0.65), dark(p.c, 0.18), light(p.c, 0.15)], angle: 90, horizon: 0.48 }, rim: WHITE_RIM, extrude: { depth: 0.08, dir: 180, near: dark(p.c, 0.45), far: dark(p.c, 0.7) }, ls: { stroke: { color: o, w: 0.045 }, shadow: SOFT_SH } }; });

  recipe('fantasy', 'Фентезі RPG', 'game', ['ігровий', 'фентезі', 'rpg', 'метал', 'брашований', 'текстура', 'кант'], 'impact',
    [{ n: 'Бронза', g: ['#ffe2b8', '#d98b3d', '#7a3c0f'], rim: BRONZE_RIM, side: BRONZE_SIDE }, { n: 'Сталь', g: ['#f0f4f8', '#9aa8b8', '#3d4a5c'], rim: SILVER_RIM, side: SILVER_SIDE },
     { n: 'Золото', g: ['#fff6c2', '#f2b833', '#8a5206'], rim: GOLD_RIM, side: GOLD_SIDE }, { n: 'Кровʼю', g: ['#ffb8a8', '#d42a1f', '#5c0a05'], rim: GOLD_RIM, side: GOLD_SIDE }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, texture: { type: 'brushed', amount: 30, size: 0.35 }, rim: p.rim, extrude: { depth: 0.1, dir: 175, near: p.side[0], far: p.side[4], stops: p.side }, ls: { stroke: { color: '#120a04', w: 0.03 }, shadow: SOFT_SH } }; });

  recipe('elements2', 'Стихія преміум', 'elements', ['стихії', 'сяйво', 'горизонт', 'кант', 'вогонь', 'лід'], 'black',
    [{ n: 'Лава', g: ['#ff6a00', '#fff27a', '#a31400', '#ff3d00'], r: '#ffb81f', gl: '#ff5a00' }, { n: 'Лід', g: ['#4fd6ff', '#ffffff', '#1a6ab8', '#7fe7ff'], r: '#dff6ff', gl: '#7fe7ff' },
     { n: 'Токсик', g: ['#3dff2e', '#f4ff8a', '#0f8a14', '#6dff3b'], r: '#d6ff5a', gl: '#6dff3b' }, { n: 'Магія', g: ['#b43cff', '#ffe6ff', '#4a0a8a', '#d17bff'], r: '#f0c4ff', gl: '#d17bff' },
     { n: 'Електрика', g: ['#ffe81f', '#ffffff', '#b88a00', '#fff27a'], r: '#ffffff', gl: '#5ac8ff' }],
    function (p) { return { face: { gradient: p.g, angle: 90, horizon: 0.5 }, rim: rimOf(p.r, 0.034), extrude: { depth: 0.06, dir: 178, near: dark(p.g[2], 0.3), far: dark(p.g[2], 0.75) }, ls: { glow: { color: p.gl, opacity: 95, size: 0.34, spread: 0 } } }; });

  recipe('deep-block', 'Довгий блок', '3d', ['3d', 'екструзія', 'довгий обʼєм', 'плакат'], 'impact',
    [{ n: 'Жовтий', a: '#ffd21f', e: '#e0491f' }, { n: 'Білий', a: '#ffffff', e: '#2a5cff' }, { n: 'Мʼята', a: '#8affd6', e: '#0f8f7a' }, { n: 'Рожевий', a: '#ff8ac8', e: '#b8105c' }, { n: 'Помаранч', a: '#ffa21f', e: '#5a1fb8' }],
    function (p) { return { face: { fill: p.a }, extrude: { depth: 0.38, dir: 135, near: p.e, far: dark(p.e, 0.7) }, ls: { stroke: { color: dark(p.e, 0.8), w: 0.012 } } }; });

  recipe('iso-layers', 'Шари 3D', '3d', ['3d', 'шари', 'смуги', 'обʼєм', 'ретро'], 'black',
    [{ n: 'Синій / білий', a: '#ffffff', x: '#2a5cff', y: '#ffffff' }, { n: 'Рожевий / жовтий', a: '#fff7d6', x: '#ff3d8b', y: '#ffd21f' }, { n: 'Чорний / жовтий', a: '#ffd21f', x: '#111111', y: '#ffd21f' }, { n: 'Мʼята / фіолет', a: '#ffffff', x: '#7a3dff', y: '#6effd0' }],
    function (p) { return { face: { fill: p.a }, extrude: { depth: 0.24, dir: 140, near: p.x, far: p.x, stops: [p.x, p.x, p.y, p.y, p.x, p.x, p.y, p.y, p.x] }, ls: { stroke: { color: '#111111', w: 0.012 } } }; });

  recipe('price-pop', 'Ціна з горизонтом', 'promo', ['ціна', 'акція', 'знижка', 'реклама', 'горизонт', '3d'], 'impact',
    [{ n: 'Жовтий', g: ['#ffd21f', '#fff9c2', '#e09a00', '#ffc81f'], e: '#c41a1a' }, { n: 'Червоний', g: ['#e01414', '#ff8a7a', '#9a0000', '#d42020'], e: '#1a1a1a' },
     { n: 'Білий', g: ['#e6e6e6', '#ffffff', '#b8b8b8', '#dcdcdc'], e: '#d10000' }, { n: 'Зелений', g: ['#1fb800', '#b8ff9a', '#0f7a00', '#2fcf14'], e: '#0a3300' }],
    function (p) { return { face: { gradient: p.g, angle: 90, horizon: 0.5 }, extrude: { depth: 0.16, dir: 150, near: p.e, far: dark(p.e, 0.6) }, ls: { stroke: { color: '#000000', w: 0.03 }, shadow: SOFT_SH } }; });

  recipe('black-friday', 'Black Friday', 'promo', ['акція', 'black friday', 'чорний', 'неон', 'обводка'], 'impact',
    [{ n: 'Жовтий', c: '#ffe81f' }, { n: 'Рожевий', c: '#ff2e8a' }, { n: 'Блакитний', c: '#1fd0ff' }, { n: 'Лайм', c: '#9dff1f' }],
    function (p) { return { face: { gradient: ['#2a2a2a', '#5a5a5a', '#0a0a0a', '#222222'], angle: 90, horizon: 0.5 }, ls: { stroke: { color: p.c, w: 0.04 }, glow: { color: p.c, opacity: 55, size: 0.2, spread: 0 } }, hard: [{ color: p.c, dir: 135, dist: 0.05, soft: 0, opacity: 100 }] }; });

  recipe('subtitle', 'Субтитри', 'minimal', ['субтитри', 'tiktok', 'reels', 'обводка', 'чисто', 'читабельний'], 'black',
    [{ n: 'Білі', a: '#ffffff' }, { n: 'Жовті', a: '#ffe81f' }, { n: 'Зелені', a: '#4dff6a' }, { n: 'Блакитні', a: '#5fe0ff' }, { n: 'Рожеві', a: '#ff7ac8' }],
    function (p) { return { face: { fill: p.a }, ls: { stroke: { color: '#000000', w: 0.07 }, shadow: { color: '#000000', opacity: 70, dir: 180, dist: 0.04, size: 0.08, spread: 0 } } }; });

  recipe('pastel-soft', 'Мʼяка пастель', 'minimal', ['пастель', 'мʼякий', 'тінь', 'чисто', 'lifestyle'], 'black',
    [{ n: 'Персик', a: '#ffd1b8' }, { n: 'Лаванда', a: '#dcc9ff' }, { n: 'Мʼята', a: '#c4f5df' }, { n: 'Небо', a: '#c4e3ff' }, { n: 'Лимон', a: '#fff3b0' }],
    function (p) { return { face: { gradient: [light(p.a, 0.5), p.a], angle: 90 }, ls: { stroke: { color: '#ffffff', w: 0.03 }, shadow: { color: dark(p.a, 0.6), opacity: 55, dir: 170, dist: 0.05, size: 0.14, spread: 0 } } }; });

  recipe('engraved', 'Гравірування', 'metal', ['метал', 'гравірування', 'вдавлений', 'кант', 'преміум'], 'black',
    [{ n: 'Золото', g: ['#c98a12', '#f7d77c', '#8f5a0c'], rim: GOLD_RIM }, { n: 'Срібло', g: ['#8a96a3', '#e3e8ee', '#4c5663'], rim: SILVER_RIM }, { n: 'Бронза', g: ['#a8582a', '#e9a56b', '#6b2f10'], rim: BRONZE_RIM }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, rim: p.rim, ls: { innerShadow: { color: '#000000', opacity: 70, dir: 150, dist: 0.03, size: 0.035 }, shadow: SOFT_SH } }; });

  recipe('brushed-rim', 'Брашований у канті', 'metal', ['метал', 'брашований', 'текстура', 'кант', 'індустріальний'], 'impact',
    [{ n: 'Сталь', g: ['#e9eef3', '#8796a8', '#39424d'], rim: SILVER_RIM, side: SILVER_SIDE }, { n: 'Золото', g: ['#fff6c9', '#f2c14e', '#9a6510'], rim: GOLD_RIM, side: GOLD_SIDE },
     { n: 'Мідь', g: ['#ffd9c2', '#e07a4a', '#7a2f10'], rim: BRONZE_RIM, side: BRONZE_SIDE }, { n: 'Титан', g: ['#b8c2d6', '#5a6680', '#1c2333'], rim: SILVER_RIM, side: SILVER_SIDE }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, texture: { type: 'brushed', amount: 38, size: 0.45 }, rim: p.rim, extrude: { depth: 0.09, dir: 172, near: p.side[0], far: p.side[4], stops: p.side }, ls: { shadow: PSH } }; });

  recipe('mega-win', 'MEGA WIN', 'slots', ['слоти', 'казино', 'виграш', 'mega win', 'золото', 'сяйво', 'кант', '3d'], 'impact',
    [{ n: 'Червоний бік', e: '#d41414', gl: '#ffb81f' }, { n: 'Фіолетовий бік', e: '#8a2fe0', gl: '#e070ff' }, { n: 'Синій бік', e: '#1f5be0', gl: '#6fc8ff' }, { n: 'Зелений бік', e: '#14a33a', gl: '#8dff5c' }, { n: 'Рожевий бік', e: '#e0148a', gl: '#ff8ad0' }],
    function (p) { var sd = sideOf(p.e); return { face: { gradient: ['#f2b01f', '#fffbd6', '#b87400', '#ffd03d'], angle: 90, horizon: 0.5 }, rim: GOLD_RIM, extrude: { depth: 0.18, dir: 172, near: p.e, far: sd[4], stops: [p.e, sd[1], sd[0], sd[3], sd[4]] }, ls: { glow: { color: p.gl, opacity: 75, size: 0.3, spread: 0 } } }; });

  recipe('diamond', 'Діамант', 'slots', ['слоти', 'діамант', 'пайетки', 'текстура', 'срібло', 'сяйво', 'vip'], 'black',
    [{ n: 'Крижаний', g: ['#ffffff', '#b8ecff', '#4da8e0'], gl: '#7fdcff' }, { n: 'Рожевий', g: ['#ffffff', '#ffc9ec', '#e060b0'], gl: '#ff8ad6' }, { n: 'Смарагд', g: ['#ffffff', '#b8ffd6', '#2fb870'], gl: '#5cffa8' }, { n: 'Аметист', g: ['#ffffff', '#e0c4ff', '#8a4de0'], gl: '#c58aff' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, texture: { type: 'flakes', amount: 45, size: 0.05 }, rim: SILVER_RIM, extrude: { depth: 0.07, dir: 175, near: SILVER_SIDE[0], far: SILVER_SIDE[4], stops: SILVER_SIDE }, ls: { glow: { color: p.gl, opacity: 80, size: 0.3, spread: 0 } } }; });

  recipe('split', 'Спліт двох кольорів', 'gradient', ['спліт', 'двоколірний', 'горизонт', 'плакат', 'сучасний'], 'impact',
    [{ n: 'Білий / червоний', a: '#ffffff', b: '#ff2b2b' }, { n: 'Жовтий / чорний', a: '#ffe81f', b: '#161616' }, { n: 'Блакитний / синій', a: '#5fe0ff', b: '#1f3fd6' },
     { n: 'Рожевий / фіолет', a: '#ff8ad0', b: '#6a1fd6' }, { n: 'Мʼята / зелений', a: '#8affd6', b: '#0f8a4a' }, { n: 'Помаранч / бордо', a: '#ffa21f', b: '#7a0a2a' }],
    function (p) { return { face: { gradient: [p.a, p.a, p.b, p.b], angle: 90, horizon: 0.5 }, ls: { stroke: { color: '#000000', w: 0.03 } }, hard: [{ color: '#000000', dir: 140, dist: 0.05, soft: 0, opacity: 100 }] }; });

  recipe('diag-grad', 'Діагональний градієнт', 'gradient', ['градієнт', 'діагональ', 'багатоколірний', 'сучасний', 'жорстка тінь'], 'black',
    [{ n: 'Instagram', g: ['#ffd21f', '#ff5a3d', '#e0148a', '#7a2fe0'], s: '#2a0a4a' }, { n: 'Аква', g: ['#8affd6', '#1fd0ff', '#2f6bff', '#5a2fe0'], s: '#0a1a4a' },
     { n: 'Лава', g: ['#ffe81f', '#ff9a1f', '#ff3d1f', '#b80a3d'], s: '#3a0510' }, { n: 'Тропік', g: ['#d6ff5a', '#3ddc6a', '#1fb8c2', '#2f6bff'], s: '#062a3a' }],
    function (p) { return { face: { gradient: p.g, angle: 35 }, ls: { stroke: { color: '#ffffff', w: 0.035 } }, hard: [{ color: p.s, dir: 140, dist: 0.06, soft: 0, opacity: 100 }] }; });

  recipe('sticker-3d', 'Стікер 3D', 'sticker', ['стікер', 'білий кант', '3d', 'тінь'], 'black',
    [{ n: 'Червоний', c: '#ff3b3b' }, { n: 'Синій', c: '#2f6bff' }, { n: 'Зелений', c: '#22c55e' }, { n: 'Фіолет', c: '#8b5cf6' }, { n: 'Помаранч', c: '#ff8a00' }],
    function (p) { return { face: { gradient: [light(p.c, 0.3), p.c], angle: 90 }, rim: { w: 0.07, hi: '#ffffff', mid: '#ffffff', lo: '#d6dae0' }, extrude: { depth: 0.07, dir: 175, near: '#b8bec8', far: '#6b7280' }, ls: { shadow: SOFT_SH } }; });

  recipe('outline-3d', 'Контур з обʼємом', 'outline', ['контур', 'без заливки', '3d', 'обʼєм', 'плакат'], 'black',
    [{ n: 'Білий / рожевий', a: '#ffffff', e: '#ff3d8b' }, { n: 'Жовтий / синій', a: '#ffd400', e: '#2a5cff' }, { n: 'Мʼята / фіолет', a: '#6effd0', e: '#7a3dff' }, { n: 'Білий / чорний', a: '#ffffff', e: '#3a3a3a' }],
    function (p) { return { hollow: true, face: { fill: p.a }, tstroke: { color: p.a, w: 0.02 }, extrude: { depth: 0.14, dir: 140, near: p.e, far: dark(p.e, 0.6) } }; });

  // ══ Мультяшні ═══════════════════════════════════════════
  function flatRim(hex, w) { return { w: w, hi: hex, mid: hex, lo: hex, flat: true }; }
  var TOON = [{ n: 'Полуниця', c: '#ff4f8a' }, { n: 'Апельсин', c: '#ff8a1f' }, { n: 'Лимон', c: '#ffcf1f' }, { n: 'Лайм', c: '#5fd62a' }, { n: 'Небо', c: '#2fa8ff' }, { n: 'Виноград', c: '#8a55ff' }];

  recipe('toon-bubble', 'Бабл-гам', 'cartoon', ['мультяшний', 'бабл', 'глянець', 'горизонт', 'білий кант', '3d', 'дитячий'], 'black', TOON,
    function (p) { var d = dark(p.c, 0.78); return { face: { gradient: [p.c, light(p.c, 0.7), dark(p.c, 0.12), light(p.c, 0.2)], angle: 90, horizon: 0.46 }, rim: flatRim('#ffffff', 0.05), extrude: { depth: 0.09, dir: 180, near: dark(p.c, 0.5), far: d }, hard: [{ color: d, dir: 180, dist: 0.035, soft: 0, opacity: 100 }], ls: { shadow: { color: '#000000', opacity: 40, dir: 180, dist: 0.05, size: 0.12, spread: 0 } } }; });

  recipe('toon-outline', 'Товстий мульт-контур', 'cartoon', ['мультяшний', 'товстий контур', 'стікер', 'жорстка тінь', 'плаский'], 'black', TOON,
    function (p) { var d = dark(p.c, 0.85); return { face: { fill: p.c }, bevelFx: { t: 0.025, light: -45, intensity: 0.3 }, rim: flatRim(d, 0.075), hard: [{ color: d, dir: 170, dist: 0.07, soft: 0, opacity: 100 }] }; });

  recipe('toon-jelly', 'Желе', 'cartoon', ['мультяшний', 'желе', 'глянець', 'відблиск', 'фаска', 'солодкий'], 'black',
    [{ n: 'Малина', c: '#ff3d7a' }, { n: 'Манго', c: '#ffa21f' }, { n: 'Ківі', c: '#6ad62a' }, { n: 'Блакитна лагуна', c: '#1fc2ff' }, { n: 'Чорниця', c: '#7a5aff' }],
    function (p) { return { face: { gradient: [light(p.c, 0.6), p.c, dark(p.c, 0.3)], angle: 90 }, gloss: { type: 'soft' }, bevelFx: { t: 0.035, light: -45, intensity: 0.55 }, rim: flatRim(light(p.c, 0.75), 0.03), extrude: { depth: 0.1, dir: 175, near: dark(p.c, 0.4), far: dark(p.c, 0.75) }, ls: { shadow: { color: dark(p.c, 0.8), opacity: 55, dir: 175, dist: 0.06, size: 0.14, spread: 0 } } }; });

  recipe('toon-burst', 'Комікс-вибух', 'cartoon', ['мультяшний', 'комікс', 'бум', 'pow', 'довгий обʼєм', 'контур'], 'comic',
    [{ n: 'BOOM жовтий', g: ['#fff36b', '#ffb000'], e: '#e0241f' }, { n: 'POW червоний', g: ['#ff8a6b', '#e01414'], e: '#ffd21f' }, { n: 'ZAP блакитний', g: ['#b8f5ff', '#1fa8ff'], e: '#7a2fe0' }, { n: 'WOW зелений', g: ['#e0ff7a', '#3fcf1f'], e: '#ff4fa8' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, rim: flatRim('#111111', 0.04), extrude: { depth: 0.22, dir: 135, near: p.e, far: dark(p.e, 0.45) }, hard: [{ color: '#111111', dir: 135, dist: 0.03, soft: 0, opacity: 100 }] }; });

  recipe('toon-kids', 'Дитячий', 'cartoon', ['мультяшний', 'дитячий', 'пастель', 'білий кант', 'кольорова тінь'], 'comic',
    [{ n: 'Рожевий', c: '#ff9ac8', s: '#7a5aff' }, { n: 'Жовтий', c: '#ffe066', s: '#ff7a4d' }, { n: 'Мʼятний', c: '#8af0c8', s: '#2f8bff' }, { n: 'Блакитний', c: '#8ad0ff', s: '#ff5fa8' }, { n: 'Бузковий', c: '#c9a8ff', s: '#ff9a3d' }],
    function (p) { return { face: { gradient: [light(p.c, 0.45), p.c], angle: 90 }, rim: flatRim('#ffffff', 0.06), hard: [{ color: p.s, dir: 150, dist: 0.07, soft: 0, opacity: 100 }], ls: { shadow: { color: '#000000', opacity: 35, dir: 160, dist: 0.05, size: 0.12, spread: 0 } } }; });

  recipe('toon-slime', 'Слайм', 'cartoon', ['мультяшний', 'слайм', 'сяйво', 'глянець', 'хелловін'], 'black',
    [{ n: 'Зелений', c: '#5fe01f' }, { n: 'Фіолетовий', c: '#b03dff' }, { n: 'Рожевий', c: '#ff3db8' }],
    function (p) { return { face: { gradient: [p.c, light(p.c, 0.75), dark(p.c, 0.3), p.c], angle: 90, horizon: 0.42 }, gloss: { type: 'streaks' }, rim: flatRim(dark(p.c, 0.8), 0.045), extrude: { depth: 0.07, dir: 180, near: dark(p.c, 0.6), far: dark(p.c, 0.88) }, ls: { glow: { color: p.c, opacity: 80, size: 0.28, spread: 0 } } }; });

  recipe('toon-glaze', 'Глазур', 'cartoon', ['мультяшний', 'глазур', 'солодкий', 'пончик', 'спліт', 'кант'], 'black',
    [{ n: 'Шоколад на карамелі', a: '#5a2d14', b: '#f2b25a', r: '#2e1406' }, { n: 'Полуниця на ванілі', a: '#ff5f9a', b: '#fff0c9', r: '#8a1448' }, { n: 'Мʼята на шоколаді', a: '#7af0c8', b: '#5a2d14', r: '#2e1406' }, { n: 'Лимон на чорниці', a: '#ffe066', b: '#5a4ae0', r: '#1f1466' }],
    function (p) { return { face: { gradient: [light(p.a, 0.25), p.a, light(p.b, 0.15), dark(p.b, 0.12)], angle: 90, horizon: 0.44 }, gloss: { type: 'soft' }, rim: flatRim(p.r, 0.045), extrude: { depth: 0.09, dir: 180, near: dark(p.b, 0.45), far: dark(p.b, 0.8) }, ls: { shadow: { color: '#000000', opacity: 45, dir: 180, dist: 0.05, size: 0.12, spread: 0 } } }; });

  recipe('toon-3d', 'Мульт 3D', 'cartoon', ['мультяшний', '3d', 'обʼєм', 'чорний контур', 'гра'], 'black', TOON,
    function (p) { return { face: { gradient: [light(p.c, 0.35), p.c], angle: 90 }, gloss: { type: 'soft' }, rim: flatRim('#141414', 0.03), extrude: { depth: 0.2, dir: 150, near: dark(p.c, 0.35), far: dark(p.c, 0.7) }, hard: [{ color: '#141414', dir: 150, dist: 0.025, soft: 0, opacity: 100 }] }; });

  recipe('toon-rainbow', 'Веселкова наклейка', 'cartoon', ['мультяшний', 'веселка', 'наклейка', 'білий кант', 'дитячий'], 'black',
    [{ n: 'Яскрава', g: ['#ff3b5c', '#ffb300', '#3ddc4a', '#2f8bff', '#a64dff'], a: 0 }, { n: 'Пастель', g: ['#ffa8c0', '#ffe0a3', '#b8f5c0', '#a9d1ff', '#dcb8ff'], a: 0 }, { n: 'Згори вниз', g: ['#ff5f8a', '#ffc21f', '#5fd62a', '#2fa8ff'], a: 90 }],
    function (p) { return { face: { gradient: p.g, angle: p.a }, bevelFx: { t: 0.02, light: -45, intensity: 0.3 }, rim: flatRim('#ffffff', 0.07), hard: [{ color: '#2a2a33', dir: 165, dist: 0.05, soft: 0, opacity: 100 }], ls: { shadow: { color: '#000000', opacity: 40, dir: 165, dist: 0.05, size: 0.12, spread: 0 } } }; });

  recipe('toon-rubber', 'Ретро-мультик 30-х', 'cartoon', ['мультяшний', 'ретро', 'rubber hose', 'чорний контур', 'довга тінь'], 'comic',
    [{ n: 'Кремовий', c: '#fff3d6' }, { n: 'Червоний', c: '#e8372a' }, { n: 'Гірчичний', c: '#f2b01f' }],
    function (p) { return { face: { fill: p.c }, rim: flatRim('#1a1410', 0.06), extrude: { depth: 0.16, dir: 140, near: '#1a1410', far: '#1a1410' } }; });

  recipe('toon-ice', 'Морозиво', 'cartoon', ['мультяшний', 'морозиво', 'пастель', 'блискітки', 'текстура', 'солодкий'], 'black',
    [{ n: 'Полуничне', c: '#ff8ab8' }, { n: 'Фісташкове', c: '#a8e08a' }, { n: 'Ванільне', c: '#ffe9a8' }, { n: 'Чорничне', c: '#a89aff' }],
    function (p) { return { face: { gradient: [light(p.c, 0.55), p.c, dark(p.c, 0.18)], angle: 90 }, texture: { type: 'glitter', amount: 28, size: 0.02 }, rim: flatRim('#ffffff', 0.05), extrude: { depth: 0.08, dir: 180, near: dark(p.c, 0.35), far: dark(p.c, 0.6) }, ls: { shadow: { color: dark(p.c, 0.7), opacity: 50, dir: 180, dist: 0.05, size: 0.12, spread: 0 } } }; });

  // ── Глянцевий бабл: перелив, білий відблиск по краю, тонкий темний контур, товста світла підкладка ──
  var BUBBLE = [
    { n: 'Рожево-фіолетовий', g: ['#ff7ac8', '#f23db0', '#8a2fb8'], o: '#4a1670', pad: '#e3b3f2' },
    { n: 'Блакитно-синій', g: ['#8ae6ff', '#2fa8ff', '#2f4fd6'], o: '#14206b', pad: '#b8d9ff' },
    { n: 'Мʼятно-бірюзовий', g: ['#a8ffe0', '#2fd6b8', '#0f8a9a'], o: '#064a55', pad: '#b8f5ea' },
    { n: 'Жовто-помаранчевий', g: ['#fff27a', '#ffb01f', '#f25a1f'], o: '#7a2400', pad: '#ffe0a8' },
    { n: 'Червоно-бордовий', g: ['#ff8a8a', '#f22f4d', '#9a0f3d'], o: '#4f061f', pad: '#ffc2cf' },
    { n: 'Лаймово-зелений', g: ['#e6ff8a', '#7ad62a', '#1f8a3d'], o: '#0a401a', pad: '#d0f5b0' }];
  recipe('toon-bubble-gloss', 'Глянцевий бабл', 'cartoon', ['мультяшний', 'бабл', 'глянець', 'відблиск', 'подвійний контур', 'логотип', 'солодкий'], 'black', BUBBLE,
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.035, light: -50, intensity: 0.9 }, gloss: { type: 'soft', color: '#ffffff' },
      rim: [flatRim(p.o, 0.016), flatRim(p.pad, 0.07), flatRim(p.o, 0.014)],
      extrude: { depth: 0.05, dir: 185, near: dark(p.pad, 0.3), far: dark(p.pad, 0.5) }, hard: [{ color: p.o, dir: 185, dist: 0.012, soft: 0, opacity: 100 }] }; });

  recipe('toon-bubble-sticker', 'Глянцевий бабл · наклейка', 'cartoon', ['мультяшний', 'бабл', 'глянець', 'наклейка', 'білий контур', 'логотип'], 'black', BUBBLE.slice(0, 4),
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.035, light: -50, intensity: 0.9 },
      rim: [flatRim(p.o, 0.02), flatRim('#ffffff', 0.065)],
      ls: { shadow: { color: p.o, opacity: 55, dir: 175, dist: 0.05, size: 0.12, spread: 0 } } }; });

  recipe('toon-bubble-deep', 'Глянцевий бабл 3D', 'cartoon', ['мультяшний', 'бабл', 'глянець', '3d', 'обʼєм', 'логотип'], 'black', BUBBLE.slice(0, 4),
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.035, light: -50, intensity: 0.9 },
      rim: [flatRim(p.o, 0.016), flatRim(p.pad, 0.045)],
      extrude: { depth: 0.16, dir: 205, near: dark(p.g[2], 0.15), far: p.o }, hard: [{ color: p.o, dir: 205, dist: 0.014, soft: 0, opacity: 100 }] }; });

  // ── Цукерка-перлина: світле «надуте» лице, яскрава лінія по краю, мʼякий кант і сяйво ──
  var PEARL = [
    { n: 'Бузкова', c: '#c94df2' }, { n: 'Рожева', c: '#ff4fa8' }, { n: 'Блакитна', c: '#2fa8ff' },
    { n: 'Мʼятна', c: '#1fcfa8' }, { n: 'Персикова', c: '#ff8a4d' }, { n: 'Лимонна', c: '#f2c21f' }];
  recipe('candy-pearl', 'Цукерка-перлина', 'cartoon', ['мультяшний', 'цукерка', 'перлина', 'надутий', 'мʼякий', 'сяйво', 'солодкий'], 'black', PEARL,
    function (p) { return { face: { gradient: [light(p.c, 0.92), light(p.c, 0.72), light(p.c, 0.35)], angle: 90 }, bevelFx: { t: 0.06, light: -55, intensity: 0.45 },
      rim: [flatRim(light(p.c, 0.9), 0.012), { w: 0.04, hi: light(p.c, 0.6), mid: light(p.c, 0.25), lo: dark(p.c, 0.25) }],
      ls: { glow: { color: dark(p.c, 0.35), opacity: 75, size: 0.3, spread: 0 } } }; });

  recipe('candy-pearl-3d', 'Цукерка-перлина 3D', 'cartoon', ['мультяшний', 'цукерка', 'перлина', 'надутий', '3d', 'солодкий'], 'black', PEARL.slice(0, 4),
    function (p) { return { face: { gradient: [light(p.c, 0.92), light(p.c, 0.72), light(p.c, 0.35)], angle: 90 }, bevelFx: { t: 0.06, light: -55, intensity: 0.45 },
      rim: [flatRim(light(p.c, 0.9), 0.012), { w: 0.04, hi: light(p.c, 0.6), mid: light(p.c, 0.25), lo: dark(p.c, 0.25) }],
      extrude: { depth: 0.1, dir: 180, near: dark(p.c, 0.2), far: dark(p.c, 0.6) }, ls: { shadow: { color: dark(p.c, 0.75), opacity: 60, dir: 180, dist: 0.06, size: 0.16, spread: 0 } } }; });

  recipe('candy-duo', 'Цукерка двоколірна', 'cartoon', ['мультяшний', 'цукерка', 'двоколірний', 'горизонт', 'надутий', 'солодкий'], 'black',
    [{ n: 'Лимон на малині', a: '#ffe14d', b: '#ff3da8' }, { n: 'Мʼята на бузку', a: '#8affd6', b: '#b04df2' }, { n: 'Персик на вишні', a: '#ffc28a', b: '#e01f5a' }, { n: 'Небо на чорниці', a: '#a8e6ff', b: '#5a4ae0' }],
    function (p) { return { face: { gradient: [light(p.a, 0.5), p.a, p.b, light(p.b, 0.25)], angle: 90, horizon: 0.55 }, bevelFx: { t: 0.05, light: -55, intensity: 0.4 },
      rim: [flatRim(light(p.b, 0.85), 0.012), { w: 0.04, hi: light(p.b, 0.5), mid: p.b, lo: dark(p.b, 0.45) }],
      ls: { glow: { color: dark(p.b, 0.3), opacity: 65, size: 0.26, spread: 0 } } }; });

  // ── Солодка вата: пастельне лице на товстій контрастній підкладці ──
  recipe('cotton-candy', 'Солодка вата', 'cartoon', ['мультяшний', 'солодка вата', 'пастель', 'товста підкладка', 'надутий', 'солодкий', 'логотип'], 'black',
    [{ n: 'Рожева на блакитному', c: '#ff9ad0', pad: '#8fd0ff' }, { n: 'Блакитна на рожевому', c: '#8fd0ff', pad: '#ff9ad0' }, { n: 'Лимонна на бузковому', c: '#ffe68a', pad: '#c9a8ff' },
     { n: 'Мʼятна на персиковому', c: '#9af0d0', pad: '#ffb89a' }, { n: 'Бузкова на мʼятному', c: '#d0b0ff', pad: '#9af0d0' }, { n: 'Біла на рожевому', c: '#fff0f8', pad: '#ff8ac0' }],
    function (p) { return { face: { gradient: [light(p.c, 0.55), p.c, dark(p.c, 0.08)], angle: 90 }, bevelFx: { t: 0.05, light: -55, intensity: 0.5 },
      rim: [flatRim(light(p.pad, 0.25), 0.095)],
      extrude: { depth: 0.07, dir: 175, near: dark(p.pad, 0.18), far: dark(p.pad, 0.32) },
      ls: { shadow: { color: dark(p.pad, 0.6), opacity: 45, dir: 175, dist: 0.05, size: 0.16, spread: 0 } } }; });

  recipe('candy-cane', 'Карамельні смуги', 'cartoon', ['мультяшний', 'карамель', 'смуги', 'льодяник', 'солодкий', 'новий рік'], 'black',
    [{ n: 'Червона', c: '#f2334d' }, { n: 'Рожева', c: '#ff6fb0' }, { n: 'Мʼятна', c: '#2fcfa8' }, { n: 'Блакитна', c: '#3da8ff' }],
    function (p) { return { face: { gradient: [light(p.c, 0.2), p.c], angle: 90 }, gloss: { type: 'stripes', color: '#ffffff' }, bevelFx: { t: 0.035, light: -50, intensity: 0.4 },
      rim: [flatRim(dark(p.c, 0.25), 0.014), flatRim('#ffffff', 0.04)],
      extrude: { depth: 0.05, dir: 180, near: dark(p.c, 0.3), far: dark(p.c, 0.55) },
      ls: { shadow: { color: dark(p.c, 0.7), opacity: 45, dir: 180, dist: 0.05, size: 0.14, spread: 0 } } }; });

  recipe('lollipop', 'Льодяник', 'cartoon', ['мультяшний', 'льодяник', 'смуги', 'контрастна підкладка', 'солодкий'], 'black',
    [{ n: 'Рожевий на блакитному', c: '#ff5fa8', pad: '#3db8ff' }, { n: 'Блакитний на рожевому', c: '#3db8ff', pad: '#ff7ab8' }, { n: 'Жовтий на бузковому', c: '#ffc21f', pad: '#a070ff' }],
    function (p) { return { face: { gradient: [light(p.c, 0.25), p.c], angle: 90 }, gloss: { type: 'stripes', color: '#ffffff' },
      rim: [flatRim(dark(p.c, 0.3), 0.014), flatRim('#ffffff', 0.018), flatRim(p.pad, 0.06)],
      extrude: { depth: 0.06, dir: 175, near: dark(p.pad, 0.25), far: dark(p.pad, 0.5) } }; });

  // ── Квест: лице з короткою «товщиною», навколо — білий, світлий і темний контури та довгий обʼєм ──
  var QUEST = [
    { n: 'Жовтий на синьому', g: ['#ffe81f', '#ffc81f', '#ff9a1f'], ln: '#ff5a1f', inr: '#7a1408', p2: '#6fc0ff', out: '#1247b8' },
    { n: 'Рожевий на фіолетовому', g: ['#ffb8e0', '#ff5fb0', '#f22f8a'], ln: '#ffe0f2', inr: '#6b0a4a', p2: '#d0a0ff', out: '#5a1fb8' },
    { n: 'Лайм на зеленому', g: ['#f2ff7a', '#b8f21f', '#6ad60f'], ln: '#3fae0a', inr: '#0f4a0a', p2: '#a8f5c0', out: '#0f8a4a' },
    { n: 'Блакитний на помаранчевому', g: ['#c2f5ff', '#4dd0ff', '#1f9aff'], ln: '#0f6ad6', inr: '#0a2a6b', p2: '#ffd08a', out: '#e0660f' },
    { n: 'Білий на червоному', g: ['#ffffff', '#fff0e0', '#ffd6b8'], ln: '#ff8a5a', inr: '#8a1f0a', p2: '#ffb0a0', out: '#d42a1f' },
    { n: 'Помаранч на бордо', g: ['#ffd66b', '#ff9a1f', '#f2600f'], ln: '#fff0b0', inr: '#5a0a14', p2: '#ffb8c2', out: '#9a0f2f' }];
  recipe('quest', 'Квест', 'cartoon', ['мультяшний', 'гра', 'квест', 'логотип', '3d', 'подвійний обʼєм', 'білий контур'], 'black', QUEST,
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.02, light: -45, intensity: 0.35 }, rim: [flatRim(p.ln, 0.012)],
      extrude: { depth: 0.085, dir: 215, near: p.inr, far: dark(p.inr, 0.3) },
      post: [flatRim('#ffffff', 0.032), flatRim(p.p2, 0.026), flatRim(p.out, 0.022), { depth: 0.14, dir: 185, near: dark(p.out, 0.15), far: dark(p.out, 0.6) }],
      ls: { shadow: { color: dark(p.out, 0.7), opacity: 55, dir: 185, dist: 0.08, size: 0.18, spread: 0 } } }; });

  recipe('quest-lite', 'Квест · наклейка', 'cartoon', ['мультяшний', 'гра', 'квест', 'наклейка', '3d', 'білий контур'], 'black', QUEST.slice(0, 4),
    function (p) { return { face: { gradient: p.g, angle: 90 }, rim: [flatRim(p.ln, 0.012)],
      extrude: { depth: 0.07, dir: 210, near: p.inr, far: dark(p.inr, 0.3) },
      post: [flatRim('#ffffff', 0.05)],
      ls: { shadow: { color: '#000000', opacity: 50, dir: 180, dist: 0.06, size: 0.14, spread: 0 } } }; });

  // ── Мінімал ───────────────────────────────────────────────
  recipe('clean-shadow', 'Чистий з тінню', 'minimal', ['тінь', 'чисто', 'субтитри'], 'black',
    [{ n: 'Білий', a: '#ffffff' }, { n: 'Жовтий', a: '#ffe14d' }, { n: 'Корал', a: '#ff6f61' }, { n: 'Мʼята', a: '#7dffcf' }],
    function (p) { return { face: { fill: p.a }, ls: { shadow: { color: '#000000', opacity: 70, dir: 150, dist: 0.04, size: 0.1, spread: 0 } } }; });

  recipe('thin-outline', 'Тонкий контур', 'minimal', ['обводка', 'субтитри', 'чисто'], 'black',
    [{ n: 'Білий/чорний', a: '#ffffff', b: '#000000' }, { n: 'Жовтий/чорний', a: '#ffe600', b: '#111111' }, { n: 'Чорний/білий', a: '#111111', b: '#ffffff' }, { n: 'Блакитний/синій', a: '#bff4ff', b: '#0b3d91' }],
    function (p) { return { face: { fill: p.a }, ls: { stroke: { color: p.b, w: 0.035 } } }; });

  recipe('letterpress', 'Тиснення', 'minimal', ['тиснення', 'вдавлений', 'внутрішня тінь'], 'black',
    [{ n: 'Сірий', a: '#8d939c' }, { n: 'Бежевий', a: '#c9b79c' }],
    function (p) { return { face: { fill: p.a }, ls: { innerShadow: { color: '#000000', opacity: 75, dir: 160, dist: 0.025, size: 0.03 } }, hard: [{ color: '#ffffff', dir: 180, dist: 0.012, soft: 0, opacity: 45 }] }; });

  // ── Контур ────────────────────────────────────────────────
  recipe('hollow', 'Порожній контур', 'outline', ['контур', 'без заливки', 'обводка'], 'black',
    [{ n: 'Білий', a: '#ffffff' }, { n: 'Жовтий', a: '#ffd400' }, { n: 'Блакитний', a: '#38e8ff' }, { n: 'Рожевий', a: '#ff4fb4' }],
    function (p) { return { hollow: true, face: { fill: p.a }, tstroke: { color: p.a, w: 0.018 } }; });

  recipe('hollow-shadow', 'Контур з тінню', 'outline', ['контур', 'без заливки', 'зсув'], 'black',
    [{ n: 'Білий/рожевий', a: '#ffffff', b: '#ff3d8b' }, { n: 'Жовтий/синій', a: '#ffd400', b: '#2a5cff' }, { n: 'Мʼята/фіолет', a: '#6effd0', b: '#7a3dff' }],
    function (p) { return { hollow: true, face: { fill: p.a }, tstroke: { color: p.a, w: 0.016 }, hard: [{ color: p.b, dir: 135, dist: 0.05, soft: 0, opacity: 100 }] }; });

  // ── Стікер ────────────────────────────────────────────────
  recipe('sticker', 'Стікер', 'sticker', ['стікер', 'біла обводка', 'тінь'], 'black',
    [{ n: 'Червоний', a: '#ff3b3b' }, { n: 'Синій', a: '#2f6bff' }, { n: 'Зелений', a: '#22c55e' }, { n: 'Фіолет', a: '#8b5cf6' }, { n: 'Помаранч', a: '#ff8a00' }],
    function (p) { return { face: { fill: p.a }, ls: { stroke: { color: '#ffffff', w: 0.11 }, shadow: { color: '#000000', opacity: 55, dir: 160, dist: 0.04, size: 0.12, spread: 0 } } }; });

  recipe('sticker-double', 'Подвійний стікер', 'sticker', ['стікер', 'подвійна обводка'], 'black',
    [{ n: 'Жовтий', a: '#ffd21f', b: '#1a1a1a' }, { n: 'Рожевий', a: '#ff5fa2', b: '#3a0b2b' }, { n: 'Блакитний', a: '#4fd8ff', b: '#06264a' }, { n: 'Лайм', a: '#b6ff3b', b: '#173300' }],
    function (p) { return { face: { fill: p.a }, tstroke: { color: p.b, w: 0.04 }, ls: { stroke: { color: '#ffffff', w: 0.09 }, shadow: { color: '#000000', opacity: 50, dir: 160, dist: 0.04, size: 0.1, spread: 0 } } }; });

  // ── Комікс ────────────────────────────────────────────────
  recipe('comic-pop', 'Комікс Pop', 'comic', ['комікс', 'градієнт', 'жорстка тінь', 'обводка'], 'impact',
    [{ n: 'Жовтий', a: '#fff45c', b: '#ff9d00' }, { n: 'Блакитний', a: '#8ef6ff', b: '#1f8bff' }, { n: 'Рожевий', a: '#ffb3e6', b: '#ff2d95' }, { n: 'Лайм', a: '#e8ff7a', b: '#3fcf1f' }],
    function (p) { return { face: { gradient: [p.a, p.b], angle: 90 }, hard: [{ color: '#000000', dir: 135, dist: 0.07, soft: 0, opacity: 100 }], ls: { stroke: { color: '#000000', w: 0.05 } } }; });

  recipe('comic-bubble', 'Комікс Бабл', 'comic', ['комікс', 'обʼєм', 'фаска', 'обводка'], 'black',
    [{ n: 'Червоний', a: '#ff6b6b', b: '#d61f1f' }, { n: 'Жовтий', a: '#ffe873', b: '#f5b100' }, { n: 'Синій', a: '#7db4ff', b: '#2459e0' }, { n: 'Зелений', a: '#8cf58c', b: '#1fae3a' }],
    function (p) { return { face: { gradient: [p.a, p.b], angle: 90 }, ls: { bevel: { size: 0.06, depth: 120, light: -45, hlOp: 70, shOp: 35 }, stroke: { color: '#111111', w: 0.06 }, shadow: { color: '#000000', opacity: 100, dir: 150, dist: 0.06, size: 0, spread: 100 } } }; });

  // ── Ретро ─────────────────────────────────────────────────
  recipe('retro-stripes', 'Ретро смуги 70-х', 'retro', ['ретро', '70-ті', 'смуги', 'зсув'], 'impact',
    [{ n: 'Пустеля', a: '#fff1d6', b: '#ff8c1a', c: '#8a3b12' }, { n: 'Майамі', a: '#ffffff', b: '#ff4fa3', c: '#1b8f9e' }, { n: 'Захід', a: '#ffe066', b: '#ff4d2e', c: '#5a1a8c' }, { n: 'Диско', a: '#ffffff', b: '#22d3ee', c: '#d946ef' }],
    function (p) { return { face: { fill: p.a }, hard: [{ color: p.b, dir: 135, dist: 0.05, soft: 0, opacity: 100 }, { color: p.c, dir: 135, dist: 0.05, soft: 0, opacity: 100 }] }; });

  recipe('long-shadow', 'Довга тінь', 'retro', ['довга тінь', 'флет', 'ретро'], 'black',
    [{ n: 'Синій', a: '#ffffff', b: '#1d3a8a' }, { n: 'Бордо', a: '#ffe9c7', b: '#6b1230' }, { n: 'Смарагд', a: '#ffffff', b: '#0f5b49' }, { n: 'Графіт', a: '#ffd23f', b: '#2b2b33' }],
    function (p) { return { face: { fill: p.a }, extrude: { depth: 0.45, dir: 135, near: p.b, far: p.b } }; });

  recipe('synthwave', 'Synthwave 80-х', 'retro', ['80-ті', 'synthwave', 'неон', 'градієнт'], 'black',
    [{ n: 'Захід', a: '#ffe66b', b: '#ff2f92', c: '#5b13b8', g: '#ff3bd0' }, { n: 'Океан', a: '#a5fff1', b: '#2f7bff', c: '#2a0c6e', g: '#3bd3ff' }],
    function (p) { return { face: { gradient: [p.a, p.b], angle: 90 }, hard: [{ color: p.c, dir: 150, dist: 0.06, soft: 0, opacity: 100 }], ls: { stroke: { color: '#ffffff', w: 0.02 }, glow: { color: p.g, opacity: 75, size: 0.25, spread: 0 } } }; });

  // ── 3D ────────────────────────────────────────────────────
  recipe('block-3d', 'Блок 3D', '3d', ['3d', 'екструзія', 'обʼєм'], 'black',
    [{ n: 'Червоний', a: '#ff4d4d' }, { n: 'Синій', a: '#4d8bff' }, { n: 'Жовтий', a: '#ffd43b' }, { n: 'Білий', a: '#f4f4f4' }],
    function (p) { return { face: { fill: p.a }, extrude: { depth: 0.14, dir: 140, near: dark(p.a, 0.35), far: dark(p.a, 0.65) }, ls: { shadow: { color: '#000000', opacity: 45, dir: 140, dist: 0.08, size: 0.12, spread: 0 } } }; });

  recipe('block-3d-outline', 'Блок 3D з контуром', '3d', ['3d', 'екструзія', 'обводка', 'ігровий'], 'black',
    [{ n: 'Помаранч', a: '#ffb02e', o: '#2b1200' }, { n: 'Блакитний', a: '#5fe0ff', o: '#04213b' }, { n: 'Рожевий', a: '#ff7ac8', o: '#3b0526' }, { n: 'Лайм', a: '#c4ff4d', o: '#132b00' }],
    function (p) { return { face: { fill: p.a }, tstroke: { color: light(p.a, 0.55), w: 0.012 }, extrude: { depth: 0.12, dir: 150, near: dark(p.a, 0.3), far: dark(p.a, 0.6) }, ls: { stroke: { color: p.o, w: 0.045 }, shadow: { color: '#000000', opacity: 50, dir: 160, dist: 0.06, size: 0.1, spread: 0 } } }; });

  recipe('thick-bottom', 'Товщина знизу', '3d', ['3d', 'кнопка', 'ігровий', 'низ'], 'black',
    [{ n: 'Зелений', a: '#5cff7a', b: '#16a34a' }, { n: 'Червоний', a: '#ff7a7a', b: '#dc2626' }, { n: 'Синій', a: '#7ab8ff', b: '#2563eb' }],
    function (p) { return { face: { gradient: [p.a, p.b], angle: 90 }, extrude: { depth: 0.08, dir: 180, near: dark(p.b, 0.35), far: dark(p.b, 0.55) }, ls: { stroke: { color: dark(p.b, 0.75), w: 0.035 } } }; });

  recipe('candy-3d', 'Цукерка 3D', '3d', ['3d', 'глянець', 'фаска', 'солодкий'], 'black',
    [{ n: 'Полуниця', a: '#ffb8d9', b: '#ff2e8a' }, { n: 'Лимон', a: '#fff7a8', b: '#ffc400' }, { n: 'Мʼята', a: '#b8ffe9', b: '#14c79b' }],
    function (p) { return { face: { gradient: [p.a, p.b], angle: 90 }, bevelFx: { t: 0.025, light: -45, intensity: 0.55 }, extrude: { depth: 0.1, dir: 160, near: dark(p.b, 0.25), far: dark(p.b, 0.5) }, ls: { stroke: { color: '#ffffff', w: 0.045 }, shadow: { color: '#000000', opacity: 45, dir: 160, dist: 0.06, size: 0.12, spread: 0 } } }; });

  // ── Ігрові ────────────────────────────────────────────────
  var GAME_PAL = [
    { n: 'Золото', a: '#fff36b', b: '#ffae00', e: '#a85600', o: '#3d1a00' },
    { n: 'Сапфір', a: '#a5f3ff', b: '#2b8cff', e: '#0a3c9e', o: '#061a4a' },
    { n: 'Смарагд', a: '#d4ff8a', b: '#2fc93f', e: '#11661c', o: '#082b0c' },
    { n: 'Рубін', a: '#ffb3a3', b: '#ff2b2b', e: '#8f0d0d', o: '#3a0505' },
    { n: 'Аметист', a: '#f0c4ff', b: '#a53dff', e: '#4f1191', o: '#22063f' },
    { n: 'Бабл-гам', a: '#ffd1f0', b: '#ff4fb8', e: '#9c1068', o: '#3f052a' }
  ];
  recipe('game-title', 'Ігровий заголовок', 'game', ['ігровий', 'мобільна гра', 'градієнт', 'фаска', 'обводка'], 'black', GAME_PAL,
    function (p) { return { face: { gradient: [p.a, p.b], angle: 90 }, bevelFx: { t: 0.02, light: -45, intensity: 0.45 }, extrude: { depth: 0.08, dir: 175, near: p.e, far: dark(p.e, 0.35) }, ls: { stroke: { color: p.o, w: 0.055 }, shadow: { color: '#000000', opacity: 50, dir: 175, dist: 0.05, size: 0.1, spread: 0 } } }; });

  recipe('big-win', 'BIG WIN', 'game', ['ігровий', 'слоти', 'виграш', 'сяйво', 'золото'], 'black',
    [{ n: 'Золото', a: '#fff8b8', b: '#ffb300', e: '#8a4b00', g: '#ffcc33' }, { n: 'Фіолет', a: '#ffe0ff', b: '#d23cff', e: '#5a0f7a', g: '#e070ff' }, { n: 'Крижаний', a: '#e8ffff', b: '#29c5ff', e: '#0b4f80', g: '#6fe3ff' }],
    function (p) { return { face: { gradient: [p.a, p.b], angle: 90 }, bevelFx: { t: 0.025, light: -40, intensity: 0.6 }, extrude: { depth: 0.09, dir: 170, near: p.e, far: dark(p.e, 0.4) }, ls: { stroke: { color: '#ffffff', w: 0.04 }, glow: { color: p.g, opacity: 85, size: 0.3, spread: 10 } } }; });

  recipe('esports', 'Кіберспорт', 'game', ['кіберспорт', 'зсув', 'агресивний'], 'impact',
    [{ n: 'Червоний', a: '#ffffff', b: '#ff1f3d' }, { n: 'Блакитний', a: '#ffffff', b: '#00d0ff' }, { n: 'Жовтий', a: '#111111', b: '#ffd000' }],
    function (p) { return { face: { fill: p.a }, hard: [{ color: p.b, dir: 125, dist: 0.06, soft: 0, opacity: 100 }], ls: { stroke: { color: p.a === '#111111' ? '#ffffff' : '#000000', w: 0.03 } } }; });

  // ── Неон ──────────────────────────────────────────────────
  var NEON = [{ n: 'Рожевий', a: '#ff4fd8' }, { n: 'Блакитний', a: '#2ee6ff' }, { n: 'Зелений', a: '#39ff6a' }, { n: 'Фіолет', a: '#a259ff' }, { n: 'Помаранч', a: '#ff8a1f' }, { n: 'Червоний', a: '#ff2e4d' }];
  recipe('neon-tube', 'Неонова трубка', 'neon', ['неон', 'сяйво', 'контур', 'вивіска'], 'segoe', NEON,
    function (p) { return { hollow: true, face: { fill: light(p.a, 0.7) }, tstroke: { color: light(p.a, 0.7), w: 0.016 }, ls: { innerGlow: { color: p.a, opacity: 80, size: 0.02 }, glow: { color: p.a, opacity: 100, size: 0.28, spread: 8 } } }; });

  recipe('neon-solid', 'Неон суцільний', 'neon', ['неон', 'сяйво'], 'black', NEON.slice(0, 4),
    function (p) { return { face: { fill: light(p.a, 0.75) }, ls: { innerGlow: { color: p.a, opacity: 90, size: 0.06 }, glow: { color: p.a, opacity: 100, size: 0.35, spread: 5 } } }; });

  // ── Метал ─────────────────────────────────────────────────
  recipe('metal', 'Метал', 'metal', ['метал', 'фаска', 'преміум', 'багатоколірний'], 'black',
    [{ n: 'Золото', g: ['#fff8d2', '#f3c24a', '#8f5a0c', '#f7d77c', '#b37a19'], o: '#3d2300' },
     { n: 'Срібло', g: ['#ffffff', '#c9d1da', '#4c5663', '#e3e8ee', '#7c8794'], o: '#1c2128' },
     { n: 'Бронза', g: ['#ffe2c4', '#d98b4e', '#6b2f10', '#e9a56b', '#8c4520'], o: '#2e1305' },
     { n: 'Рожеве золото', g: ['#fff0ec', '#eaa59b', '#7d3a33', '#f3c0b6', '#a95b52'], o: '#3a1512' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, ls: { bevel: { size: 0.04, depth: 160, light: -40, hlOp: 75, shOp: 45, chisel: true }, stroke: { color: p.o, w: 0.025 }, shadow: { color: '#000000', opacity: 55, dir: 165, dist: 0.04, size: 0.08, spread: 0 } } }; });

  recipe('chrome', 'Хром', 'metal', ['метал', 'хром', 'ретро', 'багатоколірний'], 'black',
    [{ n: 'Хром', g: ['#ffffff', '#a9d4ff', '#1b2a4a', '#c9935a', '#fff1d9'], o: '#0d1424' },
     { n: 'Рожевий хром', g: ['#ffffff', '#ffb8ec', '#4a0f4f', '#ff7ccf', '#fff0fb'], o: '#26062a' },
     { n: 'Золотий хром', g: ['#fffdf0', '#ffd66b', '#4d2a00', '#e9a23b', '#fff0c4'], o: '#241200' },
     { n: 'Темна сталь', g: ['#e9eef3', '#8796a8', '#141a21', '#5c6878', '#c9d2dc'], o: '#05080b' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.025, light: -30, intensity: 0.6 }, ls: { stroke: { color: p.o, w: 0.035 }, glow: { color: '#9fd8ff', opacity: 30, size: 0.12, spread: 0 } } }; });

  recipe('chrome-80s', 'Хром 80-х', 'retro', ['80-ті', 'хром', 'synthwave', 'багатоколірний'], 'black',
    [{ n: 'Неоновий', g: ['#ffffff', '#7fd7ff', '#1d1b6b', '#ff5fb0', '#ffe3f2'], s: '#ff2bd6' },
     { n: 'Захід', g: ['#fff9d9', '#ffc94d', '#6b1340', '#ff6b3d', '#ffe0b8'], s: '#7a1cff' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, ls: { stroke: { color: '#ffffff', w: 0.025 }, glow: { color: p.s, opacity: 70, size: 0.22, spread: 0 } }, hard: [{ color: p.s, dir: 150, dist: 0.06, soft: 0, opacity: 100 }] }; });

  // ── Глітч ─────────────────────────────────────────────────
  recipe('rgb-split', 'RGB-зсув', 'glitch', ['глітч', 'rgb', 'зсув'], 'impact',
    [{ n: 'Червоний/блакитний', a: '#ff1f3d', b: '#00e5ff' }, { n: 'Маджента/зелений', a: '#ff00c8', b: '#00ff85' }, { n: 'Жовтий/синій', a: '#ffd500', b: '#2f5bff' }],
    function (p) { return { face: { fill: '#ffffff' }, hard: [{ color: p.a, dir: 260, dist: 0.035, soft: 0, opacity: 100 }, { color: p.b, dir: 80, dist: 0.035, soft: 0, opacity: 100 }] }; });

  // ── Стихії ────────────────────────────────────────────────
  recipe('elements', 'Стихія', 'elements', ['вогонь', 'лід', 'сяйво', 'градієнт', 'багатоколірний'], 'black',
    [{ n: 'Вогонь', a: '#fff27a', b: '#ff3d00', o: '#5a0d00', g: '#ff6a00' }, { n: 'Лід', a: '#ffffff', b: '#4fd6ff', o: '#062a4f', g: '#7fe7ff' }, { n: 'Токсик', a: '#f4ff8a', b: '#3dff2e', o: '#0b3300', g: '#6dff3b' }, { n: 'Магія', a: '#ffe6ff', b: '#b43cff', o: '#24003f', g: '#d17bff' }],
    function (p) { return { face: { gradient: [p.a, mix(p.a, p.b, 0.55), dark(p.b, 0.15)], angle: 90 }, ls: { stroke: { color: p.o, w: 0.03 }, glow: { color: p.g, opacity: 90, size: 0.3, spread: 0 } } }; });

  // ── Градієнти (багатоколірні) ─────────────────────────────
  recipe('rainbow', 'Веселка', 'gradient', ['веселка', 'багатоколірний', 'яскравий', 'градієнт'], 'black',
    [{ n: 'Класична', g: ['#ff3b3b', '#ffb300', '#3ddc4a', '#2f8bff', '#a64dff'], a: 90 },
     { n: 'Пастель', g: ['#ffb3b3', '#ffe0a3', '#b8f5c0', '#a9d1ff', '#dcb8ff'], a: 90 },
     { n: 'Діагональ', g: ['#ff3b8b', '#ff9a1f', '#ffe81f', '#29d97a', '#1fa8ff'], a: 25 }],
    function (p) { return { face: { gradient: p.g, angle: p.a }, ls: { stroke: { color: '#ffffff', w: 0.045 }, shadow: { color: '#000000', opacity: 55, dir: 160, dist: 0.05, size: 0.1, spread: 0 } } }; });

  recipe('holo', 'Голограма', 'gradient', ['голограма', 'перламутр', 'багатоколірний', 'градієнт'], 'black',
    [{ n: 'Перламутр', g: ['#a8fff4', '#c9a8ff', '#ffb3e6', '#fff3a8', '#a8ffcb'] },
     { n: 'Нічна', g: ['#7af5ff', '#7a6bff', '#ff6bd5', '#ffd36b', '#6bffb5'] }],
    function (p) { return { face: { gradient: p.g, angle: 30 }, ls: { innerGlow: { color: '#ffffff', opacity: 70, size: 0.04 }, stroke: { color: '#2a1f4a', w: 0.03 }, glow: { color: '#d9b8ff', opacity: 45, size: 0.18, spread: 0 } } }; });

  recipe('sunset', 'Захід сонця', 'gradient', ['захід', 'теплий', 'багатоколірний', 'градієнт', 'ретро'], 'impact',
    [{ n: 'Тропіки', g: ['#ffe259', '#ff8a3d', '#e8336d'], s: '#3d0a4f' },
     { n: 'Сутінки', g: ['#ffd1a1', '#ff6f91', '#845ec2'], s: '#1b0f3b' },
     { n: 'Океан', g: ['#c6ffdd', '#3ac7e0', '#3a4fd6'], s: '#0b1640' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, hard: [{ color: p.s, dir: 140, dist: 0.06, soft: 0, opacity: 100 }], ls: { stroke: { color: '#ffffff', w: 0.03 } } }; });

  recipe('aurora', 'Аврора', 'gradient', ['аврора', 'неон', 'сяйво', 'багатоколірний', 'градієнт'], 'segoe',
    [{ n: 'Північна', g: ['#d5fff0', '#3dffb0', '#2bb8ff', '#7a3dff'], gl: '#3dffb0' },
     { n: 'Кібер', g: ['#fff0ff', '#ff3df0', '#7a3dff', '#2bd9ff'], gl: '#ff3df0' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, ls: { glow: { color: p.gl, opacity: 85, size: 0.3, spread: 0 } } }; });

  recipe('game-tri', 'Ігровий триколір', 'game', ['ігровий', 'мобільна гра', 'багатоколірний', 'обводка', '3d'], 'black',
    [{ n: 'Вогняний', g: ['#fff7b0', '#ffc21f', '#ff6a00', '#d42a00'], e: '#7a1600', o: '#2b0700' },
     { n: 'Морський', g: ['#e6ffff', '#5ff2ff', '#2a8bff', '#2341c9'], e: '#0f1f73', o: '#050b2e' },
     { n: 'Кислотний', g: ['#fbffd6', '#d6ff3d', '#3ddc2a', '#0f8f3a'], e: '#0a4a1c', o: '#031a09' }],
    function (p) { return { face: { gradient: p.g, angle: 90 }, bevelFx: { t: 0.02, light: -45, intensity: 0.4 }, extrude: { depth: 0.08, dir: 175, near: p.e, far: dark(p.e, 0.4) }, ls: { stroke: { color: p.o, w: 0.055 }, shadow: { color: '#000000', opacity: 50, dir: 175, dist: 0.05, size: 0.1, spread: 0 } } }; });

  // ── Реклама / Sale ────────────────────────────────────────
  recipe('sale', 'SALE / Акція', 'promo', ['акція', 'знижка', 'ціна', 'реклама'], 'impact',
    [{ n: 'Червоний/жовтий', a: '#ff2b2b', b: '#ffe100', s: '#000000' }, { n: 'Жовтий/чорний', a: '#ffe100', b: '#000000', s: '#000000' }, { n: 'Білий/червоний', a: '#ffffff', b: '#e00000', s: '#5c0000' }, { n: 'Чорний/жовтий', a: '#111111', b: '#ffd000', s: '#000000' }],
    function (p) { return { face: { fill: p.a }, ls: { stroke: { color: p.b, w: 0.07 } }, hard: [{ color: p.s, dir: 140, dist: 0.06, soft: 0, opacity: 100 }] }; });

  recipe('price-3d', 'Ціна 3D', 'promo', ['ціна', '3d', 'реклама', 'обводка'], 'black',
    [{ n: 'Жовтий', a: '#ffe600', b: '#ff9900' }, { n: 'Червоний', a: '#ff5c5c', b: '#d10000' }, { n: 'Зелений', a: '#8dff5c', b: '#1fb800' }],
    function (p) { return { face: { gradient: [p.a, p.b], angle: 90 }, extrude: { depth: 0.12, dir: 135, near: '#1a1a1a', far: '#000000' }, ls: { stroke: { color: '#000000', w: 0.04 } } }; });

  // ---------- build ----------
  var CATS = {
    premium: 'Преміум', slots: 'Слоти', game: 'Ігрові', cartoon: 'Мультяшні', '3d': '3D', gradient: 'Градієнти', neon: 'Неон', comic: 'Комікс', retro: 'Ретро', metal: 'Метал',
    sticker: 'Стікер', outline: 'Контур', glitch: 'Глітч', elements: 'Стихії', promo: 'Реклама', minimal: 'Мінімал'
  };

  function mainColor(st) {
    var g = st.face.gradient;
    if (g) return g.length > 2 ? g[Math.floor(g.length / 2)] : mix(g[0], g[1], 0.6);
    return st.face.fill;
  }

  function weightOf(st) {
    var w = 0, ls = st.ls || {};
    if (st.extrude) w += st.extrude.depth > 0.3 ? 3 : 2;
    if (st.hard) w += st.hard.length * 0.5;
    if (st.face.gradient) w += st.face.gradient.length > 2 ? 0.8 : 0.5;
    if (st.bevelFx) w += 0.5;
    if (st.texture) w += 0.6;
    if (st.gloss) w += 0.5;
    if (st.post) w += st.post.length;
    if (st.rim) w += [].concat(st.rim).length > 1 ? 2 : 1.5;
    for (var k in ls) w += (k === 'glow' || k === 'shadow') ? 0.7 : 0.4;
    return w < 1.6 ? 1 : (w < 3.2 ? 2 : 3);
  }

  function extentOf(st) { // how far decoration reaches beyond the glyphs, in em (for preview fitting)
    var ls = st.ls || {}, e = 0;
    if (st.tstroke) e += st.tstroke.w;
    [].concat(st.rim || []).forEach(function (r) { e += r.w; });
    if (st.extrude) e += st.extrude.depth;
    if (st.hard) st.hard.forEach(function (h) { e += h.dist; });
    (st.post || []).forEach(function (it) { e += it.depth || it.w; });
    if (ls.stroke) e += ls.stroke.w;
    var g = ls.glow ? ls.glow.size * 0.6 : 0, s = ls.shadow ? ls.shadow.dist + ls.shadow.size * 0.6 : 0;
    return e + Math.max(g, s);
  }

  var LIB = [];
  R.forEach(function (r) {
    r.palettes.forEach(function (p, i) {
      var st = r.fn(p);
      st.id = r.id + '-' + (i + 1);
      st.recipe = r.id;
      st.name = r.name + ' · ' + p.n;
      st.cat = r.cat;
      st.tags = r.tags.slice();
      st.font = FONTS[r.font];
      st.dim = st.extrude ? '3D' : '2D';
      st.animated = !!(st.texture && st.texture.type === 'live');
      st.weight = weightOf(st);
      st.color = colorBucket(mainColor(st));
      st.hue = hueOf(mainColor(st)).h;
      st.extent = extentOf(st);
      LIB.push(st);
    });
  });

  root.HFS_LIB = LIB;
  root.HFS_CATS = CATS;
  root.HFS_FONTS = FONTS;
  root.HFS_COLOR = { mix: mix, dark: dark, light: light, hueOf: hueOf, resample5: resample5 };
})(typeof window !== 'undefined' ? window : this);
