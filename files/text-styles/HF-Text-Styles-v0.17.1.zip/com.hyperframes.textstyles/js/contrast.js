/*
 * HF Text Styles — WCAG contrast against a background colour.
 *
 * A style is not one colour, so each style is rendered once (small, transparent) and two pixel
 * sets are kept: the outer edge of the silhouette (outline / extrusion / glow — what actually
 * meets the background) and the interior (face). For a given background each pixel is composited
 * over it and its contrast measured; the style's ratio is the better of the two medians.
 */
(function (root) {
  'use strict';

  function hexToRgb(h) { h = h.replace('#', ''); if (h.length === 3) h = h.replace(/(.)/g, '$1$1'); return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16)]; }
  function lin(c) { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }
  function lum(rgb) { return 0.2126 * lin(rgb[0]) + 0.7152 * lin(rgb[1]) + 0.0722 * lin(rgb[2]); }
  function ratioL(l1, l2) { var a = Math.max(l1, l2), b = Math.min(l1, l2); return (a + 0.05) / (b + 0.05); }
  function ratio(hexA, hexB) { return ratioL(lum(hexToRgb(hexA)), lum(hexToRgb(hexB))); }

  // WCAG 2.1: AA large 3, AA small 4.5, AAA large 4.5, AAA small 7, graphics/UI 3
  function grade(r) {
    return {
      largeAA: r >= 3, largeAAA: r >= 4.5, smallAA: r >= 4.5, smallAAA: r >= 7, ui: r >= 3
    };
  }

  var cache = {};
  var W = 200, H = 84;

  function analyze(st) {
    if (cache[st.id]) return cache[st.id];
    var c = document.createElement('canvas'); c.width = W; c.height = H;
    root.HFS_RENDER.renderStyle(c, st, 'HYPER', { mult: 1, texture: 'none' });
    var d = c.getContext('2d').getImageData(0, 0, W, H).data;
    var edge = [], face = [];
    function A(x, y) { if (x < 0 || y < 0 || x >= W || y >= H) return 0; return d[(y * W + x) * 4 + 3]; }
    for (var y = 0; y < H; y++) for (var x = 0; x < W; x++) {
      var i = (y * W + x) * 4, a = d[i + 3];
      if (a < 90) continue;
      var px = [d[i], d[i + 1], d[i + 2], a / 255];
      var outer = A(x - 2, y) < 25 || A(x + 2, y) < 25 || A(x, y - 2) < 25 || A(x, y + 2) < 25;
      if (outer) edge.push(px);
      else if (a > 240 && (x + y) % 3 === 0) face.push(px);
    }
    if (edge.length > 250) { var stp = Math.ceil(edge.length / 250); edge = edge.filter(function (_, k) { return k % stp === 0; }); }
    cache[st.id] = { edge: edge, face: face };
    return cache[st.id];
  }

  function median(arr) { if (!arr.length) return 1; arr.sort(function (a, b) { return a - b; }); return arr[Math.floor(arr.length / 2)]; }

  // median contrast of a pixel set over bg, plus the composited colour of that median pixel
  function setMedian(set, bg, bgL) {
    if (!set.length) return { r: 1, rgb: bg };
    var rs = [];
    for (var i = 0; i < set.length; i++) {
      var p = set[i], a = p[3];
      var rgb = [p[0] * a + bg[0] * (1 - a), p[1] * a + bg[1] * (1 - a), p[2] * a + bg[2] * (1 - a)];
      rs.push({ r: ratioL(lum(rgb), bgL), rgb: rgb });
    }
    rs.sort(function (a, b) { return a.r - b.r; });
    return rs[Math.floor(rs.length / 2)];
  }
  function toHex(rgb) { return '#' + rgb.map(function (v) { v = Math.round(Math.max(0, Math.min(255, v))).toString(16); return v.length < 2 ? '0' + v : v; }).join(''); }

  // { ratio, color, part } — color is the colour that actually meets the background
  // (outline / edge or the face, whichever reads better), so a flat check of color vs bg ≈ ratio
  // face colours straight from the style definition (pixels inside thick outlines are mostly the
  // outline rings, which made the face look worse than it is)
  function faceStops(st) {
    if (st.hollow) return [];
    var f = st.face || {};
    if (f.gradient) return f.gradient.length > 2 ? root.HFS_COLOR.resample5(f.gradient) : [f.gradient[0], root.HFS_COLOR.mix(f.gradient[0], f.gradient[1], 0.5), f.gradient[1]];
    return [f.fill || '#ffffff'];
  }
  function styleRatio(st, bgHex) {
    var an = analyze(st), bg = hexToRgb(bgHex), bgL = lum(bg);
    var e = setMedian(an.edge, bg, bgL);
    var fs = faceStops(st).map(function (h) { return { r: ratioL(lum(hexToRgb(h)), bgL), rgb: hexToRgb(h) }; });
    fs.sort(function (a, b) { return a.r - b.r; });
    var f = fs.length ? fs[Math.floor(fs.length / 2)] : { r: 1, rgb: bg };
    var best = e.r >= f.r ? e : f;
    return { ratio: best.r, color: toHex(best.rgb), part: e.r >= f.r ? 'edge' : 'face' };
  }

  // Dominant (median-luminance) colour of a style's face, for the manual checker
  function faceColor(st) {
    var fsx = faceStops(st);
    if (fsx.length) { var srt = fsx.slice().sort(function (a, b) { return lum(hexToRgb(a)) - lum(hexToRgb(b)); }); return srt[Math.floor(srt.length / 2)]; }
    var an = analyze(st), set = an.face.length ? an.face : an.edge;
    if (!set.length) return '#ffffff';
    var s = set.slice().sort(function (a, b) { return lum(a) - lum(b); }), p = s[Math.floor(s.length / 2)];
    return '#' + [p[0], p[1], p[2]].map(function (v) { v = Math.round(v).toString(16); return v.length < 2 ? '0' + v : v; }).join('');
  }

  root.HFS_CONTRAST = { ratio: ratio, grade: grade, styleRatio: styleRatio, faceColor: faceColor, analyze: analyze };
})(window);
