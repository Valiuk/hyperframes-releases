/**
 * Тонкий міст між панеллю та After Effects.
 *
 * Замість повного CSInterface.js тут використано лише те, що потрібно:
 * window.__adobe_cep__.evalScript / getHostEnvironment / addEventListener.
 * Офіційний CSInterface.js можна підключити замість цього файлу — API сумісне
 * за назвами (evalScript, getHostEnvironment).
 *
 * Якщо панель відкрити у звичайному Chrome, вмикається мок-режим: інтерфейс
 * живий, відповіді підставні. Зручно для правки верстки без перезапуску AE.
 */
(function (global) {
  "use strict";

  var cep = global.__adobe_cep__ || null;
  var MOCK = !cep;

  // ─── Мок-відповіді для роботи поза After Effects ──────────────────────────
  var mockData = {
    getContext: {
      app: "24.0x0 (browser mock)", project: "demo.aep", comp: "MAIN_1080x1920",
      width: 1080, height: 1920, fps: 30, duration: 12.5, layers: 14, selected: 3
    },
    previewSort: {
      total: 46, matched: 4, kept: "MAIN_1080x1920",
      folders: [
        { label: "logo", folder: "01_logo", total: 4, rule: true, children: [] },
        { label: "Comps", folder: "02_Comps", total: 6, children: [] },
        { label: "Video", folder: "03_Video", total: 12, loose: 1,
          children: [{ folder: "MOV", total: 7 }, { folder: "MP4", total: 4 }] },
        { label: "Sequences", folder: "04_Sequences", total: 2,
          children: [{ folder: "EXR", total: 2 }] },
        { label: "Images", folder: "05_Images", total: 18, loose: 2,
          children: [{ folder: "JPG", total: 6 }, { folder: "PNG", total: 10 }] },
        { label: "Design", folder: "06_Design (PSD, AI)", total: 3,
          children: [{ folder: "PSD", total: 3 }] },
        { label: "Audio", folder: "07_Audio", total: 4,
          children: [{ folder: "WAV", total: 4 }] },
        { label: "Missing", folder: "08_Missing", total: 2, children: [] }
      ]
    },
    sortProject: {
      moved: 41, total: 46, removedFolders: 3, matched: 4, kept: "MAIN_1080x1920",
      folders: [
        { label: "logo", folder: "01_logo", total: 4, moved: 4, rule: true, children: [] },
        { label: "Comps", folder: "02_Comps", total: 6, moved: 5, children: [] },
        { label: "Video", folder: "03_Video", total: 12, moved: 12, loose: 1,
          children: [{ folder: "MOV", total: 7, moved: 7 }, { folder: "MP4", total: 4, moved: 4 }] },
        { label: "Sequences", folder: "04_Sequences", total: 2, moved: 2,
          children: [{ folder: "EXR", total: 2, moved: 2 }] },
        { label: "Images", folder: "05_Images", total: 18, moved: 16, loose: 2,
          children: [{ folder: "JPG", total: 6, moved: 6 }, { folder: "PNG", total: 10, moved: 8 }] },
        { label: "Design", folder: "06_Design (PSD, AI)", total: 3, moved: 3,
          children: [{ folder: "PSD", total: 3, moved: 3 }] },
        { label: "Audio", folder: "07_Audio", total: 4, moved: 3,
          children: [{ folder: "WAV", total: 4, moved: 3 }] },
        { label: "Missing", folder: "08_Missing", total: 2, moved: 0, children: [] }
      ]
    },
    renameLayers: { affected: 3 },
    sequenceLayers: { affected: 3, step: 0.166 },
    fitToComp: { affected: 3, skipped: 0 },
    trimWorkArea: { start: 0.5, duration: 4.2, affected: 3 },
    addMarker: { time: 3.4, text: "" },
    queueComp: { comp: "MAIN_1080x1920", queue: 1 },
    projectFolder: { path: "/Users/ivan/Projects/demo" }
  };

  /**
   * Виклик команди в ExtendScript.
   * @param {string} cmd  назва команди з host/index.jsx
   * @param {object} args аргументи
   * @returns {Promise<object>} data з боку AE
   */
  function invoke(cmd, args) {
    var payload = JSON.stringify({ cmd: cmd, args: args || {} });

    if (MOCK) {
      return new Promise(function (resolve, reject) {
        setTimeout(function () {
          if (!mockData.hasOwnProperty(cmd)) {
            reject(new Error("Mock has no command " + cmd));
            return;
          }
          var data = JSON.parse(JSON.stringify(mockData[cmd]));
          // Область "In comp" складає все всередину папки з назвою композиції
          if (args && args.scope === "comp") data.container = "MAIN_1080x1920";
          if (args && args.keepActive === false) delete data.kept;
          resolve(data);
        }, 120);
      });
    }

    // JSON.stringify перетворює payload на коректний рядковий літерал для ExtendScript
    var script = "dispatch(" + JSON.stringify(payload) + ")";

    return new Promise(function (resolve, reject) {
      cep.evalScript(script, function (raw) {
        if (raw === "EvalScript error.") {
          reject(new Error("ExtendScript не виконався — перевір host/index.jsx"));
          return;
        }
        var res;
        try {
          res = JSON.parse(raw);
        } catch (e) {
          reject(new Error("Некоректна відповідь: " + String(raw).slice(0, 120)));
          return;
        }
        if (res.ok) resolve(res.data);
        else reject(new Error(res.error));
      });
    });
  }

  /** Кольори інтерфейсу самого AE, щоб панель не випадала з теми. */
  function readHostTheme() {
    if (MOCK) return { bg: [29, 29, 29] };
    try {
      var env = JSON.parse(cep.getHostEnvironment());
      var c = env.appSkinInfo.panelBackgroundColor.color;
      return { bg: [Math.round(c.red), Math.round(c.green), Math.round(c.blue)] };
    } catch (e) {
      return { bg: [29, 29, 29] };
    }
  }

  /** Підписка на зміну теми AE (Preferences → Appearance). */
  function onThemeChange(handler) {
    if (MOCK) return;
    try {
      cep.addEventListener("com.adobe.csxs.events.ThemeColorChanged", function () {
        handler(readHostTheme());
      });
    } catch (e) { /* старіші CEP — просто без live-оновлення */ }
  }

  function openPath(path) {
    if (MOCK) { console.log("open:", path); return; }
    var url = "file://" + (path.charAt(0) === "/" ? "" : "/") + path.replace(/\\/g, "/");
    global.cep.util.openURLInDefaultBrowser(url);
  }

  global.AEBridge = {
    invoke: invoke,
    readHostTheme: readHostTheme,
    onThemeChange: onThemeChange,
    openPath: openPath,
    isMock: MOCK
  };
})(window);
