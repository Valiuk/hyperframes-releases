/* AE Kit — логіка панелі. Одна кнопка = одна команда ExtendScript. */
(function () {
  "use strict";

  var $ = function (id) { return document.getElementById(id); };

  var wire = $("wire"),
      wireText = $("wire-text"),
      roComp = $("ro-comp"),
      roMeta = $("ro-meta");

  // ─── Статусний рядок ──────────────────────────────────────────────────────

  function say(text, state) {
    wire.className = "wire" + (state ? " is-" + state : "");
    wireText.textContent = text;
    wireText.title = text;
  }

  function plural(n, one, many) { return n === 1 ? one : many; }

  function count(n, word) { return n + " " + plural(n, word, word + "s"); }

  // ─── Аргументи для кожної команди ─────────────────────────────────────────

  // Область дії для розкладання: корінь проєкту / увесь проєкт / виділене
  var scope = "root";

  // ─── Правила за назвою ────────────────────────────────────────────────────

  var RULES_KEY = "aekit.rules";
  var rules = [];

  function loadRules() {
    try {
      var raw = window.localStorage.getItem(RULES_KEY);
      rules = raw ? JSON.parse(raw) : [];
    } catch (e) {
      rules = [];
    }
  }

  function saveRules() {
    try {
      window.localStorage.setItem(RULES_KEY, JSON.stringify(rules));
    } catch (e) { /* приватний режим — правила живуть до закриття панелі */ }
  }

  function renderRules() {
    var box = $("rules");
    box.innerHTML = "";
    box.hidden = !rules.length;

    for (var i = 0; i < rules.length; i++) {
      var li = document.createElement("li");
      li.className = "rule";

      var order = document.createElement("span");
      order.className = "rule-order";
      order.textContent = i + 1;

      var word = document.createElement("span");
      word.className = "rule-word";
      word.textContent = rules[i].words;
      word.title = "→ folder “" + rules[i].folder + "”";

      var kill = document.createElement("button");
      kill.className = "rule-kill";
      kill.type = "button";
      kill.textContent = "×";
      kill.title = "Remove rule";
      kill.setAttribute("data-rule", String(i));

      li.appendChild(order);
      li.appendChild(word);
      li.appendChild(kill);
      box.appendChild(li);
    }
  }

  function addRule() {
    var input = $("rule-word");
    var text = input.value.replace(/^\s+|\s+$/g, "");
    if (!text) { say("type a word to group by", "err"); input.focus(); return; }

    // Ім'я папки — перше слово так, як його набрали
    var folder = text.split(",")[0].replace(/^\s+|\s+$/g, "");
    rules.push({ words: text, folder: folder });

    saveRules();
    renderRules();
    input.value = "";
    input.focus();
    $("plan").hidden = true;
    say("rule added: " + folder, "ok");
  }

  function sortArgs() {
    return {
      scope: scope,
      numbered: $("numbered").checked,
      cleanEmpty: $("clean-empty").checked,
      keepActive: $("keep-active").checked,
      byFormat: $("by-format").checked,
      minPerFormat: $("min-per-format").value,
      rules: rules
    };
  }

  /** Список «папка → скільки» під кнопкою Preview, з вкладеними форматами. */
  function renderPlan(rows, showMoved, container) {
    var plan = $("plan");
    plan.innerHTML = "";
    if (!rows || !rows.length) { plan.hidden = true; return; }

    function line(label, total, moved, cls, tip) {
      var li = document.createElement("li");
      if (cls) li.className = cls;
      if (tip) li.title = tip;

      var name = document.createElement("span");
      name.className = "plan-name";
      name.textContent = label;

      var count = document.createElement("span");
      count.className = "plan-count";
      count.textContent = showMoved ? moved + " / " + total : String(total);
      count.title = showMoved ? "moved / total in folder" : "items";

      li.appendChild(name);
      li.appendChild(count);
      plan.appendChild(li);
    }

    // Для області "In comp" усе лягає всередину папки з назвою композиції
    if (container) {
      var head = document.createElement("li");
      head.className = "is-container";
      var hname = document.createElement("span");
      hname.className = "plan-name";
      hname.textContent = container;
      hname.title = "everything below goes inside this folder";
      head.appendChild(hname);
      plan.appendChild(head);
      plan.classList.add("has-container");
    } else {
      plan.classList.remove("has-container");
    }

    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      line(r.folder, r.total, r.moved, r.rule ? "is-rule" : "",
           r.rule ? "matched by name rule" : "");

      var kids = r.children || [];
      for (var k = 0; k < kids.length; k++) {
        line(kids[k].folder, kids[k].total, kids[k].moved, "is-child");
      }
      // Скільки лишилось лежати в самій категорії, повз формати
      if (kids.length && r.loose) {
        line("rest", r.loose, r.loose, "is-child", "stays directly in the category folder");
      }
    }
    plan.hidden = false;
  }

  var argBuilders = {
    previewSort: sortArgs,
    sortProject: sortArgs,
    renameLayers: function () {
      return {
        pattern: $("pattern").value,
        start: $("start").value,
        padding: $("padding").value
      };
    },
    sequenceLayers: function () {
      return { frames: $("frames").value, reverse: $("reverse").checked };
    },
    fitToComp: function (btn) {
      return { mode: btn.getAttribute("data-mode") || "fit" };
    },
    addMarker: function () {
      return { text: $("marker-text").value };
    }
  };

  // ─── Що показати після успіху ─────────────────────────────────────────────

  var report = {
    previewSort: function (d) {
      renderPlan(d.folders, false, d.container);
      var msg = count(d.total, "item") + " → " + count(d.folders.length, "folder");
      if (d.container) msg += " in " + d.container;
      if (d.matched) msg += " · " + d.matched + " by name";
      if (d.kept) msg += " · " + d.kept + " untouched";
      return msg;
    },
    sortProject: function (d) {
      renderPlan(d.folders, true, d.container);
      var msg = "moved " + d.moved + " of " + d.total;
      if (d.container) msg += " into " + d.container;
      if (d.matched) msg += " · " + d.matched + " by name";
      if (d.kept) msg += " · " + d.kept + " untouched";
      if (d.removedFolders) msg += " · removed " + count(d.removedFolders, "empty folder");
      return msg;
    },
    renameLayers: function (d) { return "renamed " + count(d.affected, "layer"); },
    sequenceLayers: function (d) { return "sequenced " + count(d.affected, "layer"); },
    fitToComp: function (d) {
      return "resized " + count(d.affected, "layer") + (d.skipped ? ", skipped " + d.skipped : "");
    },
    trimWorkArea: function (d) { return "work area " + d.duration.toFixed(2) + " s"; },
    addMarker: function (d) { return "marker at " + d.time.toFixed(2) + " s"; },
    queueComp: function (d) { return "render queue: " + d.queue; },
    projectFolder: function (d) { return "opened project folder"; }
  };

  // ─── Виконання ────────────────────────────────────────────────────────────

  function run(cmd, btn) {
    var args = argBuilders[cmd] ? argBuilders[cmd](btn) : {};
    if (btn) btn.disabled = true;
    say(cmd + "…");

    AEBridge.invoke(cmd, args)
      .then(function (data) {
        if (cmd === "projectFolder") AEBridge.openPath(data.path);
        var msg = report[cmd] ? report[cmd](data) : "done";
        say(msg, "ok");
        return refresh(false);
      })
      .catch(function (err) {
        say(err.message, "err");
      })
      .then(function () {
        if (btn) btn.disabled = false;
      });
  }

  // ─── Стан композиції ──────────────────────────────────────────────────────

  function refresh(spin) {
    if (spin) {
      var r = $("refresh");
      r.classList.remove("is-spinning");
      void r.offsetWidth;
      r.classList.add("is-spinning");
    }
    return AEBridge.invoke("getContext", {}).then(function (c) {
      if (!c.comp) {
        roComp.textContent = "No active composition";
        roMeta.textContent = c.project;
        return;
      }
      roComp.textContent = c.comp;
      roMeta.innerHTML =
        c.width + "×" + c.height + " · " + c.fps + " fps · " +
        c.duration.toFixed(2) + " s · " + c.layers + " / <b>" + c.selected + "</b>";
      roMeta.title = "size · frame rate · duration · layers in comp / selected";
    }).catch(function (err) {
      roComp.textContent = "No connection to After Effects";
      roMeta.textContent = err.message;
    });
  }

  // ─── Тема AE ──────────────────────────────────────────────────────────────

  function applyTheme(theme) {
    var c = theme.bg;
    document.documentElement.style.setProperty("--bg", "rgb(" + c.join(",") + ")");
    // На світлій темі AE інвертуємо текстові тони, щоб панель лишалась читабельною
    var lum = (c[0] * 0.299 + c[1] * 0.587 + c[2] * 0.114);
    var light = lum > 128;
    var s = document.documentElement.style;
    s.setProperty("--text", light ? "#26292b" : "#d8d8d8");
    s.setProperty("--text-dim", light ? "#6a6f73" : "#8b8b8b");
    s.setProperty("--line", light ? "rgba(0,0,0,0.13)" : "rgba(255,255,255,0.09)");
    s.setProperty("--surface", light ? "rgba(0,0,0,0.04)" : "rgba(255,255,255,0.035)");
    s.setProperty("--surface-hi", light ? "rgba(0,0,0,0.08)" : "rgba(255,255,255,0.07)");
    s.setProperty("--accent", light ? "#b96f00" : "#f0a63c");
  }

  // ─── Ініціалізація ────────────────────────────────────────────────────────

  document.addEventListener("click", function (e) {
    var btn = e.target.closest("[data-cmd]");
    if (btn) run(btn.getAttribute("data-cmd"), btn);
  });

  // ─── Згортання груп ───────────────────────────────────────────────────────

  var STORE_KEY = "aekit.collapsed";

  function readStored() {
    try {
      var raw = window.localStorage.getItem(STORE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function writeStored() {
    var closed = [];
    var groups = document.querySelectorAll(".group");
    for (var i = 0; i < groups.length; i++) {
      if (groups[i].classList.contains("is-collapsed")) {
        closed.push(groups[i].getAttribute("data-group"));
      }
    }
    try {
      window.localStorage.setItem(STORE_KEY, JSON.stringify(closed));
    } catch (e) { /* приватний режим — просто без запам'ятовування */ }
  }

  function setCollapsed(group, collapsed) {
    group.classList.toggle("is-collapsed", collapsed);
    group.querySelector(".eyebrow").setAttribute("aria-expanded", collapsed ? "false" : "true");
  }

  function restoreCollapsed() {
    var closed = readStored();
    for (var i = 0; i < closed.length; i++) {
      var g = document.querySelector('.group[data-group="' + closed[i] + '"]');
      if (g) setCollapsed(g, true);
    }
  }

  document.addEventListener("click", function (e) {
    var head = e.target.closest(".eyebrow");
    if (!head) return;

    var group = head.closest(".group");
    var collapsed = !group.classList.contains("is-collapsed");

    if (e.altKey) {
      // Alt+клік доводить решту груп до того ж стану — панель за один рух
      // складається в заголовки або розкривається повністю
      var all = document.querySelectorAll(".group");
      for (var i = 0; i < all.length; i++) setCollapsed(all[i], collapsed);
    } else {
      setCollapsed(group, collapsed);
    }
    writeStored();
  });

  $("refresh").addEventListener("click", function () { refresh(true); });

  $("scope").addEventListener("click", function (e) {
    var btn = e.target.closest(".seg-btn");
    if (!btn) return;
    scope = btn.getAttribute("data-scope-val");
    var all = this.querySelectorAll(".seg-btn");
    for (var i = 0; i < all.length; i++) all[i].classList.toggle("is-on", all[i] === btn);
    $("plan").hidden = true;   // старий план більше не про це
  });

  $("numbered").addEventListener("change", function () { $("plan").hidden = true; });

  function syncFormatOption() {
    var on = $("by-format").checked;
    $("min-field").hidden = !on;
    $("min-hint").hidden = !on;
    $("plan").hidden = true;
  }

  $("by-format").addEventListener("change", syncFormatOption);
  $("min-per-format").addEventListener("change", function () { $("plan").hidden = true; });
  syncFormatOption();

  // Enter у полі перейменування = натиснути кнопку
  $("pattern").addEventListener("keydown", function (e) {
    if (e.key === "Enter") run("renameLayers", document.querySelector('[data-cmd="renameLayers"]'));
  });

  $("rule-add").addEventListener("click", addRule);

  $("rule-word").addEventListener("keydown", function (e) {
    if (e.key === "Enter") { e.preventDefault(); addRule(); }
  });

  $("rules").addEventListener("click", function (e) {
    var kill = e.target.closest(".rule-kill");
    if (!kill) return;
    rules.splice(parseInt(kill.getAttribute("data-rule"), 10), 1);
    saveRules();
    renderRules();
    $("plan").hidden = true;
  });

  loadRules();
  renderRules();
  restoreCollapsed();
  applyTheme(AEBridge.readHostTheme());
  AEBridge.onThemeChange(applyTheme);

  refresh(false);
  if (AEBridge.isMock) say("browser mode — After Effects not connected");

  // Виділення в AE панель сама не відстежує: оновлюємо стан, коли до неї повертаються
  window.addEventListener("focus", function () { refresh(false); });
})();
