/**
 * AE Kit — ExtendScript-бекенд панелі.
 *
 * Панель викликає рівно одну функцію: dispatch(payload), де payload — JSON-рядок
 * виду {"cmd":"renameLayers","args":{...}}. Назад завжди повертається JSON-рядок
 * {"ok":true,"data":...} або {"ok":false,"error":"..."}.
 *
 * ExtendScript — це ES3: ніяких let/const, стрілок, JSON, Array.forEach, indexOf.
 */

// ─── JSON (ES3-сумісний мінімум) ────────────────────────────────────────────

function jsonEscape(s) {
    s = String(s);
    var out = "";
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        var code = s.charCodeAt(i);
        if (c === '"') out += '\\"';
        else if (c === "\\") out += "\\\\";
        else if (c === "\n") out += "\\n";
        else if (c === "\r") out += "\\r";
        else if (c === "\t") out += "\\t";
        else if (code < 32 || code > 126) {
            var hex = code.toString(16);
            while (hex.length < 4) hex = "0" + hex;
            out += "\\u" + hex;
        } else out += c;
    }
    return out;
}

function jsonStringify(v) {
    var t = typeof v;
    if (v === null || t === "undefined") return "null";
    if (t === "number") return isFinite(v) ? String(v) : "null";
    if (t === "boolean") return v ? "true" : "false";
    if (t === "string") return '"' + jsonEscape(v) + '"';
    if (v instanceof Array) {
        var a = [];
        for (var i = 0; i < v.length; i++) a.push(jsonStringify(v[i]));
        return "[" + a.join(",") + "]";
    }
    var parts = [];
    for (var k in v) {
        if (!v.hasOwnProperty(k)) continue;
        if (typeof v[k] === "function") continue;
        parts.push('"' + jsonEscape(k) + '":' + jsonStringify(v[k]));
    }
    return "{" + parts.join(",") + "}";
}

// Розбір вхідного рядка. Рядок формує сама панель, стороннього вводу тут немає.
function jsonParse(str) {
    return eval("(" + str + ")");
}

// ─── Дрібні помічники ───────────────────────────────────────────────────────

function activeComp() {
    var c = app.project ? app.project.activeItem : null;
    if (!c || !(c instanceof CompItem)) throw new Error("No active composition");
    return c;
}

function selectedLayers(comp) {
    var sel = comp.selectedLayers;
    if (!sel || sel.length === 0) throw new Error("No layers selected");
    return sel;
}

// Сортує шари за індексом (згори вниз у таймлайні)
function sortByIndex(layers) {
    var arr = [];
    for (var i = 0; i < layers.length; i++) arr.push(layers[i]);
    arr.sort(function (a, b) { return a.index - b.index; });
    return arr;
}

function pad(n, width) {
    var s = String(n);
    while (s.length < width) s = "0" + s;
    return s;
}

function undoable(title, fn) {
    app.beginUndoGroup(title);
    try {
        return fn();
    } finally {
        app.endUndoGroup();
    }
}

// ─── Команди ────────────────────────────────────────────────────────────────

var commands = {};

/** Стан для верхнього рядка панелі. */
commands.getContext = function () {
    var out = {
        app: app.version,
        project: (app.project && app.project.file) ? app.project.file.name : "Untitled",
        comp: null,
        width: 0,
        height: 0,
        fps: 0,
        duration: 0,
        layers: 0,
        selected: 0
    };
    var c = app.project ? app.project.activeItem : null;
    if (c && c instanceof CompItem) {
        out.comp = c.name;
        out.width = c.width;
        out.height = c.height;
        out.fps = Math.round(c.frameRate * 1000) / 1000;
        out.duration = Math.round(c.duration * 1000) / 1000;
        out.layers = c.numLayers;
        out.selected = c.selectedLayers.length;
    }
    return out;
};

/**
 * Перейменування виділених шарів за шаблоном.
 * Токени: {n} — номер, {name} — стара назва, {i} — індекс шару в композиції.
 * args: { pattern, start, padding }
 */
commands.renameLayers = function (args) {
    var comp = activeComp();
    var layers = sortByIndex(selectedLayers(comp));
    var pattern = args.pattern && args.pattern.length ? args.pattern : "{name}";
    var start = parseInt(args.start, 10);
    if (isNaN(start)) start = 1;
    var width = parseInt(args.padding, 10);
    if (isNaN(width) || width < 1) width = 2;

    return undoable("AE Kit: Rename layers", function () {
        for (var i = 0; i < layers.length; i++) {
            var L = layers[i];
            var name = pattern
                .replace(/\{name\}/g, L.name)
                .replace(/\{n\}/g, pad(start + i, width))
                .replace(/\{i\}/g, String(L.index));
            L.name = name;
        }
        return { affected: layers.length };
    });
};

/**
 * Розкладає виділені шари послідовно з кроком у кадрах.
 * args: { frames, reverse }
 */
commands.sequenceLayers = function (args) {
    var comp = activeComp();
    var layers = sortByIndex(selectedLayers(comp));
    if (args.reverse) layers.reverse();

    var frames = parseFloat(args.frames);
    if (isNaN(frames)) frames = 0;
    var step = frames * comp.frameDuration;
    var base = layers[0].startTime;

    return undoable("AE Kit: Sequence layers", function () {
        for (var i = 0; i < layers.length; i++) {
            layers[i].startTime = base + step * i;
        }
        return { affected: layers.length, step: step };
    });
};

/**
 * Вписує / заповнює виділені шари під розмір композиції.
 * args: { mode: "fit" | "fill" }
 */
commands.fitToComp = function (args) {
    var comp = activeComp();
    var layers = selectedLayers(comp);
    var fill = args.mode === "fill";
    var done = 0;
    var skipped = 0;

    return undoable("AE Kit: Fit to comp", function () {
        for (var i = 0; i < layers.length; i++) {
            var L = layers[i];
            if (!(L instanceof AVLayer) && !(L instanceof ShapeLayer) && !(L instanceof TextLayer)) {
                skipped++;
                continue;
            }
            var rect;
            try {
                rect = L.sourceRectAtTime(comp.time, false);
            } catch (e) {
                skipped++;
                continue;
            }
            if (!rect.width || !rect.height) { skipped++; continue; }

            var sx = comp.width / rect.width;
            var sy = comp.height / rect.height;
            var s = fill ? Math.max(sx, sy) : Math.min(sx, sy);

            var anchor = L.property("ADBE Transform Group").property("ADBE Anchor Point");
            var scale = L.property("ADBE Transform Group").property("ADBE Scale");
            var pos = L.property("ADBE Transform Group").property("ADBE Position");

            if (anchor.numKeys === 0) {
                anchor.setValue([rect.left + rect.width / 2, rect.top + rect.height / 2, 0].slice(0, anchor.value.length));
            }
            if (scale.numKeys === 0) {
                var sv = scale.value.length === 3 ? [s * 100, s * 100, 100] : [s * 100, s * 100];
                scale.setValue(sv);
            }
            if (pos.numKeys === 0 && !pos.expressionEnabled) {
                var pv = pos.value.length === 3
                    ? [comp.width / 2, comp.height / 2, pos.value[2]]
                    : [comp.width / 2, comp.height / 2];
                pos.setValue(pv);
            }
            done++;
        }
        return { affected: done, skipped: skipped };
    });
};

/** Робоча область = межі виділених шарів. */
commands.trimWorkArea = function () {
    var comp = activeComp();
    var layers = selectedLayers(comp);
    var inP = layers[0].inPoint;
    var outP = layers[0].outPoint;
    for (var i = 1; i < layers.length; i++) {
        if (layers[i].inPoint < inP) inP = layers[i].inPoint;
        if (layers[i].outPoint > outP) outP = layers[i].outPoint;
    }
    if (inP < 0) inP = 0;
    if (outP > comp.duration) outP = comp.duration;

    return undoable("AE Kit: Work area", function () {
        comp.workAreaStart = inP;
        comp.workAreaDuration = Math.max(comp.frameDuration, outP - inP);
        return { start: inP, duration: comp.workAreaDuration, affected: layers.length };
    });
};

/**
 * Маркер композиції на поточному часі.
 * args: { text }
 */
commands.addMarker = function (args) {
    var comp = activeComp();
    var text = args.text || "";
    return undoable("AE Kit: Marker", function () {
        var m = new MarkerValue(text);
        comp.markerProperty.setValueAtTime(comp.time, m);
        return { time: comp.time, text: text };
    });
};

/** Додає активну композицію в чергу рендерингу. */
commands.queueComp = function () {
    var comp = activeComp();
    return undoable("AE Kit: Add to render queue", function () {
        app.project.renderQueue.items.add(comp);
        return { comp: comp.name, queue: app.project.renderQueue.numItems };
    });
};

/** Шлях до теки проєкту — панель відкриє її засобами CEP. */
commands.projectFolder = function () {
    if (!app.project || !app.project.file) throw new Error("Save the project first");
    return { path: app.project.file.parent.fsName };
};

// ─── Розкладання проєкту по папках ──────────────────────────────────────────

// Порядок у списку = порядок нумерації папок у проєкті.
// split — чи має сенс ділити категорію на формати (у композицій і солідів файлу немає)
var CATEGORIES = [
    { key: "comps",   label: "Comps",      folder: "Comps",             split: false },
    { key: "video",   label: "Video",      folder: "Video",             split: true },
    { key: "seq",     label: "Sequences",  folder: "Sequences",         split: true },
    { key: "image",   label: "Images",     folder: "Images",            split: true },
    { key: "design",  label: "Design",     folder: "Design (PSD, AI)",  split: true },
    { key: "audio",   label: "Audio",      folder: "Audio",             split: true },
    { key: "solid",   label: "Solids",     folder: "Solids",            split: false },
    { key: "missing", label: "Missing",    folder: "Missing",           split: false },
    { key: "other",   label: "Other",      folder: "Other",             split: true }
];

var EXT_VIDEO  = "mov mp4 m4v avi mxf mpg mpeg mts m2t m2ts vob wmv webm 3gp dv r3d braw ari arri prores mpe".split(" ");
var EXT_IMAGE  = "jpg jpeg jpe png tif tiff tga targa bmp gif exr dpx cin hdr webp svg heic pict pct sgi rla rpf jp2 j2k iff".split(" ");
var EXT_DESIGN = "psd psb ai eps aep aet".split(" ");
var EXT_AUDIO  = "wav mp3 aif aiff aifc m4a aac flac ogg oga wma mp2 caf".split(" ");

function inList(list, value) {
    for (var i = 0; i < list.length; i++) if (list[i] === value) return true;
    return false;
}

function extensionOf(item) {
    try {
        var f = null;
        if (item.mainSource && item.mainSource.file) f = item.mainSource.file;
        else if (item.file) f = item.file;
        if (!f) return "";
        var n = f.name;
        var dot = n.lastIndexOf(".");
        return dot < 0 ? "" : n.substring(dot + 1).toLowerCase();
    } catch (e) {
        return "";
    }
}

/** До якої категорії належить елемент проєкту. */
function classify(item) {
    if (item instanceof CompItem) return "comps";
    if (!(item instanceof FootageItem)) return "other";
    if (item.footageMissing) return "missing";

    var src = item.mainSource;
    if (src instanceof SolidSource) return "solid";
    if (src instanceof PlaceholderSource) return "missing";

    var ext = extensionOf(item);
    if (inList(EXT_DESIGN, ext)) return "design";
    if (inList(EXT_AUDIO, ext)) return "audio";
    if (inList(EXT_VIDEO, ext)) return "video";
    // Нерухоме зображення чи секвенція з таких самих кадрів — різні речі в роботі
    if (inList(EXT_IMAGE, ext)) return src.isStill ? "image" : "seq";
    if (item.hasAudio && !item.hasVideo) return "audio";
    if (item.hasVideo) return src.isStill ? "image" : "video";
    return "other";
}

/** Композиція, з якою працюємо: виділена в Project, інакше активна. */
function targetComp() {
    var sel = app.project.selection;
    for (var i = 0; i < sel.length; i++) {
        if (sel[i] instanceof CompItem) return sel[i];
    }
    var c = openComp();
    if (c) return c;
    throw new Error("Select a composition in the Project panel");
}

/** Усе, що використано в композиції, включно з вкладеними прекомпами. */
function collectFromComp(comp, seen, out) {
    seen[comp.id] = true;

    for (var i = 1; i <= comp.numLayers; i++) {
        var src = null;
        try { src = comp.layer(i).source; } catch (e) { /* камери, світло, нуль-об'єкти */ }
        if (!src || seen[src.id]) continue;

        seen[src.id] = true;
        out.push(src);
        if (src instanceof CompItem) collectFromComp(src, seen, out);
    }
    return out;
}

/**
 * Активна композиція або null — на відміну від activeComp() вище, який кидає
 * помилку. Тут відсутність композиції не привід зупиняти сортування.
 */
function openComp() {
    var c = app.project.activeItem;
    return (c && c instanceof CompItem) ? c : null;
}

/**
 * scope: "root" — верхній рівень, "all" — увесь проєкт, "selection" — виділене
 * в Project, "comp" — усе, що лежить усередині вибраної композиції.
 * keepActive — не зачіпати активну композицію, хай лишається де лежить.
 * Повертає ще й контейнер: для "comp" це папка з назвою композиції.
 */
function scopeContext(scope, keepActive) {
    var skip = keepActive ? openComp() : null;
    var kept = null;
    var out = [], i;

    function push(item) {
        if (skip && item === skip) { kept = item.name; return; }
        out.push(item);
    }

    if (scope === "comp") {
        var comp = targetComp();
        var found = collectFromComp(comp, {}, []);
        for (i = 0; i < found.length; i++) push(found[i]);
        if (!out.length) throw new Error("This composition has no sources to group");
        return { items: out, comp: comp, containerName: comp.name, kept: kept };
    }

    if (scope === "selection") {
        var sel = app.project.selection;
        for (i = 0; i < sel.length; i++) {
            if (!(sel[i] instanceof FolderItem)) push(sel[i]);
        }
        if (out.length === 0) throw new Error("Nothing selected in the Project panel");
        return { items: out, comp: null, containerName: null, kept: kept };
    }

    var items = app.project.items;
    for (i = 1; i <= items.length; i++) {
        var it = items[i];
        if (it instanceof FolderItem) continue;
        if (scope === "root" && it.parentFolder !== app.project.rootFolder) continue;
        push(it);
    }
    if (out.length === 0) throw new Error("Nothing to sort");
    return { items: out, comp: null, containerName: null, kept: kept };
}

// "01_Відео" і "Відео" — та сама папка, просто з нумерацією і без
function baseName(name) {
    return String(name).replace(/^\d{1,3}[_\-.\s]+/, "");
}

// Різні розширення того самого формату не мають плодити окремі папки
var FORMAT_ALIAS = {
    jpeg: "jpg", jpe: "jpg", tiff: "tif", aiff: "aif", aifc: "aif",
    mpeg: "mpg", mpe: "mpg", m2ts: "mts", psb: "psd", oga: "ogg",
    j2k: "jp2", targa: "tga", pct: "pict", arri: "ari"
};

/** Назва підпапки для елемента: MOV, MP4, WAV… Порожньо — формату немає. */
function formatOf(item) {
    var e = extensionOf(item);
    if (!e) return "";
    if (FORMAT_ALIAS.hasOwnProperty(e)) e = FORMAT_ALIAS[e];
    return e.toUpperCase();
}

/**
 * Ділить категорію на формати. Те, що не набрало minPer файлів,
 * лишається просто в папці категорії — щоб не плодити папки з одного файла.
 */
function splitByFormat(list, minPer) {
    var map = {}, names = [], rest = [], i, j;

    for (i = 0; i < list.length; i++) {
        var f = formatOf(list[i]);
        if (!f) { rest.push(list[i]); continue; }
        if (!map[f]) { map[f] = []; names.push(f); }
        map[f].push(list[i]);
    }
    names.sort();

    var kept = [];
    for (i = 0; i < names.length; i++) {
        if (map[names[i]].length >= minPer) {
            kept.push(names[i]);
        } else {
            for (j = 0; j < map[names[i]].length; j++) rest.push(map[names[i]][j]);
            delete map[names[i]];
        }
    }
    return { names: kept, map: map, rest: rest };
}

function findChildFolder(parent, name) {
    var target = baseName(name);
    for (var i = 1; i <= parent.numItems; i++) {
        var it = parent.item(i);
        if (it instanceof FolderItem && baseName(it.name) === target) return it;
    }
    return null;
}

/** Створює або знаходить папку з назвою name всередині container. */
function ensureFolderIn(container, base, name) {
    var folder = findChildFolder(container, base);
    if (!folder) {
        folder = app.project.items.addFolder(name);
        folder.parentFolder = container;
    } else if (folder.name !== name) {
        folder.name = name;
    }
    return folder;
}

function removeEmptyFolders() {
    var removed = 0, changed = true, guard = 0;
    while (changed && guard < 12) {
        changed = false;
        guard++;
        var items = app.project.items, doomed = [], i;
        for (i = 1; i <= items.length; i++) {
            var it = items[i];
            if (it instanceof FolderItem && it.numItems === 0) doomed.push(it);
        }
        for (i = 0; i < doomed.length; i++) {
            doomed[i].remove();
            removed++;
            changed = true;
        }
    }
    return removed;
}

function bucketize(items) {
    var buckets = {};
    for (var i = 0; i < items.length; i++) {
        var k = classify(items[i]);
        if (!buckets[k]) buckets[k] = [];
        buckets[k].push(items[i]);
    }
    return buckets;
}

// ─── Правила за назвою ──────────────────────────────────────────────────────

function trim(s) {
    return String(s).replace(/^\s+/, "").replace(/\s+$/, "");
}

/**
 * Правило приходить як { words: "logo, brand", folder: "Logo" }.
 * words — через кому, збіг за будь-яким; folder порожній = перше слово.
 */
function normalizeRules(raw) {
    var out = [];
    if (!raw || !raw.length) return out;

    for (var i = 0; i < raw.length; i++) {
        var parts = String(raw[i].words || "").split(",");
        var terms = [];
        for (var j = 0; j < parts.length; j++) {
            var w = trim(parts[j]).toLowerCase();
            if (w) terms.push(w);
        }
        if (!terms.length) continue;

        var folder = trim(String(raw[i].folder || ""));
        if (!folder) folder = trim(parts[0]);
        out.push({ terms: terms, folder: folder });
    }
    return out;
}

/** Індекс першого правила, під яке підходить елемент, або -1. */
function matchRule(item, rules) {
    var name = String(item.name).toLowerCase();
    var file = "";
    try {
        if (item.mainSource && item.mainSource.file) {
            file = String(item.mainSource.file.name).toLowerCase();
        }
    } catch (e) { /* соліди й композиції файлу не мають */ }

    for (var i = 0; i < rules.length; i++) {
        var terms = rules[i].terms;
        for (var t = 0; t < terms.length; t++) {
            if (name.indexOf(terms[t]) !== -1 || file.indexOf(terms[t]) !== -1) return i;
        }
    }
    return -1;
}

/** Розводить елементи по правилах; решта йде на сортування за типом. */
function applyRules(items, rules) {
    var byRule = [], rest = [], i;
    for (i = 0; i < rules.length; i++) byRule.push([]);

    for (i = 0; i < items.length; i++) {
        var idx = rules.length ? matchRule(items[i], rules) : -1;
        if (idx >= 0) byRule[idx].push(items[i]);
        else rest.push(items[i]);
    }
    return { byRule: byRule, rest: rest };
}

// ─── Попередній перегляд і саме розкладання ─────────────────────────────────

/** Що станеться, без жодних змін у проєкті. */
commands.previewSort = function (args) {
    var ctx = scopeContext(args.scope || "root", args.keepActive !== false);
    var items = ctx.items;
    var rules = normalizeRules(args.rules);
    var split0 = applyRules(items, rules);
    var buckets = bucketize(split0.rest);

    var byFormat = !!args.byFormat;
    var minPer = parseInt(args.minPerFormat, 10);
    if (isNaN(minPer) || minPer < 1) minPer = 1;

    var rows = [], order = 1, i;

    // Спершу правила — вони конкретніші за будь-який тип
    for (i = 0; i < rules.length; i++) {
        var list = split0.byRule[i];
        if (!list.length) continue;
        rows.push({
            label: rules[i].folder,
            folder: args.numbered ? pad(order, 2) + "_" + rules[i].folder : rules[i].folder,
            total: list.length,
            rule: true,
            children: []
        });
        order++;
    }

    for (var c = 0; c < CATEGORIES.length; c++) {
        var cat = CATEGORIES[c];
        var clist = buckets[cat.key];
        if (!clist || !clist.length) continue;

        var row = {
            label: cat.label,
            folder: args.numbered ? pad(order, 2) + "_" + cat.folder : cat.folder,
            total: clist.length,
            children: []
        };
        order++;

        if (byFormat && cat.split) {
            var fsplit = splitByFormat(clist, minPer);
            for (var f = 0; f < fsplit.names.length; f++) {
                row.children.push({
                    folder: fsplit.names[f],
                    total: fsplit.map[fsplit.names[f]].length
                });
            }
            row.loose = fsplit.rest.length;
        }
        rows.push(row);
    }

    return {
        total: items.length,
        folders: rows,
        matched: items.length - split0.rest.length,
        container: ctx.containerName,
        kept: ctx.kept
    };
};

/** args: { scope, numbered, cleanEmpty, byFormat, minPerFormat, rules } */
commands.sortProject = function (args) {
    var scope = args.scope || "root";
    var numbered = !!args.numbered;
    var byFormat = !!args.byFormat;
    var minPer = parseInt(args.minPerFormat, 10);
    if (isNaN(minPer) || minPer < 1) minPer = 1;

    var ctx = scopeContext(scope, args.keepActive !== false);
    var items = ctx.items;
    var rules = normalizeRules(args.rules);

    return undoable("AE Kit: Sort into folders", function () {
        var split0 = applyRules(items, rules);
        var buckets = bucketize(split0.rest);
        var rows = [], moved = 0, order = 1, i;

        // Для області "comp" уся структура будується всередині папки з назвою
        // композиції, для решти — просто в корені проєкту
        var container = app.project.rootFolder;
        if (ctx.containerName) {
            container = ensureFolderIn(container, ctx.containerName, ctx.containerName);
        }

        // Переносить items у folder і повертає, скільки реально зрушило з місця
        function moveInto(list, folder) {
            var m = 0;
            for (var k = 0; k < list.length; k++) {
                if (list[k].parentFolder !== folder) {
                    list[k].parentFolder = folder;
                    m++;
                }
            }
            return m;
        }

        for (i = 0; i < rules.length; i++) {
            var rlist = split0.byRule[i];
            if (!rlist.length) continue;

            var rname = numbered ? pad(order, 2) + "_" + rules[i].folder : rules[i].folder;
            order++;

            var rm = moveInto(rlist, ensureFolderIn(container, rules[i].folder, rname));
            moved += rm;
            rows.push({
                label: rules[i].folder, folder: rname, total: rlist.length,
                moved: rm, rule: true, children: []
            });
        }

        for (var c = 0; c < CATEGORIES.length; c++) {
            var cat = CATEGORIES[c];
            var clist = buckets[cat.key];
            if (!clist || !clist.length) continue;

            var name = numbered ? pad(order, 2) + "_" + cat.folder : cat.folder;
            order++;

            var folder = ensureFolderIn(container, cat.folder, name);
            var row = { label: cat.label, folder: name, total: clist.length, moved: 0, children: [] };

            if (byFormat && cat.split) {
                var fsplit = splitByFormat(clist, minPer);

                for (var f = 0; f < fsplit.names.length; f++) {
                    var fname = fsplit.names[f];
                    var sub = ensureFolderIn(folder, fname, fname);
                    var sm = moveInto(fsplit.map[fname], sub);
                    row.moved += sm;
                    row.children.push({ folder: fname, total: fsplit.map[fname].length, moved: sm });
                }
                // Файли без формату або нижче порога лишаються в самій категорії
                row.moved += moveInto(fsplit.rest, folder);
                row.loose = fsplit.rest.length;
            } else {
                // Розбиття вимкнено — усе піднімається назад у папку категорії,
                // а порожні підпапки прибере крок нижче
                row.moved += moveInto(clist, folder);
            }

            moved += row.moved;
            rows.push(row);
        }

        var removed = args.cleanEmpty ? removeEmptyFolders() : 0;
        return {
            moved: moved, total: items.length, folders: rows,
            removedFolders: removed,
            matched: items.length - split0.rest.length,
            container: ctx.containerName,
            kept: ctx.kept
        };
    });
};

// ─── Точка входу ────────────────────────────────────────────────────────────

function dispatch(payload) {
    try {
        var req = jsonParse(payload);
        var fn = commands[req.cmd];
        if (!fn) throw new Error("Unknown command: " + req.cmd);
        var data = fn(req.args || {});
        return jsonStringify({ ok: true, data: data });
    } catch (e) {
        var msg = e && e.message ? e.message : String(e);
        if (e && e.line) msg += " (line " + e.line + ")";
        return jsonStringify({ ok: false, error: msg });
    }
}
