/* Адаптери провайдерів: OpenAI (Responses API), Anthropic (Messages), Gemini, OpenAI-сумісні.
 * Запити йдуть через Node http/https — без CORS-обмежень CEP. */
(function () {
  'use strict';

  let https = null, http = null;
  try { https = require('https'); http = require('http'); } catch (e) {}

  class ApiError extends Error {
    constructor(status, message, body) { super(message); this.status = status; this.body = body; }
  }

  function request(url, { method = 'GET', headers = {}, body = null, signal = null, timeout = 600000 } = {}) {
    if (!https) return requestFetch(url, { method, headers, body, signal });
    return new Promise((resolve, reject) => {
      const u = new URL(url);
      const lib = u.protocol === 'http:' ? http : https;
      const payload = body ? Buffer.from(typeof body === 'string' ? body : JSON.stringify(body), 'utf8') : null;
      const h = { ...headers };
      if (payload) { h['Content-Type'] = 'application/json'; h['Content-Length'] = payload.length; }
      const req = lib.request({
        protocol: u.protocol, hostname: u.hostname, port: u.port || undefined,
        path: u.pathname + u.search, method, headers: h
      }, (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const text = Buffer.concat(chunks).toString('utf8');
          let json = null;
          try { json = JSON.parse(text); } catch (e) {}
          resolve({ status: res.statusCode, json, text });
        });
      });
      req.on('error', (e) => reject(signal && signal.aborted ? new DOMException('Aborted', 'AbortError') : e));
      req.setTimeout(timeout, () => req.destroy(new Error('Тайм-аут запиту')));
      if (signal) {
        if (signal.aborted) { req.destroy(); return reject(new DOMException('Aborted', 'AbortError')); }
        signal.addEventListener('abort', () => req.destroy(), { once: true });
      }
      if (payload) req.write(payload);
      req.end();
    });
  }

  async function requestFetch(url, { method, headers, body, signal }) {
    const h = { ...headers };
    if (body) h['Content-Type'] = 'application/json';
    const res = await fetch(url, { method, headers: h, body: body ? JSON.stringify(body) : undefined, signal });
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch (e) {}
    return { status: res.status, json, text };
  }

  function errMessage(r) {
    const j = r.json;
    const m = (j && (j.error && (j.error.message || j.error) || j.message)) || r.text || ('HTTP ' + r.status);
    return typeof m === 'string' ? m.slice(0, 600) : JSON.stringify(m).slice(0, 600);
  }

  function ensureOk(r) {
    if (r.status >= 200 && r.status < 300) return r;
    let hint = '';
    if (r.status === 401 || r.status === 403) hint = ' — перевірте API-ключ';
    if (r.status === 404) hint = ' — модель не знайдена або недоступна для ключа';
    if (r.status === 429) hint = ' — ліміт запитів/квота';
    throw new ApiError(r.status, errMessage(r) + hint, r.json);
  }

  /* Склеюємо сусідні повідомлення однієї ролі (Gemini/Anthropic вимагають чергування) */
  function normalize(messages) {
    const out = [];
    for (const m of messages) {
      const role = m.role === 'assistant' ? 'assistant' : 'user';
      const last = out[out.length - 1];
      if (last && last.role === role) {
        last.text += '\n\n' + m.text;
        last.images = (last.images || []).concat(m.images || []);
      } else {
        out.push({ role, text: m.text || '', images: (m.images || []).slice() });
      }
    }
    if (out.length && out[0].role !== 'user') out.unshift({ role: 'user', text: '(продовження)', images: [] });
    return out;
  }

  const isReasoningOpenAI = (id) => /^(gpt-[5-9]|o\d)/.test(id);
  const isThinkingGemini = (id) => /^gemini-(3|4|5)/.test(id);

  /* ---------------- OpenAI (Responses API) ---------------- */
  async function openai({ model, system, messages, effort, key, signal }) {
    const input = normalize(messages).map((m) => {
      if (m.role === 'assistant') return { role: 'assistant', content: [{ type: 'output_text', text: m.text }] };
      const content = [{ type: 'input_text', text: m.text }];
      for (const img of m.images) content.push({ type: 'input_image', image_url: 'data:' + img.mime + ';base64,' + img.data });
      return { role: 'user', content };
    });
    const body = { model, instructions: system, input, max_output_tokens: 32000 };
    if (isReasoningOpenAI(model) && effort) body.reasoning = { effort };
    const headers = { Authorization: 'Bearer ' + key };
    let r = await request('https://api.openai.com/v1/responses', { method: 'POST', headers, body, signal });
    if (r.status === 400 && body.reasoning && /reason/i.test(r.text)) {
      delete body.reasoning;
      r = await request('https://api.openai.com/v1/responses', { method: 'POST', headers, body, signal });
    }
    ensureOk(r);
    const j = r.json || {};
    if (typeof j.output_text === 'string') return j.output_text;
    let text = '';
    for (const item of j.output || []) {
      if (item.type === 'message') for (const c of item.content || []) if (c.type === 'output_text') text += c.text;
    }
    if (!text && j.status === 'incomplete') throw new Error('Відповідь обрізана: ' + (j.incomplete_details && j.incomplete_details.reason || 'ліміт токенів'));
    return text;
  }

  /* ---------------- Anthropic (Messages API) ---------------- */
  async function anthropic({ model, system, messages, key, signal }) {
    const msgs = normalize(messages).map((m) => {
      if (m.role === 'assistant') return { role: 'assistant', content: [{ type: 'text', text: m.text || '…' }] };
      const content = [];
      for (const img of m.images) content.push({ type: 'image', source: { type: 'base64', media_type: img.mime, data: img.data } });
      content.push({ type: 'text', text: m.text || '…' });
      return { role: 'user', content };
    });
    const r = ensureOk(await request('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
      body: { model, max_tokens: 16000, system, messages: msgs },
      signal
    }));
    const j = r.json || {};
    const text = (j.content || []).filter((c) => c.type === 'text').map((c) => c.text).join('');
    if (!text && j.stop_reason === 'max_tokens') throw new Error('Відповідь обрізана лімітом токенів');
    return text;
  }

  /* ---------------- Gemini ---------------- */
  async function gemini({ model, system, messages, effort, key, signal }) {
    const contents = normalize(messages).map((m) => {
      const parts = [];
      for (const img of m.images) parts.push({ inlineData: { mimeType: img.mime, data: img.data } });
      parts.push({ text: m.text || '…' });
      return { role: m.role === 'assistant' ? 'model' : 'user', parts };
    });
    const body = {
      systemInstruction: { parts: [{ text: system }] },
      contents,
      generationConfig: { maxOutputTokens: 32768 }
    };
    if (isThinkingGemini(model) && effort) body.generationConfig.thinkingConfig = { thinkingLevel: effort };
    const url = 'https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(model) + ':generateContent';
    const headers = { 'x-goog-api-key': key };
    let r = await request(url, { method: 'POST', headers, body, signal });
    if (r.status === 400 && body.generationConfig.thinkingConfig && /think/i.test(r.text)) {
      delete body.generationConfig.thinkingConfig;
      r = await request(url, { method: 'POST', headers, body, signal });
    }
    ensureOk(r);
    const j = r.json || {};
    const cand = (j.candidates || [])[0];
    if (!cand) throw new Error('Gemini не повернув відповідь' + (j.promptFeedback ? ': ' + JSON.stringify(j.promptFeedback) : ''));
    const text = ((cand.content && cand.content.parts) || []).filter((p) => !p.thought && p.text).map((p) => p.text).join('');
    if (!text && cand.finishReason) throw new Error('Gemini зупинився: ' + cand.finishReason);
    return text;
  }

  /* ---------------- OpenAI-сумісні (Chat Completions) ---------------- */
  async function compat({ model, system, messages, key, base, signal }) {
    if (!base) throw new Error('Вкажіть Base URL у налаштуваннях');
    const msgs = [{ role: 'system', content: system }].concat(normalize(messages).map((m) => {
      if (m.role === 'assistant' || !m.images.length) return { role: m.role, content: m.text };
      const content = [{ type: 'text', text: m.text }];
      for (const img of m.images) content.push({ type: 'image_url', image_url: { url: 'data:' + img.mime + ';base64,' + img.data } });
      return { role: 'user', content };
    }));
    const headers = key ? { Authorization: 'Bearer ' + key } : {};
    headers['HTTP-Referer'] = 'https://hyperframes.local';
    headers['X-Title'] = 'Hyperframes Agent';
    const r = ensureOk(await request(base.replace(/\/+$/, '') + '/chat/completions', {
      method: 'POST', headers, body: { model, messages: msgs }, signal
    }));
    const c = r.json && r.json.choices && r.json.choices[0];
    return (c && c.message && (typeof c.message.content === 'string' ? c.message.content
      : (c.message.content || []).map((p) => p.text || '').join(''))) || '';
  }

  /* ---------------- Список моделей з API ---------------- */
  const SKIP_OPENAI = /(embedding|tts|whisper|transcribe|audio|realtime|image|dall-e|moderation|search|davinci|babbage|sora|computer-use|instruct)/i;
  const SKIP_GEMINI = /(embedding|tts|image|live|transcribe|aqa|imagen|veo|lyria|omni|robotics|banana|translate)/i;

  async function listModels(provider, { key, base }) {
    if (provider === 'openai') {
      const r = ensureOk(await request('https://api.openai.com/v1/models', { headers: { Authorization: 'Bearer ' + key } }));
      return (r.json.data || []).map((m) => m.id)
        .filter((id) => /^(gpt|o\d|chatgpt)/.test(id) && !SKIP_OPENAI.test(id))
        .sort().reverse();
    }
    if (provider === 'anthropic') {
      const r = ensureOk(await request('https://api.anthropic.com/v1/models?limit=100', {
        headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' }
      }));
      return (r.json.data || []).map((m) => m.id);
    }
    if (provider === 'gemini') {
      let ids = [], token = '';
      for (let page = 0; page < 5; page++) {
        const url = 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=200' + (token ? '&pageToken=' + token : '');
        const r = ensureOk(await request(url, { headers: { 'x-goog-api-key': key } }));
        for (const m of r.json.models || []) {
          const id = String(m.name || '').replace(/^models\//, '');
          if ((m.supportedGenerationMethods || []).includes('generateContent') && !SKIP_GEMINI.test(id)) ids.push(id);
        }
        token = r.json.nextPageToken;
        if (!token) break;
      }
      return ids.sort().reverse();
    }
    if (provider === 'compat') {
      if (!base) throw new Error('Вкажіть Base URL');
      const r = ensureOk(await request(base.replace(/\/+$/, '') + '/models', { headers: key ? { Authorization: 'Bearer ' + key } : {} }));
      return ((r.json && (r.json.data || r.json.models)) || []).map((m) => m.id || m.name).filter(Boolean).sort();
    }
    return [];
  }

  async function chat(provider, opts) {
    if (!opts.model) throw new Error('Не обрано модель');
    if (provider !== 'compat' && !opts.key) throw new Error('Не вказано API-ключ для ' + HF_MODELS[provider].name + ' (⚙ Налаштування)');
    if (provider === 'openai') return openai(opts);
    if (provider === 'anthropic') return anthropic(opts);
    if (provider === 'gemini') return gemini(opts);
    if (provider === 'compat') return compat(opts);
    throw new Error('Невідомий провайдер');
  }

  window.Providers = { chat, listModels, normalize, ApiError };
})();
