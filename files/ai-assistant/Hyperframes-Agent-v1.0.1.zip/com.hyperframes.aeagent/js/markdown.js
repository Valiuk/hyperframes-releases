/* Мінімальний безпечний Markdown → DOM */
(function () {
  'use strict';

  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  function inline(s) {
    let t = esc(s);
    t = t.replace(/`([^`\n]+)`/g, '<code>$1</code>');
    t = t.replace(/\*\*([^*\n]+)\*\*/g, '<strong>$1</strong>');
    t = t.replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g, '$1<em>$2</em>');
    t = t.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" data-ext="1">$1</a>');
    return t;
  }

  function textToHtml(text) {
    const lines = text.split('\n');
    let html = '', list = null, para = [];
    const flushPara = () => { if (para.length) { html += '<p>' + para.map(inline).join('<br>') + '</p>'; para = []; } };
    const flushList = () => { if (list) { html += '</' + list + '>'; list = null; } };
    for (const raw of lines) {
      const line = raw.replace(/\s+$/, '');
      let m;
      if (!line.trim()) { flushPara(); flushList(); continue; }
      if ((m = line.match(/^(#{1,4})\s+(.*)$/))) {
        flushPara(); flushList();
        html += '<h4>' + inline(m[2]) + '</h4>';
      } else if ((m = line.match(/^\s*[-*•]\s+(.*)$/))) {
        flushPara();
        if (list !== 'ul') { flushList(); html += '<ul>'; list = 'ul'; }
        html += '<li>' + inline(m[1]) + '</li>';
      } else if ((m = line.match(/^\s*\d+[.)]\s+(.*)$/))) {
        flushPara();
        if (list !== 'ol') { flushList(); html += '<ol>'; list = 'ol'; }
        html += '<li>' + inline(m[1]) + '</li>';
      } else {
        flushList();
        para.push(line);
      }
    }
    flushPara(); flushList();
    return html;
  }

  /* Розбиває текст на частини: {type:'text'|'code', lang, content} */
  function split(text) {
    const parts = [];
    const re = /```([\w+-]*)[^\n]*\n([\s\S]*?)(```|$)/g;
    let last = 0, m;
    while ((m = re.exec(text))) {
      if (m.index > last) parts.push({ type: 'text', content: text.slice(last, m.index) });
      parts.push({ type: 'code', lang: (m[1] || '').toLowerCase(), content: m[2].replace(/\n$/, '') });
      last = re.lastIndex;
      if (m[3] === '') break;
    }
    if (last < text.length) parts.push({ type: 'text', content: text.slice(last) });
    return parts;
  }

  const RUNNABLE = ['javascript', 'js', 'jsx', 'extendscript', 'es3'];

  // Блок без мови вважаємо скриптом лише якщо він схожий на ExtendScript
  function isRunnable(lang, content) {
    if (RUNNABLE.includes(lang)) return true;
    return lang === '' && /(app\.project|CompItem|\.property\(|\.layers\.add|\breturn\b)/.test(content || '');
  }

  function extractCode(text) {
    for (const p of split(text)) if (p.type === 'code' && isRunnable(p.lang, p.content) && p.content.trim()) return p.content;
    return null;
  }

  window.MD = { esc, textToHtml, split, isRunnable, extractCode };
})();
