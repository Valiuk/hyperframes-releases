/* CEP-міст та сховище налаштувань */
(function () {
  'use strict';

  let nodeOk = false, fs = null, path = null, os = null;
  try {
    fs = require('fs'); path = require('path'); os = require('os');
    nodeOk = true;
  } catch (e) { /* відкрито поза AE */ }

  /* ---------- CEP ---------- */
  const CEP = {
    available: typeof window.__adobe_cep__ !== 'undefined',

    eval(script) {
      return new Promise((resolve) => {
        if (!this.available) return resolve('EvalScript error.');
        window.__adobe_cep__.evalScript(script, (r) => resolve(r));
      });
    },

    extensionDir() {
      // Шлях з location.href; decodeURIComponent коректно відновлює кирилицю
      let p = decodeURIComponent(new URL(location.href).pathname);
      if (/^\/[A-Za-z]:\//.test(p)) p = p.slice(1); // Windows: /C:/... → C:/...
      return path ? path.dirname(p) : p;
    },

    lastHostError: '',

    async loadHost() {
      if (!this.available || !nodeOk) return false;
      const file = path.join(this.extensionDir(), 'jsx', 'host.jsx');
      let code;
      try { code = fs.readFileSync(file, 'utf8'); }
      catch (e) { this.lastHostError = 'не знайдено ' + file; return false; }

      // Спосіб 1: передаємо текст скрипта (не залежить від кирилиці в шляху)
      const r1 = await this.eval(
        'try{eval(decodeURIComponent("' + encodeURIComponent(code) + '"));"__ok"}' +
        'catch(e){"__err "+e.toString()+(e.line?" (рядок "+e.line+")":"")}'
      );
      if ((await this.eval('typeof HFAgent')) === 'object') { this.lastHostError = ''; return true; }

      // Спосіб 2: $.evalFile за шляхом
      const r2 = await this.eval(
        'try{$.evalFile(new File(decodeURIComponent("' + encodeURIComponent(file) + '")));"__ok"}' +
        'catch(e){"__err "+e.toString()+(e.line?" (рядок "+e.line+")":"")}'
      );
      if ((await this.eval('typeof HFAgent')) === 'object') { this.lastHostError = ''; return true; }

      this.lastHostError = [r1, r2].map((x) => String(x || '').replace(/^__err /, '')).filter((x) => x && x !== '__ok').join(' | ') || 'невідома помилка ExtendScript';
      console.error('host.jsx load failed:', this.lastHostError);
      return false;
    },

    async ensureHost() {
      if (!this.available) return false;
      const t = await this.eval('typeof HFAgent');
      if (t === 'object') return true;
      return this.loadHost();
    },

    async call(fn, ...args) {
      await this.ensureHost();
      const a = args.map((x) => '"' + encodeURIComponent(String(x)) + '"').join(',');
      const raw = await this.eval('HFAgent.' + fn + '(' + a + ')');
      try { return JSON.parse(raw); }
      catch (e) { return { ok: false, error: raw || 'EvalScript error' }; }
    },

    async getContext() {
      if (!this.available) return null;
      await this.ensureHost();
      const raw = await this.eval('HFAgent.getContext()');
      try { return JSON.parse(raw); } catch (e) { return null; }
    },

    run(code) { return this.call('run', code); },

    async captureFrame() {
      if (!nodeOk) throw new Error('Node.js недоступний у панелі');
      // ExtendScript інколи не пише у шляхи з кирилицею — беремо ASCII-папку
      let dir = os.tmpdir();
      if (!/^[\x00-\x7F]*$/.test(dir)) {
        dir = process.platform === 'win32'
          ? path.join(process.env.PUBLIC || 'C:\\Users\\Public', 'Documents')
          : '/tmp';
      }
      const file = path.join(dir, 'hf_agent_frame_' + Date.now() + '.png');
      const r = await this.call('saveFrame', file);
      if (!r.ok) throw new Error(r.error || 'Не вдалося зберегти кадр');
      // saveFrameToPng може дописувати файл асинхронно — чекаємо
      let last = -1;
      for (let i = 0; i < 80; i++) {
        await new Promise((res) => setTimeout(res, 125));
        if (fs.existsSync(file)) {
          const size = fs.statSync(file).size;
          if (size > 0 && size === last) break;
          last = size;
        }
      }
      if (!fs.existsSync(file)) throw new Error('Кадр не з’явився на диску');
      const buf = fs.readFileSync(file);
      try { fs.unlinkSync(file); } catch (e) {}
      return { mime: 'image/png', data: buf.toString('base64'), name: 'Кадр ' + r.time + ' · ' + r.comp };
    },

    openUrl(url) {
      try {
        if (this.available && window.cep && window.cep.util) return window.cep.util.openURLInDefaultBrowser(url);
      } catch (e) {}
      window.open(url, '_blank');
    }
  };

  /* ---------- Сховище ---------- */
  const dir = nodeOk ? path.join(os.homedir(), '.hyperframes-ae-agent') : null;

  function read(name, def) {
    try {
      if (nodeOk) {
        const p = path.join(dir, name);
        if (fs.existsSync(p)) return JSON.parse(fs.readFileSync(p, 'utf8'));
      } else {
        const v = localStorage.getItem('hfagent_' + name);
        if (v) return JSON.parse(v);
      }
    } catch (e) { console.warn('read', name, e); }
    return def;
  }

  function write(name, data) {
    try {
      const json = JSON.stringify(data);
      if (nodeOk) {
        fs.mkdirSync(dir, { recursive: true });
        const p = path.join(dir, name);
        fs.writeFileSync(p + '.tmp', json, 'utf8');
        fs.renameSync(p + '.tmp', p);
      } else {
        localStorage.setItem('hfagent_' + name, json);
      }
    } catch (e) { console.warn('write', name, e); }
  }

  const DEFAULT_SETTINGS = {
    provider: 'anthropic',
    models: {
      openai: HF_MODELS.openai.default,
      anthropic: HF_MODELS.anthropic.default,
      gemini: HF_MODELS.gemini.default,
      compat: ''
    },
    keys: { openai: '', anthropic: '', gemini: '', compat: '' },
    compatBase: 'https://openrouter.ai/api/v1',
    fetched: { openai: [], anthropic: [], gemini: [], compat: [] },
    custom: { openai: [], anthropic: [], gemini: [], compat: [] },
    effort: 'medium',
    mode: 'agent',
    attachContext: true,
    confirmRun: false,
    maxSteps: 6
  };

  function merge(def, val) {
    if (typeof def !== 'object' || def === null || Array.isArray(def)) return val === undefined ? def : val;
    const out = {};
    for (const k of Object.keys(def)) out[k] = merge(def[k], val ? val[k] : undefined);
    if (val) for (const k of Object.keys(val)) if (!(k in out)) out[k] = val[k];
    return out;
  }

  const Store = {
    dir,
    loadSettings() { return merge(DEFAULT_SETTINGS, read('settings.json', {})); },
    saveSettings(s) { write('settings.json', s); },
    loadChats() { return read('chats.json', []); },
    saveChats(chats) {
      // зображення не зберігаємо на диск — лише їх кількість
      const slim = chats.slice(0, 60).map((c) => ({
        ...c,
        messages: c.messages.map((m) => {
          if (!m.images || !m.images.length) return m;
          const { images, ...rest } = m;
          return { ...rest, imageCount: images.length };
        })
      }));
      write('chats.json', slim);
    }
  };

  window.CEP = CEP;
  window.Store = Store;
  window.HF_NODE = nodeOk;
})();
