/* Каталог моделей (актуально на листопад 2026).
 * Кнопка ⟳ у панелі підтягує повний список прямо з API провайдера,
 * тож нові моделі з'являтимуться без оновлення плагіна. */
window.HF_MODELS = {
  openai: {
    name: 'OpenAI',
    keyUrl: 'https://platform.openai.com/api-keys',
    default: 'gpt-6.1-sol',
    curated: [
      { id: 'gpt-6-astra',   note: 'флагман, найрозумніша, дорога' },
      { id: 'gpt-6.1-sol',   note: 'баланс ціна/якість — рекомендовано' },
      { id: 'gpt-6.1-terra', note: 'швидка й дешевша' },
      { id: 'gpt-6-luna',    note: 'найшвидша й найдешевша' },
      { id: 'gpt-6-sol',     note: 'попередня Sol' },
      { id: 'gpt-5.6-sol',   note: 'попереднє покоління' }
    ]
  },
  anthropic: {
    name: 'Claude',
    keyUrl: 'https://console.anthropic.com/settings/keys',
    default: 'claude-sonnet-5-5',
    curated: [
      { id: 'claude-fable-5-1',  note: 'найпотужніша (Mythos-клас)' },
      { id: 'claude-opus-5-5',   note: 'складні задачі та агенти' },
      { id: 'claude-sonnet-5-5', note: 'баланс — рекомендовано' },
      { id: 'claude-haiku-5-5',  note: 'швидка й дешева' }
    ]
  },
  gemini: {
    name: 'Gemini',
    keyUrl: 'https://aistudio.google.com/apikey',
    default: 'gemini-3.8-flash',
    curated: [
      { id: 'gemini-4-argon',         note: 'флагман з reasoning' },
      { id: 'gemini-3.8-flash',       note: 'найрозумніша Flash — рекомендовано' },
      { id: 'gemini-3.6-flash',       note: 'попередня Flash' },
      { id: 'gemini-3.5-flash-lite',  note: 'найшвидша й найдешевша' },
      { id: 'gemini-3.1-pro-preview', note: 'Pro (preview)' }
    ]
  },
  compat: {
    name: 'Інший API',
    keyUrl: 'https://openrouter.ai/keys',
    default: '',
    curated: [],
    presets: [
      { name: 'OpenRouter', url: 'https://openrouter.ai/api/v1' },
      { name: 'Ollama (локально)', url: 'http://localhost:11434/v1' },
      { name: 'LM Studio (локально)', url: 'http://localhost:1234/v1' },
      { name: 'DeepSeek', url: 'https://api.deepseek.com/v1' },
      { name: 'xAI (Grok)', url: 'https://api.x.ai/v1' }
    ]
  }
};
