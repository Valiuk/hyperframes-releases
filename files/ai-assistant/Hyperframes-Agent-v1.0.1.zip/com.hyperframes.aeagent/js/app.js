/* Hyperframes Agent — логіка панелі */
(function () {
  'use strict';

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => Array.from(document.querySelectorAll(s));

  const S = Store.loadSettings();
  const state = {
    chats: Store.loadChats(),
    chatId: null,
    busy: false,
    abort: null,
    pending: [],       // зображення до відправки
    confirmResolve: null
  };

  /* ---------- утиліти ---------- */
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  const saveSettings = () => Store.saveSettings(S);
  const saveChats = () => Store.saveChats(state.chats);
  const currentChat = () => state.chats.find((c) => c.id === state.chatId) || null;

  let toastTimer = null;
  function toast(msg, kind, ms) {
    const t = $('#toast');
    t.textContent = msg;
    t.className = 'toast ' + (kind || '');
    t.onclick = () => t.classList.add('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.add('hidden'), ms || 3500);
  }

  function copyText(text) {
    const done = () => toast('Скопійовано');
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(done, () => fallback());
    } else fallback();
    function fallback() {
      const ta = document.createElement('textarea');
      ta.value = text; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); done(); } catch (e) { toast('Не вдалося скопіювати', 'err'); }
      ta.remove();
    }
  }

  /* ---------- провайдер і модель ---------- */
  function fillProviders() {
    const sel = $('#provider');
    sel.innerHTML = '';
    for (const [id, p] of Object.entries(HF_MODELS)) {
      const o = document.createElement('option');
      o.value = id; o.textContent = p.name;
      sel.appendChild(o);
    }
    sel.value = S.provider;
  }

  function fillModels() {
    const prov = S.provider;
    const cat = HF_MODELS[prov];
    const sel = $('#model');
    sel.innerHTML = '';
    const seen = new Set();
    const group = (label, items) => {
      if (!items.length) return;
      const g = document.createElement('optgroup');
      g.label = label;
      for (const it of items) {
        if (seen.has(it.id)) continue;
        seen.add(it.id);
        const o = document.createElement('option');
        o.value = it.id;
        o.textContent = it.note ? it.id + ' — ' + it.note : it.id;
        g.appendChild(o);
      }
      if (g.children.length) sel.appendChild(g);
    };
    group('Рекомендовані', cat.curated);
    group('Свої', (S.custom[prov] || []).map((id) => ({ id })));
    group('Усі з API', (S.fetched[prov] || []).map((id) => ({ id })));

    let cur = S.models[prov];
    if (cur && !seen.has(cur)) { group('Обрана', [{ id: cur }]); }
    if (!cur && sel.options.length) cur = sel.options[0].value;
    if (cur) sel.value = cur;
    S.models[prov] = sel.value || '';
    if (!sel.options.length) {
      const o = document.createElement('option');
      o.value = ''; o.textContent = prov === 'compat' ? 'Натисніть ⟳ щоб завантажити моделі' : '—';
      sel.appendChild(o);
    }
  }

  async function refreshModels() {
    const prov = S.provider;
    const btn = $('#btnRefresh');
    btn.disabled = true; btn.classList.add('spin');
    try {
      const ids = await Providers.listModels(prov, { key: S.keys[prov], base: S.compatBase });
      S.fetched[prov] = ids;
      saveSettings();
      fillModels();
      toast('Моделей з API: ' + ids.length, 'ok');
    } catch (e) {
      toast('Не вдалося отримати список: ' + e.message, 'err');
    } finally {
      btn.disabled = false; btn.classList.remove('spin');
    }
  }

  /* ---------- рендер повідомлень ---------- */
  function renderAll() {
    const box = $('#messages');
    box.innerHTML = '';
    const chat = currentChat();
    if (!chat || !chat.messages.length) {
      box.appendChild(emptyState());
      return;
    }
    chat.messages.forEach((m, i) => box.appendChild(renderMessage(m, i)));
    box.scrollTop = box.scrollHeight;
  }

  function emptyState() {
    const d = document.createElement('div');
    d.className = 'empty';
    const examples = [
      'Розстав виділені шари по сітці 3×3 з відступом 40 px',
      'Зроби pop-появу виділених шарів з овершутом, зсув 3 кадри між шарами',
      'Перейменуй усі відео шари в активній композиції як shot_01, shot_02… за порядком',
      'Напиши expression для wiggle, який згасає до кінця шару'
    ];
    d.innerHTML = '<p class="lead">Опишіть, що зробити в проєкті. Агент напише скрипт, запустить його і виправить, якщо щось піде не так. Усе відкочується одним Ctrl+Z.</p>';
    const ul = document.createElement('div');
    ul.className = 'examples';
    for (const ex of examples) {
      const b = document.createElement('button');
      b.textContent = ex;
      b.onclick = () => { $('#input').value = ex; $('#input').focus(); };
      ul.appendChild(b);
    }
    d.appendChild(ul);
    return d;
  }

  function renderMessage(m, index) {
    const el = document.createElement('div');
    el.className = 'msg ' + m.role;

    if (m.role === 'user') {
      const body = document.createElement('div');
      body.className = 'bubble';
      body.textContent = m.text;
      if (m.images && m.images.length) {
        const row = document.createElement('div');
        row.className = 'thumbs';
        for (const img of m.images) {
          const i = document.createElement('img');
          i.src = 'data:' + img.mime + ';base64,' + img.data;
          row.appendChild(i);
        }
        body.appendChild(row);
      } else if (m.imageCount) {
        const s = document.createElement('div');
        s.className = 'meta';
        s.textContent = 'зображень: ' + m.imageCount + ' (не зберігаються в історії)';
        body.appendChild(s);
      }
      el.appendChild(body);
      return el;
    }

    if (m.role === 'tool') {
      const r = m.res || {};
      el.classList.add(r.ok ? 'ok' : 'err');
      const head = document.createElement('div');
      head.className = 'tool-head';
      head.innerHTML = '<span class="key">◆</span>' + (r.ok ? 'Виконано' : 'Помилка') +
        '<span class="ms">' + (r.ms != null ? r.ms + ' мс' : '') + '</span>';
      el.appendChild(head);
      const lines = [];
      if (r.ok) {
        if (r.result) lines.push(r.result);
      } else {
        lines.push(r.error + (r.line ? '  (рядок ' + r.line + ')' : ''));
        if (r.lineText) lines.push('→ ' + r.lineText.trim());
      }
      if (lines.length) {
        const p = document.createElement('div');
        p.className = 'tool-body';
        p.textContent = lines.join('\n');
        el.appendChild(p);
      }
      if (r.log) {
        const det = document.createElement('details');
        det.innerHTML = '<summary>log</summary>';
        const pre = document.createElement('pre');
        pre.textContent = r.log;
        det.appendChild(pre);
        el.appendChild(det);
      }
      if (!r.ok && S.mode === 'chat' && index === currentChat().messages.length - 1) {
        const b = document.createElement('button');
        b.className = 'small';
        b.textContent = 'Виправити помилку';
        b.onclick = () => { if (!state.busy) runConversation(currentChat(), { singleTurn: true }); };
        el.appendChild(b);
      }
      return el;
    }

    if (m.role === 'note') {
      el.textContent = m.text;
      return el;
    }

    // assistant
    if (m.model) {
      const meta = document.createElement('div');
      meta.className = 'meta';
      meta.textContent = m.model;
      el.appendChild(meta);
    }
    for (const part of MD.split(m.text || '')) {
      if (part.type === 'text') {
        if (!part.content.trim()) continue;
        const d = document.createElement('div');
        d.className = 'md';
        d.innerHTML = MD.textToHtml(part.content);
        el.appendChild(d);
      } else {
        el.appendChild(codeBlock(part));
      }
    }
    return el;
  }

  function codeBlock(part) {
    const wrap = document.createElement('div');
    wrap.className = 'code';
    const head = document.createElement('div');
    head.className = 'code-head';
    const runnable = MD.isRunnable(part.lang, part.content);
    const lbl = document.createElement('span');
    lbl.textContent = runnable ? 'ExtendScript' : (part.lang || 'код');
    head.appendChild(lbl);
    const sp = document.createElement('span'); sp.className = 'spacer'; head.appendChild(sp);
    const lines = part.content.split('\n').length;
    if (lines > 14) {
      const tg = document.createElement('button');
      tg.className = 'small ghost';
      tg.textContent = 'Розгорнути (' + lines + ')';
      tg.onclick = () => { wrap.classList.toggle('open'); tg.textContent = wrap.classList.contains('open') ? 'Згорнути' : 'Розгорнути (' + lines + ')'; };
      head.appendChild(tg);
      wrap.classList.add('long');
    }
    const cp = document.createElement('button');
    cp.className = 'small ghost';
    cp.textContent = 'Копіювати';
    cp.onclick = () => copyText(part.content);
    head.appendChild(cp);
    if (runnable) {
      const run = document.createElement('button');
      run.className = 'small primary';
      run.textContent = '▶ Запустити';
      run.onclick = () => manualRun(part.content);
      head.appendChild(run);
    }
    wrap.appendChild(head);
    const pre = document.createElement('pre');
    pre.textContent = part.content;
    wrap.appendChild(pre);
    return wrap;
  }

  /* ---------- чати ---------- */
  function newChat() {
    const c = { id: uid(), title: '', created: Date.now(), messages: [] };
    state.chats.unshift(c);
    state.chatId = c.id;
    renderAll();
    return c;
  }

  function ensureChat() { return currentChat() || newChat(); }

  function renderHistory() {
    const list = $('#historyList');
    list.innerHTML = '';
    if (!state.chats.length) { list.innerHTML = '<p class="hint">Поки порожньо.</p>'; return; }
    for (const c of state.chats) {
      const row = document.createElement('div');
      row.className = 'hrow' + (c.id === state.chatId ? ' active' : '');
      const t = document.createElement('span');
      t.className = 'htitle';
      t.textContent = c.title || 'Без назви';
      t.title = new Date(c.created).toLocaleString();
      t.onclick = () => { state.chatId = c.id; renderAll(); closeDrawers(); };
      const del = document.createElement('button');
      del.className = 'icon';
      del.textContent = '✕';
      del.title = 'Видалити чат';
      del.onclick = () => {
        state.chats = state.chats.filter((x) => x.id !== c.id);
        if (state.chatId === c.id) state.chatId = state.chats[0] ? state.chats[0].id : null;
        saveChats(); renderHistory(); renderAll();
      };
      row.appendChild(t); row.appendChild(del);
      list.appendChild(row);
    }
  }

  /* ---------- зображення ---------- */
  function downscale(mime, b64, max = 1600) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const k = Math.min(1, max / Math.max(img.width, img.height));
        if (k >= 1 && b64.length < 4e6) return resolve({ mime, data: b64 });
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        const out = c.toDataURL('image/jpeg', 0.9);
        resolve({ mime: 'image/jpeg', data: out.split(',')[1] });
      };
      img.onerror = () => resolve({ mime, data: b64 });
      img.src = 'data:' + mime + ';base64,' + b64;
    });
  }

  async function addImageFile(file) {
    if (!/^image\/(png|jpeg|webp|gif)$/.test(file.type)) return toast('Підтримуються PNG, JPG, WEBP, GIF', 'err');
    if (file.size > 15 * 1024 * 1024) return toast('Файл більший за 15 МБ', 'err');
    const b64 = await new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(String(r.result).split(',')[1]);
      r.onerror = rej;
      r.readAsDataURL(file);
    });
    const img = await downscale(file.type, b64);
    img.name = file.name || 'зображення';
    state.pending.push(img);
    renderPending();
  }

  function renderPending() {
    const box = $('#attachments');
    box.innerHTML = '';
    state.pending.forEach((img, i) => {
      const d = document.createElement('div');
      d.className = 'att';
      d.title = img.name || '';
      const im = document.createElement('img');
      im.src = 'data:' + img.mime + ';base64,' + img.data;
      const x = document.createElement('button');
      x.textContent = '✕';
      x.onclick = () => { state.pending.splice(i, 1); renderPending(); };
      d.appendChild(im); d.appendChild(x);
      box.appendChild(d);
    });
  }

  async function grabFrame() {
    if (!CEP.available) return toast('Працює лише всередині After Effects', 'err');
    const btn = $('#btnFrame');
    btn.disabled = true;
    try {
      const f = await CEP.captureFrame();
      const img = await downscale(f.mime, f.data);
      img.name = f.name;
      state.pending.push(img);
      renderPending();
    } catch (e) {
      toast(e.message, 'err');
    } finally { btn.disabled = false; }
  }

  /* ---------- запуск коду ---------- */
  async function execute(code) {
    if (!CEP.available) return { ok: false, error: 'Панель відкрита поза After Effects — виконання недоступне' };
    if (!(await CEP.ensureHost())) return { ok: false, error: 'host.jsx не завантажено: ' + CEP.lastHostError };
    return CEP.run(code);
  }

  async function manualRun(code) {
    if (state.busy) return;
    const chat = ensureChat();
    setStatus('Виконую…');
    const res = await execute(code);
    setStatus('');
    chat.messages.push({ role: 'tool', res, text: Prompts.resultText(res) });
    saveChats(); renderAll();
  }

  function askConfirm() {
    return new Promise((resolve) => {
      state.confirmResolve = resolve;
      $('#confirmBar').classList.remove('hidden');
    });
  }
  function settleConfirm(v) {
    $('#confirmBar').classList.add('hidden');
    if (state.confirmResolve) { state.confirmResolve(v); state.confirmResolve = null; }
  }

  /* ---------- розмова з моделлю ---------- */
  function apiMessages(chat, ctx) {
    const msgs = chat.messages
      .filter((m) => m.role === 'user' || m.role === 'assistant' || m.role === 'tool')
      .map((m) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', text: m.text || '', images: m.images || [] }));
    if (ctx && msgs.length) {
      const last = msgs[msgs.length - 1];
      msgs[msgs.length - 1] = { ...last, text: last.text + Prompts.contextBlock(ctx) };
    }
    return msgs;
  }

  async function askModel(chat, signal) {
    const prov = S.provider;
    const model = S.models[prov];
    let ctx = null;
    if (S.attachContext && CEP.available) {
      setStatus('Читаю проєкт…');
      ctx = await CEP.getContext();
    }
    setStatus('Думає ' + model + '…', true);
    const text = await Providers.chat(prov, {
      model,
      system: Prompts.system(S.mode),
      messages: apiMessages(chat, ctx),
      effort: S.effort,
      key: S.keys[prov],
      base: S.compatBase,
      signal
    });
    return { text: text || '(порожня відповідь)', model };
  }

  async function runConversation(chat, { singleTurn = false } = {}) {
    setBusy(true);
    const ctrl = new AbortController();
    state.abort = ctrl;
    const agent = S.mode === 'agent' && !singleTurn;
    let steps = 0;
    try {
      while (true) {
        const reply = await askModel(chat, ctrl.signal);
        chat.messages.push({ role: 'assistant', text: reply.text, model: reply.model });
        saveChats(); renderAll();
        if (!agent || ctrl.signal.aborted) break;

        const code = MD.extractCode(reply.text);
        if (!code) break;
        steps++;
        if (steps > S.maxSteps) {
          chat.messages.push({ role: 'note', text: 'Досягнуто ліміт кроків (' + S.maxSteps + '). Напишіть «продовжуй», щоб агент працював далі.' });
          break;
        }
        if (S.confirmRun) {
          setStatus('Чекаю підтвердження');
          if (!(await askConfirm())) { chat.messages.push({ role: 'note', text: 'Запуск скасовано.' }); break; }
        }
        setStatus('Виконую крок ' + steps + '…');
        const res = await execute(code);
        chat.messages.push({ role: 'tool', res, text: Prompts.resultText(res) });
        saveChats(); renderAll();
        if (ctrl.signal.aborted) break;
      }
    } catch (e) {
      if (e && (e.name === 'AbortError' || ctrl.signal.aborted)) {
        chat.messages.push({ role: 'note', text: 'Зупинено.' });
      } else {
        chat.messages.push({ role: 'note', text: 'Помилка: ' + (e && e.message ? e.message : e) });
      }
    } finally {
      saveChats(); renderAll();
      setBusy(false);
    }
  }

  async function send() {
    if (state.busy) { stop(); return; }
    const input = $('#input');
    const text = input.value.trim();
    if (!text && !state.pending.length) return;
    const chat = ensureChat();
    chat.messages.push({ role: 'user', text: text || '(зображення)', images: state.pending.slice() });
    if (!chat.title) chat.title = (text || 'Зображення').slice(0, 60);
    input.value = '';
    state.pending = [];
    renderPending();
    renderAll();
    saveChats();
    await runConversation(chat);
  }

  function stop() {
    if (state.abort) state.abort.abort();
    settleConfirm(false);
  }

  let tick = null;
  function setStatus(t, timer) {
    const el = $('#status');
    clearInterval(tick);
    if (!timer) { el.textContent = t; return; }
    const start = Date.now();
    const upd = () => { el.textContent = t + ' ' + Math.floor((Date.now() - start) / 1000) + ' с'; };
    upd(); tick = setInterval(upd, 1000);
  }

  function setBusy(b) {
    state.busy = b;
    const btn = $('#btnSend');
    btn.textContent = b ? 'Зупинити' : 'Надіслати';
    btn.classList.toggle('danger', b);
    if (!b) setStatus('');
  }

  /* ---------- шухляди ---------- */
  function closeDrawers() { $$('.drawer').forEach((d) => d.classList.add('hidden')); }
  function openDrawer(id) { closeDrawers(); $('#' + id).classList.remove('hidden'); }

  function bindSettings() {
    $$('[data-key]').forEach((inp) => {
      inp.value = S.keys[inp.dataset.key] || '';
      inp.onchange = () => { S.keys[inp.dataset.key] = inp.value.trim(); saveSettings(); };
    });
    $$('[data-key-url]').forEach((a) => {
      a.onclick = (e) => { e.preventDefault(); CEP.openUrl(HF_MODELS[a.dataset.keyUrl].keyUrl); };
    });
    const base = $('#compatBase');
    base.value = S.compatBase;
    base.onchange = () => { S.compatBase = base.value.trim(); saveSettings(); };
    const preset = $('#compatPreset');
    for (const p of HF_MODELS.compat.presets) {
      const o = document.createElement('option'); o.value = p.url; o.textContent = p.name; preset.appendChild(o);
    }
    preset.onchange = () => {
      if (!preset.value) return;
      base.value = S.compatBase = preset.value;
      S.fetched.compat = [];
      preset.value = '';
      saveSettings();
      if (S.provider === 'compat') fillModels();
    };
    $('#addCustom').onclick = () => {
      const v = $('#customModel').value.trim();
      if (!v) return;
      const list = S.custom[S.provider] || (S.custom[S.provider] = []);
      if (!list.includes(v)) list.unshift(v);
      S.models[S.provider] = v;
      $('#customModel').value = '';
      saveSettings(); fillModels();
      toast('Додано: ' + v, 'ok');
    };
    const effort = $('#effort');
    effort.value = S.effort;
    effort.onchange = () => { S.effort = effort.value; saveSettings(); };
    const ms = $('#maxSteps');
    ms.value = S.maxSteps;
    ms.onchange = () => { S.maxSteps = Math.max(1, Math.min(20, parseInt(ms.value, 10) || 6)); ms.value = S.maxSteps; saveSettings(); };
    const cr = $('#confirmRun');
    cr.checked = S.confirmRun;
    cr.onchange = () => { S.confirmRun = cr.checked; saveSettings(); };
    $('#storePath').textContent = Store.dir || 'localStorage';
  }

  function setMode(mode) {
    S.mode = mode;
    $$('.seg button').forEach((b) => b.classList.toggle('on', b.dataset.mode === mode));
    saveSettings();
  }

  /* ---------- ініціалізація ---------- */
  function init() {
    fillProviders();
    fillModels();
    bindSettings();
    setMode(S.mode);

    $('#provider').onchange = (e) => { S.provider = e.target.value; saveSettings(); fillModels(); };
    $('#model').onchange = (e) => { S.models[S.provider] = e.target.value; saveSettings(); };
    $('#btnRefresh').onclick = refreshModels;
    $('#btnNew').onclick = () => { if (!state.busy) newChat(); };
    $('#btnHistory').onclick = () => { renderHistory(); openDrawer('history'); };
    $('#btnSettings').onclick = () => openDrawer('settings');
    $$('[data-close]').forEach((b) => (b.onclick = closeDrawers));
    $$('.seg button').forEach((b) => (b.onclick = () => setMode(b.dataset.mode)));

    const ctx = $('#ctxToggle');
    ctx.checked = S.attachContext;
    ctx.onchange = () => { S.attachContext = ctx.checked; saveSettings(); };

    $('#btnPeek').onclick = async () => {
      openDrawer('peek');
      $('#peekBody').textContent = 'Читаю…';
      const c = await CEP.getContext();
      $('#peekBody').textContent = c ? JSON.stringify(c, null, 2) : 'Немає даних (панель поза After Effects?)';
    };

    $('#btnSend').onclick = send;
    $('#input').addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(); }
    });
    $('#btnAttach').onclick = () => $('#fileInput').click();
    $('#fileInput').onchange = async (e) => {
      for (const f of e.target.files) await addImageFile(f);
      e.target.value = '';
    };
    $('#btnFrame').onclick = grabFrame;
    $('#confirmYes').onclick = () => settleConfirm(true);
    $('#confirmNo').onclick = () => settleConfirm(false);

    document.addEventListener('paste', async (e) => {
      const items = (e.clipboardData && e.clipboardData.items) || [];
      for (const it of items) {
        if (it.kind === 'file' && it.type.startsWith('image/')) { e.preventDefault(); await addImageFile(it.getAsFile()); }
      }
    });
    const app = $('#app');
    app.addEventListener('dragover', (e) => { e.preventDefault(); app.classList.add('drop'); });
    app.addEventListener('dragleave', (e) => { if (e.target === app) app.classList.remove('drop'); });
    app.addEventListener('drop', async (e) => {
      e.preventDefault(); app.classList.remove('drop');
      for (const f of e.dataTransfer.files) await addImageFile(f);
    });
    $('#messages').addEventListener('click', (e) => {
      const a = e.target.closest('a[data-ext]');
      if (a) { e.preventDefault(); CEP.openUrl(a.href); }
    });

    state.chatId = state.chats[0] ? state.chats[0].id : null;
    renderAll();

    if (CEP.available && HF_NODE) {
      CEP.loadHost().then((ok) => { if (!ok) toast('host.jsx: ' + CEP.lastHostError, 'err', 15000); })
        .catch((e) => toast('host.jsx: ' + e.message, 'err'));
    }
    if (!S.keys[S.provider] && S.provider !== 'compat') {
      setTimeout(() => toast('Додайте API-ключ у ⚙ Налаштуваннях'), 400);
    }
  }

  init();
})();
