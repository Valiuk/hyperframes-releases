/*
 * Hyperframes Agent — ExtendScript host (ES3)
 * Завантажується панеллю через eval(decodeURIComponent(...)), а не через ScriptPath,
 * щоб не залежати від кирилиці в шляху до розширення.
 */

/* ---------- JSON polyfill (ES3) ---------- */
if (typeof $.global.JSON !== "object") { $.global.JSON = {}; }
(function () {
    var esc = /[\\"\u0000-\u001f\u2028\u2029]/g;
    var meta = { "\b": "\\b", "\t": "\\t", "\n": "\\n", "\f": "\\f", "\r": "\\r", "\"": "\\\"", "\\": "\\\\" };
    function quote(s) {
        esc.lastIndex = 0;
        return "\"" + String(s).replace(esc, function (c) {
            var m = meta[c];
            return typeof m === "string" ? m : "\\u" + ("0000" + c.charCodeAt(0).toString(16)).slice(-4);
        }) + "\"";
    }
    function str(v, depth) {
        if (depth > 12) { return "null"; }
        if (v === null || v === undefined) { return "null"; }
        var t = typeof v, i, out, k;
        if (t === "number") { return isFinite(v) ? String(v) : "null"; }
        if (t === "boolean") { return String(v); }
        if (t === "string") { return quote(v); }
        if (t === "function") { return "null"; }
        if (v instanceof Array) {
            out = [];
            for (i = 0; i < v.length; i++) { out.push(str(v[i], depth + 1)); }
            return "[" + out.join(",") + "]";
        }
        out = [];
        for (k in v) {
            if (v.hasOwnProperty(k)) {
                if (typeof v[k] === "function" || v[k] === undefined) { continue; }
                out.push(quote(k) + ":" + str(v[k], depth + 1));
            }
        }
        return "{" + out.join(",") + "}";
    }
    if (typeof $.global.JSON.stringify !== "function") {
        $.global.JSON.stringify = function (v) { return str(v, 0); };
    }
    if (typeof $.global.JSON.parse !== "function") {
        $.global.JSON.parse = function (s) { return eval("(" + s + ")"); };
    }
    $.global.__hfStringify = function (v) { return str(v, 0); };
})();

/* ---------- log() для скриптів агента ---------- */
$.global.__hfLog = [];
$.global.log = function () {
    var parts = [], i, a;
    for (i = 0; i < arguments.length; i++) {
        a = arguments[i];
        if (typeof a === "object" && a !== null) {
            try { parts.push($.global.__hfStringify(a)); } catch (e) { parts.push(String(a)); }
        } else { parts.push(String(a)); }
    }
    $.global.__hfLog.push(parts.join(" "));
    return parts.join(" ");
};

$.global.HFAgent = (function () {
    var S = function (o) { return $.global.__hfStringify(o); };

    function r(n) { return Math.round(n * 1000) / 1000; }

    function fmtValue(v) {
        if (v === null || v === undefined) { return null; }
        if (typeof v === "number") { return r(v); }
        if (typeof v === "boolean" || typeof v === "string") { return v; }
        if (v instanceof Array) {
            var a = [], i;
            for (i = 0; i < v.length; i++) { a.push(typeof v[i] === "number" ? r(v[i]) : v[i]); }
            return a;
        }
        try { if (v instanceof TextDocument) { return { text: v.text, font: v.font, fontSize: v.fontSize }; } } catch (e1) {}
        try { if (v instanceof Shape) { return "[shape path, " + v.vertices.length + " vertices]"; } } catch (e2) {}
        try { if (v instanceof MarkerValue) { return "[marker] " + v.comment; } } catch (e3) {}
        return String(v);
    }

    function layerType(L) {
        try {
            if (L instanceof TextLayer) { return "text"; }
            if (L instanceof ShapeLayer) { return "shape"; }
            if (L instanceof CameraLayer) { return "camera"; }
            if (L instanceof LightLayer) { return "light"; }
            if (L.nullLayer) { return "null"; }
            if (L.adjustmentLayer) { return "adjustment"; }
            if (L.source instanceof CompItem) { return "precomp"; }
            if (L.source && L.source.mainSource) {
                if (L.source.mainSource instanceof SolidSource) { return "solid"; }
                if (L.source.mainSource.isStill) { return "image"; }
                if (L.hasVideo) { return "video"; }
                if (L.hasAudio) { return "audio"; }
            }
        } catch (e) {}
        return "av";
    }

    function propPath(p) {
        var names = [], cur = p, guard = 0;
        while (cur && guard < 20) {
            try {
                if (cur.parentProperty === null) { break; }
                names.unshift(cur.name);
                cur = cur.parentProperty;
            } catch (e) { break; }
            guard++;
        }
        return names.join(" > ");
    }

    function transformInfo(L) {
        var out = {}, tg, names, i, p;
        try {
            tg = L.property("ADBE Transform Group");
            if (!tg) { return out; }
            names = [
                ["anchor", "ADBE Anchor Point"], ["position", "ADBE Position"], ["scale", "ADBE Scale"],
                ["rotation", "ADBE Rotate Z"], ["opacity", "ADBE Opacity"]
            ];
            for (i = 0; i < names.length; i++) {
                p = tg.property(names[i][1]);
                if (!p) { continue; }
                out[names[i][0]] = { v: fmtValue(p.value) };
                if (p.numKeys > 0) { out[names[i][0]].keys = p.numKeys; }
                if (p.expressionEnabled && p.expression) { out[names[i][0]].expr = p.expression.substr(0, 200); }
            }
            try { if (tg.property("ADBE Position").dimensionsSeparated) { out.positionSeparated = true; } } catch (eSep) {}
        } catch (e) {}
        return out;
    }

    function layerDetail(L) {
        var d = { index: L.index, name: L.name, type: layerType(L) }, fx, i, td, masks;
        d.transform = transformInfo(L);
        try {
            fx = L.property("ADBE Effect Parade");
            if (fx && fx.numProperties > 0) {
                d.effects = [];
                for (i = 1; i <= fx.numProperties && i <= 25; i++) {
                    d.effects.push(fx.property(i).name + " [" + fx.property(i).matchName + "]");
                }
            }
        } catch (e1) {}
        try {
            if (L instanceof TextLayer) {
                td = L.property("ADBE Text Properties").property("ADBE Text Document").value;
                d.text = { text: String(td.text).substr(0, 400), font: td.font, fontSize: r(td.fontSize) };
                try { d.text.fillColor = fmtValue(td.fillColor); } catch (eC) {}
            }
        } catch (e2) {}
        try {
            masks = L.property("ADBE Mask Parade");
            if (masks && masks.numProperties > 0) { d.masks = masks.numProperties; }
        } catch (e3) {}
        try { if (L.source && !(L.source instanceof CompItem) && L.source.width) { d.sourceSize = [L.source.width, L.source.height]; } } catch (e4) {}
        try { if (L.threeDLayer) { d.threeD = true; } } catch (e5) {}
        try { if (L.trackMatteType && L.trackMatteType !== TrackMatteType.NO_TRACK_MATTE) { d.trackMatte = String(L.trackMatteType); } } catch (e6) {}
        try { if (L.blendingMode !== BlendingMode.NORMAL) { d.blendMode = String(L.blendingMode); } } catch (e7) {}
        return d;
    }

    function getContext() {
        var out = { app: "After Effects " + app.version, project: {}, comp: null };
        try {
            var p = app.project, i, it, comps = [], footage = 0, folders = 0, solids = 0, sel = [];
            out.project.name = p.file ? p.file.displayName : "(не збережено)";
            out.project.numItems = p.numItems;
            for (i = 1; i <= p.numItems; i++) {
                it = p.item(i);
                if (it instanceof CompItem) {
                    if (comps.length < 40) { comps.push(it.name + " (id " + it.id + ")"); }
                } else if (it instanceof FolderItem) { folders++; }
                else if (it instanceof FootageItem) {
                    if (it.mainSource instanceof SolidSource) { solids++; } else { footage++; }
                }
            }
            out.project.comps = comps;
            out.project.footageItems = footage;
            out.project.solids = solids;
            out.project.folders = folders;
            for (i = 0; i < p.selection.length && i < 20; i++) { sel.push(p.selection[i].name); }
            if (sel.length) { out.project.selectedItems = sel; }

            var c = p.activeItem;
            if (c && c instanceof CompItem) {
                out.comp = {
                    name: c.name, id: c.id, width: c.width, height: c.height,
                    pixelAspect: c.pixelAspect, fps: r(c.frameRate), duration: r(c.duration),
                    currentTime: r(c.time), workArea: [r(c.workAreaStart), r(c.workAreaStart + c.workAreaDuration)],
                    numLayers: c.numLayers, bgColor: fmtValue(c.bgColor)
                };
                var layers = [], L, o;
                for (i = 1; i <= c.numLayers && i <= 80; i++) {
                    L = c.layer(i);
                    o = { i: i, name: L.name, type: layerType(L), inPoint: r(L.inPoint), outPoint: r(L.outPoint) };
                    try { if (L.parent) { o.parent = L.parent.index; } } catch (eP) {}
                    if (L.selected) { o.selected = true; }
                    if (!L.enabled) { o.hidden = true; }
                    if (L.locked) { o.locked = true; }
                    try { if (L.source && !(L instanceof TextLayer)) { o.source = L.source.name; } } catch (eS) {}
                    layers.push(o);
                }
                if (c.numLayers > 80) { out.comp.layersTruncated = true; }
                out.comp.layers = layers;

                var sl = c.selectedLayers, det = [];
                for (i = 0; i < sl.length && i < 10; i++) { det.push(layerDetail(sl[i])); }
                if (det.length) { out.comp.selectedLayerDetails = det; }

                var sp = c.selectedProperties, props = [], q, item;
                for (i = 0; i < sp.length && i < 25; i++) {
                    q = sp[i];
                    item = { path: propPath(q), matchName: q.matchName };
                    try {
                        var lay = q.propertyGroup(q.propertyDepth);
                        item.layer = lay.name;
                    } catch (eL) {}
                    try {
                        if (q.propertyType === PropertyType.PROPERTY) {
                            if (q.propertyValueType !== PropertyValueType.NO_VALUE && q.propertyValueType !== PropertyValueType.CUSTOM_VALUE) {
                                item.value = fmtValue(q.value);
                            }
                            if (q.numKeys > 0) { item.keys = q.numKeys; }
                            if (q.expression) { item.expr = q.expression.substr(0, 300); }
                        }
                    } catch (eV) {}
                    props.push(item);
                }
                if (props.length) { out.comp.selectedProperties = props; }
            }
        } catch (e) {
            out.error = e.toString();
        }
        return S(out);
    }

    function run(encoded) {
        var code = decodeURIComponent(encoded);
        // прибираємо препроцесорні директиви на кшталт #target
        code = code.replace(/^\s*#(target|include|targetengine|script|strict).*$/gm, "");
        $.global.__hfLog = [];
        var res = { ok: true }, ret, started = new Date().getTime();
        app.beginUndoGroup("Hyperframes Agent");
        try {
            ret = eval("(function(){\n" + code + "\n})()");
        } catch (e) {
            res.ok = false;
            res.error = e.toString();
            if (e.line) {
                res.line = e.line - 1;
                var lines = code.split("\n");
                if (res.line > 0 && res.line <= lines.length) { res.lineText = lines[res.line - 1].substr(0, 300); }
            }
        }
        try { app.endUndoGroup(); } catch (eU) {}
        if (ret !== undefined && ret !== null) {
            if (typeof ret === "object") {
                try { ret = $.global.__hfStringify(ret); } catch (eR) { ret = String(ret); }
            }
            res.result = String(ret).substr(0, 4000);
        }
        if ($.global.__hfLog.length) { res.log = $.global.__hfLog.join("\n").substr(0, 6000); }
        res.ms = new Date().getTime() - started;
        return S(res);
    }

    function saveFrame(encodedPath) {
        var c = app.project.activeItem;
        if (!(c && c instanceof CompItem)) { return S({ ok: false, error: "Немає активної композиції" }); }
        try {
            var f = new File(decodeURIComponent(encodedPath));
            c.saveFrameToPng(c.time, f);
            var t;
            try { t = timeToCurrentFormat(c.time, c.frameRate); } catch (eT) { t = String(r(c.time)) + "s"; }
            return S({ ok: true, time: t, comp: c.name });
        } catch (e) {
            return S({ ok: false, error: e.toString() });
        }
    }

    function ping() { return "ok " + app.version; }

    return { getContext: getContext, run: run, saveFrame: saveFrame, ping: ping };
})();
