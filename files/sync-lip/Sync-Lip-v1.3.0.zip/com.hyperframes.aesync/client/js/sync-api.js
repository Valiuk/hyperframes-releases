/**
 * sync.so REST client, running in the panel's Node context.
 * No npm dependencies — just https/fs from the CEP Node runtime.
 *
 * Flow used by the panel:
 *   POST /v2/assets/upload  -> presigned PUT url
 *   PUT  <presigned url>    -> raw bytes (up to 5 GB, no 20 MB multipart limit)
 *   POST /v2/assets         -> register the url, get an assetId
 *   POST /v2/generate       -> job, referencing both assetIds
 *   GET  /v2/generate/{id}  -> poll until COMPLETED / FAILED / REJECTED
 */
(function (global) {
    'use strict';

    var nodeRequire = global.cep_node ? global.cep_node.require : global.require;
    var https = nodeRequire('https');
    var http = nodeRequire('http');
    var fs = nodeRequire('fs');
    var path = nodeRequire('path');
    var url = nodeRequire('url');

    var API_HOST = 'api.sync.so';
    var API_BASE = '/v2';

    var MIME = {
        mp4: 'video/mp4', mov: 'video/quicktime', m4v: 'video/mp4',
        webm: 'video/webm', mkv: 'video/x-matroska', avi: 'video/x-msvideo',
        wav: 'audio/wav', mp3: 'audio/mpeg', m4a: 'audio/mp4',
        aac: 'audio/aac', aif: 'audio/aiff', aiff: 'audio/aiff', ogg: 'audio/ogg', flac: 'audio/flac'
    };

    function mimeFor(filePath) {
        var ext = path.extname(filePath).replace('.', '').toLowerCase();
        return MIME[ext] || 'application/octet-stream';
    }

    function jsonRequest(apiKey, method, endpoint, body) {
        return new Promise(function (resolve, reject) {
            var payload = body ? Buffer.from(JSON.stringify(body), 'utf8') : null;
            var req = https.request({
                host: API_HOST,
                path: API_BASE + endpoint,
                method: method,
                headers: (function () {
                    var h = { 'x-api-key': apiKey, 'Accept': 'application/json' };
                    if (payload) {
                        h['Content-Type'] = 'application/json';
                        h['Content-Length'] = payload.length;
                    }
                    return h;
                })()
            }, function (res) {
                var chunks = [];
                res.on('data', function (c) { chunks.push(c); });
                res.on('end', function () {
                    var text = Buffer.concat(chunks).toString('utf8');
                    var parsed = null;
                    try { parsed = text ? JSON.parse(text) : {}; } catch (e) { parsed = { raw: text }; }
                    if (res.statusCode >= 200 && res.statusCode < 300) {
                        resolve(parsed);
                    } else {
                        var msg = (parsed && (parsed.message || parsed.error || parsed.detail)) || text || ('HTTP ' + res.statusCode);
                        var err = new Error(method + ' ' + endpoint + ' — ' + res.statusCode + ': ' + msg);
                        err.status = res.statusCode;
                        err.code = parsed && parsed.errorCode;
                        reject(err);
                    }
                });
            });
            req.on('error', reject);
            if (payload) { req.write(payload); }
            req.end();
        });
    }

    /** PUT the file bytes straight to the presigned URL, reporting progress. */
    function putFile(uploadUrl, filePath, contentType, size, onProgress) {
        return new Promise(function (resolve, reject) {
            var u = url.parse(uploadUrl);
            var lib = u.protocol === 'http:' ? http : https;
            var sent = 0;
            var req = lib.request({
                host: u.hostname,
                port: u.port,
                path: u.path,
                method: 'PUT',
                headers: { 'Content-Type': contentType, 'Content-Length': size }
            }, function (res) {
                var chunks = [];
                res.on('data', function (c) { chunks.push(c); });
                res.on('end', function () {
                    if (res.statusCode >= 200 && res.statusCode < 300) { resolve(true); }
                    else { reject(new Error('Upload failed — HTTP ' + res.statusCode + ': ' + Buffer.concat(chunks).toString('utf8').slice(0, 400))); }
                });
            });
            req.on('error', reject);

            var stream = fs.createReadStream(filePath);
            stream.on('data', function (chunk) {
                sent += chunk.length;
                if (onProgress) { onProgress(sent / size); }
            });
            stream.on('error', function (e) { req.destroy(); reject(e); });
            stream.pipe(req);
        });
    }

    function download(fileUrl, destPath, onProgress, hops) {
        hops = hops || 0;
        return new Promise(function (resolve, reject) {
            if (hops > 5) { return reject(new Error('Too many redirects while downloading the result.')); }
            var u = url.parse(fileUrl);
            var lib = u.protocol === 'http:' ? http : https;
            lib.get({ host: u.hostname, port: u.port, path: u.path, headers: { 'Accept': '*/*' } }, function (res) {
                if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                    res.resume();
                    return resolve(download(res.headers.location, destPath, onProgress, hops + 1));
                }
                if (res.statusCode !== 200) {
                    res.resume();
                    return reject(new Error('Download failed — HTTP ' + res.statusCode));
                }
                var total = parseInt(res.headers['content-length'] || '0', 10);
                var got = 0;
                var out = fs.createWriteStream(destPath);
                res.on('data', function (c) {
                    got += c.length;
                    if (onProgress && total) { onProgress(got / total); }
                });
                res.pipe(out);
                out.on('finish', function () { out.close(function () { resolve(destPath); }); });
                out.on('error', reject);
                res.on('error', reject);
            }).on('error', reject);
        });
    }

    function SyncClient(apiKey) {
        this.apiKey = apiKey;
    }

    SyncClient.prototype.listModels = function () {
        return jsonRequest(this.apiKey, 'GET', '/models');
    };

    /** Upload a local file and register it as an asset. Returns { assetId, url }. */
    SyncClient.prototype.uploadAsset = function (filePath, kind, onProgress) {
        var self = this;
        var name = path.basename(filePath);
        var contentType = mimeFor(filePath);
        var size = fs.statSync(filePath).size;

        return jsonRequest(self.apiKey, 'POST', '/assets/upload', {
            fileName: name, contentType: contentType, size: size
        }).then(function (res) {
            return putFile(res.uploadUrl, filePath, contentType, size, onProgress).then(function () {
                return jsonRequest(self.apiKey, 'POST', '/assets', {
                    url: res.url, type: kind, name: name
                });
            });
        }).then(function (asset) {
            return { assetId: asset.id, url: asset.url, size: size };
        });
    };

    /**
     * opts: { model, videoAssetId, audioAssetId, syncMode, temperature,
     *         activeSpeakerDetection, face:{frame,x,y}, occlusionDetection, outputFileName }
     */
    SyncClient.prototype.createGeneration = function (opts) {
        var body = {
            model: opts.model,
            input: [
                { type: 'video', assetId: opts.videoAssetId },
                { type: 'audio', assetId: opts.audioAssetId }
            ],
            options: {}
        };
        if (opts.syncMode) { body.options.sync_mode = opts.syncMode; }
        if (typeof opts.temperature === 'number') { body.options.temperature = opts.temperature; }
        // A marked face wins: frame + point in the uploaded video's pixels.
        // Without one, optionally let the model find whoever is speaking.
        if (opts.face) {
            body.options.active_speaker_detection = {
                auto_detect: false,
                frame_number: opts.face.frame,
                coordinates: [opts.face.x, opts.face.y]
            };
        } else if (opts.activeSpeakerDetection) {
            body.options.active_speaker_detection = { auto_detect: true };
        }
        if (opts.occlusionDetection) { body.options.occlusion_detection_enabled = true; }
        if (opts.outputFileName) { body.outputFileName = opts.outputFileName; }
        return jsonRequest(this.apiKey, 'POST', '/generate', body);
    };

    SyncClient.prototype.getGeneration = function (id) {
        return jsonRequest(this.apiKey, 'GET', '/generate/' + id);
    };

    SyncClient.prototype.deleteGeneration = function (id) {
        return jsonRequest(this.apiKey, 'DELETE', '/generate/' + id);
    };

    /**
     * Poll until the job reaches a terminal state.
     * opts: { onTick(status, seconds), intervalMs, timeoutMs, abort: { cancelled: false } }
     */
    SyncClient.prototype.waitForGeneration = function (id, opts) {
        var self = this;
        opts = opts || {};
        var onTick = opts.onTick;
        var abort = opts.abort || {};
        var intervalMs = opts.intervalMs || 5000;
        var timeoutMs = opts.timeoutMs || 45 * 60 * 1000;
        var started = Date.now();
        return new Promise(function (resolve, reject) {
            function tick() {
                if (abort.cancelled) { return reject(new Error('Скасовано користувачем.')); }
                self.getGeneration(id).then(function (job) {
                    var elapsed = Math.round((Date.now() - started) / 1000);
                    if (onTick) { onTick(job.status, elapsed); }
                    if (abort.cancelled) { return reject(new Error('Скасовано користувачем.')); }
                    if (job.status === 'COMPLETED') { return resolve(job); }
                    if (job.status === 'FAILED' || job.status === 'REJECTED') {
                        return reject(new Error('Generation ' + job.status.toLowerCase() + ': ' + (job.error || job.errorCode || 'no reason given')));
                    }
                    if (Date.now() - started > timeoutMs) {
                        return reject(new Error('Timed out after ' + Math.round(timeoutMs / 60000) + ' min. The job may still finish — check the sync.so dashboard.'));
                    }
                    setTimeout(tick, intervalMs);
                }).catch(function (e) {
                    // A single failed poll shouldn't kill a long job.
                    if (abort.cancelled) { return reject(new Error('Скасовано користувачем.')); }
                    if (/^(Generation|Скасовано)/.test(e.message)) { return reject(e); }
                    if (Date.now() - started > timeoutMs) { return reject(e); }
                    setTimeout(tick, intervalMs * 2);
                });
            }
            tick();
        });
    };

    SyncClient.prototype.download = download;

    global.SyncAPI = {
        Client: SyncClient,
        mimeFor: mimeFor,
        download: download
    };
})(this);
