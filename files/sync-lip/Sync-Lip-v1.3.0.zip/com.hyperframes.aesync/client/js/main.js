/* Sync Lip — panel controller. Talks to After Effects through evalScript
   and to sync.so through SyncAPI (Node context). */
(function () {
    'use strict';

    var nodeRequire = window.cep_node ? window.cep_node.require : window.require;
    var fs = nodeRequire('fs');
    var os = nodeRequire('os');
    var path = nodeRequire('path');

    var cs = new CSInterface();
    var CONFIG_DIR = path.join(os.homedir(), '.aesync-lip');
    var CONFIG_FILE = path.join(CONFIG_DIR, 'config.json');

    var DEFAULTS = {
        apiKey: '',
        omVideo: 'H.264 - Match Render Settings - 15 Mbps',
        omAudio: 'WAV',
        workDir: '',
        model: 'lipsync-2',
        syncMode: 'cut_off',
        temperature: 0.5,
        concurrency: 2,
        videoLabel: 4,
        audioLabel: 8
    };

    var cfg = Object.assign({}, DEFAULTS);
    var state = {
        videoPath: '',
        audioPath: '',
        selection: [],
        auto: null,
        autoMode: null,
        assets: {},
        tab: 'comp',
        scopeCount: 0,
        segCount: 0,
        templates: null,
        compId: null,
        running: false,
        dirAnnounced: false,
        queue: [],
        seq: 0,
        compName: '',
        lastRender: null,
        labels: {},
        abort: { cancelled: false }
    };

    var $ = function (id) { return document.getElementById(id); };

    // ------------------------------------------------------------- theme
    function toHex(c) {
        function p(n) { n = Math.max(0, Math.min(255, Math.round(n))); return ('0' + n.toString(16)).slice(-2); }
        return '#' + p(c.red) + p(c.green) + p(c.blue);
    }
    function shift(c, amount) {
        return { red: c.red + amount, green: c.green + amount, blue: c.blue + amount };
    }
    function applyTheme() {
        try {
            var skin = cs.getHostEnvironment().appSkinInfo;
            var base = skin.panelBackgroundColor.color;
            var light = base.red > 127;
            var r = document.documentElement.style;
            r.setProperty('--bg', toHex(base));
            r.setProperty('--bg-sunk', toHex(shift(base, light ? -14 : -8)));
            r.setProperty('--bg-raise', toHex(shift(base, light ? 10 : 14)));
            r.setProperty('--line', toHex(shift(base, light ? -34 : 26)));
            r.setProperty('--text', light ? '#20242a' : '#d6d9dc');
            r.setProperty('--text-dim', light ? '#5e666e' : '#8b9299');
            r.setProperty('--accent', light ? '#a86a10' : '#e0a13c');
        } catch (e) { /* keep the stylesheet defaults */ }
    }

    // --------------------------------------------------------------- log
    function log(msg, cls) {
        var el = $('log');
        var stamp = new Date().toTimeString().slice(0, 8);
        var span = document.createElement('span');
        span.className = cls || '';
        span.textContent = stamp + '  ' + msg + '\n';
        el.appendChild(span);
        el.scrollTop = el.scrollHeight;
        // The folded journal still shows its latest line, so nothing important
        // happens out of sight.
        var last = $('logLast');
        if (last) { last.textContent = msg; last.className = 'log-last' + (cls ? ' ' + cls : ''); }
    }

    // ------------------------------------------------------------- queue UI
    var STAGES = ['підготовка', 'вивантаження', 'генерація', 'завантаження', 'імпорт'];

    function qAdd(item) {
        item.id = 'q' + (++state.seq);
        item.status = 'waiting';
        item.stage = 0;
        item.note = 'у черзі';
        state.queue.push(item);
        qRender();
        return item;
    }

    function qRemove(id) {
        state.queue = state.queue.filter(function (i) { return i.id !== id || i.status === 'running'; });
        qRender();
    }

    function qRender() {
        var list = $('queueList');
        list.innerHTML = '';

        // Same VO reused across two comps is nearly always a mistake when
        // localising — flag it before a paid generation, not after.
        var audioCount = {};
        state.queue.forEach(function (i) {
            if (i.audioPath) { audioCount[i.audioPath] = (audioCount[i.audioPath] || 0) + 1; }
        });

        state.queue.forEach(function (it) {
            var li = document.createElement('li');
            li.className = 'q-item ' + it.status;

            var head = document.createElement('div');
            head.className = 'q-head';

            var name = document.createElement('button');
            name.className = 'q-name';
            name.textContent = it.label;
            if (it.compId) {
                name.title = 'Відкрити цю композицію в AE';
                name.addEventListener('click', function () {
                    es('aesyncRevealComp', { compId: it.compId }).then(function (r) {
                        log('Відкрито: ' + r.name);
                    }).catch(function (e) { log(e.message, 'e'); });
                });
            } else {
                name.disabled = true;
                name.title = 'Пара файлів, без композиції';
            }
            head.appendChild(name);

            var drop = document.createElement('button');
            drop.className = 'q-drop';
            drop.textContent = '×';
            drop.title = 'Прибрати з черги';
            drop.disabled = it.status === 'running';
            drop.addEventListener('click', function () { qRemove(it.id); });
            head.appendChild(drop);
            li.appendChild(head);

            var src = document.createElement('div');
            src.className = 'q-src';
            src.appendChild(srcLine('відео',
                it.videoName || state.labels[it.videoPath] || (it.videoPath ? path.basename(it.videoPath) : '—'),
                it.videoPath || '',
                it.videoPath ? fileSize(it.videoPath) : 'рендер при старті черги'));
            src.appendChild(srcLine('озвучка',
                it.audioName || state.labels[it.audioPath] || (it.audioPath ? path.basename(it.audioPath) : '—'),
                it.audioPath || '',
                it.audioPath
                    ? ((it.audioDuration ? it.audioDuration.toFixed(1) + ' с · ' : '') + fileSize(it.audioPath))
                    : ((it.audioDuration ? it.audioDuration.toFixed(1) + ' с · ' : '') + 'рендер при старті черги')));
            li.appendChild(src);

            if (it.faceText) {
                src.appendChild(srcLine('обличчя', it.faceText, '', ''));
            }

            if (it.mode === 'render') {
                var tag = document.createElement('div');
                tag.className = 'q-flag q-flag-quiet';
                tag.textContent = it.renderNote || 'рендериться перед відправкою';
                li.appendChild(tag);
            }

            if (audioCount[it.audioPath] > 1) {
                var dup = document.createElement('div');
                dup.className = 'q-flag';
                dup.textContent = '! ця сама озвучка ще в ' + (audioCount[it.audioPath] - 1) + ' елемент(ах) черги';
                li.appendChild(dup);
            }

            var foot = document.createElement('div');
            foot.className = 'q-foot';

            var dots = document.createElement('span');
            dots.className = 'q-dots';
            for (var s = 1; s <= STAGES.length; s++) {
                var d = document.createElement('span');
                d.title = STAGES[s - 1];
                if (it.status === 'error' && s === it.stage) { d.className = 'fail'; }
                else if (s < it.stage || it.status === 'done') { d.className = 'done'; }
                else if (s === it.stage && it.status === 'running') { d.className = 'active'; }
                dots.appendChild(d);
            }
            foot.appendChild(dots);

            var note = document.createElement('span');
            note.className = 'q-note';
            note.textContent = it.note;
            note.title = it.jobId ? 'job ' + it.jobId : it.note;
            foot.appendChild(note);
            li.appendChild(foot);

            if (it.status === 'done' || it.status === 'error') {
                var again = document.createElement('div');
                again.className = 'q-again';
                var hasFiles = it.mode !== 'render' || (usable(it.videoPath) && usable(it.audioPath));
                var rep = document.createElement('button');
                rep.className = 'btn btn-ghost q-rep';
                rep.textContent = 'Повторити';
                rep.title = it.mode === 'render'
                    ? 'Ще раз з поточними налаштуваннями, без рендера: беруться ті самі відео й озвучка'
                    : 'Ще раз з поточними налаштуваннями';
                rep.disabled = !hasFiles;
                rep.addEventListener('click', function () { qRepeat(it, true); });
                again.appendChild(rep);
                if (it.mode === 'render') {
                    var rer = document.createElement('button');
                    rer.className = 'link-btn';
                    rer.textContent = 'з новим рендером';
                    rer.title = 'Якщо змінив щось у композиції: відрендерити її заново й тоді відправити';
                    rer.addEventListener('click', function () { qRepeat(it, false); });
                    again.appendChild(rer);
                }
                li.appendChild(again);
            }

            list.appendChild(li);
        });

        var waiting = state.queue.filter(function (i) { return i.status === 'waiting'; }).length;
        var done = state.queue.filter(function (i) { return i.status === 'done'; }).length;
        var failed = state.queue.filter(function (i) { return i.status === 'error'; }).length;
        $('qCount').textContent = state.queue.length
            ? (state.queue.length + ' · чекає ' + waiting + ' · готово ' + done + (failed ? ' · помилок ' + failed : ''))
            : 'порожня';
        $('btnStart').disabled = state.running || !waiting;
    }

    function fileSize(p) {
        try { return (fs.statSync(p).size / 1048576).toFixed(1) + ' МБ'; }
        catch (e) { return 'файлу немає'; }
    }

    function srcLine(kind, name, fullPath, meta) {
        var row = document.createElement('div');
        row.title = fullPath;
        var k = document.createElement('em');
        k.textContent = kind;
        row.appendChild(k);
        row.appendChild(document.createTextNode(' ' + name + (meta ? ' · ' + meta : '')));
        return row;
    }

    function qStage(it, stage, note) {
        it.stage = stage;
        it.note = note || STAGES[stage - 1] || '';
        qRender();
    }

    // ---------------------------------------------------------- extendscript
    function esEscape(s) {
        return s
            .replace(/\\/g, '\\\\')
            .replace(/"/g, '\\"')
            .replace(/\r?\n/g, '\\n')
            // Same story in this direction: the bridge only survives ASCII, so
            // Cyrillic project paths go across as \uXXXX literals.
            .replace(/[\u007f-\uffff]/g, function (c) {
                return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4);
            });
    }
    function es(fn, arg) {
        return new Promise(function (resolve, reject) {
            var call = (arg === undefined)
                ? fn + '()'
                : fn + '("' + esEscape(JSON.stringify(arg)) + '")';
            cs.evalScript(call, function (res) {
                if (!res || res === 'EvalScript error.') {
                    return reject(new Error('ExtendScript помилка у ' + fn + '. Дивись CEP-консоль на порту 8099.'));
                }
                var parsed;
                try { parsed = JSON.parse(res); }
                catch (e) { return reject(new Error(fn + ' повернув не-JSON: ' + res.slice(0, 200))); }
                if (!parsed.ok) { return reject(new Error(parsed.error)); }
                resolve(parsed.data);
            });
        });
    }

    // -------------------------------------------------------------- config
    function loadConfig() {
        try {
            if (fs.existsSync(CONFIG_FILE)) {
                cfg = Object.assign({}, DEFAULTS, JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')));
            }
        } catch (e) { log('Не вдалось прочитати конфіг: ' + e.message, 'e'); }
    }
    function saveConfig() {
        try {
            if (!fs.existsSync(CONFIG_DIR)) { fs.mkdirSync(CONFIG_DIR, { recursive: true }); }
            fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2), { mode: 0o600 });
            return true;
        } catch (e) { log('Не вдалось зберегти конфіг: ' + e.message, 'e'); return false; }
    }
    function client() {
        if (!cfg.apiKey) { throw new Error('Спочатку впиши API-ключ у налаштуваннях.'); }
        return new SyncAPI.Client(cfg.apiKey);
    }
    function markKeyState() {
        var pill = $('keyState');
        pill.textContent = cfg.apiKey ? 'ключ збережено' : 'без ключа';
        pill.className = 'pill ' + (cfg.apiKey ? 'pill-ok' : 'pill-warn');
        $('keyCard').hidden = !!cfg.apiKey;
    }

    // -------------------------------------------------------------- sources
    function fillSelect(select, items, extraLabel) {
        select.innerHTML = '';
        var none = document.createElement('option');
        none.value = '';
        none.textContent = items.length ? '— обери ' + extraLabel + ' —' : 'у проєкті немає ' + extraLabel;
        select.appendChild(none);
        items.forEach(function (it) {
            var opt = document.createElement('option');
            opt.value = it.path;
            opt.textContent = it.name + '  (' + it.duration.toFixed(2) + ' с)';
            select.appendChild(opt);
        });
    }

    function addExternal(select, filePath, label) {
        var existing = select.querySelector('option[value="' + filePath.replace(/"/g, '\\"') + '"]');
        if (!existing) {
            var opt = document.createElement('option');
            opt.value = filePath;
            opt.textContent = label || (path.basename(filePath) + '  (з диска)');
            select.appendChild(opt);
        } else if (label) {
            existing.textContent = label;
        }
        state.labels[filePath] = label || path.basename(filePath);
        select.value = filePath;
        select.dispatchEvent(new Event('change'));
    }

    function refresh() {
        return es('aesyncScanProject').then(function (d) {
            var keepV = $('videoSelect').value, keepA = $('audioSelect').value;
            fillSelect($('videoSelect'), d.video, 'відео');
            fillSelect($('audioSelect'), d.audio, 'аудіо');
            if (keepV) { addExternal($('videoSelect'), keepV, state.labels[keepV]); }
            if (keepA) { addExternal($('audioSelect'), keepA, state.labels[keepA]); }
        }).then(function () {
            return es('aesyncContext');
        }).then(function (ctx) {
            state.selection = ctx.selection || [];
            state.compId = ctx.comp ? ctx.comp.id : null;
            state.compName = ctx.comp ? ctx.comp.name : '';
            $('selMeta').textContent = state.selection.length ? state.selection[0].name : '';
            $('replaceLayer').disabled = !state.selection.length;
            if (!state.selection.length) { $('replaceLayer').checked = false; }
            faceStatus();
            return currentScope() === 'active' ? detect() : scopePreview();
        }).then(function () {
            return labelPreview(false);
        }).catch(function (e) { log(e.message, 'e'); });
    }

    // ------------------------------------------------- active comp, one click
    /** Build a preview box from rows: {title, rows:[[k,v]], status:[cls,text], note}. */
    function paintPreview(boxId, kind, p) {
        var box = $(boxId);
        box.className = 'preview' + (kind ? ' is-' + kind : '');
        box.innerHTML = '';
        function el(tag, cls, text) {
            var e = document.createElement(tag);
            if (cls) { e.className = cls; }
            if (text !== undefined) { e.textContent = text; }
            return e;
        }
        if (p.title) { box.appendChild(el('div', 'pv-title', p.title)); }
        (p.rows || []).forEach(function (r) {
            var row = el('div', 'pv-row');
            row.appendChild(el('b', '', r[0]));
            row.appendChild(el('span', '', r[1]));
            box.appendChild(row);
        });
        if (p.status) { box.appendChild(el('div', 'pv-status ' + p.status[0], p.status[1])); }
        if (p.note) { box.appendChild(el('div', 'pv-note', p.note)); }
    }

    /**
     * The active comp: what will be sent and *how*. Direct = files read off
     * disk; render = the comp goes through Render Queue first. The user no
     * longer chooses — the panel picks, and says which it picked.
     */
    function detect() {
        return es('aesyncAutoSources').then(function (d) {
            state.auto = d;
            state.autoMode = d.warnings.length ? 'render' : 'direct';
            state.compId = d.comp.id;
            if (currentScope() === 'active') {
                paintPreview('autoMeta', d.warnings.length ? 'warn' : 'ok', {
                    title: d.comp.name,
                    rows: [['відео', d.video.name],
                           ['озвучка', d.audio.name + ' · ' + d.audio.duration.toFixed(1) + ' с']],
                    status: d.warnings.length
                        ? ['warn', 'Шари підрізані — комп буде відрендерено перед відправкою']
                        : ['ok', 'Файли підуть напряму, без рендера'],
                    note: d.rerun ? 'У компі вже є ліпсінк — його буде замінено.' : ''
                });
            }
            return d;
        }).catch(function (e) {
            state.auto = null;
            var msg = e.message;
            var precomp = /прекомп/.test(msg);
            state.autoMode = precomp ? 'render' : null;
            if (currentScope() === 'active') {
                if (precomp) {
                    paintPreview('autoMeta', 'warn', {
                        title: state.compName || 'Активна композиція',
                        status: ['warn', 'Зверху прекомп — комп буде відрендерено перед відправкою']
                    });
                } else {
                    paintPreview('autoMeta', 'bad', {
                        title: state.compName || '',
                        status: ['bad', msg.replace(/^Композиція "[^"]*": /, '')],
                        note: /Немає активної/.test(msg) ? 'Відкрий комп у таймлайні й поверніться сюди.' :
                              'Потрібні шар з відеофайлом і окремий шар з озвучкою.'
                    });
                }
            }
            return null;
        }).then(function (d) { updateGo(); return d; });
    }

    function currentScope() {
        var r = document.querySelector('input[name="scope"]:checked');
        return r ? r.value : 'active';
    }

    /** Preview for the batch scopes — counts before anything is queued. */
    function scopePreview() {
        var scope = currentScope();
        if (scope === 'active') { return detect(); }
        if (scope === 'selected') {
            return es('aesyncSelectedComps').then(function (d) {
                state.scopeCount = d.comps.length;
                paintPreview('autoMeta', d.comps.length ? 'ok' : 'bad', d.comps.length ? {
                    title: 'Виділено в проєкті: ' + d.comps.length,
                    rows: d.comps.slice(0, 4).map(function (c) { return ['', c.name]; }),
                    note: (d.comps.length > 4 ? '… і ще ' + (d.comps.length - 4) + '. ' : '') +
                          'Для кожної панель окремо вирішить: напряму чи через рендер.'
                } : {
                    status: ['bad', 'У панелі Project не виділено жодної композиції'],
                    note: 'Виділи потрібні компи в панелі проєкту (не в таймлайні).'
                });
            }).catch(function (e) { paintPreview('autoMeta', 'bad', { status: ['bad', e.message] }); })
              .then(updateGo);
        }
        return es('aesyncScanComps').then(function (d) {
            state.scopeCount = d.ready.length;
            paintPreview('autoMeta', d.ready.length ? 'ok' : 'bad', {
                title: 'Готових композицій: ' + d.ready.length,
                rows: d.ready.slice(0, 4).map(function (r) { return ['', r.comp.name]; }),
                status: d.skipped.length ? ['warn', 'Пропущено ' + d.skipped.length + ' — без пари відео+озвучка'] : null,
                note: 'Беруться лише компи, де файли можна відправити напряму. Решту — через «Виділені в проєкті».'
            });
        }).catch(function (e) { paintPreview('autoMeta', 'bad', { status: ['bad', e.message] }); })
          .then(updateGo);
    }

    function itemFromComp(d) {
        return {
            label: d.comp.name,
            compName: d.comp.name,
            videoPath: d.video.path,
            audioPath: d.audio.path,
            videoName: d.video.name,
            audioName: d.audio.name,
            audioDuration: d.audio.duration,
            videoDuration: d.video.duration,
            compId: d.comp.id,
            videoRef: { index: d.video.index, name: d.video.name },
            addToComp: true,
            startTime: d.video.startTime,
            audioRef: { index: d.audio.index, name: d.audio.name },
            muteLayers: $('muteSources').checked
                ? [{ index: d.video.index, name: d.video.name, role: 'video' },
                   { index: d.audio.index, name: d.audio.name, role: 'audio' }]
                : []
        };
    }

    /** One click: read the active comp, queue it, run it. */
    function runAuto() {
        detect().then(function (d) {
            if (!d) { return; }
            qAdd(itemFromComp(d));
            startQueue();
        });
    }

    function queueActiveComp() {
        detect().then(function (d) {
            if (!d) { return; }
            qAdd(itemFromComp(d));
            log('[' + d.comp.name + '] у чергу: ' + d.video.name + ' + ' + d.audio.name);
        });
    }

    /** The multi-geo case: every comp in the project that already has a pair. */
    function queueAllComps() {
        return es('aesyncScanComps').then(function (d) {
            var queued = 0;
            d.ready.forEach(function (r) {
                var dup = state.queue.some(function (i) {
                    return i.compId === r.comp.id && i.status !== 'error';
                });
                if (dup) { return; }
                qAdd(itemFromComp(r));
                queued++;
            });
            log('Додано композицій: ' + queued + (queued < d.ready.length ? ' (решта вже в черзі)' : ''), queued ? 's' : '');
            if (d.skipped.length) {
                log('Пропущено ' + d.skipped.length + ': ' + d.skipped.slice(0, 6).map(function (s) {
                    return s.name + ' — ' + s.reason;
                }).join('; ') + (d.skipped.length > 6 ? ' …' : ''));
            }
        }).catch(function (e) { log(e.message, 'e'); });
    }

    /**
     * Queue a comp as a render-then-upload item: video and audio both come from
     * a full Render Queue pass over the comp (like the two manual "Рендер …"
     * buttons combined), not from reading layers straight off disk. Use this
     * when the comp has a precomp on top, or trimmed/spliced video or audio —
     * cases the footage-based "auto" queueing can't (or shouldn't) touch.
     * The actual render happens lazily when the queue starts (same mechanism
     * as label-prepared precomps), so this only needs to add a queue entry.
     */
    function queueRenderComp(comp) {
        var dup = state.queue.some(function (i) {
            return i.compId === comp.id && i.status !== 'error';
        });
        if (dup) {
            log('[' + comp.name + '] вже в черзі — пропускаю.');
            return Promise.resolve(false);
        }

        var wantMute = $('muteSources').checked;
        var muted = wantMute
            ? es('aesyncAutoSources', { compId: comp.id }).then(function (d) {
                  return [
                      { index: d.video.index, name: d.video.name, role: 'video' },
                      { index: d.audio.index, name: d.audio.name, role: 'audio' }
                  ];
              }).catch(function () { return []; }) // precomp on top, edited layers, etc. — render still works, just nothing to auto-mute
            : Promise.resolve([]);

        return muted.then(function (muteLayers) {
            qAdd({
                label: comp.name,
                compName: comp.name,
                compId: comp.id,
                mode: 'render',
                renderNote: 'рендер комп\u2019озиції — відео+аудіо перед відправкою',
                addToComp: true,
                muteResultAudio: false,
                audioRef: muteLayers[1] || null,
                muteLayers: muteLayers
            });
            var note = wantMute
                ? (muteLayers.length ? '' : ' (вихідні шари не визначились — вимкни їх вручну після імпорту)')
                : '';
            log('[' + comp.name + '] у чергу: рендер відео+аудіо перед відправкою' + note);
            return true;
        });
    }

    /** One button: render both tracks of the active comp and queue them together. */
    function queueRenderActive() {
        // Ask AE directly instead of trusting state.compId — that cache only
        // refreshes on PanelActivated, so switching comps in the timeline
        // without ever refocusing the panel would otherwise look like "no
        // active comp" even though one clearly is.
        return es('aesyncContext').then(function (ctx) {
            if (!ctx.comp) { return log('Немає активної композиції. Відкрий комп у таймлайні.', 'e'); }
            state.compId = ctx.comp.id;
            state.compName = ctx.comp.name;
            return queueRenderComp({ id: ctx.comp.id, name: ctx.comp.name });
        }).catch(function (e) { log(e.message, 'e'); });
    }

    /** The batch case: every comp currently selected in the Project panel, not just the active one. */
    function queueRenderSelected() {
        return es('aesyncSelectedComps').then(function (d) {
            if (!d.comps.length) {
                return log('У панелі проекту не виділено жодної композиції.', 'e');
            }
            return d.comps.reduce(function (chain, c) {
                return chain.then(function (count) {
                    return queueRenderComp(c).then(function (added) { return count + (added ? 1 : 0); });
                });
            }, Promise.resolve(0)).then(function (count) {
                log('Додано в чергу: ' + count + ' композиц' + (count === 1 ? 'ію' : 'ій') +
                    (count < d.comps.length ? ' (решта вже в черзі)' : '') +
                    ' — кожна рендериться перед відправкою.', count ? 's' : '');
            });
        }).catch(function (e) { log(e.message, 'e'); });
    }

    function queueManual() {
        var v = $('videoSelect').value, a = $('audioSelect').value;
        if (!v || !a) { log('Обери і відео, і озвучку.', 'e'); return false; }

        var bad = [v, a].filter(function (p) {
            try { return fs.statSync(p).size < 1024; } catch (e) { return true; }
        });
        if (bad.length) {
            log('Не ставлю в чергу: ' + bad.map(function (p) { return path.basename(p); }).join(', ') +
                ' — файл порожній або відсутній. Генерація на такому лише спалить квоту.', 'e');
            return false;
        }

        var replaceIdx = ($('replaceLayer').checked && state.selection.length) ? state.selection[0].index : 0;
        var label = state.compName ? state.compName + ' (вручну)' : path.basename(v);
        qAdd({
            label: label,
            compName: state.compName,
            videoPath: v,
            audioPath: a,
            compId: state.compId,
            addToComp: $('addToComp').checked,
            replaceLayerIndex: replaceIdx,
            muteLayers: []
        });
        log('[' + label + '] у чергу: ' + (state.labels[v] || path.basename(v)) + ' + ' + (state.labels[a] || path.basename(a)));
        return true;
    }

    function browse(kind) {
        var types = kind === 'video' ? ['mp4', 'mov', 'm4v', 'webm', 'mkv'] : ['wav', 'mp3', 'm4a', 'aac', 'aif', 'aiff', 'flac'];
        var res = window.cep.fs.showOpenDialog(false, false, 'Обери ' + kind, '', types);
        if (res && res.data && res.data.length) {
            addExternal($(kind === 'video' ? 'videoSelect' : 'audioSelect'), res.data[0]);
            log('Обрано з диска: ' + path.basename(res.data[0]));
        }
    }

    var TRANSLIT = {
        а: 'a', б: 'b', в: 'v', г: 'h', ґ: 'g', д: 'd', е: 'e', є: 'ie', ж: 'zh', з: 'z',
        и: 'y', і: 'i', ї: 'i', й: 'i', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p',
        р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'kh', ц: 'ts', ч: 'ch', ш: 'sh',
        щ: 'shch', ь: '', ю: 'iu', я: 'ia', ы: 'y', э: 'e', ъ: '', ё: 'e'
    };

    /** "Казик DE" → "Kazyk_DE": the comp stays recognisable in an ASCII filename. */
    function translit(s) {
        return String(s).split('').map(function (ch) {
            var lower = ch.toLowerCase();
            if (!TRANSLIT.hasOwnProperty(lower)) { return ch; }
            var out = TRANSLIT[lower];
            return ch === lower ? out : (out.charAt(0).toUpperCase() + out.slice(1));
        }).join('');
    }

    /**
     * A token unique to one pass over one item. Every file this run writes
     * carries it, so re-running a comp never writes over a file AE already
     * holds open from the previous result — that collision is what used to
     * surface as a failed render or a stale clip in the project.
     */
    function runId() {
        return Date.now().toString(36).slice(-6) +
               Math.random().toString(36).slice(2, 8);
    }

    /** Anything crossing into ExtendScript must be ASCII, so filenames get stripped. */
    function asciiName(name) {
        var clean = translit(name)
            .replace(/[^\x20-\x7E]/g, '')
            .replace(/[\\/:*?"<>|]/g, '_')
            .trim()
            .replace(/\s+/g, '_')
            .replace(/_{2,}/g, '_');
        return clean.length > 2 ? clean.slice(0, 60) : ('sync_' + Date.now());
    }
    function isAscii(s) { return !/[^\x00-\x7F]/.test(s || ''); }

    /** Real template names, straight from this AE install — no guessing at localised strings. */
    function loadTemplates(verbose) {
        return es('aesyncTemplates').then(function (d) {
            state.templates = d.outputModules;
            [['omVideo', cfg.omVideo], ['omAudio', cfg.omAudio]].forEach(function (pair) {
                var sel = $(pair[0]);
                var saved = pair[1];
                sel.innerHTML = '';
                d.outputModules.forEach(function (name) {
                    var o = document.createElement('option');
                    o.value = name;
                    o.textContent = name;
                    sel.appendChild(o);
                });
                if (saved && d.outputModules.indexOf(saved) === -1) {
                    var miss = document.createElement('option');
                    miss.value = saved;
                    miss.textContent = saved + '  — немає в цій версії AE';
                    sel.insertBefore(miss, sel.firstChild);
                }
                sel.value = saved || (d.outputModules[0] || '');
            });
            if (verbose) { log('Шаблонів Output Module у цій версії AE: ' + d.outputModules.length, 's'); }
            var missing = [cfg.omVideo, cfg.omAudio].filter(function (n) {
                return n && d.outputModules.indexOf(n) === -1;
            });
            if (missing.length) {
                log('Немає таких шаблонів: ' + missing.join(', ') + '. Обери зі списку в налаштуваннях.', 'e');
                // Fall back to something lossless rather than leaving it broken.
                var lossless = d.outputModules.filter(function (n) { return /wav|aiff/i.test(n); })[0];
                if (lossless && d.outputModules.indexOf(cfg.omAudio) === -1) {
                    cfg.omAudio = lossless;
                    $('omAudio').value = lossless;
                    saveConfig();
                    log('Для аудіо поставив "' + lossless + '".');
                }
            }
            if (/mp3/i.test(cfg.omAudio)) {
                log('MP3 для озвучки — стиснення поверх стиснення. Якщо в списку є WAV чи AIFF, краще взяти їх.');
            }
            return d;
        }).catch(function (e) { log('Не вдалось прочитати шаблони: ' + e.message, 'e'); });
    }

    // ------------------------------------------------------------ prepare
    var LABELS = ['—', 'Червоний', 'Жовтий', 'Аква', 'Рожевий', 'Лаванда', 'Персиковий',
        'Морська піна', 'Синій', 'Зелений', 'Пурпуровий', 'Помаранчевий', 'Коричневий',
        'Фуксія', 'Ціан', 'Пісковик', 'Темно-зелений'];

    // AE's default label colours, index 1..16 — the swatches look like the timeline.
    var LABEL_COLORS = ['', '#B53838', '#E4D84C', '#A9CBC7', '#E5BCC9', '#A9A9CA', '#E7C19E',
        '#B3C7B3', '#677DE0', '#4AA44C', '#8E2C9A', '#E8920D', '#7F452A', '#F46DD6',
        '#3DA2A5', '#A89677', '#1E401E'];

    function buildPicker(pickerId, selectId, nameId) {
        var box = $(pickerId);
        box.innerHTML = '';
        for (var i = 1; i < LABEL_COLORS.length; i++) {
            (function (n) {
                var b = document.createElement('button');
                b.type = 'button';
                b.className = 'swatch';
                b.setAttribute('role', 'radio');
                b.style.backgroundColor = LABEL_COLORS[n];
                b.title = n + ' · ' + LABELS[n];
                b.dataset.label = String(n);
                b.addEventListener('click', function () {
                    $(selectId).value = String(n);
                    $(selectId).dispatchEvent(new Event('change'));
                });
                box.appendChild(b);
            })(i);
        }
        syncPicker(pickerId, selectId, nameId);
    }

    /** Reflect the select into the swatches; the other picker's colour is greyed out. */
    function syncPicker(pickerId, selectId, nameId) {
        var v = $(selectId).value;
        var other = $(selectId === 'videoLabel' ? 'audioLabel' : 'videoLabel').value;
        Array.prototype.forEach.call($(pickerId).children, function (b) {
            b.setAttribute('aria-checked', b.dataset.label === v ? 'true' : 'false');
            b.disabled = b.dataset.label === other;
        });
        $(nameId).textContent = LABELS[parseInt(v, 10)] || '';
    }

    function syncPickers() {
        syncPicker('videoLabelPicker', 'videoLabel', 'videoLabelName');
        syncPicker('audioLabelPicker', 'audioLabel', 'audioLabelName');
    }

    function fillLabelSelect(id, chosen) {
        var sel = $(id);
        sel.innerHTML = '';
        for (var i = 1; i < LABELS.length; i++) {
            var o = document.createElement('option');
            o.value = String(i);
            o.textContent = i + ' · ' + LABELS[i];
            sel.appendChild(o);
        }
        sel.value = String(chosen);
    }

    function labelPreview(verbose) {
        var vName = LABELS[parseInt($('videoLabel').value, 10)];
        var aName = LABELS[parseInt($('audioLabel').value, 10)];
        return es('aesyncLabelPreview', {
            videoLabel: parseInt($('videoLabel').value, 10),
            audioLabel: parseInt($('audioLabel').value, 10)
        }).then(function (d) {
            state.segCount = (d.audio.length ? d.video.length : 0);
            var rows = d.video.slice(0, 4).map(function (v) {
                return [v.start.toFixed(1) + '–' + v.end.toFixed(1) + ' с', v.name];
            });
            if (d.video.length > 4) { rows.push(['', '… і ще ' + (d.video.length - 4)]); }
            var ok = d.video.length && d.audio.length;
            paintPreview('labelMeta', ok ? 'ok' : 'bad', {
                title: d.compName,
                rows: rows,
                status: ok
                    ? ['ok', 'Сегментів: ' + d.video.length + ', озвучка знайдена']
                    : ['bad', !d.video.length
                        ? 'Немає шарів з міткою «' + vName + '»'
                        : 'Немає шару озвучки з міткою «' + aName + '»'],
                note: ok ? 'Кожен сегмент стане прекомпом на тому ж місці таймлайну.'
                         : 'Признач мітку в таймлайні: правий клік по шару → Label.'
            });
            if (verbose) { log('[' + d.compName + '] по мітках: ' + d.video.length + ' сегментів, ' + d.audio.length + ' аудіошар(ів)'); }
            return d;
        }).catch(function (e) {
            state.segCount = 0;
            paintPreview('labelMeta', 'bad', { status: ['bad', e.message] });
            return null;
        }).then(function (d) { updateGo(); return d; });
    }

    function prepare() {
        return es('aesyncPrepare', {
            videoLabel: parseInt($('videoLabel').value, 10),
            audioLabel: parseInt($('audioLabel').value, 10)
        }).then(function (d) {
            log('[' + d.compName + '] створено прекомпів: ' + d.made.length, d.made.length ? 's' : 'e');
            d.made.forEach(function (m) {
                if (m.inPlace) {
                    log('  ' + m.name + ' → ' + m.segment.start.toFixed(2) + '–' + m.segment.end.toFixed(2) +
                        ' с, шар ' + m.landed.index);
                } else {
                    log('  ' + m.name + ' — прекомп не став на місце сегмента (' +
                        m.segment.start.toFixed(2) + '–' + m.segment.end.toFixed(2) + ' с). Перевір позицію шару.', 'e');
                }
            });
            d.skipped.forEach(function (s) {
                log('[' + d.compName + '] пропущено ' + s.name + ' — ' + s.reason, 'e');
            });
            if (true) {
                d.made.forEach(function (m) {
                    qAdd({
                        label: m.name,
                        compName: m.name,
                        compId: m.id,
                        mode: 'render',
                        renderNote: 'прекомп із міток — рендериться перед відправкою',
                        videoName: m.videoLayer.name,
                        audioName: m.audioLayer.name,
                        audioDuration: m.duration,
                        addToComp: true,
                        muteResultAudio: true,
                        audioRef: m.audioLayer,
                        muteLayers: [
                            { index: m.videoLayer.index, name: m.videoLayer.name, role: 'video' },
                            { index: m.audioLayer.index, name: m.audioLayer.name, role: 'audio' }
                        ]
                    });
                });
                if (d.made.length) { log('У чергу поставлено ' + d.made.length + ' прекомпів — вони рендеряться перед відправкою.'); }
            }
            return refresh().then(function () { return d.made.length; });
        }).catch(function (e) { log(e.message, 'e'); return 0; });
    }

    // AE's Render Queue is one engine, not one per evalScript call: two
    // "render this comp" requests in flight at once would both be poking
    // app.project.renderQueue at the same time. Everything that renders a
    // comp goes through this gate so lanes (concurrency > 1) queue up their
    // renders instead of colliding — the sync.so upload/poll/download steps
    // for other items keep running in parallel around it.
    var renderGate = Promise.resolve();
    function esRender(args) {
        var run = renderGate.then(function () { return es('aesyncRenderComp', args); });
        renderGate = run.then(function () {}, function () {});
        return run;
    }

    function hostDir() {
        // A custom folder is only usable host-side when it survives the bridge.
        return (cfg.workDir && isAscii(cfg.workDir)) ? cfg.workDir : '';
    }

    function workDir() {
        if (cfg.workDir && isAscii(cfg.workDir)) {
            if (!fs.existsSync(cfg.workDir)) { fs.mkdirSync(cfg.workDir, { recursive: true }); }
            return Promise.resolve(cfg.workDir);
        }
        if (cfg.workDir) {
            log('Тека з налаштувань містить не-ASCII символи — беру автоматичну.', 'e');
        }
        return es('aesyncWorkDir', { dirPath: '' }).then(function (d) {
            if (!fs.existsSync(d.path)) { fs.mkdirSync(d.path, { recursive: true }); }
            if (!state.dirAnnounced) {
                state.dirAnnounced = true;
                log('Робоча тека: ' + d.path);
                if (!d.nextToProject && d.projectDir && !d.projectAscii) {
                    log('Тека проєкту містить кирилицю — AE не може туди рендерити, тому тимчасові файли йдуть сюди.');
                }
            }
            return d.path;
        });
    }

    function renderComp(kind) {
        var isVideo = kind === 'video';
        var tpl = isVideo ? cfg.omVideo : cfg.omAudio;
        var ext = isVideo ? '.mp4' : '.wav';
        var compTag = state.compName || 'comp';
        var fileName = asciiName(compTag) + '_' + kind + '_' + runId() + ext;
        return workDir().then(function () {
            log('[' + compTag + '] рендер ' + (isVideo ? 'відео' : 'аудіо') + ' → ' + fileName);
            log('[' + compTag + '] шаблон "' + tpl + '"');
            return esRender({
                compId: state.compId,
                fileName: fileName,
                dirPath: hostDir(),
                omTemplate: tpl,
                forceAudio: !isVideo,
                excludeResults: true,
                soloAudio: !isVideo,
                audioLabel: cfg.audioLabel
            });
        }).then(function (d) {
            if (!isVideo) { logHeard(d.compName, d); }
            state.lastRender = { compId: d.compId, compName: d.compName };
            addExternal($(isVideo ? 'videoSelect' : 'audioSelect'), d.path,
                d.compName + ' — ' + (isVideo ? 'відео' : 'аудіо') + ' (рендер)');
            log('[' + d.compName + '] готово: ' + d.fileName + '  (' + (d.size / 1048576).toFixed(2) + ' МБ)', 's');
            if (!isVideo && d.size < 20000) {
                log('[' + d.compName + '] файл підозріло малий для озвучки — послухай його перед постановкою в чергу.', 'e');
            }
        }).catch(function (e) {
            log(e.message, 'e');
            if (/template|шаблон/i.test(e.message)) {
                loadTemplates(false).then(function (d) {
                    if (d && d.outputModules.length) {
                        log('Доступні: ' + d.outputModules.join(' · '));
                        log('Обери потрібний у налаштуваннях — поле стало списком.');
                    }
                });
            }
        });
    }

    // ------------------------------------------------------------- face
    /**
     * Read the crosshair at send time, not at queue time: the user may still
     * be nudging it while earlier items run. Null = let the model choose.
     */
    function resolveFace(it) {
        var mode = it.mode === 'render' ? 'render' : (it.videoRef ? 'direct' : null);
        if (!mode || !it.compId) { it.faceText = ''; return Promise.resolve(null); }
        return es('aesyncFaceResolve', { compId: it.compId, mode: mode, videoRef: it.videoRef || null })
            .then(function (d) {
                if (!d.face) {
                    it.faceText = 'автоматично';
                    log('[' + it.label + '] обличчя не позначене — модель обере сама');
                    return null;
                }
                var f = d.face;
                it.faceText = 'кадр ' + f.frame + ' · точка ' + f.x + ', ' + f.y;
                log('[' + it.label + '] обличчя: кадр ' + f.frame + ', точка ' + f.x + ',' + f.y +
                    ' у відео ' + f.width + '×' + f.height);
                return f;
            });
    }

    function faceStatus() {
        return es('aesyncFaceList').then(function (d) {
            var n = d.marks.length;
            $('faceRow').classList.toggle('is-set', n > 0);
            $('btnFaceClear').hidden = !n;
            $('faceState').textContent = !n ? 'автоматично — модель обере сама'
                : n === 1 ? 'позначене на ' + d.marks[0].time.toFixed(1).replace('.', ',') + ' с'
                : 'позначено облич: ' + n;
            $('faceHint').hidden = n > 0 && !state.faceJustMarked;
        }).catch(function () {});
    }

    function faceMark() {
        es('aesyncFaceMark').then(function (d) {
            state.faceJustMarked = true;
            log(d.created
                ? 'Приціл додано на ' + d.time.toFixed(2) + ' с — перетягни його на обличчя у вікні композиції.'
                : 'Приціл перенесено на кадр ' + d.time.toFixed(2) + ' с.', 's');
            $('faceHint').textContent = 'Перетягни приціл на потрібне обличчя у вікні композиції. Для сегментів — по прицілу на кожен: став індикатор часу на сегмент і натисни ще раз.';
            return faceStatus();
        }).catch(function (e) { log(e.message, 'e'); });
    }

    // ------------------------------------------------------- tabs + action
    function setTab(tab) {
        state.tab = tab;
        Array.prototype.forEach.call(document.querySelectorAll('.tab'), function (t) {
            t.setAttribute('aria-selected', t.dataset.tab === tab ? 'true' : 'false');
        });
        Array.prototype.forEach.call(document.querySelectorAll('.tab-panel'), function (p) {
            p.hidden = p.dataset.panel !== tab;
        });
        cfg.tab = tab; saveConfig();
        $('faceRow').hidden = tab === 'files';
        if (tab === 'comp') { scopePreview(); }
        else if (tab === 'segments') { labelPreview(false); }
        updateGo();
    }

    /** The action button always says what it is about to do. */
    function updateGo() {
        var go = $('btnGo'), q = $('btnQueueOnly');
        if (!go) { return; }
        var label = 'Запустити ліпсінк', can = true;
        if (state.tab === 'comp') {
            var scope = currentScope();
            if (scope === 'active') { can = !!state.autoMode; }
            else {
                can = state.scopeCount > 0;
                if (can) { label = 'Запустити ліпсінк (' + state.scopeCount + ')'; }
            }
        } else if (state.tab === 'segments') {
            can = state.segCount > 0;
            label = can ? 'Нарізати й запустити (' + state.segCount + ')' : 'Нарізати й запустити';
        } else {
            can = !!($('videoSelect').value && $('audioSelect').value);
        }
        go.textContent = label;
        go.disabled = !can;
        q.disabled = !can;
    }

    /** Active / selected comp: direct when files can go as they are, render otherwise. */
    function queueCompSmart(comp) {
        var dup = state.queue.some(function (i) { return i.compId === comp.id && i.status === 'waiting'; });
        if (dup) { log('[' + comp.name + '] вже чекає в черзі.'); return Promise.resolve(false); }
        return es('aesyncAutoSources', { compId: comp.id }).then(function (d) {
            if (d.warnings.length) { return queueRenderComp(comp); }
            qAdd(itemFromComp(d));
            log('[' + d.comp.name + '] у чергу напряму: ' + d.video.name + ' + ' + d.audio.name);
            return true;
        }).catch(function (e) {
            if (/прекомп/.test(e.message)) { return queueRenderComp(comp); }
            log(e.message, 'e');
            return false;
        });
    }

    function addFromTab() {
        if (state.tab === 'segments') { return prepare(); }
        if (state.tab === 'files') { return Promise.resolve(queueManual()); }
        var scope = currentScope();
        if (scope === 'all') { return queueAllComps(); }
        if (scope === 'selected') {
            return es('aesyncSelectedComps').then(function (d) {
                return d.comps.reduce(function (chain, c) {
                    return chain.then(function () { return queueCompSmart(c); });
                }, Promise.resolve());
            }).catch(function (e) { log(e.message, 'e'); });
        }
        return es('aesyncContext').then(function (ctx) {
            if (!ctx.comp) { log('Немає активної композиції. Відкрий комп у таймлайні.', 'e'); return false; }
            state.compName = ctx.comp.name;
            return queueCompSmart({ id: ctx.comp.id, name: ctx.comp.name });
        });
    }

    function go(start) {
        if (start && !cfg.apiKey) {
            $('keyCard').hidden = false;
            $('keyInline').focus();
            log('Спершу встав API-ключ sync.so.', 'e');
            return;
        }
        $('btnGo').disabled = true; $('btnQueueOnly').disabled = true;
        addFromTab().then(function () {
            var waiting = state.queue.some(function (i) { return i.status === 'waiting'; });
            if (start && waiting && !state.running) { startQueue(); }
        }).catch(function (e) { log(e.message, 'e'); })
          .then(updateGo);
    }

    // -------------------------------------------------------------- runner
    function busy(on) {
        state.running = on;
        $('btnCancel').hidden = !on;
        $('btnStart').hidden = on;
        ['btnClearQueue', 'btnRenderComp', 'btnRenderAudio', 'btnBrowseVideo', 'btnBrowseAudio',
         'btnRescan', 'concurrency', 'btnLabelPreview'].forEach(function (id) {
            $(id).disabled = on;
        });
        updateGo();
        qRender();
    }

    function currentOptions() {
        return {
            model: $('model').value,
            syncMode: $('syncMode').value,
            temperature: parseFloat($('temperature').value),
            activeSpeakerDetection: $('activeSpeaker').checked,
            occlusionDetection: $('occlusion').checked
        };
    }

    /** Say exactly which layer ended up in the sound file — the check that matters. */
    function logHeard(label, d) {
        if (!d || !d.heard) { return; }
        if (d.heard.length === 1) {
            log('[' + label + '] у звук пішов лише шар «' + d.heard[0] + '»');
        } else {
            log('[' + label + '] у звук потрапило шарів: ' + d.heard.length +
                (d.heard.length ? ' — ' + d.heard.join(', ') : '') + '. Перевір файл перед відправкою.', 'e');
        }
    }

    /** Prepared precomps have no source files yet — render them first. */
    function usable(p) {
        try { return !!p && fs.statSync(p).size >= 1024; } catch (e) { return false; }
    }

    function prepareSources(it) {
        if (it.mode !== 'render') { return Promise.resolve(); }
        // A repeat with the same files: the render already happened, skip it.
        if (it.reuseFiles && usable(it.videoPath) && usable(it.audioPath)) {
            qStage(it, 1, 'готові файли');
            log('[' + it.label + '] без рендера — беру файли минулого прогону: ' +
                path.basename(it.videoPath) + ' + ' + path.basename(it.audioPath));
            return Promise.resolve();
        }
        if (it.reuseFiles) {
            log('[' + it.label + '] файлів минулого рендера вже немає на диску — рендерю заново.');
        }
        var tag = asciiName(it.label);
        var stamp = it.runId;
        qStage(it, 1, 'рендер відео');
        return esRender({
            compId: it.compId,
            fileName: tag + '_video_' + stamp + '.mp4',
            dirPath: hostDir(),
            omTemplate: cfg.omVideo,
            excludeResults: true
        }).then(function (d) {
            it.videoPath = d.path;
            qStage(it, 1, 'рендер аудіо');
            return esRender({
                compId: it.compId,
                fileName: tag + '_audio_' + stamp + '.wav',
                dirPath: hostDir(),
                omTemplate: cfg.omAudio,
                forceAudio: true,
                excludeResults: true,
                soloAudio: true,
                audioRef: it.audioRef || null,
                audioLabel: cfg.audioLabel
            });
        }).then(function (d) {
            it.audioPath = d.path;
            logHeard(it.label, d);
            log('[' + it.label + '] відрендерено ' + path.basename(it.videoPath) + ' + ' + path.basename(it.audioPath));
        });
    }

    // sync.so keeps uploaded assets, so a file that hasn't changed since its
    // last upload goes by its asset id instead of being sent again.
    function assetKey(p) {
        try { var st = fs.statSync(p); return p + '|' + st.size + '|' + st.mtimeMs; } catch (e) { return ''; }
    }
    function forgetAsset(p) {
        Object.keys(state.assets).forEach(function (k) { if (k.indexOf(p + '|') === 0) { delete state.assets[k]; } });
    }
    function uploadOnce(api, it, p, kind, word) {
        var key = assetKey(p);
        if (key && state.assets[key]) {
            qStage(it, 2, word + ' вже на sync.so');
            return Promise.resolve({ assetId: state.assets[key], reused: true });
        }
        return api.uploadAsset(p, kind, function (frac) {
            qStage(it, 2, word + ' ' + Math.round(frac * 100) + '%');
        }).then(function (r) {
            if (key) { state.assets[key] = r.assetId; }
            return r;
        });
    }

    /**
     * Put a finished or failed item back in line. reuse=true keeps its
     * rendered files and sync.so uploads; false renders the comp again —
     * for when the comp itself changed. Settings and the face mark are read
     * when it runs, so whatever is set now is what it gets.
     */
    function qRepeat(it, reuse) {
        it.status = 'waiting';
        it.stage = 0;
        it.jobId = '';
        it.reuseFiles = !!reuse;
        it.repeats = (it.repeats || 0) + 1;
        it.note = reuse ? 'у черзі · повтор без рендера' : 'у черзі · з новим рендером';
        log('[' + it.label + '] ' + (reuse ? 'повтор з готовими файлами' : 'повтор із новим рендером') +
            ' — модель ' + $('model').value);
        qRender();
        if (!state.running) { startQueue(); }
    }

    /** One queue item, start to finish. Never rejects — failures land on the item. */
    function processItem(api, it) {
        var startedAt = Date.now();
        var opts = currentOptions();
        var outPath = '', outName = '', jobId = '';

        it.status = 'running';
        it.runId = runId();
        qStage(it, 1, 'перевірка');

        return prepareSources(it).then(function () {
            if (!fs.existsSync(it.videoPath) || !fs.existsSync(it.audioPath)) {
                throw new Error('Файл джерела зник з диска.');
            }
            var empty = [it.videoPath, it.audioPath].filter(function (p) {
                try { return fs.statSync(p).size < 1024; } catch (e) { return true; }
            });
            if (empty.length) {
                throw new Error('Порожній файл: ' + empty.map(function (p) { return path.basename(p); }).join(', ') +
                    '. Пропускаю, щоб не витрачати генерацію.');
            }

            log('[' + it.label + '] відео ' + path.basename(it.videoPath) + ' (' + fileSize(it.videoPath) + ')' +
                ' + аудіо ' + path.basename(it.audioPath) + ' (' + fileSize(it.audioPath) +
                (it.audioDuration ? ', ' + it.audioDuration.toFixed(1) + ' с' : '') + ')');

            return uploadOnce(api, it, it.videoPath, 'VIDEO', 'відео');
        }).then(function (v) {
            return uploadOnce(api, it, it.audioPath, 'AUDIO', 'аудіо').then(function (a) { return { v: v, a: a }; });
        }).then(function (assets) {
            qStage(it, 3, 'створення');
            opts.videoAssetId = assets.v.assetId;
            opts.audioAssetId = assets.a.assetId;
            opts.outputFileName = asciiName('lip_' + (it.compName || path.basename(it.videoPath, path.extname(it.videoPath))));
            return resolveFace(it).then(function (face) {
                opts.face = face;
                return api.createGeneration(opts).catch(function (e) {
                    // A remembered asset may have expired on sync.so's side.
                    // Upload fresh once and try again rather than fail the item.
                    if (!assets.v.reused && !assets.a.reused) { throw e; }
                    log('[' + it.label + '] збережені файли на sync.so не підійшли — вивантажую заново.');
                    forgetAsset(it.videoPath); forgetAsset(it.audioPath);
                    return uploadOnce(api, it, it.videoPath, 'VIDEO', 'відео').then(function (v2) {
                        return uploadOnce(api, it, it.audioPath, 'AUDIO', 'аудіо').then(function (a2) {
                            opts.videoAssetId = v2.assetId;
                            opts.audioAssetId = a2.assetId;
                            return api.createGeneration(opts);
                        });
                    });
                });
            });
        }).then(function (job) {
            jobId = job.id;
            it.jobId = jobId;
            log('[' + it.label + '] job ' + jobId);
            return api.waitForGeneration(jobId, {
                abort: state.abort,
                intervalMs: 5000,
                onTick: function (status, seconds) {
                    qStage(it, 3, status.toLowerCase() + ' · ' + seconds + ' с');
                }
            });
        }).then(function (job) {
            qStage(it, 4, '0%');
            return workDir().then(function (dir) {
                outName = asciiName(job.outputFileName || ('sync_' + jobId)) + '_' + it.runId + '.mp4';
                outPath = path.join(dir, outName);
                return api.download(job.outputUrl, outPath, function (frac) {
                    qStage(it, 4, Math.round(frac * 100) + '%');
                });
            });
        }).then(function () {
            qStage(it, 5, 'імпорт');
            return es('aesyncImport', {
                fileName: outName,
                dirPath: hostDir(),
                addToComp: !!it.addToComp && !it.replaceLayerIndex,
                compId: it.compId || 0,
                useActiveComp: !it.compId,
                replaceLayerIndex: it.replaceLayerIndex || 0,
                startTime: it.startTime || 0,
                muteLayers: it.muteLayers || [],
                muteResultAudio: !!it.muteResultAudio,
                replacePrevious: $('replacePrev').checked,
                jobId: jobId,
                model: opts.model,
                folderName: 'Sync Lip'
            });
        }).then(function (d) {
            it.status = 'done';
            it.stage = 5;
            it.note = Math.round((Date.now() - startedAt) / 1000) + ' с';
            it.resultName = d.name;
            log('[' + it.label + '] → "' + d.name + '" ' + (d.placed || 'у проєкті') + ', ' + it.note, 's');
            if (d.version > 1) {
                log('[' + it.label + '] прогін №' + d.version + ' для цієї композиції' +
                    (d.previous ? ', попередніх результатів знайдено: ' + d.previous : '') + '.');
            }

            if (d.missedComp) {
                it.status = 'error';
                it.note = 'композиції немає';
                log('[' + it.label + '] Композицію не знайдено — її перейменували чи видалили? ' +
                    'Файл імпортовано в бін "Sync Lip", постав шар вручну.', 'e');
            } else if (it.compId && d.compId && d.compId !== it.compId) {
                it.status = 'error';
                it.note = 'не та композиція';
                log('[' + it.label + '] Результат ліг у "' + d.compName + '" замість очікуваної. Перевір шар.', 'e');
            }
            qRender();
        }).catch(function (e) {
            it.status = state.abort.cancelled ? 'waiting' : 'error';
            it.note = state.abort.cancelled ? 'зупинено' : e.message.slice(0, 60);
            log('[' + it.label + '] ' + e.message, 'e');
            if (jobId && !state.abort.cancelled) {
                log('[' + it.label + '] id генерації ' + jobId + ' — її видно в дашборді sync.so.');
            }
            if (/429|too many/i.test(e.message)) {
                log('Схоже на ліміт паралельних генерацій твого тарифу — постав «Паралельно: 1».');
            }
            qRender();
        });
    }

    /** Simple worker pool: `concurrency` items in flight, the rest wait their turn. */
    function startQueue() {
        if (state.running) { return; }
        var api;
        try { api = client(); }
        catch (e) { log(e.message, 'e'); $('settings').hidden = false; return; }

        var pending = state.queue.filter(function (i) { return i.status === 'waiting'; });
        if (!pending.length) { log('У черзі немає нічого, що чекає.', 'e'); return; }

        state.abort = { cancelled: false };
        busy(true);
        var started = Date.now();
        var lanes = Math.min(parseInt(cfg.concurrency, 10) || 1, pending.length);
        log('Старт черги: ' + pending.length + ' шт., паралельно ' + lanes);

        // Workers take the next waiting item each time, so anything queued or
        // repeated while the queue runs is picked up in the same run.
        function next() {
            if (state.abort.cancelled) { return Promise.resolve(); }
            var it = state.queue.filter(function (i) { return i.status === 'waiting'; })[0];
            if (!it) { return Promise.resolve(); }
            it.status = 'running';
            return processItem(api, it).then(next);
        }
        var workers = [];
        for (var w = 0; w < lanes; w++) { workers.push(next()); }

        Promise.all(workers).then(function () {
            busy(false);
            var done = state.queue.filter(function (i) { return i.status === 'done'; }).length;
            var failed = state.queue.filter(function (i) { return i.status === 'error'; }).length;
            log('Черга завершена: готово ' + done + (failed ? ', з помилками ' + failed : '') +
                ' · ' + Math.round((Date.now() - started) / 1000) + ' с', failed ? '' : 's');
            refresh();
        });
    }

    // --------------------------------------------------------------- wire
    function init() {
        applyTheme();
        cs.addEventListener(CSInterface.THEME_COLOR_CHANGED_EVENT, applyTheme);

        loadConfig();
        $('apiKey').value = cfg.apiKey;
        $('workDir').value = cfg.workDir;
        $('model').value = cfg.model;
        $('syncMode').value = cfg.syncMode;
        $('temperature').value = cfg.temperature;
        $('tempVal').textContent = cfg.temperature;
        fillLabelSelect('videoLabel', cfg.videoLabel);
        fillLabelSelect('audioLabel', cfg.audioLabel);
        buildPicker('videoLabelPicker', 'videoLabel', 'videoLabelName');
        buildPicker('audioLabelPicker', 'audioLabel', 'audioLabelName');
        Array.prototype.forEach.call(document.querySelectorAll('input[name="scope"]'), function (r) {
            r.checked = r.value === (cfg.scope || 'active');
            r.addEventListener('change', function () { cfg.scope = this.value; saveConfig(); scopePreview(); });
        });
        Array.prototype.forEach.call(document.querySelectorAll('.tab'), function (t) {
            t.addEventListener('click', function () { setTab(t.dataset.tab); });
        });
        state.tab = cfg.tab || 'comp';
        $('concurrency').value = String(cfg.concurrency);
        $('cfgPath').textContent = CONFIG_FILE;
        qRender();
        markKeyState();

        $('btnSettings').addEventListener('click', function () {
            $('settings').hidden = !$('settings').hidden;
            if (!$('settings').hidden && !state.templates) { loadTemplates(false); }
        });
        $('btnCloseSettings').addEventListener('click', function () { $('settings').hidden = true; });
        $('btnKeyInline').addEventListener('click', function () {
            var key = $('keyInline').value.trim();
            if (!key) { return log('Встав ключ у поле.', 'e'); }
            cfg.apiKey = key;
            $('apiKey').value = key;
            if (saveConfig()) { markKeyState(); log('Ключ збережено.', 's'); }
        });
        $('btnReloadTpl').addEventListener('click', function (ev) {
            ev.preventDefault();
            loadTemplates(true);
        });
        $('btnSaveSettings').addEventListener('click', function () {
            cfg.apiKey = $('apiKey').value.trim();
            cfg.omVideo = $('omVideo').value;
            cfg.omAudio = $('omAudio').value;
            cfg.workDir = $('workDir').value.trim();
            if (saveConfig()) {
                markKeyState();
                $('settings').hidden = true;
                log('Налаштування збережено.', 's');
            }
        });
        $('btnCheckKey').addEventListener('click', function () {
            var key = $('apiKey').value.trim();
            if (!key) { return log('Поле ключа порожнє.', 'e'); }
            new SyncAPI.Client(key).listModels().then(function (m) {
                var names = (m.models || m || []).map(function (x) { return x.id || x.name || x; });
                log('Ключ робочий. Доступні моделі: ' + names.join(', '), 's');
            }).catch(function (e) { log('Ключ не пройшов: ' + e.message, 'e'); });
        });

        $('btnDiag').addEventListener('click', function () {
            es('aesyncWorkDir', { dirPath: hostDir() }).then(function (d) {
                log('Тека проєкту: ' + (d.projectDir || 'проєкт не збережено'));
                log('Робоча тека:  ' + d.path);
                log('Шлях лише з ASCII: ' + (d.ascii ? 'так' : 'ні — AE може не змогти туди рендерити'), d.ascii ? 's' : 'e');
                log('Node її бачить: ' + (fs.existsSync(d.path) ? 'так' : 'ні'), fs.existsSync(d.path) ? 's' : 'e');
                if (d.projectDir && !d.projectAscii) {
                    log('У теці проєкту є кирилиця, тому робоча тека винесена окремо.');
                }
                return es('aesyncEcho', { text: d.path }).then(function (r) {
                    var same = r.received === d.path;
                    log('Рядок назад в AE: ' + (same ? 'цілий' : 'зіпсований — ' + r.received), same ? 's' : 'e');
                });
            }).catch(function (e) { log(e.message, 'e'); });
        });
        $('btnRescan').addEventListener('click', function (ev) {
            ev.preventDefault();
            ev.stopPropagation();
            refresh();
        });
        $('btnBrowseVideo').addEventListener('click', function () { browse('video'); });
        $('btnBrowseAudio').addEventListener('click', function () { browse('audio'); });
        $('btnRenderComp').addEventListener('click', function () { renderComp('video'); });
        $('btnRenderAudio').addEventListener('click', function () { renderComp('audio'); });

        function meta(selId, metaId) {
            var v = $(selId).value;
            $(metaId).textContent = v ? path.basename(v) : '';
        }
        $('videoSelect').addEventListener('change', function () { meta('videoSelect', 'videoMeta'); updateGo(); });
        $('audioSelect').addEventListener('change', function () { meta('audioSelect', 'audioMeta'); updateGo(); });

        $('temperature').addEventListener('input', function () {
            $('tempVal').textContent = parseFloat(this.value).toFixed(2);
            cfg.temperature = parseFloat(this.value); saveConfig();
        });
        $('model').addEventListener('change', function () { cfg.model = this.value; saveConfig(); });
        $('syncMode').addEventListener('change', function () { cfg.syncMode = this.value; saveConfig(); });

        $('replaceLayer').addEventListener('change', function () {
            if (this.checked) { $('addToComp').checked = false; }
        });
        $('addToComp').addEventListener('change', function () {
            if (this.checked) { $('replaceLayer').checked = false; }
        });

        $('btnLabelPreview').addEventListener('click', function (ev) {
            ev.preventDefault();
            ev.stopPropagation();
            labelPreview(true);
        });
        ['videoLabel', 'audioLabel'].forEach(function (id) {
            $(id).addEventListener('change', function () {
                cfg[id] = parseInt(this.value, 10);
                saveConfig();
                syncPickers();
                labelPreview(false);
            });
        });

        $('btnFaceMark').addEventListener('click', faceMark);
        $('btnFaceClear').addEventListener('click', function () {
            es('aesyncFaceClear').then(function (d) {
                state.faceJustMarked = false;
                log('Прицілів прибрано: ' + d.removed + '. Обличчя обиратиме модель.');
                return faceStatus();
            }).catch(function (e) { log(e.message, 'e'); });
        });
        $('btnGo').addEventListener('click', function () { go(true); });
        $('btnQueueOnly').addEventListener('click', function () { go(false); });
        $('btnStart').addEventListener('click', function () {
            var noComp = state.queue.filter(function (i) {
                return i.status === 'waiting' && !i.compId;
            });
            if (noComp.length) {
                log('Без прив\'язки до композиції: ' + noComp.length +
                    ' — вони підуть в активну композицію.');
            }
            startQueue();
        });
        $('btnClearQueue').addEventListener('click', function () {
            state.queue = state.queue.filter(function (i) { return i.status === 'running'; });
            qRender();
        });
        $('concurrency').addEventListener('change', function () {
            cfg.concurrency = parseInt(this.value, 10);
            saveConfig();
        });
        $('btnCancel').addEventListener('click', function () {
            state.abort.cancelled = true;
            log('Зупиняю чергу. Те, що вже запущено на sync.so, доробиться там і буде оплачено.');
        });

        // AE tells the panel when the project or selection changed.
        try {
            cs.addEventListener('com.adobe.csxs.events.PanelActivated', refresh);
        } catch (e) {}

        es('aesyncPing').then(function (d) {
            log('After Effects ' + d.version + (d.project ? ' · ' + d.project : ' · проєкт не збережено'));
            return loadTemplates(false);
        }).then(function () {
            return refresh();
        }).then(function () {
            setTab(state.tab);
        }).catch(function (e) { log(e.message, 'e'); });
    }

    document.addEventListener('DOMContentLoaded', init);
})();
