/**
 * AE Sync Lip — ExtendScript host layer
 * Everything the panel needs from After Effects itself:
 * reading footage paths, rendering a comp, importing the synced result back.
 *
 * All functions take a JSON string and return a JSON string, so the panel
 * never has to parse loose text.
 */

// ---------------------------------------------------------------- utilities

function _esc(s) {
    s = String(s);
    var out = '';
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        var code = s.charCodeAt(i);
        if (c === '"') { out += '\\"'; }
        else if (c === '\\') { out += '\\\\'; }
        else if (c === '\n') { out += '\\n'; }
        else if (c === '\r') { out += '\\r'; }
        else if (c === '\t') { out += '\\t'; }
        else if (code < 32 || code > 126) {
            // The evalScript bridge mangles anything outside ASCII — Cyrillic
            // paths come back as "?????". Ship escapes, let JSON.parse decode.
            out += '\\u' + ('0000' + code.toString(16)).slice(-4);
        }
        else { out += c; }
    }
    return out;
}

function _ser(v) {
    if (v === null || v === undefined) { return 'null'; }
    var t = typeof v;
    if (t === 'number') { return isFinite(v) ? String(v) : 'null'; }
    if (t === 'boolean') { return v ? 'true' : 'false'; }
    if (t === 'string') { return '"' + _esc(v) + '"'; }
    if (v instanceof Array) {
        var a = [];
        for (var i = 0; i < v.length; i++) { a.push(_ser(v[i])); }
        return '[' + a.join(',') + ']';
    }
    var o = [];
    for (var k in v) {
        if (v.hasOwnProperty(k)) { o.push('"' + _esc(k) + '":' + _ser(v[k])); }
    }
    return '{' + o.join(',') + '}';
}

function _ok(data) { return _ser({ ok: true, data: data }); }
function _err(msg) { return _ser({ ok: false, error: String(msg) }); }
function _parse(s) { if (!s) { return {}; } return eval('(' + s + ')'); }

function _ext(name) {
    var i = String(name).lastIndexOf('.');
    return i < 0 ? '' : String(name).substring(i + 1).toLowerCase();
}

function _activeComp() {
    var c = app.project.activeItem;
    if (c && c instanceof CompItem) { return c; }
    return null;
}

// ------------------------------------------------------------ project scan

/**
 * Every footage item in the project that is backed by a real file on disk,
 * split into things you can lipsync (video) and things you can lipsync to (audio).
 */
function aesyncScanProject() {
    try {
        var video = [];
        var audio = [];
        var items = app.project.items;
        for (var i = 1; i <= items.length; i++) {
            var it = items[i];
            if (!(it instanceof FootageItem)) { continue; }
            var src = it.mainSource;
            if (!(src instanceof FileSource) || !src.file) { continue; }
            if (src.isStill) { continue; }

            var rec = {
                id: it.id,
                name: it.name,
                path: src.file.fsName,
                ext: _ext(it.name),
                duration: it.duration,
                width: it.width,
                height: it.height
            };
            if (it.hasVideo) { video.push(rec); }
            if (it.hasAudio) { audio.push(rec); }
        }
        return _ok({ video: video, audio: audio });
    } catch (e) { return _err(e); }
}

/** What the user currently has selected — used for "replace this layer". */
function aesyncContext() {
    try {
        var comp = _activeComp();
        var out = {
            comp: null,
            selection: [],
            projectSaved: (app.project.file !== null),
            projectDir: app.project.file ? app.project.file.parent.fsName : ''
        };
        if (!comp) { return _ok(out); }

        out.comp = {
            id: comp.id,
            name: comp.name,
            width: comp.width,
            height: comp.height,
            duration: comp.duration,
            frameRate: comp.frameRate
        };
        var sel = comp.selectedLayers;
        for (var i = 0; i < sel.length; i++) {
            var L = sel[i];
            var rec = { index: L.index, name: L.name, sourcePath: '', hasAudio: false, hasVideo: false };
            if (L instanceof AVLayer && L.source instanceof FootageItem) {
                rec.hasAudio = L.source.hasAudio;
                rec.hasVideo = L.source.hasVideo;
                if (L.source.mainSource instanceof FileSource && L.source.mainSource.file) {
                    rec.sourcePath = L.source.mainSource.file.fsName;
                }
            }
            out.selection.push(rec);
        }
        return _ok(out);
    } catch (e) { return _err(e); }
}

function _layerFile(L) {
    if (L instanceof AVLayer && L.source instanceof FootageItem &&
        L.source.mainSource instanceof FileSource && L.source.mainSource.file) {
        return L.source.mainSource.file.fsName;
    }
    return '';
}

/** True when what you hear/see on the timeline is not simply the whole source file. */
function _isEdited(L) {
    var eps = 0.0005;
    if (Math.abs(L.startTime) > eps) { return true; }
    if (L.stretch !== 100) { return true; }
    if (L.timeRemapEnabled) { return true; }
    if (L.inPoint > L.startTime + eps) { return true; }
    if (L.source && L.outPoint < L.startTime + L.source.duration - eps) { return true; }
    return false;
}

// Layers the panel created or touched carry a marker in their comment, so a
// second pass over the same comp can tell its own output from real source
// material. Without this a re-run lipsyncs the previous lipsync.
var TAG_RESULT = 'aesync:result';
var TAG_SOURCE = 'aesync:source';
var TAG_PRECOMP = 'aesync:precomp';
var TAG_FACE = 'aesync:face';

// ------------------------------------------------------------------- face
//
// Choosing a face is done the AE way: a crosshair guide layer the user drags
// onto the face in the comp viewer. Guide layers never render, so the mark
// can stay in the project. At send time the crosshair is converted into the
// pixel space and frame index of whatever file actually goes to sync.so —
// the source footage, the rendered comp, or a prepared precomp.

function _faceMarkers(comp) {
    var out = [];
    for (var i = 1; i <= comp.numLayers; i++) {
        if (_hasTag(comp.layer(i), TAG_FACE)) { out.push(comp.layer(i)); }
    }
    return out;
}

/** The comp time the mark was made on; the layer's in-point if the note is gone. */
function _faceTime(L) {
    var m = /t=([0-9.]+)/.exec(String(L.comment || ''));
    return m ? parseFloat(m[1]) : L.inPoint;
}

/**
 * Evaluate an expression on a layer at a comp time by borrowing a temporary
 * Point Control. ExtendScript has no toComp/fromComp/sourceTime of its own;
 * the expression engine does, and it handles parenting, scale, rotation,
 * stretch and time remap the same way the render will.
 */
function _evalOn(layer, expr, t) {
    var fx = layer.property('ADBE Effect Parade').addProperty('ADBE Point Control');
    var prop = fx.property(1);
    try {
        prop.expression = expr;
        if (prop.expressionError) { throw new Error(prop.expressionError); }
        return prop.valueAtTime(t, false);
    } finally {
        try { fx.remove(); } catch (e) {}
    }
}

/** The top visible video layer under the playhead: the mark lives as long as it. */
function _videoUnder(comp, t) {
    for (var i = 1; i <= comp.numLayers; i++) {
        var L = comp.layer(i);
        if (!(L instanceof AVLayer) || !L.source || !L.enabled) { continue; }
        if (_hasTag(L, TAG_FACE) || _hasTag(L, TAG_RESULT)) { continue; }
        if (!L.source.hasVideo) { continue; }
        if (L.inPoint <= t && L.outPoint > t) { return L; }
    }
    return null;
}

function _buildCrosshair(layer, d) {
    var root = layer.property('ADBE Root Vectors Group');
    function ring(size, width, color) {
        var g = root.addProperty('ADBE Vector Group');
        var v = g.property('ADBE Vectors Group');
        v.addProperty('ADBE Vector Shape - Ellipse').property('ADBE Vector Ellipse Size').setValue([size, size]);
        var r1 = v.addProperty('ADBE Vector Shape - Rect');
        r1.property('ADBE Vector Rect Size').setValue([size * 0.55, 0.1]);
        var r2 = v.addProperty('ADBE Vector Shape - Rect');
        r2.property('ADBE Vector Rect Size').setValue([0.1, size * 0.55]);
        var st = v.addProperty('ADBE Vector Graphic - Stroke');
        st.property('ADBE Vector Stroke Color').setValue(color);
        st.property('ADBE Vector Stroke Width').setValue(width);
    }
    ring(d, Math.max(6, d * 0.06), [0, 0, 0]);          // dark outline: readable on bright skin
    ring(d, Math.max(3, d * 0.03), [1, 0.82, 0.25]);    // amber, the panel's action colour
}

/** Put a crosshair on the current frame, or move an existing one to it. */
function aesyncFaceMark() {
    try {
        var comp = _activeComp();
        if (!comp) { return _err('Немає активної композиції. Відкрий комп у таймлайні.'); }
        var t = comp.time;
        app.beginUndoGroup('Sync Lip — позначити обличчя');

        // A crosshair already covering this moment is re-aimed at this frame
        // instead of stacking a second one on top of it.
        var marks = _faceMarkers(comp), L = null, created = false;
        for (var i = 0; i < marks.length; i++) {
            if (marks[i].inPoint <= t && marks[i].outPoint > t) { L = marks[i]; break; }
        }
        if (!L) {
            var under = _videoUnder(comp, t);
            L = comp.layers.addShape();
            L.name = '◎ Обличчя для ліпсінку';
            L.guideLayer = true;
            L.label = 0;
            _buildCrosshair(L, Math.round(Math.min(comp.width, comp.height) * 0.14));
            L.property('ADBE Transform Group').property('ADBE Position').setValue([comp.width / 2, comp.height / 2]);
            L.startTime = 0;
            L.inPoint = under ? under.inPoint : 0;
            L.outPoint = under ? under.outPoint : comp.duration;
            L.moveToBeginning();
            created = true;
        }
        L.comment = TAG_FACE + ' · t=' + t.toFixed(3);
        for (var j = 1; j <= comp.numLayers; j++) { comp.layer(j).selected = false; }
        L.selected = true;
        app.endUndoGroup();
        return _ok({ created: created, time: t, count: _faceMarkers(comp).length });
    } catch (e) {
        try { app.endUndoGroup(); } catch (e2) {}
        return _err(e);
    }
}

function aesyncFaceList() {
    try {
        var comp = _activeComp();
        if (!comp) { return _ok({ marks: [] }); }
        var marks = _faceMarkers(comp), out = [];
        for (var i = 0; i < marks.length; i++) { out.push({ name: marks[i].name, time: _faceTime(marks[i]) }); }
        return _ok({ marks: out, comp: comp.name });
    } catch (e) { return _err(e); }
}

function aesyncFaceClear() {
    try {
        var comp = _activeComp();
        if (!comp) { return _ok({ removed: 0 }); }
        app.beginUndoGroup('Sync Lip — прибрати позначки облич');
        var marks = _faceMarkers(comp);
        for (var i = 0; i < marks.length; i++) { marks[i].remove(); }
        app.endUndoGroup();
        return _ok({ removed: marks.length });
    } catch (e) {
        try { app.endUndoGroup(); } catch (e2) {}
        return _err(e);
    }
}

/** First crosshair whose frame falls inside [a, b). */
function _markIn(comp, a, b) {
    var marks = _faceMarkers(comp);
    for (var i = 0; i < marks.length; i++) {
        var t = _faceTime(marks[i]);
        if (t >= a - 0.0005 && t < b) { return marks[i]; }
    }
    return null;
}

function _point(v) { return [Math.round(v[0]), Math.round(v[1])]; }

/**
 * Translate the crosshair into what sync.so needs: a zero-based frame index
 * and an [x, y] pixel point in the uploaded video.
 *   direct — the source file of the video layer goes up as is
 *   render — the comp `compId` is rendered from 0; the crosshair may sit in
 *            that comp or, for a prepared precomp, in the comp that holds it
 * Returns face: null when nothing is marked — the model then picks itself.
 */
function aesyncFaceResolve(argsJson) {
    try {
        var a = _parse(argsJson);
        var comp = _findComp(a.compId);
        if (!comp) { return _ok({ face: null, reason: 'композицію не знайдено' }); }
        var m, xy, frame, w, h, t;

        app.beginUndoGroup('Sync Lip — обличчя');
        try {
            if (a.mode === 'direct') {
                var V = null, ref = a.videoRef || {};
                if (ref.index >= 1 && ref.index <= comp.numLayers && comp.layer(ref.index).name === ref.name) {
                    V = comp.layer(ref.index);
                }
                if (!V) {
                    for (var i = 1; i <= comp.numLayers; i++) {
                        if (comp.layer(i).name === ref.name) { V = comp.layer(i); break; }
                    }
                }
                if (!V || !V.source) { return _ok({ face: null, reason: 'відеошар не знайдено' }); }
                m = _markIn(comp, V.inPoint, V.outPoint);
                if (!m) { return _ok({ face: null }); }
                t = _faceTime(m);
                xy = _point(_evalOn(V, 'var f=thisComp.layer(' + m.index + ');fromComp(f.toComp(f.transform.anchorPoint))', t));
                var st = _evalOn(V, '[sourceTime(time),0]', t)[0];
                frame = Math.round(st * V.source.frameRate);
                w = V.source.width; h = V.source.height;
            } else {
                m = _markIn(comp, 0, comp.duration);
                if (m) {
                    t = _faceTime(m);
                    xy = _point(_evalOn(m, 'toComp(transform.anchorPoint)', t));
                    frame = Math.round(t * comp.frameRate);
                } else {
                    // A prepared precomp: look for the crosshair one level up.
                    var items = app.project.items, found = false;
                    for (var k = 1; k <= items.length && !found; k++) {
                        var P = items[k];
                        if (!(P instanceof CompItem) || P === comp) { continue; }
                        for (var j = 1; j <= P.numLayers && !found; j++) {
                            var O = P.layer(j);
                            if (O.source !== comp) { continue; }
                            m = _markIn(P, O.inPoint, O.outPoint);
                            if (!m) { continue; }
                            t = _faceTime(m);
                            xy = _point(_evalOn(O, 'var f=thisComp.layer(' + m.index + ');fromComp(f.toComp(f.transform.anchorPoint))', t));
                            frame = Math.round(_evalOn(O, '[sourceTime(time),0]', t)[0] * comp.frameRate);
                            found = true;
                        }
                    }
                    if (!found) { return _ok({ face: null }); }
                }
                w = comp.width; h = comp.height;
            }
        } finally {
            app.endUndoGroup();
        }

        if (xy[0] < 0 || xy[1] < 0 || xy[0] > w || xy[1] > h) {
            return _err('Приціл «' + m.name + '» стоїть поза кадром відео. Перетягни його на обличчя.');
        }
        if (frame < 0) { frame = 0; }
        return _ok({ face: { frame: frame, x: xy[0], y: xy[1], width: w, height: h, time: t } });
    } catch (e) {
        try { app.endUndoGroup(); } catch (e2) {}
        return _err(e);
    }
}

function _hasTag(L, tag) {
    return !!(L && L.comment && String(L.comment).indexOf(tag) === 0);
}

/**
 * 'video' or 'audio' for a layer the panel switched off, null otherwise.
 * The role matters: a UGC clip carries its own speech track, and treating
 * that clip as a sound source is exactly how two voices end up in one render.
 * Older untagged-role markers fall back to what the source contains.
 */
function _sourceRole(L) {
    if (!_hasTag(L, TAG_SOURCE)) { return null; }
    var c = String(L.comment);
    if (c.indexOf(TAG_SOURCE + ':audio') === 0) { return 'audio'; }
    if (c.indexOf(TAG_SOURCE + ':video') === 0) { return 'video'; }
    var src = L.source;
    return (src && src.hasVideo && !(src.mainSource && src.mainSource.isStill)) ? 'video' : 'audio';
}

/**
 * The one layer that should be heard when rendering speech for sync.so.
 * Priority: a layer already marked as the voice → the ref the queue item
 * carries → a layer with the audio label → the topmost audible layer that
 * has no picture of its own.
 */
function _speechLayer(comp, ref, audioLabel) {
    var i, L;
    for (i = 1; i <= comp.numLayers; i++) {
        L = comp.layer(i);
        if (L instanceof AVLayer && _sourceRole(L) === 'audio') { return L; }
    }
    if (ref && ref.index >= 1 && ref.index <= comp.numLayers) {
        L = comp.layer(ref.index);
        if (L instanceof AVLayer && (!ref.name || L.name === ref.name) && L.source && L.source.hasAudio) { return L; }
    }
    if (audioLabel) {
        for (i = 1; i <= comp.numLayers; i++) {
            L = comp.layer(i);
            if (L instanceof AVLayer && L.label === audioLabel && L.source && L.source.hasAudio &&
                !_hasTag(L, TAG_RESULT)) { return L; }
        }
    }
    for (i = 1; i <= comp.numLayers; i++) {
        L = comp.layer(i);
        if (!(L instanceof AVLayer) || !L.source || _hasTag(L, TAG_RESULT)) { continue; }
        if (L.source.hasAudio && !L.source.hasVideo && L.audioEnabled) { return L; }
    }
    return null;
}

/** Put back whatever _toggles_ a render temporarily changed. */
function _restoreToggles(list) {
    if (!list) { return; }
    // Backwards: a layer toggled twice gets its earliest — original — state last.
    for (var i = list.length - 1; i >= 0; i--) {
        try { list[i].layer.enabled = list[i].enabled; } catch (e1) {}
        try { list[i].layer.audioEnabled = list[i].audio; } catch (e2) {}
    }
}

/** Previous results living in this comp, newest first by layer order. */
function _resultLayers(comp) {
    var out = [];
    for (var i = 1; i <= comp.numLayers; i++) {
        if (_hasTag(comp.layer(i), TAG_RESULT)) { out.push(comp.layer(i)); }
    }
    return out;
}

function _findComp(id) {
    if (!id) { return null; }

    // itemByID is the direct route; the scan covers versions where it misbehaves.
    try {
        var direct = app.project.itemByID(id);
        if (direct && direct instanceof CompItem) { return direct; }
    } catch (e) {}

    var items = app.project.items;
    for (var i = 1; i <= items.length; i++) {
        // Loose compare on purpose: ids can arrive as strings through the bridge.
        if (items[i] instanceof CompItem && items[i].id == id) { return items[i]; }
    }
    return null;
}

/** Open a queued comp in the viewer, so "is this the right one" takes one click. */
function aesyncRevealComp(argsJson) {
    try {
        var a = _parse(argsJson);
        var comp = _findComp(a.compId);
        if (!comp) { return _err('Композицію не знайдено — можливо, її видалили з проєкту.'); }
        comp.openInViewer();
        return _ok({ name: comp.name });
    } catch (e) { return _err(e); }
}

/**
 * Find the lipsync pair inside a comp: the topmost visible layer with picture,
 * and the topmost audible layer that isn't that same layer.
 * Returns null when the comp has no usable pair.
 */
function _compSources(comp) {
    var videoL = null, audioL = null, precomp = false;
    var vFallback = null, aFallback = null, rerun = false;

    for (var i = 1; i <= comp.numLayers; i++) {
        var L = comp.layer(i);
        if (!(L instanceof AVLayer)) { continue; }

        // Our own output is never a source. Otherwise a second run would feed
        // the generated clip back into the model.
        if (_hasTag(L, TAG_RESULT)) { rerun = true; continue; }

        var src = L.source;
        if (!src) { continue; }
        if (src instanceof CompItem) { precomp = true; continue; }
        if (!(src instanceof FootageItem)) { continue; }

        var showsPicture = src.hasVideo && L.enabled && !src.mainSource.isStill;
        var makesSound = src.hasAudio && L.audioEnabled;

        // Originals are switched off after a run but keep their marker, so a
        // re-run picks exactly the same pair as the first one.
        var role = _sourceRole(L);
        if (role === 'video') { if (!vFallback) { vFallback = L; } continue; }
        if (role === 'audio') { if (!aFallback) { aFallback = L; } continue; }

        if (showsPicture && !videoL) { videoL = L; continue; }
        if (makesSound && !audioL) { audioL = L; }
    }

    if (!videoL) { videoL = vFallback; }
    if (!audioL) { audioL = aFallback; }

    if (!videoL) {
        return { error: precomp
            ? 'зверху прекомп, не футаж — потрібен рендер'
            : (rerun ? 'є лише попередній результат, вихідного відеошару немає'
                     : 'немає увімкненого шару з відеофайлом') };
    }
    if (!audioL) { return { error: 'немає окремого шару з аудіо' }; }

    var vPath = _layerFile(videoL);
    var aPath = _layerFile(audioL);
    if (!vPath) { return { error: 'відеошар "' + videoL.name + '" без файлу на диску' }; }
    if (!aPath) { return { error: 'аудіошар "' + audioL.name + '" без файлу на диску' }; }

    var warnings = [];
    if (_isEdited(audioL)) {
        warnings.push('Аудіошар "' + audioL.name + '" підрізаний або зміщений — на sync.so піде весь файл цілком.');
    }
    if (_isEdited(videoL)) {
        warnings.push('Відеошар "' + videoL.name + '" підрізаний або зміщений — на sync.so піде весь файл цілком.');
    }

    return {
        comp: { id: comp.id, name: comp.name, duration: comp.duration },
        rerun: rerun,
        video: {
            index: videoL.index, name: videoL.name, path: vPath,
            startTime: videoL.startTime, duration: videoL.source.duration
        },
        audio: {
            index: audioL.index, name: audioL.name, path: aPath,
            startTime: audioL.startTime, duration: audioL.source.duration
        },
        warnings: warnings
    };
}

/**
 * Read the two sources straight off a comp — the active one by default, or a
 * specific comp when args.compId is given (used to line up mute targets for
 * a comp that isn't open in the timeline, e.g. one picked in the Project panel).
 * args: { compId (optional) }
 */
function aesyncAutoSources(argsJson) {
    try {
        var a = argsJson ? _parse(argsJson) : {};
        var comp = a.compId ? _findComp(a.compId) : _activeComp();
        if (!comp) {
            return _err(a.compId
                ? 'Композицію не знайдено — можливо, її видалили з проєкту.'
                : 'Немає активної композиції. Відкрий комп у таймлайні.');
        }
        var r = _compSources(comp);
        if (r.error) { return _err('Композиція "' + comp.name + '": ' + r.error + '.'); }
        return _ok(r);
    } catch (e) { return _err(e); }
}

/**
 * Compositions currently selected in the Project panel — distinct from the
 * active comp and from selected *layers* inside a timeline. Backs the batch
 * "render selected comps" flow.
 */
function aesyncSelectedComps() {
    try {
        var out = [];
        var sel = app.project.selection;
        for (var i = 0; i < sel.length; i++) {
            if (sel[i] instanceof CompItem) {
                out.push({ id: sel[i].id, name: sel[i].name, duration: sel[i].duration });
            }
        }
        return _ok({ comps: out });
    } catch (e) { return _err(e); }
}

/**
 * Every comp in the project that already holds a usable video+audio pair —
 * the whole multi-geo batch in one call. Comps that don't qualify come back
 * in `skipped` with the reason, so nothing disappears silently.
 */
function aesyncScanComps() {
    try {
        var ready = [], skipped = [];
        var items = app.project.items;
        for (var i = 1; i <= items.length; i++) {
            var it = items[i];
            if (!(it instanceof CompItem)) { continue; }
            if (it.name === '__aesync_probe__') { continue; }
            var r = _compSources(it);
            if (r.error) { skipped.push({ name: it.name, reason: r.error }); }
            else { ready.push(r); }
        }
        return _ok({ ready: ready, skipped: skipped });
    } catch (e) { return _err(e); }
}

function _isAscii(s) { return /^[\x20-\x7E]*$/.test(String(s)); }

/** Build a subfolder through absoluteURI — percent-encoded, so no codepage conversion. */
function _folderFrom(base, sub) {
    var f = new Folder(base.absoluteURI + '/' + sub);
    if (!f.exists) { f.create(); }
    return f;
}

/**
 * The folder every temp file lives in.
 *
 * AE's render engine resolves output paths through the system's non-Unicode
 * codepage. On a machine whose locale can't represent the characters, a
 * perfectly good Cyrillic path arrives as "E:\??????\?????" and the render
 * dies with "Directory does not exist". So: prefer a base whose path is plain
 * ASCII (temp folder rather than the project folder, if it comes to that), and
 * build every File through absoluteURI instead of fsName.
 */
function _workFolder(dirPath) {
    var f, i;

    if (dirPath && _isAscii(dirPath)) {
        var custom = new Folder(dirPath);
        if (!custom.exists) { custom.create(); }
        if (custom.exists) { return custom; }
    }

    var bases = [];
    if (app.project.file) { bases.push(app.project.file.parent); }
    bases.push(Folder.temp);
    bases.push(Folder.userData);

    for (i = 0; i < bases.length; i++) {
        if (_isAscii(bases[i].fsName)) {
            f = _folderFrom(bases[i], '_sync_lip');
            if (f.exists) { return f; }
        }
    }
    // Everything is non-ASCII — try anyway via URI notation.
    for (i = 0; i < bases.length; i++) {
        f = _folderFrom(bases[i], '_sync_lip');
        if (f.exists) { return f; }
    }
    throw new Error('Не вдалось створити робочу теку в жодному з можливих місць.');
}

/** Diagnostic: hands a string straight back so the panel can compare round trips. */
function aesyncEcho(argsJson) {
    try {
        var a = _parse(argsJson);
        return _ok({ received: a.text, length: String(a.text).length });
    } catch (e) { return _err(e); }
}

// --------------------------------------------------------------- prepare

/**
 * Turn labelled layers into ready-to-lipsync precomps.
 *
 * In a real edit the voiceover is one long layer at the bottom and the picture
 * is a row of segments above it. sync.so needs one video and the matching
 * slice of audio, so for every layer tagged with the video label this builds a
 * precomp holding that segment plus the audio trimmed to exactly its range,
 * shifted to start at zero. The parent timeline keeps looking the same.
 *
 * args: { videoLabel, audioLabel, suffix }
 */
function aesyncPrepare(argsJson) {
    try {
        var a = _parse(argsJson);
        var videoLabel = a.videoLabel || 4;   // Pink by default
        var audioLabel = a.audioLabel || 8;   // Blue by default
        var suffix = a.suffix || ' · LIP';

        var comp = _activeComp();
        if (!comp) { return _err('Немає активної композиції.'); }

        var i, L;
        var audioRefs = [];
        var targetCount = 0;

        // Layers that already are one of our own precomps. The marker is the
        // reliable test — a rename would defeat matching on the name suffix,
        // and a renamed precomp getting precomposed again is how nested
        // "Comp 2 · LIP · LIP" layers appear.
        function isOwnPrecomp(layer) {
            if (_hasTag(layer, TAG_PRECOMP)) { return true; }
            return layer.source instanceof CompItem && String(layer.name).indexOf(suffix) !== -1;
        }

        for (i = 1; i <= comp.numLayers; i++) {
            L = comp.layer(i);
            if (!(L instanceof AVLayer) || !L.source) { continue; }
            if (isOwnPrecomp(L)) { continue; }
            if (L.label === videoLabel && L.source.hasVideo) { targetCount++; }
            else if (L.label === audioLabel && L.source.hasAudio) {
                audioRefs.push({
                    source: L.source,
                    startTime: L.startTime,
                    inPoint: L.inPoint,
                    outPoint: L.outPoint,
                    name: L.name
                });
            }
        }

        if (!targetCount) {
            return _err('Немає шарів з міткою №' + videoLabel + ' (відео). Признач її сегментам, які треба синхронізувати.');
        }
        if (!audioRefs.length) {
            return _err('Немає шару з міткою №' + audioLabel + ' (аудіо). Признач її доріжці озвучки.');
        }

        app.beginUndoGroup('Sync Lip — підготовка прекомпів');

        var made = [], skipped = [];
        // Keys of segments we've already dealt with (made or skipped), so a
        // fresh rescan below doesn't loop on the same failed layer forever.
        var doneKeys = {};
        function keyOf(layer) {
            return layer.name + '|' + layer.inPoint.toFixed(3) + '|' + layer.outPoint.toFixed(3);
        }

        // IMPORTANT: we deliberately do NOT collect all target layers into an
        // array up front and loop over that array. After precompose() runs
        // once, After Effects invalidates every other previously-fetched
        // Layer object for that comp — touching one throws "ReferenceError:
        // Object is invalid" (that was the actual bug: this used to throw
        // *before* the segment's own try/catch even started, which killed
        // the whole batch after the first layer and left it as one
        // uncropped, audio-less precomp). So instead: rescan the comp fresh
        // immediately before handling each single segment, and never hold a
        // Layer reference across the precompose() call below.
        var guard = targetCount + audioRefs.length + 4; // hard cap, just in case
        while (guard-- > 0) {
            var V = null;
            for (i = 1; i <= comp.numLayers; i++) {
                L = comp.layer(i);
                if (!(L instanceof AVLayer) || !L.source) { continue; }
                if (isOwnPrecomp(L)) { continue; }
                if (L.label === videoLabel && L.source.hasVideo && !doneKeys[keyOf(L)]) { V = L; break; }
            }
            if (!V) { break; } // nothing left to process

            var t0 = V.inPoint, t1 = V.outPoint;
            var vName = V.name;
            var vIndex = V.index;
            var vSource = V.source;
            var segName = vName.replace(/\.[a-z0-9]+$/i, '') + suffix;
            var vKey = keyOf(V);
            doneKeys[vKey] = true; // mark up front so a caught failure below can't loop forever
            // From here on, never touch V again: the moment precompose() below
            // consumes it, V itself becomes an invalid object (that's the layer
            // being removed/replaced), and re-reading e.g. V.source or V.name
            // throws "ReferenceError: Object is invalid" — which is what used
            // to abort the whole batch after the very first segment. Everything
            // needed from V is captured into plain variables above instead.

            // Everything for this one segment lives in its own try/catch: a
            // problem with one layer (a sliver of overlap, a stray zero-length
            // trim, whatever) must not abort the layers still waiting in line.
            try {
                // Which audio layer actually covers this segment?
                var ref = null;
                for (var r = 0; r < audioRefs.length; r++) {
                    if (audioRefs[r].inPoint < t1 - 0.001 && audioRefs[r].outPoint > t0 + 0.001) { ref = audioRefs[r]; break; }
                }
                if (!ref) {
                    skipped.push({ name: vName, reason: 'озвучка не перекриває цей сегмент' });
                    continue;
                }

                // The overlap check above only confirms *some* overlap; the
                // actual intersection can still come out at (or past) zero
                // width for a sliver right at the segment's edge. Catch that
                // here, in plain math, instead of letting AE throw later when
                // outPoint ends up <= inPoint.
                var aIn = Math.max(t0, ref.inPoint);
                var aOut = Math.min(t1, ref.outPoint);
                if (aOut - aIn < 1 / comp.frameRate) {
                    skipped.push({ name: vName, reason: 'озвучка перекриває сегмент менше ніж на кадр' });
                    continue;
                }

                // Move attributes inside: only then does the layer keep its own
                // trim and timing within the new comp, which is what the retiming
                // below relies on. With "leave all attributes" AE builds a comp the
                // length of the whole source instead, and the segment loses its place.
                var newComp = comp.layers.precompose([vIndex], segName, true);
                if (!newComp) { throw new Error('AE не створив нову композицію (precompose)'); }

                var innerV = null;
                for (i = 1; i <= newComp.numLayers; i++) {
                    if (newComp.layer(i).source === vSource) { innerV = newComp.layer(i); break; }
                }
                if (!innerV) { innerV = newComp.layer(1); }

                var shift = innerV.inPoint;
                var segDuration = innerV.outPoint - innerV.inPoint;
                if (segDuration < 1 / comp.frameRate) { throw new Error('нульова тривалість сегмента'); }

                // The audio slice, placed on the parent's time base — precompose
                // preserves it, so the original numbers still line up.
                var innerA = newComp.layers.add(ref.source);
                innerA.startTime = ref.startTime;
                innerA.inPoint = aIn;
                innerA.outPoint = aOut;
                innerA.moveToEnd();

                // Slide the whole thing to zero, then crop the comp to the segment.
                for (i = 1; i <= newComp.numLayers; i++) {
                    newComp.layer(i).startTime = newComp.layer(i).startTime - shift;
                }
                newComp.duration = segDuration;

                // The precomp now runs 0..segDuration internally, so putting the
                // layer at t0 restores the segment to exactly where it was.
                var outer = null;
                for (i = 1; i <= comp.numLayers; i++) {
                    if (comp.layer(i).source === newComp) { outer = comp.layer(i); break; }
                }
                var landedAt = null;
                if (outer) {
                    outer.startTime = t0;
                    try { outer.inPoint = t0; } catch (e1) {}
                    try { outer.outPoint = t1; } catch (e2) {}
                    outer.label = videoLabel;
                    if (!_hasTag(outer, TAG_PRECOMP)) {
                        try { outer.comment = TAG_PRECOMP + (outer.comment ? ' · ' + outer.comment : ''); } catch (eTag) {}
                    }
                    landedAt = { start: outer.inPoint, end: outer.outPoint, index: outer.index };
                }

                made.push({
                    id: newComp.id,
                    name: newComp.name,
                    duration: newComp.duration,
                    videoLayer: { index: innerV.index, name: innerV.name },
                    audioLayer: { index: innerA.index, name: innerA.name },
                    videoPath: _layerFile(innerV),
                    audioPath: _layerFile(innerA),
                    segment: { start: t0, end: t1 },
                    landed: landedAt,
                    // A frame of slack: if the precomp didn't land back on the
                    // segment, the panel should say so rather than let it slide.
                    inPlace: landedAt ? (Math.abs(landedAt.start - t0) < 0.05 &&
                                         Math.abs(landedAt.end - t1) < 0.05) : false
                });
            } catch (segErr) {
                skipped.push({ name: vName, reason: String(segErr) });
            }
        }

        app.endUndoGroup();
        return _ok({ made: made, skipped: skipped, compName: comp.name });
    } catch (e) {
        try { app.endUndoGroup(); } catch (e3) {}
        return _err(e);
    }
}

/** What the prepare tool would act on right now — shown before anything changes. */
function aesyncLabelPreview(argsJson) {
    try {
        var a = _parse(argsJson);
        var comp = _activeComp();
        if (!comp) { return _err('Немає активної композиції.'); }
        var video = [], audio = [];
        for (var i = 1; i <= comp.numLayers; i++) {
            var L = comp.layer(i);
            if (!(L instanceof AVLayer) || !L.source) { continue; }
            if (L.label === (a.videoLabel || 4) && L.source.hasVideo) {
                video.push({ index: L.index, name: L.name, start: L.inPoint, end: L.outPoint });
            } else if (L.label === (a.audioLabel || 8) && L.source.hasAudio) {
                audio.push({ index: L.index, name: L.name, start: L.inPoint, end: L.outPoint });
            }
        }
        return _ok({ compName: comp.name, video: video, audio: audio });
    } catch (e) { return _err(e); }
}

/** Output module templates available in this AE install, so the UI can offer real names. */
function aesyncTemplates() {
    try {
        var comp = _activeComp();
        var temp = null;
        var created = false;
        app.beginUndoGroup('Sync Lip — read templates');
        if (!comp) {
            temp = app.project.items.addComp('__aesync_probe__', 16, 16, 1, 1, 25);
            comp = temp; created = true;
        }
        var rq = app.project.renderQueue;
        var item = rq.items.add(comp);
        var om = item.outputModule(1);
        var names = om.templates;
        var rsNames = item.templates;
        item.remove();
        if (created) { temp.remove(); }
        app.endUndoGroup();
        var list = [];
        for (var i = 0; i < names.length; i++) { list.push(names[i]); }
        var rlist = [];
        for (var j = 0; j < rsNames.length; j++) { rlist.push(rsNames[j]); }
        return _ok({ outputModules: list, renderSettings: rlist });
    } catch (e) {
        try { app.endUndoGroup(); } catch (e2) {}
        return _err(e);
    }
}

// ---------------------------------------------------------------- rendering

/**
 * Render the active comp (or a comp by id) through the render queue.
 * args: { compId, fileName (ASCII), dirPath (optional, ASCII), omTemplate, rsTemplate }
 * Other queued items are parked and restored afterwards.
 */
function aesyncRenderComp(argsJson) {
    var toggled = [];
    try {
        var a = _parse(argsJson);
        var comp = null;
        if (a.compId) {
            var items = app.project.items;
            for (var i = 1; i <= items.length; i++) {
                if (items[i].id === a.compId && items[i] instanceof CompItem) { comp = items[i]; break; }
            }
        }
        if (!comp) { comp = _activeComp(); }
        if (!comp) { return _err('No composition is active. Open a comp or pick footage instead.'); }

        // On a re-run the comp still holds the previous result on top, opaque.
        // Rendering it as-is would send the old lipsync back for another pass,
        // so the comp is put back into its pre-run state for the duration of
        // the render and restored afterwards.
        var x, LX;
        if (a.excludeResults) {
            for (x = 1; x <= comp.numLayers; x++) {
                LX = comp.layer(x);
                if (!(LX instanceof AVLayer)) { continue; }
                if (_hasTag(LX, TAG_RESULT)) {
                    toggled.push({ layer: LX, enabled: LX.enabled, audio: LX.audioEnabled });
                    try { LX.enabled = false; } catch (eX1) {}
                    try { LX.audioEnabled = false; } catch (eX2) {}
                } else if (_sourceRole(LX) === 'video') {
                    // Picture only. Its sound is the original-language speech
                    // and must stay out — sound is decided by the solo below.
                    toggled.push({ layer: LX, enabled: LX.enabled, audio: LX.audioEnabled });
                    try { LX.enabled = true; } catch (eX3) {}
                }
            }
        }

        // For a sound render exactly one layer is audible: the voice. Music,
        // the clip's own speech, the previous result — all off for the
        // duration, all restored afterwards. Two voices in one file can't
        // happen by construction.
        var heard = [];
        var speechName = '';
        if (a.soloAudio) {
            var speech = _speechLayer(comp, a.audioRef, a.audioLabel);
            if (!speech) {
                _restoreToggles(toggled);
                return _err('Не знайшов шар з озвучкою для рендера звуку. Познач його міткою аудіо.');
            }
            speechName = speech.name;
            for (x = 1; x <= comp.numLayers; x++) {
                LX = comp.layer(x);
                if (!(LX instanceof AVLayer) || !LX.hasAudio) { continue; }
                var want = (LX === speech);
                if (LX.audioEnabled !== want) {
                    toggled.push({ layer: LX, enabled: LX.enabled, audio: LX.audioEnabled });
                    try { LX.audioEnabled = want; } catch (eS) {}
                }
            }
            for (x = 1; x <= comp.numLayers; x++) {
                LX = comp.layer(x);
                if (LX instanceof AVLayer && LX.hasAudio && LX.audioEnabled) { heard.push(LX.name); }
            }
        }

        var rq = app.project.renderQueue;
        var parked = [];
        for (var k = 1; k <= rq.numItems; k++) {
            var q = rq.item(k);
            if (q.status === RQItemStatus.QUEUED) { parked.push(q); q.render = false; }
        }

        var item = rq.items.add(comp);
        if (a.rsTemplate) { try { item.applyTemplate(a.rsTemplate); } catch (e1) {} }
        // Whole comp, not the work area: the result is laid back from 0 and
        // a face mark's frame number counts from 0 too.
        try { item.timeSpanStart = 0; item.timeSpanDuration = comp.duration; } catch (eSpan) {}
        var om = item.outputModule(1);
        if (a.omTemplate) {
            try { om.applyTemplate(a.omTemplate); }
            catch (e2) {
                item.remove();
                for (var r0 = 0; r0 < parked.length; r0++) { parked[r0].render = true; }
                _restoreToggles(toggled);
                return _err('Шаблон Output Module не знайдено: ' + a.omTemplate);
            }
        }
        // An audio-only template still writes silence if the module has audio
        // switched off, and a 0-byte file is worse than a failed render.
        if (a.forceAudio) {
            try { om.setSettings({ 'Output Audio': 'On' }); } catch (e5) {}
            try { om.setSettings({ 'Audio Output': 'On' }); } catch (e6) {}
        }
        var folder = _workFolder(a.dirPath);
        var fileName = a.fileName || ('src_' + (new Date()).getTime() + '.mp4');
        var outFile = new File(folder.absoluteURI + '/' + fileName);
        if (outFile.exists) { outFile.remove(); }
        om.file = outFile;
        item.render = true;

        rq.render();

        var status = item.status;
        var written = om.file ? om.file.fsName : outFile.fsName;
        item.remove();
        for (var r = 0; r < parked.length; r++) { parked[r].render = true; }
        _restoreToggles(toggled);

        if (status !== RQItemStatus.DONE) { return _err('Рендер не завершився (статус ' + status + ').'); }

        // AE may append a frame number or change the extension via the template.
        var f = new File(written);
        if (!f.exists) {
            if (outFile.exists) { written = outFile.fsName; f = outFile; }
            else { return _err('Рендер пройшов, але файлу немає: ' + written); }
        }
        if (f.length === 0) {
            return _err('Рендер видав порожній файл (0 байт). У шаблоні "' + (a.omTemplate || '') +
                '" вимкнено Audio Output, або в композиції немає звуку на час рендера.');
        }
        return _ok({
            path: written,
            fileName: f.name,
            dir: folder.fsName,
            size: f.length,
            compId: comp.id,
            compName: comp.name,
            duration: comp.duration,
            frameRate: comp.frameRate,
            speech: speechName,
            heard: heard
        });
    } catch (e) {
        // Never leave the comp in the half-toggled state a failed render made.
        try { _restoreToggles(toggled); } catch (e2) {}
        return _err(e);
    }
}

// ------------------------------------------------------------------ import

/**
 * Bring the synced file back in.
 * args: { fileName (ASCII), dirPath (optional), addToComp, compId,
 *         replaceLayerIndex, startTime, muteLayers:[{index,name}],
 *         replacePrevious, muteResultAudio, jobId, model, folderName }
 */
function aesyncImport(argsJson) {
    try {
        var a = _parse(argsJson);
        var file = a.fileName
            ? new File(_workFolder(a.dirPath).absoluteURI + '/' + a.fileName)
            : new File(a.path);
        if (!file.exists) { return _err('Файл не знайдено: ' + file.fsName); }

        app.beginUndoGroup('Sync Lip — import result');

        var io = new ImportOptions(file);
        var footage = app.project.importFile(io);

        // A queue item names its own comp. If that comp is gone, the result stays
        // in the project rather than quietly landing in whatever is open — putting
        // a German lipsync into the Italian comp is worse than not placing it.
        var comp = null;
        var missedComp = false;
        if (a.compId) {
            comp = _findComp(a.compId);
            if (!comp) { missedComp = true; }
        } else if (a.useActiveComp) {
            comp = _activeComp();
        }

        // How many times this comp has been through the panel already. Names
        // that repeat are what makes a second run collide with the first.
        var previous = comp ? _resultLayers(comp) : [];
        var version = previous.length + 1;

        // Naming happens here, not in the panel: comp names are often Cyrillic
        // and would be mangled crossing the bridge.
        if (comp) {
            footage.name = 'LIP · ' + comp.name + (version > 1 ? ' · v' + version : '');
        }

        if (a.folderName) {
            var folder = null;
            for (var i = 1; i <= app.project.items.length; i++) {
                var it = app.project.items[i];
                if (it instanceof FolderItem && it.name === a.folderName) { folder = it; break; }
            }
            if (!folder) { folder = app.project.items.addFolder(a.folderName); }
            footage.parentFolder = folder;
        }

        var placed = 'файл у проєкті, без розміщення';
        if (comp && a.replaceLayerIndex) {
            var target = comp.layer(a.replaceLayerIndex);
            if (target && target instanceof AVLayer) {
                target.replaceSource(footage, false);
                placed = 'замінено шар "' + target.name + '"';
            }
        } else if (comp && a.addToComp) {
            // Grab the layers to switch off *before* adding, because inserting
            // a layer at the top shifts every index below it. Names are checked
            // too: a queued item may have been built before the comp changed.
            var toMute = [];
            var stale = 0;
            if (a.muteLayers && a.muteLayers.length) {
                for (var m = 0; m < a.muteLayers.length; m++) {
                    var ref = a.muteLayers[m];
                    if (ref.index >= 1 && ref.index <= comp.numLayers) {
                        var cand = comp.layer(ref.index);
                        if (!ref.name || cand.name === ref.name) {
                            // Position in the list is the role when not given:
                            // the queue always sends [video, audio].
                            toMute.push({ layer: cand, role: ref.role || (m === 0 ? 'video' : 'audio') });
                        }
                        else { stale++; }
                    } else { stale++; }
                }
            }

            // Old results go first — resolved above, so removing them here
            // can't shift the indices the mute refs were built from.
            var cleared = 0;
            for (var p = 0; p < previous.length; p++) {
                if (a.replacePrevious) {
                    try { previous[p].remove(); cleared++; } catch (e8) {}
                } else {
                    try { previous[p].enabled = false; } catch (e9) {}
                    try { previous[p].audioEnabled = false; } catch (e10) {}
                }
            }

            var newLayer = comp.layers.add(footage);
            newLayer.moveToBeginning();
            if (a.startTime) { newLayer.startTime = a.startTime; }
            // Inside a prepared precomp the parent timeline already plays the
            // full voiceover, so the result contributes picture only.
            if (a.muteResultAudio) { try { newLayer.audioEnabled = false; } catch (e7) {} }
            // The marker is what makes the next run recognisable; the job id
            // keeps it traceable to the exact generation months later.
            newLayer.comment = TAG_RESULT + ' · v' + version +
                (a.jobId ? ' · ' + a.jobId : '') + (a.model ? ' · ' + a.model : '');

            var muted = 0;
            for (var n = 0; n < toMute.length; n++) {
                var L2 = toMute[n].layer;
                if (L2 instanceof AVLayer) {
                    try { L2.enabled = false; } catch (e3) {}
                    try { L2.audioEnabled = false; } catch (e4) {}
                    // Tagged with its role so a re-run finds the originals
                    // again and knows the clip is picture, the VO is sound.
                    var tag = TAG_SOURCE + ':' + toMute[n].role;
                    var rest = String(L2.comment || '');
                    if (rest.indexOf(TAG_SOURCE) === 0) {
                        // Replace an older marker rather than stacking them.
                        var cut = rest.indexOf(' · ');
                        rest = cut === -1 ? '' : rest.substring(cut + 3);
                    }
                    try { L2.comment = tag + (rest ? ' · ' + rest : ''); } catch (e11) {}
                    muted++;
                }
            }
            placed = 'шаром у "' + comp.name + '"' + (version > 1 ? ' (v' + version + ')' : '')
                + (cleared ? ', попередніх видалено: ' + cleared : '')
                + (muted ? ', вихідних вимкнено: ' + muted : '')
                + (stale ? ', пропущено змінених шарів: ' + stale : '');
        }

        if (missedComp) {
            placed = 'композицію не знайдено (id ' + a.compId + ') — файл лежить у проєкті';
        }

        app.endUndoGroup();
        return _ok({
            name: footage.name,
            id: footage.id,
            compId: comp ? comp.id : 0,
            compName: comp ? comp.name : '',
            version: version,
            previous: previous.length,
            missedComp: missedComp,
            placed: placed
        });
    } catch (e) {
        try { app.endUndoGroup(); } catch (e2) {}
        return _err(e);
    }
}

/** Where temp renders go: next to the project if saved, otherwise the system temp folder. */
function aesyncWorkDir(argsJson) {
    try {
        var a = argsJson ? _parse(argsJson) : {};
        var f = _workFolder(a.dirPath);
        var projectDir = app.project.file ? app.project.file.parent.fsName : '';
        return _ok({
            path: f.fsName,
            uri: f.absoluteURI,
            ascii: _isAscii(f.fsName),
            projectDir: projectDir,
            projectAscii: projectDir ? _isAscii(projectDir) : true,
            nextToProject: projectDir ? (f.fsName.indexOf(projectDir) === 0) : false
        });
    } catch (e) { return _err(e); }
}

function aesyncPing() { return _ok({ version: app.version, project: app.project.file ? app.project.file.name : '' }); }
