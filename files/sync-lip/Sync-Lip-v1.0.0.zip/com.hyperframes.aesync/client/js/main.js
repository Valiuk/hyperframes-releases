/* Sync Lip — panel controller. Talks to After Effects through evalScript
   and to sync.so through SyncAPI (Node context). */
(function () {
    'use strict';

    var nodeRequire = window.cep_node ? window.cep_node.require : window.require;
    var fs = nodeRequire('fs');
    var os = nodeRequire('os');
    var path = nodeRequire('path');

    var cs = new CSInterface();
    var CONFIG_DIR = path.join(os.homedir(), '.aesync-lip');
    var CONFIG_FILE = path.join(CONFIG_DIR, 'config.json');

    var DEFAULTS = {
        apiKey: '',
        omVideo: 'H.264 - Match Render Settings - 15 Mbps',
        omAudio: 'WAV',
        workDir: '',
        model: 'lipsync-2',
        syncMode: 'cut_off',
        temperature: 0.5,
        concurrency: 2,
        videoLabel: 4,
        audioLabel: 8
    };

    var cfg = Object.assign({}, DEFAULTS);
    var state = {
        videoPath: '',
        audioPath: '',
        selection: [],
        auto: null,
        templates: null,
        compId: null,
        running: false,
        dirAnnounced: false,
        queue: [],
        seq: 0,
        compName: '',
        lastRender: null,
        labels: {},
        abort: { cancelled: false }
    };

    var $ = function (id) { return document.getElementById(id); };

    // ------------------------------------------------------------- theme
    function toHex(c) {
        function p(n) { n = Math.max(0, Math.min(255, Math.round(n))); return ('0' + n.toString(16)).slice(-2); }
        return '#' + p(c.red) + p(c.green) + p(c.blue);
    }
    function shift(c, amount) {
        return { red: c.red + amount, green: c.green + amount, blue: c.blue + amount };
    }
    function applyTheme() {
        try {
            var skin = cs.getHostEnvironment().appSkinInfo;
            var base = skin.panelBackgroundColor.color;
            var light = base.red > 127;
            var r = document.documentElement.style;
            r.setProperty('--bg', toHex(base));
            r.setProperty('--bg-sunk', toHex(shift(base, light ? -14 : -8)));
            r.setProperty('--bg-raise', toHex(shift(base, light ? 10 : 14)));
            r.setProperty('--line', toHex(shift(base, light ? -34 : 26)));
            r.setProperty('--text', light ? '#20242a' : '#d6d9dc');
            r.setProperty('--text-dim', light ? '#5e666e' : '#8b9299');
            r.setProperty('--accent', light ? '#a86a10' : '#e0a13c');
        } catch (e) { /* keep the stylesheet defaults */ }
    }

    // --------------------------------------------------------------- log
    function log(msg, cls) {
        var el = $('log');
        var stamp = new Date().toTimeString().slice(0, 8);
        var span = document.createElement('span');
        span.className = cls || '';
        span.textContent = stamp + '  ' + msg + '\n';
        el.appendChild(span);
        el.scrollTop = el.scrollHeight;
    }

    // ------------------------------------------------------------- queue UI
    var STAGES = ['підготовка', 'вивантаження', 'генерація', 'завантаження', 'імпорт'];

    function qAdd(item) {
        item.id = 'q' + (++state.seq);
        item.status = 'waiting';
        item.stage = 0;
        item.note = 'у черзі';
        state.queue.push(item);
        qRender();
        return item;
    }

    function qRemove(id) {
        state.queue = state.queue.filter(function (i) { return i.id !== id || i.status === 'running'; });
        qRender();
    }

    function qRender() {
        var list = $('queueList');
        list.innerHTML = '';

        // Same VO reused across two comps is nearly always a mistake when
        // localising — flag it before a paid generation, not after.
        var audioCount = {};
        state.queue.forEach(function (i) {
            if (i.audioPath) { audioCount[i.audioPath] = (audioCount[i.audioPath] || 0) + 1; }
        });

        state.queue.forEach(function (it) {
            var li = document.createElement('li');
            li.className = 'q-item ' + it.status;

            var head = document.createElement('div');
            head.className = 'q-head';

            var name = document.createElement('button');
            name.className = 'q-name';
            name.textContent = it.label;
            if (it.compId) {
                name.title = 'Відкрити цю композицію в AE';
                name.addEventListener('click', function () {
                    es('aesyncRevealComp', { compId: it.compId }).then(function (r) {
                        log('Відкрито: ' + r.name);
                    }).catch(function (e) { log(e.message, 'e'); });
                });
            } else {
                name.disabled = true;
                name.title = 'Пара файлів, без композиції';
            }
            head.appendChild(name);

            var drop = document.createElement('button');
            drop.className = 'q-drop';
            drop.textContent = '×';
            drop.title = 'Прибрати з черги';
            drop.disabled = it.status === 'running';
            drop.addEventListener('click', function () { qRemove(it.id); });
            head.appendChild(drop);
            li.appendChild(head);

            var src = document.createElement('div');
            src.className = 'q-src';
            src.appendChild(srcLine('відео',
                it.videoName || state.labels[it.videoPath] || (it.videoPath ? path.basename(it.videoPath) : '—'),
                it.videoPath || '',
                it.videoPath ? fileSize(it.videoPath) : 'рендер при старті черги'));
            src.appendChild(srcLine('аудіо',
                it.audioName || state.labels[it.audioPath] || (it.audioPath ? path.basename(it.audioPath) : '—'),
                it.audioPath || '',
                it.audioPath
                    ? ((it.audioDuration ? it.audioDuration.toFixed(1) + ' с · ' : '') + fileSize(it.audioPath))
                    : ((it.audioDuration ? it.audioDuration.toFixed(1) + ' с · ' : '') + 'рендер при старті черги')));
            li.appendChild(src);

            if (it.mode === 'render') {
                var tag = document.createElement('div');
                tag.className = 'q-flag q-flag-quiet';
                tag.textContent = it.renderNote || 'рендериться перед відправкою';
                li.appendChild(tag);
            }

            if (audioCount[it.audioPath] > 1) {
                var dup = document.createElement('div');
                dup.className = 'q-flag';
                dup.textContent = '! ця сама озвучка ще в ' + (audioCount[it.audioPath] - 1) + ' елемент(ах) черги';
                li.appendChild(dup);
            }

            var foot = document.createElement('div');
            foot.className = 'q-foot';

            var dots = document.createElement('span');
            dots.className = 'q-dots';
            for (var s = 1; s <= STAGES.length; s++) {
                var d = document.createElement('span');
                d.title = STAGES[s - 1];
                if (it.status === 'error' && s === it.stage) { d.className = 'fail'; }
                else if (s < it.stage || it.status === 'done') { d.className = 'done'; }
                else if (s === it.stage && it.status === 'running') { d.className = 'active'; }
                dots.appendChild(d);
            }
            foot.appendChild(dots);

            var note = document.createElement('span');
            note.className = 'q-note';
            note.textContent = it.note;
            note.title = it.jobId ? 'job ' + it.jobId : it.note;
            foot.appendChild(note);
            li.appendChild(foot);

            list.appendChild(li);
        });

        var waiting = state.queue.filter(function (i) { return i.status === 'waiting'; }).length;
        var done = state.queue.filter(function (i) { return i.status === 'done'; }).length;
        var failed = state.queue.filter(function (i) { return i.status === 'error'; }).length;
        $('qCount').textContent = state.queue.length
            ? (state.queue.length + ' · чекає ' + waiting + ' · готово ' + done + (failed ? ' · помилок ' + failed : ''))
            : 'порожня';
        $('btnStart').disabled = state.running || !waiting;
    }

    function fileSize(p) {
        try { return (fs.statSync(p).size / 1048576).toFixed(1) + ' МБ'; }
        catch (e) { return 'файлу немає'; }
    }

    function srcLine(kind, name, fullPath, meta) {
        var row = document.createElement('div');
        row.title = fullPath;
        var k = document.createElement('em');
        k.textContent = kind;
        row.appendChild(k);
        row.appendChild(document.createTextNode(' ' + name + ' · ' + meta));
        return row;
    }

    function qStage(it, stage, note) {
        it.stage = stage;
        it.note = note || STAGES[stage - 1] || '';
        qRender();
    }

    // ---------------------------------------------------------- extendscript
    function esEscape(s) {
        return s
            .replace(/\\/g, '\\\\')
            .replace(/"/g, '\\"')
            .replace(/\r?\n/g, '\\n')
            // Same story in this direction: the bridge only survives ASCII, so
            // Cyrillic project paths go across as \uXXXX literals.
            .replace(/[\u007f-\uffff]/g, function (c) {
                return '\\u' + ('0000' + c.charCodeAt(0).toString(16)).slice(-4);
            });
    }
    function es(fn, arg) {
        return new Promise(function (resolve, reject) {
            var call = (arg === undefined)
                ? fn + '()'
                : fn + '("' + esEscape(JSON.stringify(arg)) + '")';
            cs.evalScript(call, function (res) {
                if (!res || res === 'EvalScript error.') {
                    return reject(new Error('ExtendScript помилка у ' + fn + '. Дивись CEP-консоль на порту 8099.'));
                }
                var parsed;
                try { parsed = JSON.parse(res); }
                catch (e) { return reject(new Error(fn + ' повернув не-JSON: ' + res.slice(0, 200))); }
                if (!parsed.ok) { return reject(new Error(parsed.error)); }
                resolve(parsed.data);
            });
        });
    }

    // -------------------------------------------------------------- config
    function loadConfig() {
        try {
            if (fs.existsSync(CONFIG_FILE)) {
                cfg = Object.assign({}, DEFAULTS, JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')));
            }
        } catch (e) { log('Не вдалось прочитати конфіг: ' + e.message, 'e'); }
    }
    function saveConfig() {
        try {
            if (!fs.existsSync(CONFIG_DIR)) { fs.mkdirSync(CONFIG_DIR, { recursive: true }); }
            fs.writeFileSync(CONFIG_FILE, JSON.stringify(cfg, null, 2), { mode: 0o600 });
            return true;
        } catch (e) { log('Не вдалось зберегти конфіг: ' + e.message, 'e'); return false; }
    }
    function client() {
        if (!cfg.apiKey) { throw new Error('Спочатку впиши API-ключ у налаштуваннях.'); }
        return new SyncAPI.Client(cfg.apiKey);
    }
    function markKeyState() {
        var pill = $('keyState');
        pill.textContent = cfg.apiKey ? 'ключ збережено' : 'без ключа';
        pill.className = 'pill ' + (cfg.apiKey ? 'pill-ok' : 'pill-warn');
    }

    // -------------------------------------------------------------- sources
    function fillSelect(select, items, extraLabel) {
        select.innerHTML = '';
        var none = document.createElement('option');
        none.value = '';
        none.textContent = items.length ? '— обери ' + extraLabel + ' —' : 'у проєкті немає ' + extraLabel;
        select.appendChild(none);
        items.forEach(function (it) {
            var opt = document.createElement('option');
            opt.value = it.path;
            opt.textContent = it.name + '  (' + it.duration.toFixed(2) + ' с)';
            select.appendChild(opt);
        });
    }

    function addExternal(select, filePath, label) {
        var existing = select.querySelector('option[value="' + filePath.replace(/"/g, '\\"') + '"]');
        if (!existing) {
            var opt = document.createElement('option');
            opt.value = filePath;
            opt.textContent = label || (path.basename(filePath) + '  (з диска)');
            select.appendChild(opt);
        } else if (label) {
            existing.textContent = label;
        }
        state.labels[filePath] = label || path.basename(filePath);
        select.value = filePath;
        select.dispatchEvent(new Event('change'));
    }

    function refresh() {
        return es('aesyncScanProject').then(function (d) {
            var keepV = $('videoSelect').value, keepA = $('audioSelect').value;
            fillSelect($('videoSelect'), d.video, 'відео');
            fillSelect($('audioSelect'), d.audio, 'аудіо');
            if (keepV) { addExternal($('videoSelect'), keepV, state.labels[keepV]); }
            if (keepA) { addExternal($('audioSelect'), keepA, state.labels[keepA]); }
        }).then(function () {
            return es('aesyncContext');
        }).then(function (ctx) {
            state.selection = ctx.selection || [];
            state.compId = ctx.comp ? ctx.comp.id : null;
            state.compName = ctx.comp ? ctx.comp.name : '';
            $('selMeta').textContent = state.selection.length
                ? '→ ' + state.selection[0].name
                : '(нічого не виділено)';
            if (!state.selection.length) { $('replaceLayer').checked = false; }
            return detect();
        }).then(function () {
            return labelPreview(false);
        }).catch(function (e) { log(e.message, 'e'); });
    }

    // ------------------------------------------------- active comp, one click
    function detect() {
        return es('aesyncAutoSources').then(function (d) {
            state.auto = d;
            state.compId = d.comp.id;
            var box = $('autoMeta');
            box.className = 'auto-meta';
            box.innerHTML = '';
            var line = function (text, cls) {
                var el = document.createElement('div');
                if (cls) { el.className = cls; }
                el.textContent = text;
                box.appendChild(el);
            };
            line('комп · ' + d.comp.name);
            line('відео · ' + d.video.name + '  [шар ' + d.video.index + ']');
            line('аудіо · ' + d.audio.name + '  [шар ' + d.audio.index + ']  ' + d.audio.duration.toFixed(2) + ' с');
            d.warnings.forEach(function (w) { line('! ' + w, 'warn'); });
            $('btnAuto').disabled = false;
            return d;
        }).catch(function (e) {
            state.auto = null;
            var box = $('autoMeta');
            box.className = 'auto-meta empty';
            box.textContent = e.message;
            $('btnAuto').disabled = true;
            return null;
        });
    }

    function itemFromComp(d) {
        return {
            label: d.comp.name,
            compName: d.comp.name,
            videoPath: d.video.path,
            audioPath: d.audio.path,
            videoName: d.video.name,
            audioName: d.audio.name,
            audioDuration: d.audio.duration,
            videoDuration: d.video.duration,
            compId: d.comp.id,
            addToComp: true,
            startTime: d.video.startTime,
            audioRef: { index: d.audio.index, name: d.audio.name },
            muteLayers: $('muteSources').checked
                ? [{ index: d.video.index, name: d.video.name, role: 'video' },
                   { index: d.audio.index, name: d.audio.name, role: 'audio' }]
                : []
        };
    }

    /** One click: read the active comp, queue it, run it. */
    function runAuto() {
        detect().then(function (d) {
            if (!d) { return; }
            qAdd(itemFromComp(d));
            startQueue();
        });
    }

    function queueActiveComp() {
        detect().then(function (d) {
            if (!d) { return; }
            qAdd(itemFromComp(d));
            log('[' + d.comp.name + '] у чергу: ' + d.video.name + ' + ' + d.audio.name);
        });
    }

    /** The multi-geo case: every comp in the project that already has a pair. */
    function queueAllComps() {
        es('aesyncScanComps').then(function (d) {
            var queued = 0;
            d.ready.forEach(function (r) {
                var dup = state.queue.some(function (i) {
                    return i.compId === r.comp.id && i.status !== 'error';
                });
                if (dup) { return; }
                qAdd(itemFromComp(r));
                queued++;
            });
            log('Додано композицій: ' + queued + (queued < d.ready.length ? ' (решта вже в черзі)' : ''), queued ? 's' : '');
            if (d.skipped.length) {
                log('Пропущено ' + d.skipped.length + ': ' + d.skipped.slice(0, 6).map(function (s) {
                    return s.name + ' — ' + s.reason;
                }).join('; ') + (d.skipped.length > 6 ? ' …' : ''));
            }
        }).catch(function (e) { log(e.message, 'e'); });
    }

    /**
     * Queue a comp as a render-then-upload item: video and audio both come from
     * a full Render Queue pass over the comp (like the two manual "Рендер …"
     * buttons combined), not from reading layers straight off disk. Use this
     * when the comp has a precomp on top, or trimmed/spliced video or audio —
     * cases the footage-based "auto" queueing can't (or shouldn't) touch.
     * The actual render happens lazily when the queue starts (same mechanism
     * as label-prepared precomps), so this only needs to add a queue entry.
     */
    function queueRenderComp(comp) {
        var dup = state.queue.some(function (i) {
            return i.compId === comp.id && i.status !== 'error';
        });
        if (dup) {
            log('[' + comp.name + '] вже в черзі — пропускаю.');
            return Promise.resolve(false);
        }

        var wantMute = $('muteSources').checked;
        var muted = wantMute
            ? es('aesyncAutoSources', { compId: comp.id }).then(function (d) {
                  return [
                      { index: d.video.index, name: d.video.name, role: 'video' },
                      { index: d.audio.index, name: d.audio.name, role: 'audio' }
                  ];
              }).catch(function () { return []; }) // precomp on top, edited layers, etc. — render still works, just nothing to auto-mute
            : Promise.resolve([]);

        return muted.then(function (muteLayers) {
            qAdd({
                label: comp.name,
                compName: comp.name,
                compId: comp.id,
                mode: 'render',
                renderNote: 'рендер комп\u2019озиції — відео+аудіо перед відправкою',
                addToComp: true,
                muteResultAudio: false,
                audioRef: muteLayers[1] || null,
                muteLayers: muteLayers
            });
            var note = wantMute
                ? (muteLayers.length ? '' : ' (вихідні шари не визначились — вимкни їх вручну після імпорту)')
                : '';
            log('[' + comp.name + '] у чергу: рендер відео+аудіо перед відправкою' + note);
            return true;
        });
    }

    /** One button: render both tracks of the active comp and queue them together. */
    function queueRenderActive() {
        // Ask AE directly instead of trusting state.compId — that cache only
        // refreshes on PanelActivated, so switching comps in the timeline
        // without ever refocusing the panel would otherwise look like "no
        // active comp" even though one clearly is.
        return es('aesyncContext').then(function (ctx) {
            if (!ctx.comp) { return log('Немає активної композиції. Відкрий комп у таймлайні.', 'e'); }
            state.compId = ctx.comp.id;
            state.compName = ctx.comp.name;
            return queueRenderComp({ id: ctx.comp.id, name: ctx.comp.name });
        }).catch(function (e) { log(e.message, 'e'); });
    }

    /** The batch case: every comp currently selected in the Project panel, not just the active one. */
    function queueRenderSelected() {
        es('aesyncSelectedComps').then(function (d) {
            if (!d.comps.length) {
                return log('У панелі проекту не виділено жодної композиції.', 'e');
            }
            return d.comps.reduce(function (chain, c) {
                return chain.then(function (count) {
                    return queueRenderComp(c).then(function (added) { return count + (added ? 1 : 0); });
                });
            }, Promise.resolve(0)).then(function (count) {
                log('Додано в чергу: ' + count + ' композиц' + (count === 1 ? 'ію' : 'ій') +
                    (count < d.comps.length ? ' (решта вже в черзі)' : '') +
                    ' — кожна рендериться перед відправкою.', count ? 's' : '');
            });
        }).catch(function (e) { log(e.message, 'e'); });
    }

    function queueManual() {
        var v = $('videoSelect').value, a = $('audioSelect').value;
        if (!v || !a) { return log('Потрібні і відео, і аудіо.', 'e'); }

        var bad = [v, a].filter(function (p) {
            try { return fs.statSync(p).size < 1024; } catch (e) { return true; }
        });
        if (bad.length) {
            return log('Не ставлю в чергу: ' + bad.map(function (p) { return path.basename(p); }).join(', ') +
                ' — файл порожній або відсутній. Генерація на такому лише спалить квоту.', 'e');
        }

        var replaceIdx = ($('replaceLayer').checked && state.selection.length) ? state.selection[0].index : 0;
        var label = state.compName ? state.compName + ' (вручну)' : path.basename(v);
        qAdd({
            label: label,
            compName: state.compName,
            videoPath: v,
            audioPath: a,
            compId: state.compId,
            addToComp: $('addToComp').checked,
            replaceLayerIndex: replaceIdx,
            muteLayers: []
        });
        log('[' + label + '] у чергу: ' + (state.labels[v] || path.basename(v)) + ' + ' + (state.labels[a] || path.basename(a)));
    }

    function browse(kind) {
        var types = kind === 'video' ? ['mp4', 'mov', 'm4v', 'webm', 'mkv'] : ['wav', 'mp3', 'm4a', 'aac', 'aif', 'aiff', 'flac'];
        var res = window.cep.fs.showOpenDialog(false, false, 'Обери ' + kind, '', types);
        if (res && res.data && res.data.length) {
            addExternal($(kind === 'video' ? 'videoSelect' : 'audioSelect'), res.data[0]);
            log('Обрано з диска: ' + path.basename(res.data[0]));
        }
    }

    var TRANSLIT = {
        а: 'a', б: 'b', в: 'v', г: 'h', ґ: 'g', д: 'd', е: 'e', є: 'ie', ж: 'zh', з: 'z',
        и: 'y', і: 'i', ї: 'i', й: 'i', к: 'k', л: 'l', м: 'm', н: 'n', о: 'o', п: 'p',
        р: 'r', с: 's', т: 't', у: 'u', ф: 'f', х: 'kh', ц: 'ts', ч: 'ch', ш: 'sh',
        щ: 'shch', ь: '', ю: 'iu', я: 'ia', ы: 'y', э: 'e', ъ: '', ё: 'e'
    };

    /** "Казик DE" → "Kazyk_DE": the comp stays recognisable in an ASCII filename. */
    function translit(s) {
        return String(s).split('').map(function (ch) {
            var lower = ch.toLowerCase();
            if (!TRANSLIT.hasOwnProperty(lower)) { return ch; }
            var out = TRANSLIT[lower];
            return ch === lower ? out : (out.charAt(0).toUpperCase() + out.slice(1));
        }).join('');
    }

    /**
     * A token unique to one pass over one item. Every file this run writes
     * carries it, so re-running a comp never writes over a file AE already
     * holds open from the previous result — that collision is what used to
     * surface as a failed render or a stale clip in the project.
     */
    function runId() {
        return Date.now().toString(36).slice(-6) +
               Math.random().toString(36).slice(2, 8);
    }

    /** Anything crossing into ExtendScript must be ASCII, so filenames get stripped. */
    function asciiName(name) {
        var clean = translit(name)
            .replace(/[^\x20-\x7E]/g, '')
            .replace(/[\\/:*?"<>|]/g, '_')
            .trim()
            .replace(/\s+/g, '_')
            .replace(/_{2,}/g, '_');
        return clean.length > 2 ? clean.slice(0, 60) : ('sync_' + Date.now());
    }
    function isAscii(s) { return !/[^\x00-\x7F]/.test(s || ''); }

    /** Real template names, straight from this AE install — no guessing at localised strings. */
    function loadTemplates(verbose) {
        return es('aesyncTemplates').then(function (d) {
            state.templates = d.outputModules;
            [['omVideo', cfg.omVideo], ['omAudio', cfg.omAudio]].forEach(function (pair) {
                var sel = $(pair[0]);
                var saved = pair[1];
                sel.innerHTML = '';
                d.outputModules.forEach(function (name) {
                    var o = document.createElement('option');
                    o.value = name;
                    o.textContent = name;
                    sel.appendChild(o);
                });
                if (saved && d.outputModules.indexOf(saved) === -1) {
                    var miss = document.createElement('option');
                    miss.value = saved;
                    miss.textContent = saved + '  — немає в цій версії AE';
                    sel.insertBefore(miss, sel.firstChild);
                }
                sel.value = saved || (d.outputModules[0] || '');
            });
            if (verbose) { log('Шаблонів Output Module у цій версії AE: ' + d.outputModules.length, 's'); }
            var missing = [cfg.omVideo, cfg.omAudio].filter(function (n) {
                return n && d.outputModules.indexOf(n) === -1;
            });
            if (missing.length) {
                log('Немає таких шаблонів: ' + missing.join(', ') + '. Обери зі списку в налаштуваннях.', 'e');
                // Fall back to something lossless rather than leaving it broken.
                var lossless = d.outputModules.filter(function (n) { return /wav|aiff/i.test(n); })[0];
                if (lossless && d.outputModules.indexOf(cfg.omAudio) === -1) {
                    cfg.omAudio = lossless;
                    $('omAudio').value = lossless;
                    saveConfig();
                    log('Для аудіо поставив "' + lossless + '".');
                }
            }
            if (/mp3/i.test(cfg.omAudio)) {
                log('MP3 для озвучки — стиснення поверх стиснення. Якщо в списку є WAV чи AIFF, краще взяти їх.');
            }
            return d;
        }).catch(function (e) { log('Не вдалось прочитати шаблони: ' + e.message, 'e'); });
    }

    // ------------------------------------------------------------ prepare
    var LABELS = ['—', 'Червоний', 'Жовтий', 'Аква', 'Рожевий', 'Лаванда', 'Персиковий',
        'Морська піна', 'Синій', 'Зелений', 'Пурпуровий', 'Помаранчевий', 'Коричневий',
        'Фуксія', 'Ціан', 'Пісковик', 'Темно-зелений'];

    function fillLabelSelect(id, chosen) {
        var sel = $(id);
        sel.innerHTML = '';
        for (var i = 1; i < LABELS.length; i++) {
            var o = document.createElement('option');
            o.value = String(i);
            o.textContent = i + ' · ' + LABELS[i];
            sel.appendChild(o);
        }
        sel.value = String(chosen);
    }

    function labelPreview(verbose) {
        return es('aesyncLabelPreview', {
            videoLabel: parseInt($('videoLabel').value, 10),
            audioLabel: parseInt($('audioLabel').value, 10)
        }).then(function (d) {
            var box = $('labelMeta');
            box.className = 'auto-meta';
            box.innerHTML = '';
            var line = function (text, cls) {
                var el = document.createElement('div');
                if (cls) { el.className = cls; }
                el.textContent = text;
                box.appendChild(el);
            };
            line('комп · ' + d.compName);
            line('сегментів · ' + d.video.length + ' · озвучка · ' + d.audio.length + ' шар(ів)');
            d.video.slice(0, 4).forEach(function (v) {
                line('  ' + v.name + '  ' + v.start.toFixed(2) + '–' + v.end.toFixed(2) + ' с');
            });
            if (d.video.length > 4) { line('  … ще ' + (d.video.length - 4)); }
            if (!d.video.length || !d.audio.length) {
                box.className = 'auto-meta empty';
                line('! признач мітки: відео — ' + LABELS[parseInt($('videoLabel').value, 10)] +
                     ', аудіо — ' + LABELS[parseInt($('audioLabel').value, 10)], 'warn');
            }
            if (verbose) { log('[' + d.compName + '] по мітках: ' + d.video.length + ' сегментів, ' + d.audio.length + ' аудіошар(ів)'); }
            return d;
        }).catch(function (e) {
            var box = $('labelMeta');
            box.className = 'auto-meta empty';
            box.textContent = e.message;
            return null;
        });
    }

    function prepare() {
        $('btnPrepare').disabled = true;
        es('aesyncPrepare', {
            videoLabel: parseInt($('videoLabel').value, 10),
            audioLabel: parseInt($('audioLabel').value, 10)
        }).then(function (d) {
            log('[' + d.compName + '] створено прекомпів: ' + d.made.length, d.made.length ? 's' : 'e');
            d.made.forEach(function (m) {
                if (m.inPlace) {
                    log('  ' + m.name + ' → ' + m.segment.start.toFixed(2) + '–' + m.segment.end.toFixed(2) +
                        ' с, шар ' + m.landed.index);
                } else {
                    log('  ' + m.name + ' — прекомп не став на місце сегмента (' +
                        m.segment.start.toFixed(2) + '–' + m.segment.end.toFixed(2) + ' с). Перевір позицію шару.', 'e');
                }
            });
            d.skipped.forEach(function (s) {
                log('[' + d.compName + '] пропущено ' + s.name + ' — ' + s.reason, 'e');
            });
            if ($('prepQueue').checked) {
                d.made.forEach(function (m) {
                    qAdd({
                        label: m.name,
                        compName: m.name,
                        compId: m.id,
                        mode: 'render',
                        renderNote: 'прекомп із міток — рендериться перед відправкою',
                        videoName: m.videoLayer.name,
                        audioName: m.audioLayer.name,
                        audioDuration: m.duration,
                        addToComp: true,
                        muteResultAudio: true,
                        audioRef: m.audioLayer,
                        muteLayers: [
                            { index: m.videoLayer.index, name: m.videoLayer.name, role: 'video' },
                            { index: m.audioLayer.index, name: m.audioLayer.name, role: 'audio' }
                        ]
                    });
                });
                if (d.made.length) { log('У чергу поставлено ' + d.made.length + ' прекомпів — вони рендеряться перед відправкою.'); }
            }
            return refresh();
        }).catch(function (e) { log(e.message, 'e'); })
          .then(function () { $('btnPrepare').disabled = state.running; });
    }

    // AE's Render Queue is one engine, not one per evalScript call: two
    // "render this comp" requests in flight at once would both be poking
    // app.project.renderQueue at the same time. Everything that renders a
    // comp goes through this gate so lanes (concurrency > 1) queue up their
    // renders instead of colliding — the sync.so upload/poll/download steps
    // for other items keep running in parallel around it.
    var renderGate = Promise.resolve();
    function esRender(args) {
        var run = renderGate.then(function () { return es('aesyncRenderComp', args); });
        renderGate = run.then(function () {}, function () {});
        return run;
    }

    function hostDir() {
        // A custom folder is only usable host-side when it survives the bridge.
        return (cfg.workDir && isAscii(cfg.workDir)) ? cfg.workDir : '';
    }

    function workDir() {
        if (cfg.workDir && isAscii(cfg.workDir)) {
            if (!fs.existsSync(cfg.workDir)) { fs.mkdirSync(cfg.workDir, { recursive: true }); }
            return Promise.resolve(cfg.workDir);
        }
        if (cfg.workDir) {
            log('Тека з налаштувань містить не-ASCII символи — беру автоматичну.', 'e');
        }
        return es('aesyncWorkDir', { dirPath: '' }).then(function (d) {
            if (!fs.existsSync(d.path)) { fs.mkdirSync(d.path, { recursive: true }); }
            if (!state.dirAnnounced) {
                state.dirAnnounced = true;
                log('Робоча тека: ' + d.path);
                if (!d.nextToProject && d.projectDir && !d.projectAscii) {
                    log('Тека проєкту містить кирилицю — AE не може туди рендерити, тому тимчасові файли йдуть сюди.');
                }
            }
            return d.path;
        });
    }

    function renderComp(kind) {
        var isVideo = kind === 'video';
        var tpl = isVideo ? cfg.omVideo : cfg.omAudio;
        var ext = isVideo ? '.mp4' : '.wav';
        var compTag = state.compName || 'comp';
        var fileName = asciiName(compTag) + '_' + kind + '_' + runId() + ext;
        return workDir().then(function () {
            log('[' + compTag + '] рендер ' + (isVideo ? 'відео' : 'аудіо') + ' → ' + fileName);
            log('[' + compTag + '] шаблон "' + tpl + '"');
            return esRender({
                compId: state.compId,
                fileName: fileName,
                dirPath: hostDir(),
                omTemplate: tpl,
                forceAudio: !isVideo,
                excludeResults: true,
                soloAudio: !isVideo,
                audioLabel: cfg.audioLabel
            });
        }).then(function (d) {
            if (!isVideo) { logHeard(d.compName, d); }
            state.lastRender = { compId: d.compId, compName: d.compName };
            addExternal($(isVideo ? 'videoSelect' : 'audioSelect'), d.path,
                d.compName + ' — ' + (isVideo ? 'відео' : 'аудіо') + ' (рендер)');
            log('[' + d.compName + '] готово: ' + d.fileName + '  (' + (d.size / 1048576).toFixed(2) + ' МБ)', 's');
            if (!isVideo && d.size < 20000) {
                log('[' + d.compName + '] файл підозріло малий для озвучки — послухай його перед постановкою в чергу.', 'e');
            }
        }).catch(function (e) {
            log(e.message, 'e');
            if (/template|шаблон/i.test(e.message)) {
                loadTemplates(false).then(function (d) {
                    if (d && d.outputModules.length) {
                        log('Доступні: ' + d.outputModules.join(' · '));
                        log('Обери потрібний у налаштуваннях — поле стало списком.');
                    }
                });
            }
        });
    }

    // -------------------------------------------------------------- runner
    function busy(on) {
        state.running = on;
        $('btnCancel').hidden = !on;
        ['btnAuto', 'btnRun', 'btnQueueComp', 'btnQueueAll', 'btnClearQueue',
         'btnRenderComp', 'btnRenderAudio', 'btnBrowseVideo', 'btnBrowseAudio',
         'btnRescan', 'concurrency', 'btnPrepare', 'btnLabelPreview',
         'btnQueueRenderComp', 'btnQueueRenderSelected'].forEach(function (id) {
            $(id).disabled = on;
        });
        qRender();
    }

    function currentOptions() {
        return {
            model: $('model').value,
            syncMode: $('syncMode').value,
            temperature: parseFloat($('temperature').value),
            activeSpeakerDetection: $('activeSpeaker').checked,
            occlusionDetection: $('occlusion').checked
        };
    }

    /** Say exactly which layer ended up in the sound file — the check that matters. */
    function logHeard(label, d) {
        if (!d || !d.heard) { return; }
        if (d.heard.length === 1) {
            log('[' + label + '] у звук пішов лише шар «' + d.heard[0] + '»');
        } else {
            log('[' + label + '] у звук потрапило шарів: ' + d.heard.length +
                (d.heard.length ? ' — ' + d.heard.join(', ') : '') + '. Перевір файл перед відправкою.', 'e');
        }
    }

    /** Prepared precomps have no source files yet — render them first. */
    function prepareSources(it) {
        if (it.mode !== 'render') { return Promise.resolve(); }
        var tag = asciiName(it.label);
        var stamp = it.runId;
        qStage(it, 1, 'рендер відео');
        return esRender({
            compId: it.compId,
            fileName: tag + '_video_' + stamp + '.mp4',
            dirPath: hostDir(),
            omTemplate: cfg.omVideo,
            excludeResults: true
        }).then(function (d) {
            it.videoPath = d.path;
            qStage(it, 1, 'рендер аудіо');
            return esRender({
                compId: it.compId,
                fileName: tag + '_audio_' + stamp + '.wav',
                dirPath: hostDir(),
                omTemplate: cfg.omAudio,
                forceAudio: true,
                excludeResults: true,
                soloAudio: true,
                audioRef: it.audioRef || null,
                audioLabel: cfg.audioLabel
            });
        }).then(function (d) {
            it.audioPath = d.path;
            logHeard(it.label, d);
            log('[' + it.label + '] відрендерено ' + path.basename(it.videoPath) + ' + ' + path.basename(it.audioPath));
        });
    }

    /** One queue item, start to finish. Never rejects — failures land on the item. */
    function processItem(api, it) {
        var startedAt = Date.now();
        var opts = currentOptions();
        var outPath = '', outName = '', jobId = '';

        it.status = 'running';
        it.runId = runId();
        qStage(it, 1, 'перевірка');

        return prepareSources(it).then(function () {
            if (!fs.existsSync(it.videoPath) || !fs.existsSync(it.audioPath)) {
                throw new Error('Файл джерела зник з диска.');
            }
            var empty = [it.videoPath, it.audioPath].filter(function (p) {
                try { return fs.statSync(p).size < 1024; } catch (e) { return true; }
            });
            if (empty.length) {
                throw new Error('Порожній файл: ' + empty.map(function (p) { return path.basename(p); }).join(', ') +
                    '. Пропускаю, щоб не витрачати генерацію.');
            }

            log('[' + it.label + '] відео ' + path.basename(it.videoPath) + ' (' + fileSize(it.videoPath) + ')' +
                ' + аудіо ' + path.basename(it.audioPath) + ' (' + fileSize(it.audioPath) +
                (it.audioDuration ? ', ' + it.audioDuration.toFixed(1) + ' с' : '') + ')');

            return api.uploadAsset(it.videoPath, 'VIDEO', function (frac) {
                qStage(it, 2, 'відео ' + Math.round(frac * 100) + '%');
            });
        }).then(function (v) {
            return api.uploadAsset(it.audioPath, 'AUDIO', function (frac) {
                qStage(it, 2, 'аудіо ' + Math.round(frac * 100) + '%');
            }).then(function (a) { return { v: v, a: a }; });
        }).then(function (assets) {
            qStage(it, 3, 'створення');
            opts.videoAssetId = assets.v.assetId;
            opts.audioAssetId = assets.a.assetId;
            opts.outputFileName = asciiName('lip_' + (it.compName || path.basename(it.videoPath, path.extname(it.videoPath))));
            return api.createGeneration(opts);
        }).then(function (job) {
            jobId = job.id;
            it.jobId = jobId;
            log('[' + it.label + '] job ' + jobId);
            return api.waitForGeneration(jobId, {
                abort: state.abort,
                intervalMs: 5000,
                onTick: function (status, seconds) {
                    qStage(it, 3, status.toLowerCase() + ' · ' + seconds + ' с');
                }
            });
        }).then(function (job) {
            qStage(it, 4, '0%');
            return workDir().then(function (dir) {
                outName = asciiName(job.outputFileName || ('sync_' + jobId)) + '_' + it.runId + '.mp4';
                outPath = path.join(dir, outName);
                return api.download(job.outputUrl, outPath, function (frac) {
                    qStage(it, 4, Math.round(frac * 100) + '%');
                });
            });
        }).then(function () {
            qStage(it, 5, 'імпорт');
            return es('aesyncImport', {
                fileName: outName,
                dirPath: hostDir(),
                addToComp: !!it.addToComp && !it.replaceLayerIndex,
                compId: it.compId || 0,
                useActiveComp: !it.compId,
                replaceLayerIndex: it.replaceLayerIndex || 0,
                startTime: it.startTime || 0,
                muteLayers: it.muteLayers || [],
                muteResultAudio: !!it.muteResultAudio,
                replacePrevious: $('replacePrev').checked,
                jobId: jobId,
                model: opts.model,
                folderName: 'Sync Lip'
            });
        }).then(function (d) {
            it.status = 'done';
            it.stage = 5;
            it.note = Math.round((Date.now() - startedAt) / 1000) + ' с';
            it.resultName = d.name;
            log('[' + it.label + '] → "' + d.name + '" ' + (d.placed || 'у проєкті') + ', ' + it.note, 's');
            if (d.version > 1) {
                log('[' + it.label + '] прогін №' + d.version + ' для цієї композиції' +
                    (d.previous ? ', попередніх результатів знайдено: ' + d.previous : '') + '.');
            }

            if (d.missedComp) {
                it.status = 'error';
                it.note = 'композиції немає';
                log('[' + it.label + '] Композицію не знайдено — її перейменували чи видалили? ' +
                    'Файл імпортовано в бін "Sync Lip", постав шар вручну.', 'e');
            } else if (it.compId && d.compId && d.compId !== it.compId) {
                it.status = 'error';
                it.note = 'не та композиція';
                log('[' + it.label + '] Результат ліг у "' + d.compName + '" замість очікуваної. Перевір шар.', 'e');
            }
            qRender();
        }).catch(function (e) {
            it.status = state.abort.cancelled ? 'waiting' : 'error';
            it.note = state.abort.cancelled ? 'зупинено' : e.message.slice(0, 60);
            log('[' + it.label + '] ' + e.message, 'e');
            if (jobId && !state.abort.cancelled) {
                log('[' + it.label + '] id генерації ' + jobId + ' — її видно в дашборді sync.so.');
            }
            if (/429|too many/i.test(e.message)) {
                log('Схоже на ліміт паралельних генерацій твого тарифу — постав «Паралельно: 1».');
            }
            qRender();
        });
    }

    /** Simple worker pool: `concurrency` items in flight, the rest wait their turn. */
    function startQueue() {
        if (state.running) { return; }
        var api;
        try { api = client(); }
        catch (e) { log(e.message, 'e'); $('settings').hidden = false; return; }

        var pending = state.queue.filter(function (i) { return i.status === 'waiting'; });
        if (!pending.length) { log('У черзі немає нічого, що чекає.', 'e'); return; }

        state.abort = { cancelled: false };
        busy(true);
        var started = Date.now();
        var lanes = Math.min(parseInt(cfg.concurrency, 10) || 1, pending.length);
        log('Старт черги: ' + pending.length + ' шт., паралельно ' + lanes);

        var idx = 0;
        function next() {
            if (state.abort.cancelled || idx >= pending.length) { return Promise.resolve(); }
            return processItem(api, pending[idx++]).then(next);
        }
        var workers = [];
        for (var w = 0; w < lanes; w++) { workers.push(next()); }

        Promise.all(workers).then(function () {
            busy(false);
            var done = state.queue.filter(function (i) { return i.status === 'done'; }).length;
            var failed = state.queue.filter(function (i) { return i.status === 'error'; }).length;
            log('Черга завершена: готово ' + done + (failed ? ', з помилками ' + failed : '') +
                ' · ' + Math.round((Date.now() - started) / 1000) + ' с', failed ? '' : 's');
            refresh();
        });
    }

    // --------------------------------------------------------------- wire
    function init() {
        applyTheme();
        cs.addEventListener(CSInterface.THEME_COLOR_CHANGED_EVENT, applyTheme);

        loadConfig();
        $('apiKey').value = cfg.apiKey;
        $('workDir').value = cfg.workDir;
        $('model').value = cfg.model;
        $('syncMode').value = cfg.syncMode;
        $('temperature').value = cfg.temperature;
        $('tempVal').textContent = cfg.temperature;
        fillLabelSelect('videoLabel', cfg.videoLabel);
        fillLabelSelect('audioLabel', cfg.audioLabel);
        $('concurrency').value = String(cfg.concurrency);
        $('cfgPath').textContent = CONFIG_FILE;
        qRender();
        markKeyState();

        $('btnSettings').addEventListener('click', function () {
            $('settings').hidden = !$('settings').hidden;
            if (!$('settings').hidden && !state.templates) { loadTemplates(false); }
        });
        $('btnReloadTpl').addEventListener('click', function (ev) {
            ev.preventDefault();
            loadTemplates(true);
        });
        $('btnSaveSettings').addEventListener('click', function () {
            cfg.apiKey = $('apiKey').value.trim();
            cfg.omVideo = $('omVideo').value;
            cfg.omAudio = $('omAudio').value;
            cfg.workDir = $('workDir').value.trim();
            if (saveConfig()) {
                markKeyState();
                $('settings').hidden = true;
                log('Налаштування збережено.', 's');
            }
        });
        $('btnCheckKey').addEventListener('click', function () {
            var key = $('apiKey').value.trim();
            if (!key) { return log('Поле ключа порожнє.', 'e'); }
            new SyncAPI.Client(key).listModels().then(function (m) {
                var names = (m.models || m || []).map(function (x) { return x.id || x.name || x; });
                log('Ключ робочий. Доступні моделі: ' + names.join(', '), 's');
            }).catch(function (e) { log('Ключ не пройшов: ' + e.message, 'e'); });
        });

        $('btnDiag').addEventListener('click', function () {
            es('aesyncWorkDir', { dirPath: hostDir() }).then(function (d) {
                log('Тека проєкту: ' + (d.projectDir || 'проєкт не збережено'));
                log('Робоча тека:  ' + d.path);
                log('Шлях лише з ASCII: ' + (d.ascii ? 'так' : 'ні — AE може не змогти туди рендерити'), d.ascii ? 's' : 'e');
                log('Node її бачить: ' + (fs.existsSync(d.path) ? 'так' : 'ні'), fs.existsSync(d.path) ? 's' : 'e');
                if (d.projectDir && !d.projectAscii) {
                    log('У теці проєкту є кирилиця, тому робоча тека винесена окремо.');
                }
                return es('aesyncEcho', { text: d.path }).then(function (r) {
                    var same = r.received === d.path;
                    log('Рядок назад в AE: ' + (same ? 'цілий' : 'зіпсований — ' + r.received), same ? 's' : 'e');
                });
            }).catch(function (e) { log(e.message, 'e'); });
        });
        $('btnRescan').addEventListener('click', function (ev) {
            ev.preventDefault();
            ev.stopPropagation();
            refresh();
        });
        $('btnBrowseVideo').addEventListener('click', function () { browse('video'); });
        $('btnBrowseAudio').addEventListener('click', function () { browse('audio'); });
        $('btnRenderComp').addEventListener('click', function () { renderComp('video'); });
        $('btnRenderAudio').addEventListener('click', function () { renderComp('audio'); });

        function meta(selId, metaId) {
            var v = $(selId).value;
            $(metaId).textContent = v ? path.basename(v) : '';
        }
        $('videoSelect').addEventListener('change', function () { meta('videoSelect', 'videoMeta'); });
        $('audioSelect').addEventListener('change', function () { meta('audioSelect', 'audioMeta'); });

        $('temperature').addEventListener('input', function () {
            $('tempVal').textContent = parseFloat(this.value).toFixed(2);
            cfg.temperature = parseFloat(this.value); saveConfig();
        });
        $('model').addEventListener('change', function () { cfg.model = this.value; saveConfig(); });
        $('syncMode').addEventListener('change', function () { cfg.syncMode = this.value; saveConfig(); });

        $('replaceLayer').addEventListener('change', function () {
            if (this.checked) { $('addToComp').checked = false; }
        });
        $('addToComp').addEventListener('change', function () {
            if (this.checked) { $('replaceLayer').checked = false; }
        });

        $('btnPrepare').addEventListener('click', prepare);
        $('btnLabelPreview').addEventListener('click', function (ev) {
            ev.preventDefault();
            ev.stopPropagation();
            labelPreview(true);
        });
        ['videoLabel', 'audioLabel'].forEach(function (id) {
            $(id).addEventListener('change', function () {
                cfg[id] = parseInt(this.value, 10);
                saveConfig();
                labelPreview(false);
            });
        });

        $('btnAuto').addEventListener('click', runAuto);
        $('btnQueueComp').addEventListener('click', queueActiveComp);
        $('btnQueueAll').addEventListener('click', queueAllComps);
        $('btnQueueRenderComp').addEventListener('click', queueRenderActive);
        $('btnQueueRenderSelected').addEventListener('click', queueRenderSelected);
        $('btnRun').addEventListener('click', queueManual);
        $('btnStart').addEventListener('click', function () {
            var noComp = state.queue.filter(function (i) {
                return i.status === 'waiting' && !i.compId;
            });
            if (noComp.length) {
                log('Без прив\'язки до композиції: ' + noComp.length +
                    ' — вони підуть в активну композицію.');
            }
            startQueue();
        });
        $('btnClearQueue').addEventListener('click', function () {
            state.queue = state.queue.filter(function (i) { return i.status === 'running'; });
            qRender();
        });
        $('concurrency').addEventListener('change', function () {
            cfg.concurrency = parseInt(this.value, 10);
            saveConfig();
        });
        $('btnCancel').addEventListener('click', function () {
            state.abort.cancelled = true;
            log('Зупиняю чергу. Те, що вже запущено на sync.so, доробиться там і буде оплачено.');
        });

        // AE tells the panel when the project or selection changed.
        try {
            cs.addEventListener('com.adobe.csxs.events.PanelActivated', refresh);
        } catch (e) {}

        es('aesyncPing').then(function (d) {
            log('After Effects ' + d.version + (d.project ? ' · ' + d.project : ' · проєкт не збережено'));
            return loadTemplates(false);
        }).then(function () {
            return refresh();
        }).catch(function (e) { log(e.message, 'e'); });
    }

    document.addEventListener('DOMContentLoaded', init);
})();
