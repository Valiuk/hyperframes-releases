/* HF Screen Fit — panel side */
(function () {
  "use strict";

  var fs = require("fs");
  var isWin = process.platform === "win32";
  // ASCII-only temp path (user profile paths may contain Cyrillic).
  var TMP_DIR = isWin ? "C:/Users/Public/HF_ScreenFit" : "/tmp/hf_screenfit";
  var FRAME = TMP_DIR + "/frame.png";

  var ERR = {
    NO_COMP: "Відкрий композицію і зроби її активною.",
    SELECT_GAMEPLAY: "Виділи шар геймплею з Corner Pin.",
    NO_BG: "Не знайшов фон під геймплеєм. Виділи фон другим шаром.",
    BAD_GAMEPLAY: "Виділений шар не має відео.",
    SELECT_MASK: "Виділи один шар-маску (роторуки чи матт), не з ригу.",
    LOST_LAYERS: "Не вдалося знову знайти шари після очищення старого ригу. Виділи геймплей і спробуй ще раз.",
    NO_RIG: "Спочатку збери риг — аналіз виставляє значення на ньому."
  };

  var $ = function (id) { return document.getElementById(id); };

  function jsx(script) {
    return new Promise(function (resolve) {
      window.__adobe_cep__.evalScript(script, function (res) {
        var out;
        try { out = JSON.parse(res); } catch (e) { out = { error: "JSX: " + res }; }
        resolve(out);
      });
    });
  }
  function q(s) { return '"' + String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"'; }

  function log(msg, isErr) {
    var el = $("log");
    el.textContent = msg || "";
    el.className = "log" + (isErr ? " err" : "");
  }
  function errText(e) {
    var m = String(e).match(/^([A-Z_]+)(\s*\[.*\])?$/);
    return (m && ERR[m[1]]) ? ERR[m[1]] : e;
  }

  function busy(on) {
    ["btnBuild", "btnRemove", "btnAnalyze", "btnRefresh", "btnMask", "btnMaskClear"].forEach(function (id) { $(id).disabled = on; });
  }

  // ---------- status ----------
  function setDD(id, text, cls) {
    var el = $(id);
    el.textContent = text || "—";
    el.className = cls || "";
    el.title = text || "";
  }
  function refresh() {
    return jsx("hf_status()").then(function (s) {
      if (s.error) {
        setDD("stComp", errText(s.error), "bad");
        setDD("stGame"); setDD("stPin"); setDD("stBg"); setDD("stMask");
        return;
      }
      setDD("stComp", s.comp + (s.rig ? "  · риг є" : ""));
      setDD("stMask", s.rig ? (s.mask || "немає — світло радіальне") : "спершу збери риг", s.mask ? "good" : "");
      if (s.pickError) {
        setDD("stGame", errText(s.pickError), "bad"); setDD("stPin"); setDD("stBg");
        return;
      }
      setDD("stGame", s.gameplay);
      setDD("stPin", s.pin || "не знайдено — візьму межі шару", s.pin ? "good" : "bad");
      setDD("stBg", s.bg);
    });
  }

  // ---------- build / remove ----------
  function build() {
    busy(true); log("Збираю риг…");
    jsx("hf_build()").then(function (r) {
      if (r.error) log(errText(r.error), true);
      else if (r.warn) log("Зібрано, але не вдалося підв'язати: " + r.warn, true);
      else log("Готово. Ручки — на HF Screen Fit.");
      return refresh();
    }).then(function () { busy(false); });
  }
  function remove() {
    busy(true);
    jsx("hf_remove()").then(function (r) {
      log(r.error ? errText(r.error) : "Риг прибрано.", !!r.error);
      return refresh();
    }).then(function () { busy(false); });
  }

  function setMask() {
    busy(true);
    jsx("hf_setGlowMask()").then(function (r) {
      log(r.error ? errText(r.error) : "Світіння обмежене шаром " + r.mask + ".", !!r.error);
      return refresh();
    }).then(function () { busy(false); });
  }
  function clearMask() {
    busy(true);
    jsx("hf_clearGlowMask()").then(function (r) {
      log(r.error ? errText(r.error) : "Маску світіння прибрано.", !!r.error);
      return refresh();
    }).then(function () { busy(false); });
  }

  // ---------- analysis ----------
  function waitForFile(path, timeoutMs) {
    var start = Date.now(), lastSize = -1;
    return new Promise(function (resolve, reject) {
      (function tick() {
        var size = -1;
        try { size = fs.statSync(path).size; } catch (e) {}
        if (size > 0 && size === lastSize) return resolve();
        lastSize = size;
        if (Date.now() - start > timeoutMs) return reject(new Error("Кадр не відрендерився за " + timeoutMs / 1000 + " с."));
        setTimeout(tick, 250);
      })();
    });
  }

  function frameToJpeg(path, maxSide) {
    return new Promise(function (resolve, reject) {
      var b64 = fs.readFileSync(path).toString("base64");
      var img = new Image();
      img.onload = function () {
        var k = Math.min(1, maxSide / Math.max(img.width, img.height));
        var c = document.createElement("canvas");
        c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL("image/jpeg", 0.85).split(",")[1]);
      };
      img.onerror = function () { reject(new Error("Не вдалося прочитати кадр.")); };
      img.src = "data:image/png;base64," + b64;
    });
  }

  var SYSTEM = [
    "You are a VFX compositing supervisor for mobile-game performance ads.",
    "You receive one frame of live footage in which a phone screen was replaced with gameplay via corner pin.",
    "Estimate parameters that make the screen sit naturally in the plate while keeping gameplay readable.",
    "Respond with ONLY a JSON object, no prose, no markdown fences."
  ].join(" ");

  var USER = [
    "Return JSON with exactly these keys:",
    "light_angle_deg: number 0-360, direction the dominant light comes FROM in image space, 0 = top, clockwise (90 = from the right).",
    "glare: 0-60, strength of a soft specular sheen on the glass (hard direct light or window nearby = higher).",
    "reflection: 0-35, how much of the blurred environment should reflect in the glass (bright surroundings = higher).",
    "screen_exposure: -1.5 to 0.5 stops for the screen relative to its source (bright daylight scene = negative, dark scene = 0 or slightly positive).",
    "black_lift: 0-0.08, how much to lift screen blacks (real screens never reach pure black; more in bright ambient light).",
    "glow_intensity: 0-80, how strongly the screen light spills onto the hand/surface around the phone (dark scene = higher, daylight = low).",
    "glow_spread: 50-220, spill radius as % of screen diagonal.",
    "bloom: 0-60, halation on bright UI elements (dark scenes = higher).",
    "softness: 0-3, Gaussian blur in px so the screen matches the plate's sharpness (compressed selfie/webcam footage = 1-2).",
    "grain: 0-12, noise % to match the plate's sensor noise and compression.",
    "saturation: -40 to 0, how much the camera should desaturate the screen (screens filmed by cameras lose saturation; very saturated UI = more negative).",
    "light_color_hex: '#rrggbb', the colour of the dominant ambient light.",
    "scene: short English tag like 'indoor warm evening'.",
    "note: one short sentence in Ukrainian describing the lighting you see and the main integration choice."
  ].join("\n");

  function clamp(v, a, b, d) { v = Number(v); if (!isFinite(v)) v = d; return Math.min(b, Math.max(a, v)); }

  function callClaude(jpegB64) {
    var key = $("apiKey").value.trim();
    if (!key) return Promise.reject(new Error("Встав API-ключ Anthropic."));
    return fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true"
      },
      body: JSON.stringify({
        model: $("model").value.trim() || "claude-sonnet-5-5",
        max_tokens: 600,
        system: SYSTEM,
        messages: [{
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: "image/jpeg", data: jpegB64 } },
            { type: "text", text: USER }
          ]
        }]
      })
    }).then(function (r) {
      return r.json().then(function (j) {
        if (!r.ok) throw new Error("API " + r.status + ": " + ((j.error && j.error.message) || "помилка"));
        var text = (j.content || []).filter(function (b) { return b.type === "text"; })
          .map(function (b) { return b.text; }).join("");
        var m = text.replace(/```json|```/g, "").match(/\{[\s\S]*\}/);
        if (!m) throw new Error("Модель не повернула JSON.");
        return JSON.parse(m[0]);
      });
    });
  }

  function showResult(p) {
    var rows = [
      ["Світло звідки", Math.round(p.light_angle_deg) + "°"],
      ["Блік", Math.round(p.glare)],
      ["Відображення", Math.round(p.reflection)],
      ["Експозиція екрана", p.screen_exposure.toFixed(2) + " st"],
      ["Підйом чорних", p.black_lift.toFixed(3)],
      ["Світіння на сцену", Math.round(p.glow_intensity)],
      ["Радіус світіння", Math.round(p.glow_spread) + "%"],
      ["Bloom", Math.round(p.bloom)],
      ["М'якість", p.softness.toFixed(1) + " px"],
      ["Зерно", p.grain.toFixed(1) + "%"],
      ["Насиченість", Math.round(p.saturation)]
    ];
    var el = $("result");
    el.innerHTML = "";
    if (p.note) {
      var n = document.createElement("p"); n.className = "note"; n.textContent = p.note; el.appendChild(n);
    }
    var t = document.createElement("table");
    rows.forEach(function (r) {
      var tr = document.createElement("tr");
      r.forEach(function (c) { var td = document.createElement("td"); td.textContent = c; tr.appendChild(td); });
      t.appendChild(tr);
    });
    el.appendChild(t);
    el.hidden = false;
  }

  function analyze() {
    localStorage.setItem("hf_key", $("apiKey").value.trim());
    localStorage.setItem("hf_model", $("model").value.trim());
    busy(true); log("Рендерю кадр…");
    try { if (!fs.existsSync(TMP_DIR)) fs.mkdirSync(TMP_DIR); } catch (e) {}
    try { if (fs.existsSync(FRAME)) fs.unlinkSync(FRAME); } catch (e) {}

    var hidden = "";
    jsx("hf_renderFrame(" + q(FRAME) + ")").then(function (r) {
      if (r.error) throw new Error(errText(r.error));
      hidden = r.hidden || "";
      return waitForFile(FRAME, 15000);
    }).then(function () {
      return jsx("hf_restore(" + q(hidden) + ")");
    }).then(function () {
      log("Claude дивиться на кадр…");
      return frameToJpeg(FRAME, 1024);
    }).then(callClaude).then(function (raw) {
      var p = {
        light_angle_deg: ((Number(raw.light_angle_deg) % 360) + 360) % 360 || 315,
        glare: clamp(raw.glare, 0, 60, 25),
        reflection: clamp(raw.reflection, 0, 35, 12),
        screen_exposure: clamp(raw.screen_exposure, -1.5, 0.5, 0),
        black_lift: clamp(raw.black_lift, 0, 0.08, 0.02),
        glow_intensity: clamp(raw.glow_intensity, 0, 80, 35),
        glow_spread: clamp(raw.glow_spread, 50, 220, 110),
        bloom: clamp(raw.bloom, 0, 60, 20),
        softness: clamp(raw.softness, 0, 3, 1),
        grain: clamp(raw.grain, 0, 12, 4),
        saturation: clamp(raw.saturation, -40, 0, -20),
        note: raw.note || ""
      };
      if (/^#[0-9a-f]{6}$/i.test(raw.light_color_hex || "")) {
        document.documentElement.style.setProperty("--glow", raw.light_color_hex);
      }
      showResult(p);
      return jsx("hf_apply(" + [p.light_angle_deg, p.glare, p.reflection, p.screen_exposure,
        p.black_lift, p.glow_intensity, p.glow_spread, p.bloom, p.softness, p.grain, p.saturation].join(",") + ")").then(function (r) {
        if (r.error) log(errText(r.error), true);
        else log("Значення виставлено на HF Screen Fit.");
      });
    }).catch(function (e) {
      if (hidden) jsx("hf_restore(" + q(hidden) + ")");
      log(e.message || String(e), true);
    }).then(function () { busy(false); });
  }

  // ---------- init ----------
  $("apiKey").value = localStorage.getItem("hf_key") || "";
  $("model").value = localStorage.getItem("hf_model") || "claude-sonnet-5-5";
  $("btnRefresh").addEventListener("click", refresh);
  $("btnBuild").addEventListener("click", build);
  $("btnRemove").addEventListener("click", remove);
  $("btnAnalyze").addEventListener("click", analyze);
  $("btnMask").addEventListener("click", setMask);
  $("btnMaskClear").addEventListener("click", clearMask);
  window.addEventListener("focus", refresh);
  refresh();
})();
