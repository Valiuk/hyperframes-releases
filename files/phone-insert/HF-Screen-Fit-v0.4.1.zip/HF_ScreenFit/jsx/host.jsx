// HF Screen Fit - host side (ExtendScript). Keep this file ASCII-only.
// Builds a live, expression-driven rig that integrates a corner-pinned
// gameplay layer into the plate: screen level, bloom, reflection, glare,
// and screen light spilling onto the scene.

var HF_NULL = "HF Screen Fit";
var HF_BAKE = ["Scene Color (auto)", "Screen Color (auto)"];
var HF_LAYERS = ["HF Screen Fit", "HF Glare", "HF Reflection", "HF Tilt Shade", "HF Screen Glow", "HF Matte", "HF Glow Matte"];

// ---------- helpers ----------
function hf_esc(s) {
    return String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n");
}
function hf_json(o) {
    var a = [];
    for (var k in o) {
        if (!o.hasOwnProperty(k)) continue;
        var v = o[k], s;
        if (typeof v === "number" || typeof v === "boolean") s = String(v);
        else if (v === null || v === undefined) s = "null";
        else s = '"' + hf_esc(v) + '"';
        a.push('"' + k + '":' + s);
    }
    return "{" + a.join(",") + "}";
}
function hf_err(e, where) {
    return hf_json({ error: ((e && e.message) ? e.message : String(e)) +
        (where ? " [" + where + (e && e.line ? ", line " + e.line : "") + "]" : "") });
}

function hf_comp() {
    var c = app.project.activeItem;
    if (!(c && c instanceof CompItem)) throw new Error("NO_COMP");
    return c;
}
function hf_isRigName(n) {
    for (var i = 0; i < HF_LAYERS.length; i++) if (n === HF_LAYERS[i]) return true;
    return false;
}
function hf_findPin(L) {
    var fx = L.property("ADBE Effect Parade");
    if (!fx) return null;
    var i, e;
    for (i = 1; i <= fx.numProperties; i++) {
        e = fx.property(i);
        if (e.matchName === "ADBE Corner Pin" || e.matchName === "CC Power Pin") return e;
    }
    for (i = 1; i <= fx.numProperties; i++) {
        e = fx.property(i);
        if (/pin/i.test(e.name) && e.numProperties >= 4 &&
            e.property(1).propertyValueType === PropertyValueType.TwoD_SPATIAL) return e;
    }
    return null;
}
// Real, expressionable parameters of an effect, in order (skips twirl-group
// markers and custom-data params that cannot take expressions).
function hf_vals(group, out) {
    out = out || [];
    for (var i = 1; i <= group.numProperties; i++) {
        var p = group.property(i);
        if (p.propertyType === PropertyType.PROPERTY) {
            if (p.propertyValueType !== PropertyValueType.NO_VALUE && p.canSetExpression) out.push(p);
        } else {
            hf_vals(p, out);
        }
    }
    return out;
}
// Find a parameter by display name, falling back to its 0-based position
// among hf_vals() (works on localized AE too).
function hf_prop(effect, names, fallbackIndex) {
    var v = hf_vals(effect);
    for (var i = 0; i < v.length; i++)
        for (var j = 0; j < names.length; j++) if (v[i].name === names[j]) return v[i];
    return v[fallbackIndex] || null;
}
var HF_WARN = [];
function hf_ex(prop, text, label) {
    try {
        if (!prop) throw new Error("missing");
        prop.expression = text;
    } catch (e) {
        HF_WARN.push(label);
    }
}
function hf_addFx(layer, matchName, name) {
    var e = layer.property("ADBE Effect Parade").addProperty(matchName);
    e.name = name;
    return e;
}
function hf_slider(layer, name, val) {
    var e = hf_addFx(layer, "ADBE Slider Control", name);
    e.property(1).setValue(val);
    return e;
}
function hf_isAV(L) {
    return (L instanceof AVLayer) && L.hasVideo;
}

// Pick gameplay (layer with a corner pin) and background from the selection.
function hf_pick(comp) {
    var sel = comp.selectedLayers, g = null, bg = null, i;
    if (sel.length < 1) throw new Error("SELECT_GAMEPLAY");
    for (i = 0; i < sel.length; i++) if (!g && hf_findPin(sel[i]) && !hf_isRigName(sel[i].name)) g = sel[i];
    if (!g) g = sel[0];
    for (i = 0; i < sel.length; i++) if (sel[i] !== g && hf_isAV(sel[i]) && !hf_isRigName(sel[i].name)) { bg = sel[i]; break; }
    if (!bg) {
        for (i = g.index + 1; i <= comp.numLayers; i++) {
            var L = comp.layer(i);
            if (hf_isAV(L) && L.enabled && !hf_isRigName(L.name) && !L.isTrackMatte) { bg = L; break; }
        }
    }
    if (!bg) throw new Error("NO_BG");
    if (!hf_isAV(g)) throw new Error("BAD_GAMEPLAY");
    return { g: g, bg: bg };
}
function hf_makeUnique(comp, L) {
    var n = 0;
    for (var i = 1; i <= comp.numLayers; i++) if (comp.layer(i).name === L.name) n++;
    if (n > 1) L.name = L.name + " [" + L.index + "]";
}

function hf_removeRigIn(comp) {
    // Removing a property invalidates references to its parent group in AE,
    // so every removal re-acquires everything from the comp.
    var i, j, found;
    for (i = comp.numLayers; i >= 1; i--) {
        if (hf_isRigName(comp.layer(i).name)) comp.layer(i).remove();
    }
    for (i = 1; i <= comp.numLayers; i++) {
        do {
            found = false;
            var fx = comp.layer(i).property("ADBE Effect Parade");
            if (!fx) break;
            for (j = fx.numProperties; j >= 1; j--) {
                if (fx.property(j).name.indexOf("HF ") === 0) {
                    fx.property(j).remove();
                    found = true;
                    break;
                }
            }
        } while (found);
    }
}
// Layer references can go stale while the rig is being removed, so tag the
// chosen layers through their comment and look them up again afterwards.
function hf_findByTag(comp, tag) {
    for (var i = 1; i <= comp.numLayers; i++) {
        var c = comp.layer(i).comment;
        if (c && c.indexOf(tag) === 0) {
            comp.layer(i).comment = c.substring(tag.length);
            return comp.layer(i);
        }
    }
    return null;
}

// ---------- expression text ----------
function hf_cornersExpr(gName, pin) {
    var s = 'var L=thisComp.layer("' + hf_esc(gName) + '");\n';
    if (pin) {
        s += 'var f=L.effect("' + hf_esc(pin.name) + '");\n' +
             'var p1=L.toComp(f(1)),p2=L.toComp(f(2)),p3=L.toComp(f(3)),p4=L.toComp(f(4));\n';
    } else {
        s += 'var w=L.width,h=L.height;\n' +
             'var p1=L.toComp([0,0]),p2=L.toComp([w,0]),p3=L.toComp([0,h]),p4=L.toComp([w,h]);\n';
    }
    return s;
}
var HF_C = 'var c=thisComp.layer("' + HF_NULL + '");\n';
var HF_D = 'var D=1-0.7*c.effect("Readability")(1)/100;\n';

// ---------- public: status ----------
function hf_status() {
    try {
        var comp = hf_comp();
        var hasRig = false;
        for (var i = 1; i <= comp.numLayers; i++) if (comp.layer(i).name === HF_NULL) hasRig = true;
        var out = { comp: comp.name, rig: hasRig, gameplay: "", pin: "", bg: "", mask: hasRig ? hf_glowMaskName(comp) : "", baked: hasRig ? hf_bakedState(comp) : "" };
        try {
            var p = hf_pick(comp);
            var pin = hf_findPin(p.g);
            out.gameplay = p.g.name; out.bg = p.bg.name; out.pin = pin ? pin.name : "";
        } catch (e) { out.pickError = e.message; }
        return hf_json(out);
    } catch (e) { return hf_err(e); }
}

// ---------- fresh-lookup helpers ----------
// AE invalidates layer/property references after many operations (adding,
// removing, duplicating, changing popups). Everything below is looked up by
// name right before it is used, and nothing is held across operations.
var HF_STAGE = "";
function hf_L(comp, name) {
    var L = comp.layer(name);
    if (!L) throw new Error("NO_LAYER " + name);
    return L;
}
function hf_E(comp, layerName, fxName) {
    var e = hf_L(comp, layerName).property("ADBE Effect Parade").property(fxName);
    if (!e) throw new Error("NO_EFFECT " + fxName);
    return e;
}
function hf_newFx(comp, layerName, matchName, fxName) {
    var e = hf_L(comp, layerName).property("ADBE Effect Parade").addProperty(matchName);
    e.name = fxName;
}
function hf_X(comp, layerName, fxName, names, idx, text, label) {
    try {
        var p = hf_prop(hf_E(comp, layerName, fxName), names, idx);
        if (!p) throw new Error("missing");
        p.expression = text;
    } catch (e) { HF_WARN.push(label); }
}
function hf_V(comp, layerName, fxName, names, idx, val, label) {
    try {
        var p = hf_prop(hf_E(comp, layerName, fxName), names, idx);
        if (!p) throw new Error("missing");
        p.setValue(val);
    } catch (e) { HF_WARN.push(label + " (value)"); }
}
function hf_ctl(comp, matchName, fxName, val) {
    hf_newFx(comp, HF_NULL, matchName, fxName);
    if (val !== undefined) hf_V(comp, HF_NULL, fxName, [], 0, val, fxName);
}
function hf_opacityExpr(comp, layerName, text, label) {
    try {
        hf_L(comp, layerName).property("ADBE Transform Group").property("ADBE Opacity").expression = text;
    } catch (e) { HF_WARN.push(label); }
}
function hf_setMatte(comp, layerName, gName, dupName) {
    var L = hf_L(comp, layerName), g = hf_L(comp, gName);
    var wasEnabled = g.enabled;
    if (typeof L.setTrackMatte === "function") {
        L.setTrackMatte(g, TrackMatteType.ALPHA);
        hf_L(comp, gName).enabled = wasEnabled;
    } else {
        var m = g.duplicate();
        m.name = dupName || "HF Matte";
        m.moveBefore(hf_L(comp, layerName));
        hf_L(comp, layerName).trackMatteType = TrackMatteType.ALPHA;
        m.enabled = false;
    }
}
function hf_clearMatte(comp, layerName) {
    var L = hf_L(comp, layerName);
    if (typeof L.removeTrackMatte === "function") L.removeTrackMatte();
    else L.trackMatteType = TrackMatteType.NO_TRACK_MATTE;
    for (var i = comp.numLayers; i >= 1; i--) if (comp.layer(i).name === "HF Glow Matte") comp.layer(i).remove();
}
function hf_glowMaskName(comp) {
    var gl = comp.layer("HF Screen Glow");
    if (!gl) return "";
    try { if (gl.trackMatteLayer) return gl.trackMatteLayer.name; } catch (e) {}
    return comp.layer("HF Glow Matte") ? "HF Glow Matte" : "";
}

// ---------- public: build ----------
function hf_build() {
    app.beginUndoGroup("HF Screen Fit: build");
    try {
        HF_WARN = [];
        HF_STAGE = "pick";
        var comp = hf_comp();
        var p = hf_pick(comp);
        p.g.comment = "HF_G|" + p.g.comment;
        p.bg.comment = "HF_BG|" + p.bg.comment;

        HF_STAGE = "cleanup";
        var keepMask = hf_glowMaskName(comp);
        if (keepMask === "HF Glow Matte") keepMask = "";
        if (keepMask) {
            var km = comp.layer(keepMask);
            km.comment = "HF_M|" + km.comment;
        }
        hf_removeRigIn(comp);
        var mL = keepMask ? hf_findByTag(comp, "HF_M|") : null;
        var gL = hf_findByTag(comp, "HF_G|"), bL = hf_findByTag(comp, "HF_BG|");
        if (!gL || !bL) throw new Error("LOST_LAYERS");
        hf_makeUnique(comp, gL);
        hf_makeUnique(comp, bL);
        var G = gL.name, B = bL.name;
        var pin = hf_findPin(gL);
        var pinName = pin ? pin.name : "";
        var GN = hf_esc(G), BN = hf_esc(B);

        // --- control null ---
        HF_STAGE = "controls";
        var n = comp.layers.addNull();
        n.name = HF_NULL;
        hf_L(comp, HF_NULL).label = 9;
        hf_L(comp, HF_NULL).moveToBeginning();
        hf_ctl(comp, "ADBE Slider Control", "Screen Exposure", 0);
        hf_ctl(comp, "ADBE Slider Control", "Black Lift", 0.02);
        hf_ctl(comp, "ADBE Slider Control", "Scene Adapt", 50);
        hf_ctl(comp, "ADBE Slider Control", "Readability", 50);
        hf_ctl(comp, "ADBE Slider Control", "Reflection", 8);
        hf_ctl(comp, "ADBE Slider Control", "Glare", 25);
        hf_ctl(comp, "ADBE Angle Control", "Light Angle", 315);
        hf_ctl(comp, "ADBE Slider Control", "Glow Intensity", 60);
        hf_ctl(comp, "ADBE Slider Control", "Glow Spread", 85);
        hf_ctl(comp, "ADBE Slider Control", "Bloom", 20);
        hf_ctl(comp, "ADBE Slider Control", "Softness", 1);
        hf_ctl(comp, "ADBE Slider Control", "Grain", 4);
        hf_ctl(comp, "ADBE Slider Control", "Saturation", -20);
        hf_ctl(comp, "ADBE Slider Control", "WB Match", 40);
        hf_ctl(comp, "ADBE Slider Control", "Motion Blur", 100);
        hf_ctl(comp, "ADBE Slider Control", "View Falloff", 60);

        HF_STAGE = "auto values";
        var corners = hf_cornersExpr(G, pin);
        hf_ctl(comp, "ADBE Point Control", "Screen Center (auto)");
        hf_X(comp, HF_NULL, "Screen Center (auto)", [], 0,
            corners + 'div(add(add(p1,p2),add(p3,p4)),4);', "Screen Center");
        hf_ctl(comp, "ADBE Slider Control", "Screen Size (auto)");
        hf_X(comp, HF_NULL, "Screen Size (auto)", [], 0,
            corners + '(length(p1,p4)+length(p2,p3))/2;', "Screen Size");
        var taper = corners +
            'var t1=length(p1,p2), b1=length(p3,p4), l1=length(p1,p3), r1=length(p2,p4);\n' +
            'var ty=(b1-t1)/Math.max(b1+t1,0.001), tx=(l1-r1)/Math.max(l1+r1,0.001);\n';
        hf_ctl(comp, "ADBE Slider Control", "Screen Tilt (auto)");
        hf_X(comp, HF_NULL, "Screen Tilt (auto)", [], 0,
            taper + 'clamp(Math.sqrt(tx*tx+ty*ty)*2,0,1);', "Screen Tilt");
        // Cheap sampling: a sparse grid of tiny samples instead of one huge
        // sampleImage (which forces a full-area read every frame and froze AE).
        var ringExpr =
            'posterizeTime(8);\n' +
            'var bg=thisComp.layer("' + BN + '");\n' +
            'var ct=effect("Screen Center (auto)")(1), s=effect("Screen Size (auto)")(1);\n' +
            'var R=Math.max(s*0.9,30), sr=0, sg=0, sb=0, n=0;\n' +
            'for (var i=0;i<12;i++) {\n' +
            '  var a=i/12*Math.PI*2;\n' +
            '  var v=bg.sampleImage(bg.fromComp(add(ct,[Math.cos(a)*R,Math.sin(a)*R])),[4,4],true,time);\n' +
            '  if (v[3]>0.5) { sr+=v[0]; sg+=v[1]; sb+=v[2]; n++; }\n' +
            '}\n' +
            'n=Math.max(n,1); sr/=n; sg/=n; sb/=n;\n';
        var gridExpr =
            'posterizeTime(8);\n' +
            'var g=thisComp.layer("' + GN + '");\n' +
            'var W=g.width, H=g.height, N=5, sr=0, sg=0, sb=0, n=0;\n' +
            'for (var i=0;i<N;i++) for (var j=0;j<N;j++) {\n' +
            '  var v=g.sampleImage([W*(i+0.5)/N,H*(j+0.5)/N],[3,3],false,time);\n' +
            '  if (v[3]>0.5) { sr+=v[0]; sg+=v[1]; sb+=v[2]; n++; }\n' +
            '}\n' +
            'n=Math.max(n,1); sr/=n; sg/=n; sb/=n;\n' +
            'var l=0.2126*sr+0.7152*sg+0.0722*sb;\n';

        // Only TWO sampling expressions, and they are created DISABLED with
        // neutral static values: nothing calls sampleImage during the build.
        // "Bake" evaluates them in small chunks; luma values derive cheaply.
        hf_ctl(comp, "ADBE Color Control", "Scene Color (auto)", [0.45, 0.45, 0.45, 1]);
        hf_X(comp, HF_NULL, "Scene Color (auto)", [], 0, ringExpr + '[sr,sg,sb,1];', "Scene Color");
        hf_ctl(comp, "ADBE Color Control", "Screen Color (auto)", [0.5, 0.5, 0.5, 1]);
        hf_X(comp, HF_NULL, "Screen Color (auto)", [], 0, gridExpr + '[sr,sg,sb,1];', "Screen Color");
        for (var bk = 0; bk < HF_BAKE.length; bk++) {
            try { hf_E(comp, HF_NULL, HF_BAKE[bk]).property(1).expressionEnabled = false; } catch (eb) {}
        }
        var lumaOf = function (src) {
            return 'var v=effect("' + src + '")(1);\n0.2126*v[0]+0.7152*v[1]+0.0722*v[2];';
        };
        hf_ctl(comp, "ADBE Slider Control", "Scene Luma (auto)");
        hf_X(comp, HF_NULL, "Scene Luma (auto)", [], 0, lumaOf("Scene Color (auto)"), "Scene Luma");
        hf_ctl(comp, "ADBE Slider Control", "Screen Luma (auto)");
        hf_X(comp, HF_NULL, "Screen Luma (auto)", [], 0, lumaOf("Screen Color (auto)"), "Screen Luma");

        // --- glare above the screen ---
        HF_STAGE = "glare";
        var gs = comp.layers.addSolid([0, 0, 0], "HF Glare", comp.width, comp.height, comp.pixelAspect, comp.duration);
        gs.name = "HF Glare";
        hf_L(comp, "HF Glare").moveBefore(hf_L(comp, G));
        hf_L(comp, "HF Glare").blendingMode = BlendingMode.SCREEN;
        hf_newFx(comp, "HF Glare", "ADBE Ramp", "HF Glare Ramp");
        var dirExpr = HF_C +
            'var ct=fromComp(c.effect("Screen Center (auto)")(1));\n' +
            'var s=c.effect("Screen Size (auto)")(1)*0.5;\n' +
            'var a=degreesToRadians(c.effect("Light Angle")(1));\n' +
            'var d=[Math.sin(a),-Math.cos(a)];\n';
        hf_X(comp, "HF Glare", "HF Glare Ramp", [], 0, dirExpr + 'add(ct,mul(d,s));', "Glare start");
        hf_V(comp, "HF Glare", "HF Glare Ramp", [], 1, [1, 1, 1, 1], "Glare colour");
        hf_X(comp, "HF Glare", "HF Glare Ramp", [], 2, dirExpr + 'sub(ct,mul(d,s));', "Glare end");
        hf_V(comp, "HF Glare", "HF Glare Ramp", [], 3, [0, 0, 0, 1], "Glare end colour");
        hf_V(comp, "HF Glare", "HF Glare Ramp", [], 4, 1, "Glare shape");
        hf_opacityExpr(comp, "HF Glare", HF_C + HF_D + 'c.effect("Glare")(1)*D;', "Glare opacity");

        // --- reflection above the screen ---
        HF_STAGE = "reflection";
        var rd = hf_L(comp, B).duplicate();
        rd.name = "HF Reflection";
        hf_L(comp, "HF Reflection").moveBefore(hf_L(comp, G));
        hf_L(comp, "HF Reflection").blendingMode = BlendingMode.SCREEN;
        hf_newFx(comp, "HF Reflection", "ADBE Box Blur2", "HF Reflection Blur");
        hf_V(comp, "HF Reflection", "HF Reflection Blur", [], 0, 60, "Reflection blur");
        hf_opacityExpr(comp, "HF Reflection", HF_C + HF_D + 'c.effect("Reflection")(1)*D;', "Reflection opacity");

        // --- far edge of a tilted screen is darker ---
        HF_STAGE = "tilt shade";
        var ts = comp.layers.addSolid([1, 1, 1], "HF Tilt Shade", comp.width, comp.height, comp.pixelAspect, comp.duration);
        ts.name = "HF Tilt Shade";
        hf_L(comp, "HF Tilt Shade").moveBefore(hf_L(comp, G));
        hf_L(comp, "HF Tilt Shade").blendingMode = BlendingMode.MULTIPLY;
        hf_newFx(comp, "HF Tilt Shade", "ADBE Ramp", "HF Tilt Ramp");
        var tdir = HF_C + taper +
            'var ct=div(add(add(p1,p2),add(p3,p4)),4);\n' +
            'var top=div(add(p1,p2),2), rgt=div(add(p2,p4),2);\n' +
            'var d=add(mul(sub(top,ct),ty),mul(sub(rgt,ct),tx));\n' +
            'var dl=length(d); if (dl<0.001) { d=[0,-1]; dl=1; }\n' +
            'd=div(d,dl);\n' +
            'var s=c.effect("Screen Size (auto)")(1)*0.5;\n';
        hf_X(comp, "HF Tilt Shade", "HF Tilt Ramp", [], 0, tdir + 'fromComp(sub(ct,mul(d,s)));', "Tilt start");
        hf_V(comp, "HF Tilt Shade", "HF Tilt Ramp", [], 1, [1, 1, 1, 1], "Tilt start colour");
        hf_X(comp, "HF Tilt Shade", "HF Tilt Ramp", [], 2, tdir + 'fromComp(add(ct,mul(d,s)));', "Tilt end");
        hf_X(comp, "HF Tilt Shade", "HF Tilt Ramp", [], 3, HF_C + HF_D + taper +
            'var k=Math.min(0.5,Math.sqrt(tx*tx+ty*ty)*4*c.effect("View Falloff")(1)/100)*D;\n' +
            '[1-k,1-k,1-k,1];', "Tilt shade amount");
        hf_V(comp, "HF Tilt Shade", "HF Tilt Ramp", [], 4, 1, "Tilt shape");

        HF_STAGE = "mattes";
        hf_setMatte(comp, "HF Glare", G);
        hf_setMatte(comp, "HF Reflection", G);
        hf_setMatte(comp, "HF Tilt Shade", G);

        // --- camera match + screen level on the gameplay layer ---
        HF_STAGE = "white balance";
        hf_newFx(comp, G, "ADBE Exposure2", "HF WB Match");
        hf_V(comp, G, "HF WB Match", [], 0, 2, "WB channels mode");
        var wbIdx = [4, 7, 10];
        for (var wi = 0; wi < 3; wi++) {
            hf_X(comp, G, "HF WB Match", [], wbIdx[wi], HF_C +
                'var v=c.effect("Scene Color (auto)")(1);\n' +
                'var l=Math.max(0.2126*v[0]+0.7152*v[1]+0.0722*v[2],0.001);\n' +
                'var k=c.effect("WB Match")(1)/100;\n' +
                'clamp(k*Math.log(Math.max(v[' + wi + '],0.001)/l)/Math.LN2,-0.6,0.6);', "WB channel " + wi);
        }

        HF_STAGE = "saturation";
        hf_newFx(comp, G, "ADBE HUE SATURATION", "HF Saturation");
        hf_X(comp, G, "HF Saturation", ["Master Saturation"], 2,
            HF_C + 'clamp(c.effect("Saturation")(1),-100,100);', "Saturation");

        HF_STAGE = "screen level";
        hf_newFx(comp, G, "ADBE Exposure2", "HF Screen Level");
        var adapt = HF_C + HF_D +
            'var ad=c.effect("Scene Adapt")(1)/100;\n' +
            'var lum=c.effect("Scene Luma (auto)")(1);\n' +
            'var hi=Math.max(0,lum-0.4);\n';
        hf_X(comp, G, "HF Screen Level", ["Exposure"], 1,
            adapt + 'c.effect("Screen Exposure")(1) - ad*hi*1.5*D\n' +
            ' - c.effect("View Falloff")(1)/100*c.effect("Screen Tilt (auto)")(1)*1.2;', "Screen exposure");
        hf_X(comp, G, "HF Screen Level", ["Offset"], 2,
            adapt + '// Exposure works in linear light: scale the lift so 0.02 reads as a gentle sRGB lift\n' +
            '(c.effect("Black Lift")(1)*D + ad*hi*0.08*D)*0.15;', "Black lift");

        HF_STAGE = "bloom";
        hf_newFx(comp, G, "ADBE Glo2", "HF Bloom");
        hf_V(comp, G, "HF Bloom", ["Glow Threshold"], 1, 70, "Bloom threshold");
        hf_X(comp, G, "HF Bloom", ["Glow Radius"], 2, HF_C +
            'clamp(c.effect("Screen Size (auto)")(1)*0.025,2,30);', "Bloom radius");
        hf_X(comp, G, "HF Bloom", ["Glow Intensity"], 3, HF_C + HF_D +
            '// bright, light-theme UIs: a big white area would bloom over the text\n' +
            'var sl=c.effect("Screen Luma (auto)")(1);\n' +
            'var f=clamp((0.75-sl)/0.4,0,1);\n' +
            'c.effect("Bloom")(1)/100*1.5*f*D;', "Bloom");

        HF_STAGE = "softness";
        hf_newFx(comp, G, "ADBE Gaussian Blur 2", "HF Softness");
        hf_X(comp, G, "HF Softness", [], 0, HF_C + HF_D + 'Math.max(0,c.effect("Softness")(1))*D;', "Softness");

        HF_STAGE = "motion blur";
        hf_newFx(comp, G, "ADBE Motion Blur", "HF Motion Blur");
        var vel = HF_C +
            'var sc=c.effect("Screen Center (auto)")(1);\n' +
            'var v=sub(sc.valueAtTime(time),sc.valueAtTime(time-thisComp.frameDuration));\n' +
            'var cut=length(v)>c.effect("Screen Size (auto)")(1)*0.5;\n';
        hf_X(comp, G, "HF Motion Blur", ["Direction"], 0,
            vel + 'length(v)<0.01 ? 0 : radiansToDegrees(Math.atan2(v[0],-v[1]));', "Motion blur direction");
        hf_X(comp, G, "HF Motion Blur", ["Blur Length"], 1,
            vel + 'cut ? 0 : length(v)*0.5*c.effect("Motion Blur")(1)/100;', "Motion blur length");

        HF_STAGE = "grain";
        hf_newFx(comp, G, "ADBE Noise", "HF Grain");
        hf_X(comp, G, "HF Grain", [], 0, HF_C + 'Math.max(0,c.effect("Grain")(1));', "Grain");

        // --- screen light spilling onto the scene (below the screen) ---
        HF_STAGE = "screen glow";
        var sg = comp.layers.addSolid([0, 0, 0], "HF Screen Glow", comp.width, comp.height, comp.pixelAspect, comp.duration);
        sg.name = "HF Screen Glow";
        hf_L(comp, "HF Screen Glow").moveAfter(hf_L(comp, G));
        hf_L(comp, "HF Screen Glow").blendingMode = BlendingMode.ADD;
        hf_newFx(comp, "HF Screen Glow", "ADBE Ramp", "HF Glow Ramp");
        hf_X(comp, "HF Screen Glow", "HF Glow Ramp", [], 0,
            HF_C + 'fromComp(c.effect("Screen Center (auto)")(1));', "Glow center");
        hf_X(comp, "HF Screen Glow", "HF Glow Ramp", [], 1, HF_C +
            'var v=c.effect("Screen Color (auto)")(1), i=c.effect("Glow Intensity")(1)/100;\n' +
            'var l=0.2126*v[0]+0.7152*v[1]+0.0722*v[2], k=1.6;\n' +
            '[clamp(l+(v[0]-l)*k,0,1)*i,clamp(l+(v[1]-l)*k,0,1)*i,clamp(l+(v[2]-l)*k,0,1)*i,1];', "Glow colour");
        hf_X(comp, "HF Screen Glow", "HF Glow Ramp", [], 2, HF_C +
            'var s=c.effect("Screen Size (auto)")(1)*c.effect("Glow Spread")(1)/100;\n' +
            'add(fromComp(c.effect("Screen Center (auto)")(1)),[s,0]);', "Glow radius");
        hf_V(comp, "HF Screen Glow", "HF Glow Ramp", [], 3, [0, 0, 0, 1], "Glow end colour");
        hf_V(comp, "HF Screen Glow", "HF Glow Ramp", [], 4, 2, "Glow shape");

        if (mL) {
            HF_STAGE = "glow mask";
            try { hf_setMatte(comp, "HF Screen Glow", mL.name, "HF Glow Matte"); }
            catch (em) { HF_WARN.push("Glow mask"); }
        }

        HF_STAGE = "done";
        try { hf_L(comp, HF_NULL).selected = true; } catch (e0) {}
        return hf_json({ ok: true, gameplay: G, bg: B, pin: pinName, warn: HF_WARN.join(" | ") });
    } catch (e) {
        return hf_json({ error: ((e && e.message) ? e.message : String(e)) +
            " [" + HF_STAGE + (e && e.line ? ", line " + e.line : "") + "]" });
    } finally {
        app.endUndoGroup();
    }
}

// ---------- public: glow mask ----------
function hf_setGlowMask() {
    app.beginUndoGroup("HF Screen Fit: glow mask");
    try {
        var comp = hf_comp();
        if (!comp.layer("HF Screen Glow")) throw new Error("NO_RIG");
        var sel = comp.selectedLayers;
        if (sel.length !== 1 || hf_isRigName(sel[0].name) || !hf_isAV(sel[0])) throw new Error("SELECT_MASK");
        hf_makeUnique(comp, sel[0]);
        var name = sel[0].name;
        hf_clearMatte(comp, "HF Screen Glow");
        hf_setMatte(comp, "HF Screen Glow", name, "HF Glow Matte");
        return hf_json({ ok: true, mask: name });
    } catch (e) { return hf_err(e, "glow mask"); }
    finally { app.endUndoGroup(); }
}
function hf_clearGlowMask() {
    app.beginUndoGroup("HF Screen Fit: clear glow mask");
    try {
        var comp = hf_comp();
        if (!comp.layer("HF Screen Glow")) throw new Error("NO_RIG");
        hf_clearMatte(comp, "HF Screen Glow");
        return hf_json({ ok: true });
    } catch (e) { return hf_err(e, "glow mask"); }
    finally { app.endUndoGroup(); }
}


function hf_bakedState(comp) {
    var n = comp.layer(HF_NULL);
    if (!n) return "";
    try {
        var p = n.property("ADBE Effect Parade").property(HF_BAKE[0]).property(1);
        if (p.expressionEnabled) return "live";
        return p.numKeys > 0 ? "baked" : "static";
    } catch (e) { return ""; }
}
// Chunked bake, driven by the panel so AE stays responsive between chunks.
// Sample times cover the work area, at most `maxSamples` of them.
function hf_bakeTimes(comp, maxSamples) {
    var fd = comp.frameDuration;
    var t0 = comp.workAreaStart, t1 = t0 + comp.workAreaDuration - fd;
    var frames = Math.max(1, Math.round((t1 - t0) / fd));
    var stepF = Math.max(4, Math.ceil(frames / Math.max(2, maxSamples)));
    var times = [];
    for (var f = 0; f <= frames; f += stepF) times.push(t0 + f * fd);
    if (times[times.length - 1] < t1 - fd * 0.5) times.push(t1);
    return times;
}
function hf_bakeBegin(maxSamples) {
    app.beginUndoGroup("HF Screen Fit: bake");
    try {
        var comp = hf_comp();
        if (!comp.layer(HF_NULL)) throw new Error("NO_RIG");
        for (var k = 0; k < HF_BAKE.length; k++) {
            var p = hf_E(comp, HF_NULL, HF_BAKE[k]).property(1);
            while (p.numKeys > 0) p.removeKey(1);
            hf_E(comp, HF_NULL, HF_BAKE[k]).property(1).expressionEnabled = true;
        }
        return hf_json({ ok: true, n: hf_bakeTimes(comp, maxSamples).length });
    } catch (e) { return hf_err(e, "bake"); }
    finally { app.endUndoGroup(); }
}
function hf_bakeChunk(maxSamples, from, to) {
    try {
        var comp = hf_comp();
        var times = hf_bakeTimes(comp, maxSamples);
        to = Math.min(to, times.length);
        for (var k = 0; k < HF_BAKE.length; k++) {
            var tt = [], vv = [];
            var p = hf_E(comp, HF_NULL, HF_BAKE[k]).property(1);
            for (var i = from; i < to; i++) { tt.push(times[i]); vv.push(p.valueAtTime(times[i], false)); }
            if (tt.length) hf_E(comp, HF_NULL, HF_BAKE[k]).property(1).setValuesAtTimes(tt, vv);
        }
        return hf_json({ ok: true, done: to });
    } catch (e) { return hf_err(e, "bake chunk"); }
}
function hf_bakeEnd() {
    try {
        var comp = hf_comp();
        for (var k = 0; k < HF_BAKE.length; k++)
            hf_E(comp, HF_NULL, HF_BAKE[k]).property(1).expressionEnabled = false;
        return hf_json({ ok: true });
    } catch (e) { return hf_err(e, "bake end"); }
}
function hf_live() {
    app.beginUndoGroup("HF Screen Fit: live");
    try {
        var comp = hf_comp();
        if (!comp.layer(HF_NULL)) throw new Error("NO_RIG");
        for (var k = 0; k < HF_BAKE.length; k++) {
            var p = hf_E(comp, HF_NULL, HF_BAKE[k]).property(1);
            while (p.numKeys > 0) p.removeKey(1);
            hf_E(comp, HF_NULL, HF_BAKE[k]).property(1).expressionEnabled = true;
        }
        return hf_json({ ok: true });
    } catch (e) { return hf_err(e, "live"); }
    finally { app.endUndoGroup(); }
}

// ---------- public: remove ----------
function hf_remove() {
    app.beginUndoGroup("HF Screen Fit: remove");
    try { hf_removeRigIn(hf_comp()); return hf_json({ ok: true }); }
    catch (e) { return hf_err(e, "remove"); }
    finally { app.endUndoGroup(); }
}

// ---------- public: frame render for analysis ----------
function hf_renderFrame(path) {
    try {
        var comp = hf_comp();
        var hidden = [];
        for (var i = 1; i <= comp.numLayers; i++) {
            var L = comp.layer(i);
            if (hf_isRigName(L.name) && L.name !== "HF Matte" && L.enabled) { L.enabled = false; hidden.push(i); }
        }
        var f = new File(path);
        var dir = f.parent;
        if (!dir.exists) dir.create();
        if (f.exists) f.remove();
        comp.saveFrameToPng(comp.time, f);
        return hf_json({ ok: true, hidden: hidden.join(",") });
    } catch (e) { return hf_err(e, "render"); }
}
function hf_restore(list) {
    try {
        var comp = hf_comp();
        if (list) {
            var a = String(list).split(",");
            for (var i = 0; i < a.length; i++) {
                var n = parseInt(a[i], 10);
                if (n >= 1 && n <= comp.numLayers) comp.layer(n).enabled = true;
            }
        }
        return hf_json({ ok: true });
    } catch (e) { return hf_err(e); }
}

// ---------- public: apply analysis ----------
function hf_apply(angle, glare, refl, expo, lift, glowI, glowS, bloom, soft, grain, sat) {
    app.beginUndoGroup("HF Screen Fit: apply analysis");
    try {
        var comp = hf_comp(), ctrl = null;
        for (var i = 1; i <= comp.numLayers; i++) if (comp.layer(i).name === HF_NULL) ctrl = comp.layer(i);
        if (!ctrl) throw new Error("NO_RIG");
        var set = function (n, v) {
            try { hf_L(comp, HF_NULL).property("ADBE Effect Parade").property(n).property(1).setValue(v); } catch (e1) {}
        };
        set("Light Angle", angle);
        set("Glare", glare);
        set("Reflection", refl);
        set("Screen Exposure", expo);
        set("Black Lift", lift);
        set("Glow Intensity", glowI);
        set("Glow Spread", glowS);
        set("Bloom", bloom);
        if (soft !== undefined) set("Softness", soft);
        if (grain !== undefined) set("Grain", grain);
        if (sat !== undefined) set("Saturation", sat);
        return hf_json({ ok: true });
    } catch (e) { return hf_err(e, "apply"); }
    finally { app.endUndoGroup(); }
}
