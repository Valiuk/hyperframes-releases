/* Smart Rename — panel side */
(function () {
  "use strict";

  var csi = new CSInterface();
  var $ = function (s) { return document.querySelector(s); };
  var state = { scope: "selection", items: [], busy: false, provider: "gemini", keys: {} };
  var STORE = "hf_smart_rename_v2";
  var FIELDS = ["provider", "model", "customModel", "frames", "thumb", "lang", "case", "template", "hint"];
  var CHECKS = ["renameFiles", "keepExt"];

  var PROVIDERS = {
    gemini: {
      label: "API-ключ Gemini",
      placeholder: "AIza...",
      keyUrl: "https://aistudio.google.com/apikey",
      models: [
        ["gemini-3.1-flash-lite", "Gemini 3.1 Flash Lite — найдешевше"],
        ["gemini-3.7-flash", "Gemini 3.7 Flash — баланс"],
        ["gemini-3.1-pro-preview", "Gemini 3.1 Pro — максимум якості"]
      ],
      def: "gemini-3.7-flash"
    },
    claude: {
      label: "API-ключ Anthropic",
      placeholder: "sk-ant-...",
      keyUrl: "https://platform.claude.com/settings/keys",
      models: [
        ["claude-haiku-4-5-20251001", "Haiku 4.5 — швидко й дешево"],
        ["claude-sonnet-5", "Sonnet 5 — баланс"],
        ["claude-opus-5", "Opus 5 — максимум якості"]
      ],
      def: "claude-sonnet-5"
    }
  };

  // ---------- налаштування ----------

  function populateModels() {
    var p = PROVIDERS[$("#provider").value] || PROVIDERS.gemini;
    var sel = $("#model");
    sel.innerHTML = "";
    p.models.forEach(function (m) {
      var o = document.createElement("option");
      o.value = m[0]; o.textContent = m[1];
      if (m[0] === p.def) o.selected = true;
      sel.appendChild(o);
    });
    $("#keyLabel").textContent = p.label;
    $("#apiKey").placeholder = p.placeholder;
  }

  function loadSettings() {
    var raw;
    try { raw = JSON.parse(localStorage.getItem(STORE) || "{}"); } catch (e) { raw = {}; }
    state.keys = raw.keys || {};
    if (raw.provider && PROVIDERS[raw.provider]) $("#provider").value = raw.provider;
    state.provider = $("#provider").value;
    populateModels();
    FIELDS.forEach(function (id) { if (raw[id] !== undefined && raw[id] !== "") $("#" + id).value = raw[id]; });
    CHECKS.forEach(function (id) { if (raw[id] !== undefined) $("#" + id).checked = raw[id]; });
    $("#apiKey").value = state.keys[state.provider] || "";
    if (raw.scope) setScope(raw.scope);
  }

  function saveSettings() {
    state.keys[state.provider] = $("#apiKey").value.trim();
    var o = { scope: state.scope, keys: state.keys };
    FIELDS.forEach(function (id) { o[id] = $("#" + id).value; });
    CHECKS.forEach(function (id) { o[id] = $("#" + id).checked; });
    try { localStorage.setItem(STORE, JSON.stringify(o)); } catch (e) {}
  }

  function cfg() {
    return {
      provider: $("#provider").value,
      apiKey: $("#apiKey").value.trim(),
      model: $("#customModel").value.trim() || $("#model").value,
      frames: parseInt($("#frames").value, 10),
      thumb: parseInt($("#thumb").value, 10),
      lang: $("#lang").value,
      caseStyle: $("#case").value,
      template: $("#template").value || "{name}",
      hint: $("#hint").value.trim(),
      renameFiles: $("#renameFiles").checked,
      keepExt: $("#keepExt").checked
    };
  }

  // ---------- міст до ExtendScript ----------

  function jsx(cmd, args) {
    return new Promise(function (resolve, reject) {
      var payload = encodeURIComponent(JSON.stringify({ cmd: cmd, args: args || {} }));
      csi.evalScript('SR_run("' + payload + '")', function (raw) {
        if (!raw || raw === "EvalScript error.") return reject(new Error("ExtendScript не відповів"));
        var res;
        try { res = JSON.parse(decodeURIComponent(raw)); }
        catch (e) { return reject(new Error("Погана відповідь AE: " + String(raw).slice(0, 120))); }
        if (res.ok) resolve(res.data); else reject(new Error(res.error));
      });
    });
  }

  function readBase64(path) {
    var nodeErr = "";
    try {
      var req = (typeof cep_node !== "undefined" && cep_node.require) ? cep_node.require
              : (typeof require === "function" ? require : null);
      if (req) {
        var fs = req("fs");
        if (!fs.existsSync(path)) throw new Error("файлу немає на диску");
        var buf = fs.readFileSync(path);
        if (!buf.length) throw new Error("файл порожній");
        return buf.toString("base64");
      }
    } catch (e) { nodeErr = e.message; }

    try {
      var r = window.cep.fs.readFile(path, window.cep.encoding.Base64);
      if (r.err) throw new Error("cep.fs код " + r.err);
      if (!r.data) throw new Error("порожні дані");
      return r.data;
    } catch (e2) {
      throw new Error("Кадр не прочитано (" + (nodeErr || e2.message) + "): " + path);
    }
  }

  // ---------- імена ----------

  function baseName(p) { return String(p).replace(/\\/g, "/").split("/").pop(); }
  function stripExt(n) { var i = n.lastIndexOf("."); return i > 0 ? n.slice(0, i) : n; }

  function words(str) {
    return String(str)
      .replace(/['\u2019\u02BC`]/g, "")
      .replace(/[^A-Za-z0-9А-Яа-яЁёЇїІіЄєҐґ]+/g, " ")
      .trim().split(/\s+/).filter(Boolean);
  }

  function caseify(str, style) {
    var w = words(str);
    if (!w.length) return "";
    switch (style) {
      case "kebab": return w.map(lc).join("-");
      case "camel": return w.map(function (x, i) { return i ? cap(lc(x)) : lc(x); }).join("");
      case "title": return w.map(function (x) { return cap(lc(x)); }).join(" ");
      case "upper": return w.map(function (x) { return x.toUpperCase(); }).join("_");
      default: return w.map(lc).join("_");
    }
    function lc(x) { return x.toLowerCase(); }
    function cap(x) { return x.charAt(0).toUpperCase() + x.slice(1); }
  }

  function sanitize(n) {
    return String(n).replace(/[\\\/:\*\?"<>\|]/g, "").replace(/^[\s\.]+|[\s\.]+$/g, "").slice(0, 120);
  }

  function composeName(c, res, info, index) {
    var map = {
      name: res.name || "",
      subject: res.subject || "",
      category: res.category || "",
      tags: (res.tags || []).slice(0, 3).join(" "),
      index: ("0" + index).slice(-2),
      orig: stripExt(baseName(info.file)),
      w: info.width,
      h: info.height,
      dur: info.isStill ? "still" : Math.max(1, Math.round(info.duration)) + "s",
      date: new Date().toISOString().slice(0, 10),
      ext: info.ext
    };
    var out = c.template.replace(/\{(\w+)\}/g, function (m, k) {
      return map[k] !== undefined ? String(map[k]) : "";
    });
    return sanitize(caseify(out, c.caseStyle));
  }

  function dedupe() {
    var seen = {};
    state.items.forEach(function (it) {
      if (!it.newName) return;
      var key = it.newName.toLowerCase();
      if (!seen[key]) { seen[key] = 1; return; }
      seen[key]++;
      it.newName = it.newName + "_" + seen[key];
    });
  }

  // ---------- модель ----------

  function systemPrompt(c) {
    var langLine = {
      lat: "Слова пиши українською, але латиницею за офіційною транслітерацією (napr. sonyachnyi_kyiv).",
      en: "Пиши англійською мовою.",
      uk: "Пиши українською кирилицею."
    }[c.lang];

    return [
      "Ти іменуєш медіафайли для монтажера в After Effects.",
      "На вході — один або кілька кадрів з файлу. Твоє завдання — коротка описова назва вмісту.",
      langLine,
      "Правила: 2–5 слів; конкретика замість загальних слів (ніяких image, video, footage, clip);",
      "спершу головний обʼєкт, потім дія або контекст; без дат, часу, номерів і розширень;",
      "не вигадуй бренди й тексти, яких не видно в кадрі.",
      c.hint ? "Додаткова вимога користувача: " + c.hint : "",
      "Відповідай ЛИШЕ JSON-обʼєктом, без пояснень і без markdown:",
      '{"name":"2-5 слів опису","subject":"головний обʼєкт, 1-2 слова","category":"people|product|city|nature|interior|screen|text|abstract|animal|food|vehicle|other","tags":["до 4 ключових слів"],"confidence":0.0}'
    ].filter(Boolean).join("\n");
  }

  function metaLine(info) {
    var kind = info.isStill ? "нерухоме зображення" : (info.isSequence ? "секвенція кадрів" : "відео");
    return "Тип: " + kind +
      "; роздільна здатність: " + info.width + "x" + info.height +
      (info.isStill ? "" : "; тривалість: " + (Math.round(info.duration * 10) / 10) + " с") +
      "; поточне імʼя: " + baseName(info.file) +
      ". Кадри подані в хронологічному порядку.";
  }

  function extractJson(text) {
    var t = String(text).trim().replace(/^```[a-z]*\s*/i, "").replace(/```\s*$/, "");
    var a = t.indexOf("{"), b = t.lastIndexOf("}");
    if (a < 0 || b < a) throw new Error("Модель повернула не JSON");
    return JSON.parse(t.slice(a, b + 1));
  }

  function post(url, headers, body, tryNo) {
    tryNo = tryNo || 1;
    return fetch(url, {
      method: "POST",
      headers: headers,
      body: JSON.stringify(body)
    }).then(function (r) {
      if (r.ok) return r.json();
      return r.text().then(function (t) {
        if ((r.status === 429 || r.status >= 500) && tryNo < 3) {
          return new Promise(function (res) { setTimeout(res, 1500 * tryNo); })
            .then(function () { return post(url, headers, body, tryNo + 1); });
        }
        throw new Error("API " + r.status + ": " + t.slice(0, 180));
      });
    });
  }

  function askGemini(c, images, info) {
    var parts = images.map(function (b64) {
      return { inline_data: { mime_type: "image/png", data: b64 } };
    });
    parts.push({ text: metaLine(info) });

    var gen = { responseMimeType: "application/json", maxOutputTokens: 2048 };
    if (/^gemini-[0-2]\./.test(c.model)) gen.temperature = 0.2;      // 3.x не приймає temperature
    else gen.thinkingConfig = { thinkingLevel: "low" };              // іменування не потребує довгих роздумів

    var body = {
      system_instruction: { parts: [{ text: systemPrompt(c) }] },
      contents: [{ role: "user", parts: parts }],
      generationConfig: gen
    };

    var url = "https://generativelanguage.googleapis.com/v1beta/models/" +
      encodeURIComponent(c.model) + ":generateContent";

    return post(url, {
      "Content-Type": "application/json",
      "x-goog-api-key": c.apiKey
    }, body).then(function (data) {
      if (data.promptFeedback && data.promptFeedback.blockReason) {
        throw new Error("Запит заблоковано: " + data.promptFeedback.blockReason);
      }
      var cand = (data.candidates || [])[0];
      if (!cand) throw new Error("Модель не повернула відповідь");
      var text = ((cand.content && cand.content.parts) || [])
        .map(function (p) { return p.text || ""; }).join("");
      if (!text) throw new Error("Порожня відповідь (finishReason: " + (cand.finishReason || "?") + ")");
      return extractJson(text);
    });
  }

  function askClaude(c, images, info) {
    var content = images.map(function (b64) {
      return { type: "image", source: { type: "base64", media_type: "image/png", data: b64 } };
    });
    content.push({ type: "text", text: metaLine(info) });

    return post("https://api.anthropic.com/v1/messages", {
      "Content-Type": "application/json",
      "x-api-key": c.apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true"
    }, {
      model: c.model,
      max_tokens: 400,
      temperature: 0.2,
      system: systemPrompt(c),
      messages: [{ role: "user", content: content }]
    }).then(function (data) {
      var text = (data.content || []).filter(function (b) { return b.type === "text"; })
        .map(function (b) { return b.text; }).join("");
      return extractJson(text);
    });
  }

  function askModel(c, images, info) {
    return c.provider === "claude" ? askClaude(c, images, info) : askGemini(c, images, info);
  }

  // ---------- UI ----------

  function status(msg) { $("#status").textContent = msg; }

  function setProgress(v) {
    var bar = $("#progress");
    if (v === null) { bar.hidden = true; return; }
    bar.hidden = false;
    $("#progressFill").style.width = Math.round(v * 100) + "%";
  }

  function setScope(s) {
    state.scope = s;
    Array.prototype.forEach.call(document.querySelectorAll(".seg-btn"), function (b) {
      b.classList.toggle("is-on", b.dataset.scope === s);
    });
  }

  function render() {
    var list = $("#list"), c = cfg();
    list.innerHTML = "";
    if (!state.items.length) {
      list.innerHTML = '<p class="empty">Порожньо. Виділіть футедж у Project і натисніть «Оновити».</p>';
      return;
    }
    state.items.forEach(function (it, i) {
      var row = document.createElement("div");
      row.className = "item" + (it.checked ? "" : " is-off");

      var cb = document.createElement("input");
      cb.type = "checkbox";
      cb.checked = it.checked;
      cb.addEventListener("change", function () {
        it.checked = cb.checked;
        row.classList.toggle("is-off", !cb.checked);
        refreshButtons();
      });

      var col = document.createElement("div");
      var old = document.createElement("div");
      old.className = "old";
      old.textContent = c.keepExt ? baseName(it.info.file) : stripExt(baseName(it.info.file));
      var meta = document.createElement("div");
      meta.className = "meta";
      meta.textContent = it.info.width + "×" + it.info.height + " · " +
        (it.info.isStill ? "still" : (Math.round(it.info.duration * 10) / 10) + "s") +
        (it.info.isSequence ? " · sequence" : "") +
        (it.info.used ? " · у " + it.info.used + " комп." : "");
      col.appendChild(old);
      col.appendChild(meta);

      if (it.newName !== undefined) {
        var inp = document.createElement("input");
        inp.type = "text";
        inp.className = "new" + (it.applied ? " is-done" : "");
        inp.value = it.newName;
        inp.addEventListener("input", function () { it.newName = inp.value; });
        col.appendChild(inp);
      }
      if (it.error) {
        var e = document.createElement("div");
        e.className = "err"; e.textContent = it.error;
        col.appendChild(e);
      }
      if (it.note) {
        var d = document.createElement("div");
        d.className = "done"; d.textContent = it.note;
        col.appendChild(d);
      }

      row.appendChild(cb);
      row.appendChild(col);
      list.appendChild(row);
    });
  }

  function refreshButtons() {
    var checked = state.items.filter(function (i) { return i.checked; });
    $("#btnAnalyze").disabled = state.busy || !checked.length;
    $("#btnAnalyze").textContent = checked.length ? "Проаналізувати (" + checked.length + ")" : "Проаналізувати";
    $("#btnApply").disabled = state.busy || !checked.filter(function (i) { return i.newName; }).length;
  }

  // ---------- сценарії ----------

  function reload() {
    status("Читаю проєкт…");
    jsx("list", { scope: state.scope }).then(function (items) {
      state.items = items.map(function (info) {
        return { info: info, checked: true };
      });
      render();
      refreshButtons();
      status(items.length
        ? "Знайдено " + items.length + " файлів."
        : (state.scope === "selection" ? "У виділенні немає футеджу." : "У проєкті немає футеджу."));
    }).catch(function (e) {
      status("Помилка: " + e.message);
    });
  }

  function pool(items, size, worker) {
    var i = 0, done = 0;
    var runners = [];
    for (var k = 0; k < Math.min(size, items.length); k++) {
      runners.push((function run() {
        if (i >= items.length) return Promise.resolve();
        var idx = i++;
        return Promise.resolve()
          .then(function () { return worker(items[idx], idx); })
          .catch(function (e) { items[idx].error = e.message; })
          .then(function () {
            done++;
            setProgress(done / items.length);
            return run();
          });
      })());
    }
    return Promise.all(runners);
  }

  function analyze() {
    var c = cfg();
    if (!c.apiKey) {
      $("#settings").hidden = false;
      status("Спершу вкажіть API-ключ " + (c.provider === "claude" ? "Anthropic" : "Gemini") + " у налаштуваннях.");
      $("#apiKey").focus();
      return;
    }
    var targets = state.items.filter(function (i) { return i.checked; });
    if (!targets.length) return;

    state.busy = true; refreshButtons();
    targets.forEach(function (t) { t.error = null; t.note = null; t.applied = false; });

    status("Знімаю кадри…");
    setProgress(0);

    var chain = Promise.resolve();
    targets.forEach(function (t, idx) {
      chain = chain.then(function () {
        return jsx("frames", { id: t.info.id, count: c.frames, maxSize: c.thumb })
          .then(function (files) { t.files = files; })
          .catch(function (e) { t.error = "Кадр не знято: " + e.message; })
          .then(function () { setProgress((idx + 1) / targets.length * 0.4); });
      });
    });

    chain.then(function () {
      status("Аналізую вміст…");
      var ready = targets.filter(function (t) { return t.files && t.files.length; });
      var done = 0;
      return pool(ready, 3, function (t) {
        var images;
        try { images = t.files.map(readBase64); }
        catch (e) { throw new Error(e.message); }
        return askModel(c, images, t.info).then(function (res) {
          t.result = res;
          t.newName = composeName(c, res, t.info, state.items.indexOf(t) + 1);
        }).then(function () {
          done++;
          setProgress(0.4 + 0.6 * done / ready.length);
          status("Аналізую вміст… " + done + "/" + ready.length);
        });
      });
    }).then(function () {
      dedupe();
      render();
      setProgress(null);
      var okCount = targets.filter(function (t) { return t.newName; }).length;
      var errCount = targets.filter(function (t) { return t.error; }).length;
      status("Готово: " + okCount + " імен" + (errCount ? ", помилок: " + errCount : "") + ". Перевірте й натисніть «Застосувати».");
      return jsx("cleanup").catch(function () {});
    }).catch(function (e) {
      setProgress(null);
      status("Помилка: " + e.message);
    }).then(function () {
      state.busy = false;
      refreshButtons();
    });
  }

  function apply() {
    var c = cfg();
    var targets = state.items.filter(function (i) { return i.checked && i.newName; });
    if (!targets.length) return;
    state.busy = true; refreshButtons();
    status("Перейменовую…");

    jsx("rename", {
      renameFiles: c.renameFiles,
      items: targets.map(function (t) { return { id: t.info.id, newName: t.newName }; })
    }).then(function (report) {
      var okCount = 0;
      report.forEach(function (r) {
        var t = state.items.filter(function (i) { return i.info.id === r.id; })[0];
        if (!t) return;
        if (r.ok) { okCount++; t.applied = true; t.error = null; t.note = r.msg || (c.renameFiles ? "Файл і елемент оновлено" : "Імʼя в проєкті оновлено"); if (r.file) t.info.file = r.file; }
        else { t.error = r.msg; }
      });
      render();
      status("Перейменовано: " + okCount + " з " + report.length + ".");
    }).catch(function (e) {
      status("Помилка: " + e.message);
    }).then(function () {
      state.busy = false;
      refreshButtons();
    });
  }

  // ---------- події ----------

  document.addEventListener("click", function (ev) {
    var b = ev.target.closest ? ev.target.closest(".seg-btn") : null;
    if (b) { setScope(b.dataset.scope); saveSettings(); reload(); }
  });

  $("#btnReload").addEventListener("click", reload);
  $("#btnSettings").addEventListener("click", function () {
    $("#settings").hidden = !$("#settings").hidden;
  });
  $("#btnAnalyze").addEventListener("click", analyze);
  $("#btnApply").addEventListener("click", apply);
  FIELDS.concat(CHECKS).forEach(function (id) {
    $("#" + id).addEventListener("change", saveSettings);
  });
  $("#apiKey").addEventListener("change", saveSettings);

  $("#provider").addEventListener("change", function () {
    state.keys[state.provider] = $("#apiKey").value.trim();
    state.provider = $("#provider").value;
    populateModels();
    $("#customModel").value = "";
    $("#apiKey").value = state.keys[state.provider] || "";
    saveSettings();
  });

  $("#keyLink").addEventListener("click", function (e) {
    e.preventDefault();
    csi.openURLInDefaultBrowser(PROVIDERS[$("#provider").value].keyUrl);
  });

  loadSettings();
  render();
  reload();
})();
