/*
 * Smart Rename — host side (ExtendScript)
 * Все, що ходить через evalScript, кодується percent-encoding (чистий ASCII),
 * тому кирилиця в іменах та шляхах не ламається.
 */

// ---------- helpers ----------

function _isImageExt(ext) {
    var list = ["png", "jpg", "jpeg", "tif", "tiff", "tga", "exr", "dpx", "psd", "bmp", "hdr", "webp"];
    ext = String(ext).toLowerCase();
    for (var i = 0; i < list.length; i++) if (list[i] === ext) return true;
    return false;
}

function _baseName(path) {
    var p = String(path).replace(/\\/g, "/");
    var i = p.lastIndexOf("/");
    return i >= 0 ? p.substring(i + 1) : p;
}

function _ext(path) {
    var n = _baseName(path);
    var i = n.lastIndexOf(".");
    return i > 0 ? n.substring(i + 1) : "";
}

function _stripExt(name) {
    var i = String(name).lastIndexOf(".");
    return i > 0 ? String(name).substring(0, i) : String(name);
}

function _sanitize(name) {
    var s = String(name);
    s = s.replace(/[\\\/:\*\?"<>\|\r\n\t]/g, "");
    s = s.replace(/\s+/g, " ");
    s = s.replace(/^[\s\.]+|[\s\.]+$/g, "");
    if (s.length > 120) s = s.substring(0, 120);
    return s;
}

function _stringify(v) {
    var t = typeof v;
    if (v === null || t === "undefined") return "null";
    if (t === "number") return isFinite(v) ? String(v) : "null";
    if (t === "boolean") return v ? "true" : "false";
    if (t === "string") {
        var out = "", c;
        for (var i = 0; i < v.length; i++) {
            c = v.charAt(i);
            if (c === '"') out += '\\"';
            else if (c === "\\") out += "\\\\";
            else if (c === "\n") out += "\\n";
            else if (c === "\r") out += "\\r";
            else if (c === "\t") out += "\\t";
            else if (v.charCodeAt(i) < 32 || v.charCodeAt(i) > 126) {
                var h = v.charCodeAt(i).toString(16);
                while (h.length < 4) h = "0" + h;
                out += "\\u" + h;
            } else out += c;
        }
        return '"' + out + '"';
    }
    if (v instanceof Array) {
        var a = [];
        for (var j = 0; j < v.length; j++) a.push(_stringify(v[j]));
        return "[" + a.join(",") + "]";
    }
    var parts = [];
    for (var k in v) {
        if (!v.hasOwnProperty(k)) continue;
        if (typeof v[k] === "function") continue;
        parts.push(_stringify(String(k)) + ":" + _stringify(v[k]));
    }
    return "{" + parts.join(",") + "}";
}

var _tmpCache = null;

function _tempFolder() {
    if (_tmpCache && _tmpCache.exists) return _tmpCache;
    var cands = [Folder.temp, Folder.userData, Folder.myDocuments];
    if (app.project.file) cands.splice(1, 0, app.project.file.parent);
    for (var i = 0; i < cands.length; i++) {
        if (!cands[i]) continue;
        try {
            var f = new Folder(cands[i].absoluteURI + "/hf_smart_rename");
            if (!f.exists) f.create();
            if (!f.exists) continue;
            var t = new File(f.absoluteURI + "/write_test.txt");
            t.open("w"); t.write("ok"); t.close();
            if (t.exists) { t.remove(); _tmpCache = f; return f; }
        } catch (e) {}
    }
    throw new Error("Немає теки з правом запису для тимчасових кадрів");
}

function _findById(id) {
    var p = app.project;
    for (var i = 1; i <= p.numItems; i++) {
        if (p.item(i).id === id) return p.item(i);
    }
    return null;
}

function _collect(item, out) {
    if (item instanceof FolderItem) {
        for (var i = 1; i <= item.numItems; i++) _collect(item.item(i), out);
    } else if (item instanceof FootageItem) {
        if (item.mainSource instanceof FileSource && item.mainSource.file) out.push(item);
    }
}

function _isSequence(item) {
    try {
        return !item.mainSource.isStill && item.hasVideo && _isImageExt(_ext(item.mainSource.file.fsName));
    } catch (e) { return false; }
}

function _info(item) {
    var f = item.mainSource.file;
    var path = f.fsName;
    return {
        id: item.id,
        name: item.name,
        file: path,
        folder: f.parent ? f.parent.fsName : "",
        ext: _ext(path),
        width: item.width,
        height: item.height,
        duration: item.duration,
        frameRate: item.frameRate,
        hasVideo: item.hasVideo,
        hasAudio: item.hasAudio,
        isStill: item.mainSource.isStill,
        isSequence: _isSequence(item),
        missing: f.exists ? false : true,
        used: item.usedIn.length
    };
}

// ---------- commands ----------

function _cmdList(args) {
    var raw = [], out = [], i;
    if (args.scope === "project") {
        for (i = 1; i <= app.project.numItems; i++) _collect(app.project.item(i), raw);
    } else {
        var sel = app.project.selection;
        for (i = 0; i < sel.length; i++) _collect(sel[i], raw);
    }
    var seen = {};
    for (i = 0; i < raw.length; i++) {
        if (seen[raw[i].id]) continue;
        seen[raw[i].id] = true;
        var inf = _info(raw[i]);
        if (!inf.hasVideo) continue;              // аудіо пропускаємо
        if (inf.missing) continue;                // офлайн пропускаємо
        out.push(inf);
    }
    return out;
}

function _cmdFrames(args) {
    var item = _findById(args.id);
    if (!item) throw new Error("Елемент не знайдено в проєкті");
    if (!item.hasVideo || !item.width) throw new Error("Немає відеопотоку");

    var maxSize = args.maxSize || 512;
    var count = args.count || 1;
    var w = item.width, h = item.height;
    var scale = Math.min(1, maxSize / Math.max(w, h));
    var cw = Math.max(4, Math.round(w * scale));
    var ch = Math.max(4, Math.round(h * scale));
    var fr = item.frameRate > 0 ? item.frameRate : 25;
    var dur = item.duration > 0 ? item.duration : 1;

    var comp = app.project.items.addComp("HF_SR_TMP", cw, ch, 1, dur, fr);
    var files = [];
    try {
        var lay = comp.layers.add(item);
        lay.property("ADBE Transform Group").property("ADBE Scale").setValue([scale * 100, scale * 100]);

        var times = [];
        if (item.mainSource.isStill || count <= 1 || dur <= 2 / fr) {
            times.push(0);
        } else {
            for (var i = 1; i <= count; i++) times.push(dur * i / (count + 1));
        }

        var folder = _tempFolder();
        for (var j = 0; j < times.length; j++) {
            var t = Math.min(times[j], Math.max(0, dur - 1 / fr));
            var f = new File(folder.absoluteURI + "/sr_" + item.id + "_" + j + ".png");
            if (f.exists) { try { f.remove(); } catch (e) {} }

            comp.saveFrameToPng(t, f);

            // AE віддає керування раніше, ніж файл долітає на диск
            var probe = new File(f.absoluteURI), waited = 0;
            while ((!probe.exists || probe.length === 0) && waited < 5000) {
                $.sleep(50);
                waited += 50;
                probe = new File(f.absoluteURI);
            }
            if (!probe.exists) throw new Error("AE не записав кадр: " + f.fsName);
            if (probe.length === 0) throw new Error("Кадр записався порожнім: " + f.fsName);

            files.push(f.fsName);
        }
    } finally {
        comp.remove();
    }
    return files;
}

function _uniqueFile(folder, base, ext, currentPath) {
    var n = 0, cand;
    while (true) {
        var nm = base + (n === 0 ? "" : "_" + n) + (ext ? "." + ext : "");
        cand = new File(folder.fsName + "/" + nm);
        if (!cand.exists || cand.fsName === currentPath) return cand;
        n++;
        if (n > 999) return cand;
    }
}

function _cmdRename(args) {
    var list = args.items || [];
    var report = [];
    if (args.renameFiles) {
        try { app.purge(PurgeTarget.ALL_CACHES); } catch (e) {}
    }
    app.beginUndoGroup("Smart Rename");
    try {
        for (var i = 0; i < list.length; i++) {
            var e = list[i];
            var r = { id: e.id, ok: false, msg: "", file: "" };
            var item = _findById(e.id);
            var nm = _sanitize(e.newName);
            if (!item) { r.msg = "Елемент зник із проєкту"; report.push(r); continue; }
            if (!nm) { r.msg = "Порожнє імʼя"; report.push(r); continue; }

            if (args.renameFiles && !_isSequence(item)) {
                var f = item.mainSource.file;
                var ext = _ext(f.fsName);
                var target = _uniqueFile(f.parent, nm, ext, f.fsName);
                if (target.fsName === f.fsName) {
                    item.name = nm; r.ok = true; r.msg = "Файл уже так називається"; r.file = f.fsName;
                } else {
                    var renamed = false;
                    try { renamed = f.rename(_baseName(target.fsName)); } catch (err) { renamed = false; }
                    if (renamed) {
                        try {
                            item.replace(new File(target.fsName));
                            item.name = nm;
                            r.ok = true; r.file = target.fsName;
                        } catch (err2) {
                            r.msg = "Файл перейменовано, але релінк не вдався: " + err2.toString();
                            r.file = target.fsName;
                        }
                    } else {
                        item.name = nm;
                        r.ok = true;
                        r.msg = "Файл зайнятий — перейменовано лише в проєкті";
                    }
                }
            } else {
                item.name = nm;
                r.ok = true;
                if (args.renameFiles) r.msg = "Секвенція — файли на диску не чіпали";
            }
            report.push(r);
        }
    } finally {
        app.endUndoGroup();
    }
    return report;
}

function _cmdCleanup() {
    var f = _tempFolder();
    var files = f.getFiles("*.png");
    for (var i = 0; i < files.length; i++) { try { files[i].remove(); } catch (e) {} }
    return files.length;
}

// ---------- entry point ----------

function SR_run(encodedPayload) {
    var res;
    try {
        var json = decodeURIComponent(encodedPayload);
        var req = eval("(" + json + ")");
        var args = req.args || {};
        var data;
        switch (req.cmd) {
            case "ping":    data = { app: app.version, project: app.project.file ? app.project.file.fsName : "" }; break;
            case "list":    data = _cmdList(args); break;
            case "frames":  data = _cmdFrames(args); break;
            case "rename":  data = _cmdRename(args); break;
            case "cleanup": data = _cmdCleanup(); break;
            default: throw new Error("Невідома команда: " + req.cmd);
        }
        res = { ok: true, data: data };
    } catch (err) {
        res = { ok: false, error: (err && err.toString) ? err.toString() : String(err) };
    }
    return encodeURIComponent(_stringify(res));
}
