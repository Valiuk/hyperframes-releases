/**
 * Currency Fiddler — host script (ExtendScript)
 * Scans text layers with a Digit Fiddler effect, reports values + currency,
 * writes back new values, decimals and Source Text.
 *
 * All strings crossing the CEP bridge are escaped to \uXXXX so that Cyrillic
 * and currency glyphs (₴ € £ ¥) survive the ExtendScript encoding.
 */

// ---------------------------------------------------------------- utilities

function CF_esc(s) {
    s = String(s);
    var out = '', c, code;
    for (var i = 0; i < s.length; i++) {
        c = s.charAt(i);
        code = s.charCodeAt(i);
        if (c === '"') { out += '\\"'; }
        else if (c === '\\') { out += '\\\\'; }
        else if (code === 10) { out += '\\n'; }
        else if (code === 13) { out += '\\r'; }
        else if (code === 9) { out += '\\t'; }
        else if (code < 32 || code > 126) {
            var h = code.toString(16);
            while (h.length < 4) { h = '0' + h; }
            out += '\\u' + h;
        }
        else { out += c; }
    }
    return '"' + out + '"';
}

function CF_num(n) {
    if (n === null || n === undefined || isNaN(n)) { return 'null'; }
    return String(n);
}

function CF_bool(b) { return b ? 'true' : 'false'; }

function CF_parse(jsonString) {
    // ExtendScript has no JSON object. Payloads come only from our own panel.
    return eval('(' + jsonString + ')');
}

// ISO 4217 codes. Matched case-sensitively so that ordinary words like "try",
// "all", "cup" or "top" are never read as currencies.
var CF_CODES = [
    'AED', 'AFN', 'ALL', 'AMD', 'ANG', 'AOA', 'ARS', 'AUD', 'AWG', 'AZN', 'BAM', 'BBD',
    'BDT', 'BGN', 'BHD', 'BIF', 'BMD', 'BND', 'BOB', 'BRL', 'BSD', 'BTN', 'BWP', 'BYN',
    'BZD', 'CAD', 'CDF', 'CHF', 'CLP', 'CNY', 'COP', 'CRC', 'CUP', 'CVE', 'CZK', 'DJF',
    'DKK', 'DOP', 'DZD', 'EGP', 'ERN', 'ETB', 'EUR', 'FJD', 'FKP', 'GBP', 'GEL', 'GGP',
    'GHS', 'GIP', 'GMD', 'GNF', 'GTQ', 'GYD', 'HKD', 'HNL', 'HTG', 'HUF', 'IDR', 'ILS',
    'IMP', 'INR', 'IQD', 'IRR', 'ISK', 'JEP', 'JMD', 'JOD', 'JPY', 'KES', 'KGS', 'KHR',
    'KMF', 'KPW', 'KRW', 'KWD', 'KYD', 'KZT', 'LAK', 'LBP', 'LKR', 'LRD', 'LSL', 'LYD',
    'MAD', 'MDL', 'MGA', 'MKD', 'MMK', 'MNT', 'MOP', 'MRU', 'MUR', 'MVR', 'MWK', 'MXN',
    'MYR', 'MZN', 'NAD', 'NGN', 'NIO', 'NOK', 'NPR', 'NZD', 'OMR', 'PAB', 'PEN', 'PGK',
    'PHP', 'PKR', 'PLN', 'PYG', 'QAR', 'RON', 'RSD', 'RUB', 'RWF', 'SAR', 'SBD', 'SCR',
    'SDG', 'SEK', 'SGD', 'SHP', 'SLE', 'SOS', 'SRD', 'SSP', 'STN', 'SVC', 'SYP', 'SZL',
    'THB', 'TJS', 'TMT', 'TND', 'TOP', 'TRY', 'TTD', 'TWD', 'TZS', 'UAH', 'UGX', 'USD',
    'UYU', 'UZS', 'VES', 'VND', 'VUV', 'WST', 'XAF', 'XCD', 'XOF', 'XPF', 'YER', 'ZAR',
    'ZMW', 'ZWL'
];

// Symbols and local spellings. Letters here match case-insensitively, so single
// ambiguous letters (L, R, K) are deliberately absent.
var CF_SYMBOL_TOKENS = [
    'Bds$', 'AR$', 'BD$', 'BZ$', 'CL$', 'CO$', 'RD$', 'FJ$', 'HK$', 'CI$', 'MX$', 'NZ$',
    'SI$', 'SR$', 'TT$', 'NT$', 'UY$', 'WS$', 'EC$', 'A$', 'B$', 'R$', 'C$', 'E\u00a3',
    'G$', 'J$', 'L\u00a3', 'L$', 'N$', 'B/', 'S/', 'S$', 'S\u00a3', 'T$', 'Z$', '\u060b',
    '\u0192', '\u20bc', '\u09f3', '\u00a5', '\u20a1', '\u20b1', '\u20ac', '\u00a3',
    '\u20be', '\u20b5', '\u20aa', '\u20b9', '\u0441', '\u17db', '\u20a9', '\u20b8',
    '\u20ad', '\u20a8', '\u20ae', '\u20a6', '\u20b2', '\u20bd', '\u0e3f', '\u20ba',
    '\u20b4', '$', '\u20ab'
];

var CF_WORD_TOKENS = [
    '\u0454\u0432\u0440\u043e', 'so\u02bbm', 'FCFA', '\u0433\u0440\u043d',
    '\u0434\u043e\u043b', '\u0440\u0443\u0431', 'lei', '\u0434\u0435\u043d',
    '\u0434\u0438\u043d', 'CFA', 'CFP', 'KSh', 'TSh', 'USh', 'z\u0142', 'zl', 'K\u010d',
    'Ft', '\u043b\u0432', 'Rp', 'RM', 'DH', 'Bs', 'Kz', 'MT', 'ZK'
];

function CF_isLetter(ch) {
    if (!ch) { return false; }
    return /[A-Za-z\u0400-\u04FF\u00C0-\u024F]/.test(ch);
}

/**
 * Letter tokens (UAH, грн, Ft, lei) must sit on word boundaries, otherwise
 * "left" would read as Hungarian forint. Symbol tokens match anywhere.
 */
function CF_tokenAt(text, tok, from, caseSensitive) {
    var startsWithLetter = CF_isLetter(tok.charAt(0));
    var endsWithLetter = CF_isLetter(tok.charAt(tok.length - 1));
    var hay = text, needle = tok;
    if (!caseSensitive && (startsWithLetter || endsWithLetter)) {
        hay = text.toLowerCase();
        needle = tok.toLowerCase();
    }
    var at = hay.indexOf(needle, from || 0);
    while (at !== -1) {
        var okLeft = !startsWithLetter || !CF_isLetter(text.charAt(at - 1));
        var okRight = !endsWithLetter || !CF_isLetter(text.charAt(at + tok.length));
        if (okLeft && okRight) { return at; }
        at = hay.indexOf(needle, at + 1);
    }
    return -1;
}

function CF_isCode(tok) {
    return /^[A-Z]{3}$/.test(tok);
}

function CF_findCurrency(text) {
    var res = { token: '', pos: '', index: -1 };
    if (!text) { return res; }
    var firstDigit = -1;
    for (var d = 0; d < text.length; d++) {
        if (text.charAt(d) >= '0' && text.charAt(d) <= '9') { firstDigit = d; break; }
    }
    // ISO codes first (unambiguous), then symbols, then local spellings.
    var groups = [
        { list: CF_CODES, strict: true },
        { list: CF_SYMBOL_TOKENS, strict: false },
        { list: CF_WORD_TOKENS, strict: false }
    ];
    for (var g = 0; g < groups.length; g++) {
        var list = groups[g].list;
        for (var i = 0; i < list.length; i++) {
            var at = CF_tokenAt(text, list[i], 0, groups[g].strict);
            if (at !== -1) {
                res.token = text.substr(at, list[i].length);
                res.index = at;
                res.pos = (firstDigit === -1 || at < firstDigit) ? 'prefix' : 'suffix';
                return res;
            }
        }
    }
    return res;
}

/** Spans of every string literal in an expression, skipping comments. */
function CF_literalSpans(expr) {
    var spans = [], i = 0, n = expr.length;
    while (i < n) {
        var ch = expr.charAt(i);
        if (ch === '"' || ch === "'") {
            var q = ch, start = i + 1, j = start;
            while (j < n) {
                if (expr.charAt(j) === '\\') { j += 2; continue; }
                if (expr.charAt(j) === q) { break; }
                if (expr.charAt(j) === '\n') { break; }
                j++;
            }
            spans.push({ start: start, end: j });
            i = j + 1;
        } else if (ch === '/' && expr.charAt(i + 1) === '/') {
            while (i < n && expr.charAt(i) !== '\n') { i++; }
        } else if (ch === '/' && expr.charAt(i + 1) === '*') {
            i += 2;
            while (i < n && !(expr.charAt(i) === '*' && expr.charAt(i + 1) === '/')) { i++; }
            i += 2;
        } else {
            i++;
        }
    }
    return spans;
}

/** Finds a currency token inside the expression's string literals only. */
function CF_findCurrencyInExpr(expr) {
    var res = { token: '', pos: '', span: -1 };
    if (!expr) { return res; }
    var spans = CF_literalSpans(expr);
    for (var s = 0; s < spans.length; s++) {
        var lit = expr.substring(spans[s].start, spans[s].end);
        if (!lit) { continue; }
        var c = CF_findCurrency(lit);
        if (c.token) {
            res.token = c.token;
            res.span = s;
            res.pos = (c.index === 0 && /^\s*$/.test(lit.substring(c.token.length))) ? 'prefix' : c.pos;
            return res;
        }
    }
    return res;
}

/** Swaps the currency token inside string literals, leaving code untouched. */
function CF_replaceCurrencyInExpr(expr, oldTok, newTok) {
    var out = { expr: expr, changed: false };
    if (!expr || !newTok) { return out; }

    var spans = CF_literalSpans(expr);
    var token = oldTok || CF_findCurrencyInExpr(expr).token;
    if (!token) { return out; }

    var result = expr, moved = false;
    for (var s = spans.length - 1; s >= 0; s--) {
        var lit = expr.substring(spans[s].start, spans[s].end);
        var strictLit = CF_isCode(token);
        var at = CF_tokenAt(lit, token, 0, strictLit);
        if (at === -1) { continue; }
        var newLit = lit;
        while (at !== -1) {
            newLit = newLit.substring(0, at) + newTok + newLit.substring(at + token.length);
            at = CF_tokenAt(newLit, token, at + newTok.length, strictLit);
        }
        result = result.substring(0, spans[s].start) + newLit + result.substring(spans[s].end);
        moved = true;
    }
    if (moved) { out.expr = result; out.changed = true; }
    return out;
}

/**
 * Appends the currency to whatever the expression returns. The last non-empty,
 * non-comment line of an AE expression is its result, so only that line moves.
 */
function CF_wrapExpression(expr, token, pos) {
    var lines = expr.split(/\r\n|\r|\n/);
    var last = -1;
    for (var i = lines.length - 1; i >= 0; i--) {
        var t = lines[i].replace(/^\s+|\s+$/g, '');
        if (!t || t.indexOf('//') === 0) { continue; }
        last = i;
        break;
    }
    if (last === -1) { return null; }

    var line = lines[last];
    var trimmed = line.replace(/\s+$/, '');
    var semi = false;
    if (trimmed.charAt(trimmed.length - 1) === ';') {
        trimmed = trimmed.substring(0, trimmed.length - 1);
        semi = true;
    }
    // A closing brace or an assignment is not a return value — don't touch it.
    if (/[}{]$/.test(trimmed) || /^\s*(var|if|for|while|function)\b/.test(trimmed)) { return null; }

    var addition = (pos === 'suffix')
        ? '(' + trimmed + ') + " ' + token + '"'
        : '"' + token + ' " + (' + trimmed + ')';

    lines[last] = addition + (semi ? ';' : '');
    return lines.join('\n');
}

function CF_extractNumber(text) {
    if (!text) { return null; }
    var m = text.match(/-?[0-9][0-9\s.,\u00A0']*[0-9]|-?[0-9]/);
    if (!m) { return null; }
    var raw = m[0].replace(/[\s\u00A0']/g, '');
    // Last separator with 1-2 trailing digits is the decimal mark.
    var lastComma = raw.lastIndexOf(',');
    var lastDot = raw.lastIndexOf('.');
    var cut = Math.max(lastComma, lastDot);
    if (cut > -1 && raw.length - cut - 1 <= 2 && raw.length - cut - 1 > 0) {
        raw = raw.substring(0, cut).replace(/[.,]/g, '') + '.' + raw.substring(cut + 1);
    } else {
        raw = raw.replace(/[.,]/g, '');
    }
    var v = parseFloat(raw);
    return isNaN(v) ? null : v;
}

// ------------------------------------------------------------------- scan

function CF_isTargetEffect(fx, opts) {
    if (opts.anyEffect) { return true; }
    var needles = opts.match || ['digit fiddler'];
    var name = String(fx.name).toLowerCase();
    var mn = String(fx.matchName).toLowerCase().replace(/[\s_-]/g, '');
    for (var i = 0; i < needles.length; i++) {
        var n = String(needles[i]).toLowerCase();
        if (!n) { continue; }
        if (name.indexOf(n) !== -1) { return true; }
        if (mn.indexOf(n.replace(/[\s_-]/g, '')) !== -1) { return true; }
    }
    return false;
}

function CF_paramInfo(p, idx) {
    var isDrop = false;
    try { isDrop = (p.isDropdownEffect === true); } catch (e) {}
    var val = null;
    try {
        if (p.propertyValueType === PropertyValueType.OneD) { val = p.value; }
    } catch (e2) {}
    var locked = false, reason = '';
    try {
        if (p.expressionEnabled) { locked = true; reason = 'expression'; }
    } catch (e3) {}
    var keys = [];
    try {
        if (p.propertyValueType === PropertyValueType.OneD) {
            for (var k = 1; k <= p.numKeys; k++) {
                keys.push({ t: p.keyTime(k), v: p.keyValue(k) });
            }
        }
    } catch (e4) {}
    return {
        idx: idx,
        name: p.name,
        matchName: p.matchName,
        oneD: (p.propertyValueType === PropertyValueType.OneD),
        isDropdown: isDrop,
        value: val,
        locked: locked,
        reason: reason,
        keys: keys
    };
}

function CF_pickValueParam(params) {
    var i, p;
    for (i = 0; i < params.length; i++) {
        p = params[i];
        if (!p.oneD || p.isDropdown) { continue; }
        if (/value|\u0437\u043D\u0430\u0447\u0435\u043D|number|amount|\u0447\u0438\u0441\u043B/i.test(p.name)) { return p; }
    }
    for (i = 0; i < params.length; i++) {
        p = params[i];
        if (p.oneD && !p.isDropdown) { return p; }
    }
    return null;
}

function CF_pickParam(params, re) {
    for (var i = 0; i < params.length; i++) {
        if (params[i].oneD && !params[i].isDropdown && re.test(params[i].name)) { return params[i]; }
    }
    return null;
}

function CF_collectComps(scope) {
    var comps = [];
    var i;
    if (scope === 'active' || scope === 'selectedLayers') {
        var it = app.project.activeItem;
        if (it && it instanceof CompItem) { comps.push(it); }
        return comps;
    }
    if (scope === 'selectedComps') {
        var sel = app.project.selection;
        for (i = 0; i < sel.length; i++) {
            if (sel[i] instanceof CompItem) { comps.push(sel[i]); }
        }
        if (comps.length) { return comps; }
    }
    for (i = 1; i <= app.project.numItems; i++) {
        if (app.project.item(i) instanceof CompItem) { comps.push(app.project.item(i)); }
    }
    return comps;
}

function CF_scan(optsJson) {
    var opts;
    try { opts = optsJson ? CF_parse(optsJson) : {}; } catch (e) { opts = {}; }
    if (!opts.scope) { opts.scope = 'active'; }

    if (!app.project) { return '{"ok":false,"error":' + CF_esc('Немає відкритого проєкту') + '}'; }

    var comps = CF_collectComps(opts.scope);
    if (!comps.length) {
        return '{"ok":false,"error":' + CF_esc('Не знайдено композицій у вибраній області') + '}';
    }

    var rows = [];
    for (var c = 0; c < comps.length; c++) {
        var comp = comps[c];
        var layers = (opts.scope === 'selectedLayers') ? comp.selectedLayers : null;
        var count = layers ? layers.length : comp.numLayers;

        for (var li = 0; li < count; li++) {
            var layer = layers ? layers[li] : comp.layer(li + 1);
            if (!(layer instanceof TextLayer)) { continue; }

            var parade = layer.property('ADBE Effect Parade');
            if (!parade || parade.numProperties === 0) { continue; }

            for (var f = 1; f <= parade.numProperties; f++) {
                var fx = parade.property(f);
                if (!CF_isTargetEffect(fx, opts)) { continue; }

                var params = [];
                for (var pi = 1; pi <= fx.numProperties; pi++) {
                    try { params.push(CF_paramInfo(fx.property(pi), pi)); } catch (ep) {}
                }
                var valP = CF_pickValueParam(params);
                if (!valP && !opts.anyEffect) { continue; }
                if (!valP) { continue; }

                var decP = CF_pickParam(params, /decimal|\u0440\u043E\u0437\u0440\u044F\u0434|\u0434\u0435\u0441\u044F\u0442/i);

                var stProp = layer.property('ADBE Text Properties').property('ADBE Text Document');
                var rawText = '';
                var evalText = '';
                var exprText = '';
                var stExpr = false;
                try { stExpr = stProp.expressionEnabled === true; } catch (e4) {}
                try { rawText = stProp.value.text; } catch (e5) { rawText = ''; }
                try { evalText = stProp.valueAtTime(comp.time, false).text; } catch (e6) { evalText = rawText; }
                if (stExpr) { try { exprText = stProp.expression; } catch (e7) { exprText = ''; } }

                // Look where we can actually edit: expression literals first, then the
                // static template text Digit Fiddler formats, then the rendered result.
                var cur = { token: '', pos: '' };
                var curSource = '';
                if (stExpr) {
                    cur = CF_findCurrencyInExpr(exprText);
                    if (cur.token) { curSource = 'expression'; }
                }
                if (!cur.token) {
                    cur = CF_findCurrency(rawText);
                    if (cur.token) { curSource = 'template'; }
                }
                if (!cur.token) {
                    cur = CF_findCurrency(evalText);
                    if (cur.token) { curSource = 'render'; }
                }
                if (curSource !== 'render') {
                    // The literal has no digits, so read the side from the rendered text.
                    var byText = CF_findCurrency(evalText || rawText);
                    if (byText.pos) { cur.pos = byText.pos; }
                }

                rows.push({
                    comp: comp.name,
                    compIdx: comp.id,
                    layer: layer.name,
                    layerIdx: layer.index,
                    fxIdx: f,
                    fxName: fx.name,
                    fxMatch: fx.matchName,
                    valIdx: valP.idx,
                    valName: valP.name,
                    value: valP.value,
                    valLocked: valP.locked,
                    valReason: valP.reason,
                    keys: valP.keys,
                    textKeys: (function () { try { return stProp.numKeys; } catch (e) { return 0; } }()),
                    fps: comp.frameRate,
                    decIdx: decP ? decP.idx : -1,
                    decimals: decP ? decP.value : null,
                    text: evalText || rawText,
                    rawText: rawText,
                    expr: exprText,
                    textExpr: stExpr,
                    currency: cur.token,
                    currencyPos: cur.pos,
                    currencySource: curSource,
                    textNumber: CF_extractNumber(evalText || rawText),
                    params: params
                });
            }
        }
    }

    // serialize
    var out = [];
    for (var r = 0; r < rows.length; r++) {
        var o = rows[r];
        var ps = [];
        for (var q = 0; q < o.params.length; q++) {
            var pp = o.params[q];
            ps.push('{"idx":' + pp.idx + ',"name":' + CF_esc(pp.name) +
                ',"oneD":' + CF_bool(pp.oneD) + ',"isDropdown":' + CF_bool(pp.isDropdown) +
                ',"value":' + CF_num(pp.value) + ',"locked":' + CF_bool(pp.locked) +
                ',"reason":' + CF_esc(pp.reason) + '}');
        }
        out.push('{' +
            '"comp":' + CF_esc(o.comp) + ',"compIdx":' + o.compIdx +
            ',"layer":' + CF_esc(o.layer) + ',"layerIdx":' + o.layerIdx +
            ',"fxIdx":' + o.fxIdx + ',"fxName":' + CF_esc(o.fxName) +
            ',"fxMatch":' + CF_esc(o.fxMatch) +
            ',"valIdx":' + o.valIdx + ',"valName":' + CF_esc(o.valName) +
            ',"value":' + CF_num(o.value) +
            ',"valLocked":' + CF_bool(o.valLocked) + ',"valReason":' + CF_esc(o.valReason) +
            ',"keys":' + CF_keysJson(o.keys) + ',"textKeys":' + o.textKeys +
            ',"fps":' + CF_num(o.fps) +
            ',"decIdx":' + o.decIdx + ',"decimals":' + CF_num(o.decimals) +
            ',"text":' + CF_esc(o.text) + ',"rawText":' + CF_esc(o.rawText) +
            ',"expr":' + CF_esc(o.expr) + ',"textExpr":' + CF_bool(o.textExpr) +
            ',"currency":' + CF_esc(o.currency) + ',"currencyPos":' + CF_esc(o.currencyPos) +
            ',"currencySource":' + CF_esc(o.currencySource) +
            ',"textNumber":' + CF_num(o.textNumber) +
            ',"params":[' + ps.join(',') + ']' +
            '}');
    }
    return '{"ok":true,"rows":[' + out.join(',') + ']}';
}

function CF_keysJson(keys) {
    var parts = [];
    for (var i = 0; i < keys.length; i++) {
        parts.push('{"t":' + CF_num(keys[i].t) + ',"v":' + CF_num(keys[i].v) + '}');
    }
    return '[' + parts.join(',') + ']';
}

// ------------------------------------------------------------------ write

function CF_compById(id) {
    for (var i = 1; i <= app.project.numItems; i++) {
        var it = app.project.item(i);
        if (it instanceof CompItem && it.id === id) { return it; }
    }
    return null;
}

/**
 * Writes a number without creating new keyframes.
 *  - keys given  -> each existing key gets its own value (by key index)
 *  - animated, no keys given -> every existing key gets the same value
 *  - static      -> plain setValue
 */
function CF_setOneD(prop, comp, value, keys) {
    if (prop.expressionEnabled) { return 'expression'; }
    var n = prop.numKeys;
    if (n > 0) {
        if (keys && keys.length) {
            if (keys.length !== n) { return 'keycount'; }
            for (var k = 0; k < keys.length; k++) {
                if (keys[k] !== null && keys[k] !== undefined) {
                    prop.setValueAtKey(k + 1, keys[k]);
                }
            }
            return 'keys';
        }
        if (value === null || value === undefined) { return 'skip'; }
        for (var j = 1; j <= n; j++) { prop.setValueAtKey(j, value); }
        return 'keys';
    }
    if (value === null || value === undefined) { return 'skip'; }
    prop.setValue(value);
    return 'ok';
}

/**
 * Reduces a text to just the currency marker. The whitespace that separated
 * it from the number is kept, so "45,000.00 BRL" becomes " MYR", not "MYR".
 */
function CF_currencyOnly(text, oldTok, newTok, pos) {
    var tok = oldTok || CF_findCurrency(text).token;
    if (!tok) { return newTok; }
    var at = CF_tokenAt(text, tok, 0, CF_isCode(tok));
    if (at === -1) { return newTok; }

    var before = text.substring(0, at);
    var after = text.substring(at + tok.length);
    if (pos === 'suffix') {
        var gapL = before.match(/[ \u00A0\u202F]+$/);
        return (gapL && /[0-9]/.test(before) ? gapL[0] : '') + newTok;
    }
    var gapR = after.match(/^[ \u00A0\u202F]+/);
    return newTok + (gapR && /[0-9]/.test(after) ? gapR[0] : '');
}

/** Applies fn to the static TextDocument, on every text keyframe if there are any. */
function CF_editTextDoc(stProp, fn) {
    var n = stProp.numKeys, changed = false, td, before;
    if (n > 0) {
        for (var k = 1; k <= n; k++) {
            td = stProp.keyValue(k);
            before = td.text;
            td.text = fn(before);
            if (td.text !== before) { stProp.setValueAtKey(k, td); changed = true; }
        }
        return changed;
    }
    td = stProp.value;
    before = td.text;
    td.text = fn(before);
    if (td.text !== before) { stProp.setValue(td); changed = true; }
    return changed;
}

function CF_replaceCurrency(text, oldTok, newTok, pos, allowAppend) {
    if (!newTok) { return text; }
    var token = oldTok;
    if (!token) { token = CF_findCurrency(text).token; }

    if (token) {
        var strict = CF_isCode(token);
        var at = CF_tokenAt(text, token, 0, strict);
        var out = text, changed = false;
        while (at !== -1) {
            out = out.substring(0, at) + newTok + out.substring(at + token.length);
            changed = true;
            at = CF_tokenAt(out, token, at + newTok.length, strict);
        }
        if (changed) { return out; }
    }

    if (!allowAppend) { return text; }
    if (!text) { return newTok; }
    return (pos === 'suffix') ? (text + ' ' + newTok) : (newTok + ' ' + text);
}

function CF_apply(payloadJson) {
    var payload;
    try { payload = CF_parse(payloadJson); } catch (e) {
        return '{"ok":false,"error":' + CF_esc('Не вдалося прочитати дані: ' + e.toString()) + '}';
    }
    var items = payload.items || [];
    var applied = 0, skipped = 0, notes = [];

    app.beginUndoGroup('Currency Fiddler — застосувати зміни');
    try {
        for (var i = 0; i < items.length; i++) {
            var it = items[i];
            var comp = CF_compById(it.compIdx);
            if (!comp) { skipped++; notes.push('Композицію не знайдено: ' + it.comp); continue; }
            var layer = comp.layer(it.layerIdx);
            if (!layer) { skipped++; notes.push('Шар не знайдено: ' + it.layer); continue; }

            var fx = layer.property('ADBE Effect Parade').property(it.fxIdx);
            if (!fx) { skipped++; notes.push('Ефект не знайдено на шарі ' + layer.name); continue; }

            var touched = false;

            var vp = fx.property(it.valIdx);
            var st = CF_setOneD(vp, comp, it.value, it.keys);
            if (st === 'expression') {
                notes.push(layer.name + ': на значенні є вираз, пропущено');
            } else if (st === 'keycount') {
                notes.push(layer.name + ': кількість ключів змінилась після сканування — проскануй ще раз');
            } else if (st === 'keys' || st === 'ok') {
                touched = true;
            }

            if (it.decimals !== null && it.decimals !== undefined && it.decIdx > 0) {
                try {
                    var dst = CF_setOneD(fx.property(it.decIdx), comp, it.decimals, null);
                    if (dst === 'keys' || dst === 'ok') { touched = true; }
                } catch (ed) {}
            }

            if (it.params) {
                for (var k = 0; k < it.params.length; k++) {
                    try { CF_setOneD(fx.property(it.params[k].idx), comp, it.params[k].value, null); touched = true; } catch (ek) {}
                }
            }

            var stProp = layer.property('ADBE Text Properties').property('ADBE Text Document');

            if (it.newExpr !== null && it.newExpr !== undefined && it.newExpr !== '') {
                // Manual expression override wins over everything else.
                try {
                    stProp.expression = it.newExpr;
                    touched = true;
                } catch (ex1) {
                    notes.push(layer.name + ': вираз відхилено — ' + ex1.toString());
                }
            } else if (it.newText !== null && it.newText !== undefined) {
                var manual = it.newText;
                if (CF_editTextDoc(stProp, function () { return manual; })) { touched = true; }
            } else if (it.newCurrency !== null && it.newCurrency !== undefined && it.newCurrency !== '') {
                var swapped = false;

                // 1. The expression's own string literals.
                if (stProp.expressionEnabled) {
                    var swap = CF_replaceCurrencyInExpr(stProp.expression, it.currency, it.newCurrency);
                    if (swap.changed) {
                        try {
                            stProp.expression = swap.expr;
                            swapped = true;
                            touched = true;
                        } catch (ex2) {
                            notes.push(layer.name + ': вираз не прийнявся — ' + ex2.toString());
                        }
                    }
                }

                // 2. The static TextDocument. The number lives in Digit Fiddler, so
                //    the text keeps nothing but the currency marker.
                if (!swapped) {
                    var oldTok = it.currency, newTok = it.newCurrency, side = it.currencyPos;
                    var hasTok = false;
                    CF_editTextDoc(stProp, function (t) {
                        var tok = oldTok || CF_findCurrency(t).token;
                        if (tok && CF_tokenAt(t, tok, 0, CF_isCode(tok)) !== -1) { hasTok = true; }
                        return t;
                    });
                    if (hasTok && CF_editTextDoc(stProp, function (t) {
                        return CF_currencyOnly(t, oldTok, newTok, side);
                    })) {
                        swapped = true;
                        touched = true;
                    }
                }

                // 3. Nothing to replace — append only if the user allowed it.
                if (!swapped && it.allowAppend) {
                    if (stProp.expressionEnabled) {
                        var wrapped = CF_wrapExpression(stProp.expression, it.newCurrency, it.currencyPos || 'suffix');
                        if (wrapped) {
                            try {
                                stProp.expression = wrapped;
                                swapped = true;
                                touched = true;
                                notes.push(layer.name + ': валюту дописано в кінець виразу');
                            } catch (ex3) {
                                notes.push(layer.name + ': вираз не прийнявся — ' + ex3.toString());
                            }
                        }
                    } else {
                        var onlyTok = it.newCurrency;
                        CF_editTextDoc(stProp, function () { return onlyTok; });
                        swapped = true;
                        touched = true;
                        notes.push(layer.name + ': Source Text замінено на позначку валюти');
                    }
                }

                if (!swapped) {
                    notes.push(layer.name + ': «' + it.currency + '» не знайдено ні в тексті, ні у виразі');
                }
            }

            if (touched) { applied++; } else { skipped++; }
        }
    } catch (err) {
        app.endUndoGroup();
        return '{"ok":false,"error":' + CF_esc(err.toString()) + '}';
    }
    app.endUndoGroup();

    var ns = [];
    for (var n = 0; n < notes.length; n++) { ns.push(CF_esc(notes[n])); }
    return '{"ok":true,"applied":' + applied + ',"skipped":' + skipped + ',"notes":[' + ns.join(',') + ']}';
}

function CF_reveal(compId, layerIdx) {
    var comp = CF_compById(compId);
    if (!comp) { return '{"ok":false}'; }
    comp.openInViewer();
    for (var i = 1; i <= comp.numLayers; i++) { comp.layer(i).selected = false; }
    var l = comp.layer(layerIdx);
    if (l) { l.selected = true; }
    return '{"ok":true}';
}
