/**
 * Minimal CEP bridge. Wraps window.__adobe_cep__ so the panel does not need
 * the full CSInterface.js bundle.
 */
(function (global) {
    'use strict';

    var cep = global.__adobe_cep__;

    function available() {
        return !!(cep && typeof cep.evalScript === 'function');
    }

    function evalScript(script) {
        return new Promise(function (resolve, reject) {
            if (!available()) {
                reject(new Error('Панель запущена поза After Effects'));
                return;
            }
            try {
                cep.evalScript(script, function (result) {
                    if (result === 'EvalScript error.') {
                        reject(new Error('Помилка в host-скрипті. Перевір консоль CEP.'));
                        return;
                    }
                    resolve(result);
                });
            } catch (e) {
                reject(e);
            }
        });
    }

    /** Encodes an argument so it survives being embedded in an evalScript string. */
    function quote(value) {
        var json = JSON.stringify(value);
        var out = '';
        for (var i = 0; i < json.length; i++) {
            var code = json.charCodeAt(i);
            var ch = json.charAt(i);
            if (ch === '\\') { out += '\\\\'; }
            else if (ch === "'") { out += "\\'"; }
            else if (code < 32 || code > 126) {
                var h = code.toString(16);
                while (h.length < 4) { h = '0' + h; }
                out += '\\u' + h;
            } else { out += ch; }
        }
        return "'" + out + "'";
    }

    async function call(fn, arg) {
        var script = (arg === undefined)
            ? fn + '()'
            : fn + '(' + quote(arg) + ')';
        var raw = await evalScript(script);
        try {
            return JSON.parse(raw);
        } catch (e) {
            throw new Error('Некоректна відповідь host-скрипта: ' + String(raw).slice(0, 200));
        }
    }

    function hostVersion() {
        if (!cep || !cep.getHostEnvironment) { return null; }
        try { return JSON.parse(cep.getHostEnvironment()).appVersion; }
        catch (e) { return null; }
    }

    global.CEP = { available: available, call: call, evalScript: evalScript, hostVersion: hostVersion };
}(window));
