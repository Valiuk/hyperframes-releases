/**
 * Currency Fiddler — panel logic.
 */
(function () {
    'use strict';

    // ------------------------------------------------------------ currencies

    // Full ISO 4217 list. The rate feed can add anything missing at runtime.
    var CODES = [
        'AED', 'AFN', 'ALL', 'AMD', 'ANG', 'AOA', 'ARS', 'AUD', 'AWG', 'AZN', 'BAM', 'BBD',
        'BDT', 'BGN', 'BHD', 'BIF', 'BMD', 'BND', 'BOB', 'BRL', 'BSD', 'BTN', 'BWP', 'BYN',
        'BZD', 'CAD', 'CDF', 'CHF', 'CLP', 'CNY', 'COP', 'CRC', 'CUP', 'CVE', 'CZK', 'DJF',
        'DKK', 'DOP', 'DZD', 'EGP', 'ERN', 'ETB', 'EUR', 'FJD', 'FKP', 'GBP', 'GEL', 'GGP',
        'GHS', 'GIP', 'GMD', 'GNF', 'GTQ', 'GYD', 'HKD', 'HNL', 'HTG', 'HUF', 'IDR', 'ILS',
        'IMP', 'INR', 'IQD', 'IRR', 'ISK', 'JEP', 'JMD', 'JOD', 'JPY', 'KES', 'KGS', 'KHR',
        'KMF', 'KPW', 'KRW', 'KWD', 'KYD', 'KZT', 'LAK', 'LBP', 'LKR', 'LRD', 'LSL', 'LYD',
        'MAD', 'MDL', 'MGA', 'MKD', 'MMK', 'MNT', 'MOP', 'MRU', 'MUR', 'MVR', 'MWK', 'MXN',
        'MYR', 'MZN', 'NAD', 'NGN', 'NIO', 'NOK', 'NPR', 'NZD', 'OMR', 'PAB', 'PEN', 'PGK',
        'PHP', 'PKR', 'PLN', 'PYG', 'QAR', 'RON', 'RSD', 'RUB', 'RWF', 'SAR', 'SBD', 'SCR',
        'SDG', 'SEK', 'SGD', 'SHP', 'SLE', 'SOS', 'SRD', 'SSP', 'STN', 'SVC', 'SYP', 'SZL',
        'THB', 'TJS', 'TMT', 'TND', 'TOP', 'TRY', 'TTD', 'TWD', 'TZS', 'UAH', 'UGX', 'USD',
        'UYU', 'UZS', 'VES', 'VND', 'VUV', 'WST', 'XAF', 'XCD', 'XOF', 'XPF', 'YER', 'ZAR',
        'ZMW', 'ZWL'
    ];

    // Display symbol per code; anything absent renders as the code itself.
    var SYMBOLS = {
        USD: '$', EUR: '\u20ac', GBP: '\u00a3', JPY: '\u00a5', CNY: '\u00a5',
        UAH: '\u20b4', RUB: '\u20bd', KZT: '\u20b8', GEL: '\u20be', TRY: '\u20ba',
        INR: '\u20b9', KRW: '\u20a9', KPW: '\u20a9', THB: '\u0e3f', ILS: '\u20aa',
        VND: '\u20ab', PHP: '\u20b1', NGN: '\u20a6', PYG: '\u20b2', LAK: '\u20ad',
        MNT: '\u20ae', KHR: '\u17db', CRC: '\u20a1', SVC: '\u20a1', GHS: '\u20b5',
        AZN: '\u20bc', PLN: 'z\u0142', CZK: 'K\u010d', HUF: 'Ft', RON: 'lei',
        BGN: '\u043b\u0432', BRL: 'R$', CAD: 'C$', AUD: 'A$', NZD: 'NZ$', SGD: 'S$',
        HKD: 'HK$', TWD: 'NT$', MXN: 'MX$', ARS: 'AR$', CLP: 'CL$', COP: 'CO$', UYU: 'UY$',
        DOP: 'RD$', JMD: 'J$', TTD: 'TT$', BZD: 'BZ$', BND: 'B$', BSD: 'B$', GYD: 'G$',
        XCD: 'EC$', FJD: 'FJ$', NAD: 'N$', SRD: 'SR$', SBD: 'SI$', LRD: 'L$', ZWL: 'Z$',
        BMD: 'BD$', KYD: 'CI$', BBD: 'Bds$', EGP: 'E\u00a3', LBP: 'L\u00a3',
        SYP: 'S\u00a3', SHP: '\u00a3', FKP: '\u00a3', GIP: '\u00a3', JEP: '\u00a3',
        GGP: '\u00a3', IMP: '\u00a3', SDG: 'SDG', ZAR: 'R', IDR: 'Rp', MYR: 'RM',
        CHF: 'CHF', NOK: 'kr', SEK: 'kr', DKK: 'kr', ISK: 'kr', PKR: '\u20a8',
        LKR: '\u20a8', NPR: '\u20a8', MUR: '\u20a8', SCR: '\u20a8', AWG: '\u0192',
        ANG: '\u0192', AOA: 'Kz', MMK: 'K', MWK: 'MK', VES: 'Bs', BOB: 'Bs', PEN: 'S/',
        MAD: 'DH', AED: 'AED', SAR: 'SAR', QAR: 'QAR', KWD: 'KD', BHD: 'BD', OMR: 'OMR',
        JOD: 'JD', IQD: 'IQD', IRR: 'IRR', YER: 'YER', TND: 'DT', DZD: 'DA', LYD: 'LD',
        AFN: '\u060b', UZS: 'so\u02bbm', TMT: 'TMT', TJS: 'SM', KGS: '\u0441', BYN: 'Br',
        MDL: 'MDL', MKD: '\u0434\u0435\u043d', RSD: '\u0434\u0438\u043d', ALL: 'L',
        BAM: 'KM', HTG: 'G', HNL: 'L', NIO: 'C$', GTQ: 'Q', PAB: 'B/', CUP: '\u20b1',
        CVE: 'CVE', STN: 'Db', MZN: 'MT', ZMW: 'ZK', BWP: 'P', LSL: 'L', SZL: 'L',
        KES: 'KSh', TZS: 'TSh', UGX: 'USh', RWF: 'FRw', ETB: 'Br', ERN: 'Nfk', DJF: 'Fdj',
        SOS: 'Sh', SSP: 'SSP', GMD: 'D', GNF: 'FG', SLE: 'Le', XAF: 'FCFA', XOF: 'CFA',
        XPF: 'CFP', CDF: 'FC', BIF: 'FBu', KMF: 'CF', MGA: 'Ar', MVR: 'Rf', BTN: 'Nu',
        BDT: '\u09f3', MOP: 'MOP', MRU: 'UM', WST: 'WS$', TOP: 'T$', VUV: 'VT', PGK: 'K',
        SLL: 'Le'
    };

    // Tokens that may literally appear in a text layer, mapped to a code.
    var TOKEN_TO_CODE = {
        'Bds$': 'BBD', 'AR$': 'ARS', 'BD$': 'BMD', 'BZ$': 'BZD', 'CL$': 'CLP',
        'CO$': 'COP', 'RD$': 'DOP', 'FJ$': 'FJD', 'HK$': 'HKD', 'CI$': 'KYD', 'MX$': 'MXN',
        'NZ$': 'NZD', 'SI$': 'SBD', 'SR$': 'SRD', 'TT$': 'TTD', 'NT$': 'TWD', 'UY$': 'UYU',
        'WS$': 'WST', 'EC$': 'XCD', 'A$': 'AUD', 'B$': 'BND', 'R$': 'BRL', 'C$': 'CAD',
        'E\u00a3': 'EGP', 'G$': 'GYD', 'J$': 'JMD', 'L\u00a3': 'LBP', 'L$': 'LRD',
        'N$': 'NAD', 'B/': 'PAB', 'S/': 'PEN', 'S$': 'SGD', 'S\u00a3': 'SYP', 'T$': 'TOP',
        'Z$': 'ZWL', '\u060b': 'AFN', ƒ: 'ANG', '\u20bc': 'AZN', '\u09f3': 'BDT',
        '\u00a5': 'JPY', '\u20a1': 'CRC', '\u20b1': 'CUP', '\u20ac': 'EUR',
        '\u00a3': 'GBP', '\u20be': 'GEL', '\u20b5': 'GHS', '\u20aa': 'ILS',
        '\u20b9': 'INR', с: 'KGS', '\u17db': 'KHR', '\u20a9': 'KRW', '\u20b8': 'KZT',
        '\u20ad': 'LAK', '\u20a8': 'PKR', '\u20ae': 'MNT', '\u20a6': 'NGN',
        '\u20b2': 'PYG', '\u20bd': 'RUB', '\u0e3f': 'THB', '\u20ba': 'TRY',
        '\u20b4': 'UAH', '$': 'USD', '\u20ab': 'VND', soʻm: 'UZS', FCFA: 'XAF', lei: 'RON',
        ден: 'MKD', дин: 'RSD', CFA: 'XOF', CFP: 'XPF', KSh: 'KES', TSh: 'TZS', USh: 'UGX',
        zł: 'PLN', Kč: 'CZK', Ft: 'HUF', лв: 'BGN', Rp: 'IDR', RM: 'MYR', DH: 'MAD',
        Bs: 'BOB', Kz: 'AOA', MT: 'MZN', ZK: 'ZMW', грн: 'UAH', євро: 'EUR', дол: 'USD',
        руб: 'RUB', zl: 'PLN', AED: 'AED', AFN: 'AFN', ALL: 'ALL', AMD: 'AMD', ANG: 'ANG',
        AOA: 'AOA', ARS: 'ARS', AUD: 'AUD', AWG: 'AWG', AZN: 'AZN', BAM: 'BAM', BBD: 'BBD',
        BDT: 'BDT', BGN: 'BGN', BHD: 'BHD', BIF: 'BIF', BMD: 'BMD', BND: 'BND', BOB: 'BOB',
        BRL: 'BRL', BSD: 'BSD', BTN: 'BTN', BWP: 'BWP', BYN: 'BYN', BZD: 'BZD', CAD: 'CAD',
        CDF: 'CDF', CHF: 'CHF', CLP: 'CLP', CNY: 'CNY', COP: 'COP', CRC: 'CRC', CUP: 'CUP',
        CVE: 'CVE', CZK: 'CZK', DJF: 'DJF', DKK: 'DKK', DOP: 'DOP', DZD: 'DZD', EGP: 'EGP',
        ERN: 'ERN', ETB: 'ETB', EUR: 'EUR', FJD: 'FJD', FKP: 'FKP', GBP: 'GBP', GEL: 'GEL',
        GGP: 'GGP', GHS: 'GHS', GIP: 'GIP', GMD: 'GMD', GNF: 'GNF', GTQ: 'GTQ', GYD: 'GYD',
        HKD: 'HKD', HNL: 'HNL', HTG: 'HTG', HUF: 'HUF', IDR: 'IDR', ILS: 'ILS', IMP: 'IMP',
        INR: 'INR', IQD: 'IQD', IRR: 'IRR', ISK: 'ISK', JEP: 'JEP', JMD: 'JMD', JOD: 'JOD',
        JPY: 'JPY', KES: 'KES', KGS: 'KGS', KHR: 'KHR', KMF: 'KMF', KPW: 'KPW', KRW: 'KRW',
        KWD: 'KWD', KYD: 'KYD', KZT: 'KZT', LAK: 'LAK', LBP: 'LBP', LKR: 'LKR', LRD: 'LRD',
        LSL: 'LSL', LYD: 'LYD', MAD: 'MAD', MDL: 'MDL', MGA: 'MGA', MKD: 'MKD', MMK: 'MMK',
        MNT: 'MNT', MOP: 'MOP', MRU: 'MRU', MUR: 'MUR', MVR: 'MVR', MWK: 'MWK', MXN: 'MXN',
        MYR: 'MYR', MZN: 'MZN', NAD: 'NAD', NGN: 'NGN', NIO: 'NIO', NOK: 'NOK', NPR: 'NPR',
        NZD: 'NZD', OMR: 'OMR', PAB: 'PAB', PEN: 'PEN', PGK: 'PGK', PHP: 'PHP', PKR: 'PKR',
        PLN: 'PLN', PYG: 'PYG', QAR: 'QAR', RON: 'RON', RSD: 'RSD', RUB: 'RUB', RWF: 'RWF',
        SAR: 'SAR', SBD: 'SBD', SCR: 'SCR', SDG: 'SDG', SEK: 'SEK', SGD: 'SGD', SHP: 'SHP',
        SLE: 'SLE', SOS: 'SOS', SRD: 'SRD', SSP: 'SSP', STN: 'STN', SVC: 'SVC', SYP: 'SYP',
        SZL: 'SZL', THB: 'THB', TJS: 'TJS', TMT: 'TMT', TND: 'TND', TOP: 'TOP', TRY: 'TRY',
        TTD: 'TTD', TWD: 'TWD', TZS: 'TZS', UAH: 'UAH', UGX: 'UGX', USD: 'USD', UYU: 'UYU',
        UZS: 'UZS', VES: 'VES', VND: 'VND', VUV: 'VUV', WST: 'WST', XAF: 'XAF', XCD: 'XCD',
        XOF: 'XOF', XPF: 'XPF', YER: 'YER', ZAR: 'ZAR', ZMW: 'ZMW', ZWL: 'ZWL'
    };

    // Approximate starting rates per 1 USD. Editable, and replaced wholesale by
    // «Оновити» — treat them as placeholders, not as market data.
    var DEFAULT_RATES = {
        USD: 1, EUR: 0.92, UAH: 41.5, GBP: 0.78, PLN: 4.0, CZK: 23.2, HUF: 360, RON: 4.58,
        BGN: 1.8, CHF: 0.88, SEK: 10.5, NOK: 10.8, DKK: 6.87, ISK: 138, TRY: 34.5,
        KZT: 480, GEL: 2.7, MDL: 17.8, AZN: 1.7, AMD: 388, BYN: 3.27, RSD: 108, MKD: 56.5,
        ALL: 92, BAM: 1.8, JPY: 155, CNY: 7.2, KRW: 1380, TWD: 32.3, HKD: 7.79, SGD: 1.34,
        MOP: 8.03, INR: 84, PKR: 278, BDT: 120, LKR: 295, NPR: 134, MMK: 2100, KHR: 4050,
        LAK: 21800, MNT: 3400, THB: 34.2, VND: 25200, IDR: 15800, MYR: 4.42, PHP: 58,
        BND: 1.34, AUD: 1.52, NZD: 1.66, CAD: 1.37, MXN: 18.5, BRL: 5.5, ARS: 1000,
        CLP: 960, COP: 4200, PEN: 3.75, BOB: 6.9, PYG: 7800, UYU: 41, GTQ: 7.7, DOP: 60,
        CRC: 510, HNL: 24.8, NIO: 36.8, JMD: 157, TTD: 6.8, PAB: 1, BSD: 1, SVC: 8.75,
        CUP: 24, EGP: 48.5, MAD: 9.9, TND: 3.1, DZD: 133, NGN: 1560, KES: 129, GHS: 15.5,
        ETB: 122, TZS: 2700, UGX: 3700, ZMW: 26, MZN: 64, AOA: 910, ZAR: 18.2, XOF: 605,
        XAF: 605, ILS: 3.72, AED: 3.67, SAR: 3.75, QAR: 3.64, KWD: 0.307, BHD: 0.377,
        OMR: 0.385, JOD: 0.709, IQD: 1310, LBP: 89500, RUB: 92, UZS: 12800
    };

    var state = {
        rows: [],
        rates: Object.assign({}, DEFAULT_RATES),
        ratesLabel: 'курси введено вручну'
    };

    var $ = function (id) { return document.getElementById(id); };
    var fmt = new Intl.NumberFormat('uk-UA', { maximumFractionDigits: 4 });

    // ---------------------------------------------------------- persistence

    function loadPrefs() {
        try {
            var raw = window.localStorage.getItem('currencyFiddler');
            if (!raw) { return; }
            var p = JSON.parse(raw);
            if (p.rates) { state.rates = Object.assign({}, DEFAULT_RATES, p.rates); }
            if (p.ratesLabel) { state.ratesLabel = p.ratesLabel; }
            if (p.toCur) { state.savedTo = p.toCur; }
            if (p.ratesUrl) { $('ratesUrl').value = p.ratesUrl; }
        } catch (e) { /* prefs are optional */ }
    }

    function savePrefs() {
        try {
            window.localStorage.setItem('currencyFiddler', JSON.stringify({
                rates: state.rates,
                ratesLabel: state.ratesLabel,
                toCur: $('toCur').value,
                ratesUrl: $('ratesUrl').value
            }));
        } catch (e) { /* prefs are optional */ }
    }

    // -------------------------------------------------------------- helpers

    function codeFromToken(token) {
        if (!token) { return ''; }
        if (TOKEN_TO_CODE[token]) { return TOKEN_TO_CODE[token]; }
        var upper = token.toUpperCase();
        if (knownCodes().indexOf(upper) !== -1) { return upper; }
        var keys = Object.keys(TOKEN_TO_CODE);
        for (var i = 0; i < keys.length; i++) {
            if (keys[i].toLowerCase() === token.toLowerCase()) { return TOKEN_TO_CODE[keys[i]]; }
        }
        return '';
    }

    function tokenFromCode(code, originalToken) {
        // Keep the writing style the layer already used: symbol stays symbol,
        // three-letter code stays a code.
        var symbol = SYMBOLS[code] || code;
        var wasCode = originalToken && /^[A-Za-zА-Яа-яЇїІіЄєҐґ]{3,4}$/.test(originalToken);
        return wasCode ? code : symbol;
    }

    function rateBetween(from, to) {
        var a = state.rates[from], b = state.rates[to];
        if (!a || !b) { return null; }
        return b / a;
    }

    function roundValue(v, cfg) {
        if (v === null || isNaN(v)) { return v; }
        var f = { near: Math.round, down: Math.floor, up: Math.ceil }[cfg.dir] || Math.round;

        if (cfg.mode === 'none') { return v; }
        if (cfg.mode === 'decimals') {
            var p = Math.pow(10, cfg.decimals);
            return f(v * p) / p;
        }
        if (cfg.mode === 'sig') {
            if (v === 0) { return 0; }
            var mag = Math.floor(Math.log(Math.abs(v)) / Math.LN10);
            var scale = Math.pow(10, mag - (cfg.sig - 1));
            var r = f(v / scale) * scale;
            // A value like 9.7 at 1 digit becomes 10, which needs one order more.
            return Math.round(r * 1e6) / 1e6;
        }
        if (cfg.mode === 'step') {
            var s = cfg.step > 0 ? cfg.step : 1;
            return Math.round((f(v / s) * s) * 1e6) / 1e6;
        }
        if (cfg.mode === 'charm') {
            if (cfg.charm === 0.99) { return Math.ceil(v) - 0.01; }
            if (cfg.charm === 9) { return Math.max(9, Math.ceil(v / 10) * 10 - 1); }
            return Math.max(99, Math.ceil(v / 100) * 100 - 1);
        }
        return v;
    }

    function decimalsOf(v) {
        var s = String(v);
        var i = s.indexOf('.');
        return i === -1 ? 0 : Math.min(6, s.length - i - 1);
    }

    function hasKeys(row) {
        return !!(row.keys && row.keys.length);
    }

    function keysChanged(row) {
        if (!hasKeys(row)) { return false; }
        for (var i = 0; i < row.keys.length; i++) {
            if (row.outKeys[i] !== row.keys[i].v) { return true; }
        }
        return false;
    }

    function timecode(t, fps) {
        var rate = Math.round(fps || 25);
        var total = Math.round(t * (fps || 25));
        var ff = total % rate;
        var s = Math.floor(total / rate);
        var pad = function (n) { return (n < 10 ? '0' : '') + n; };
        return pad(Math.floor(s / 3600)) + ':' + pad(Math.floor(s / 60) % 60) + ':' +
            pad(s % 60) + ':' + pad(ff);
    }

    function readRoundCfg() {
        return {
            mode: $('roundMode').value,
            decimals: parseInt($('decimals').value, 10) || 0,
            sig: Math.max(1, parseInt($('sig').value, 10) || 2),
            step: parseFloat($('step').value) || 1,
            charm: parseFloat($('charm').value),
            dir: $('dir').value
        };
    }

    function setStatus(text, kind) {
        var el = $('status');
        el.textContent = text;
        el.className = 'status' + (kind ? ' ' + kind : '');
    }

    // ------------------------------------------------------------ rendering

    /** Every code we know about: the ISO list plus whatever the feed returned. */
    function knownCodes() {
        var seen = {}, out = [];
        CODES.concat(Object.keys(state.rates)).forEach(function (c) {
            if (!seen[c]) { seen[c] = true; out.push(c); }
        });
        return out.sort();
    }

    function fillCurrencySelects(keepSelection) {
        var prev = keepSelection
            ? { from: $('fromCur').value, to: $('toCur').value }
            : { from: 'AUTO', to: 'UAH' };

        knownCodes();
        ['fromCur', 'toCur'].forEach(function (id) {
            var sel = $(id);
            sel.innerHTML = '';
            if (id === 'fromCur') {
                var auto = document.createElement('option');
                auto.value = 'AUTO';
                auto.textContent = 'AUTO';
                sel.appendChild(auto);
            }
            knownCodes().forEach(function (c) {
                var o = document.createElement('option');
                o.value = c;
                // A dot marks a code we have no rate for yet.
                o.textContent = state.rates[c] ? c : c + ' ·';
                if (!state.rates[c]) { o.title = 'Немає курсу — натисни «Оновити»'; }
                sel.appendChild(o);
            });
        });
        $('fromCur').value = prev.from;
        $('toCur').value = prev.to;
        if (!$('toCur').value) { $('toCur').value = 'UAH'; }
    }

    function renderBoard() {
        var from = $('fromCur').value;
        var to = $('toCur').value;
        if (from === 'AUTO') {
            var codes = {};
            state.rows.forEach(function (r) { if (r.code) { codes[r.code] = true; } });
            var found = Object.keys(codes);
            if (found.length === 1) { from = found[0]; }
            else if (found.length > 1) {
                $('rateOut').textContent = found.length + ' валюти в шарах';
                $('rateSource').textContent = state.ratesLabel;
                return;
            } else {
                $('rateOut').textContent = '—';
                $('rateSource').textContent = state.ratesLabel;
                return;
            }
        }
        var r = rateBetween(from, to);
        $('rateOut').textContent = r === null ? 'немає курсу' : (from === to ? '1,0000' : fmtRate(r));
        $('rateSource').textContent = state.ratesLabel;
    }

    function fmtRate(r) {
        var d = r < 1 ? 6 : (r < 100 ? 4 : 2);
        return r.toFixed(d).replace('.', ',');
    }

    function renderRows() {
        var list = $('list');
        list.innerHTML = '';

        if (!state.rows.length) {
            var p = document.createElement('p');
            p.className = 'empty';
            p.textContent = 'Нічого не знайдено. Перевір область пошуку або назву ефекту в налаштуваннях.';
            list.appendChild(p);
            $('countLabel').textContent = 'Нічого не знайдено';
            $('apply').disabled = true;
            return;
        }

        state.rows.forEach(function (row, i) {
            list.appendChild(buildCard(row, i));
        });

        var checked = state.rows.filter(function (r) { return r.checked; }).length;
        $('countLabel').textContent = 'Знайдено ' + state.rows.length + ' · вибрано ' + checked;
        $('apply').disabled = checked === 0;
    }

    function buildCard(row, index) {
        var card = document.createElement('div');
        card.className = 'card';
        if (row.outValue !== row.value || row.outCode !== row.code || keysChanged(row)) {
            card.classList.add('is-changed');
        }
        if (row.valLocked && row.valReason === 'expression') { card.classList.add('is-locked'); }

        var top = document.createElement('div');
        top.className = 'card-top';

        var cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.checked = row.checked;
        cb.addEventListener('change', function () {
            row.checked = cb.checked;
            renderRows();
        });

        var name = document.createElement('span');
        name.className = 'card-name';
        name.textContent = row.layer;
        name.title = 'Показати шар у композиції';
        name.addEventListener('click', function () {
            CEP.evalScript('CF_reveal(' + row.compIdx + ',' + row.layerIdx + ')')
                .catch(function () {});
        });

        var comp = document.createElement('span');
        comp.className = 'card-comp';
        comp.textContent = row.comp;

        top.appendChild(cb);
        top.appendChild(name);
        top.appendChild(comp);

        if (row.valLocked) {
            var tag = document.createElement('span');
            tag.className = 'tag warn';
            tag.textContent = 'вираз';
            top.appendChild(tag);
        }
        var keyTag = null;
        if (hasKeys(row)) {
            keyTag = document.createElement('span');
            keyTag.className = 'tag tag-keys';
            keyTag.textContent = 'ключі: ' + row.keys.length;
            keyTag.title = 'Показати значення на кожному ключі';
            top.appendChild(keyTag);
        }

        var vals = document.createElement('div');
        vals.className = 'card-values';

        var curIn = mkInput(row.currency || row.code, 'cur');
        curIn.addEventListener('change', function () {
            row.currency = curIn.value.trim();
            row.code = codeFromToken(row.currency) || row.code;
            renderBoard();
        });

        var valIn = mkInput(String(row.value), '');
        valIn.addEventListener('change', function () {
            var v = parseFloat(valIn.value.replace(',', '.'));
            if (!isNaN(v)) { row.value = v; row.outValue = v; renderRows(); }
        });

        var arrow = document.createElement('span');
        arrow.className = 'arrow';
        arrow.textContent = '→';

        var outCurIn = mkInput(row.outCurrency || row.currency || '', 'cur out');
        outCurIn.addEventListener('change', function () {
            row.outCurrency = outCurIn.value.trim();
            row.outCode = codeFromToken(row.outCurrency) || row.outCode;
            renderRows();
        });

        var outValIn = mkInput(String(row.outValue), 'out');
        outValIn.addEventListener('change', function () {
            var v = parseFloat(outValIn.value.replace(',', '.'));
            if (!isNaN(v)) { row.outValue = v; renderRows(); }
        });

        if (hasKeys(row)) {
            // The pair shows the value at the playhead; keys are edited in the drawer.
            valIn.disabled = true;
            outValIn.disabled = true;
            valIn.title = outValIn.title = 'Значення на поточному кадрі — ключі редагуються нижче';
        }

        vals.appendChild(curIn);
        vals.appendChild(valIn);
        vals.appendChild(arrow);
        vals.appendChild(outCurIn);
        vals.appendChild(outValIn);

        var note = document.createElement('div');
        note.className = 'card-note';
        var bits = [];
        if (row.text) { bits.push('«' + row.text.replace(/\s+/g, ' ').slice(0, 48) + '»'); }
        if (row.textExpr) { bits.push('Source Text = вираз'); }
        bits.push(row.fxName + ' › ' + row.valName);
        note.textContent = bits.join(' · ');
        note.title = 'Показати решту параметрів ефекту';
        note.style.cursor = 'pointer';

        var params = buildParams(row);
        note.addEventListener('click', function () { params.hidden = !params.hidden; });
        if (keyTag) {
            keyTag.addEventListener('click', function () { params.hidden = !params.hidden; });
        }

        card.appendChild(top);
        card.appendChild(vals);
        card.appendChild(note);
        card.appendChild(params);
        card.dataset.index = index;
        return card;
    }

    function buildParams(row) {
        var box = document.createElement('div');
        box.className = 'params';
        box.hidden = true;

        if (hasKeys(row)) { box.appendChild(buildKeysEditor(row)); }
        box.appendChild(buildTextEditor(row));

        var editable = row.params.filter(function (p) {
            return p.oneD && p.idx !== row.valIdx;
        });

        if (!editable.length) { return box; }

        if (!row.paramEdits) { row.paramEdits = {}; }

        editable.forEach(function (p) {
            var line = document.createElement('label');
            line.className = 'param-row';

            var label = document.createElement('span');
            label.textContent = p.name + (p.isDropdown ? ' (пункт)' : '');

            var input = document.createElement('input');
            input.type = 'number';
            input.step = p.isDropdown ? '1' : 'any';
            input.value = (row.paramEdits[p.idx] !== undefined) ? row.paramEdits[p.idx] : p.value;
            if (p.locked) { input.disabled = true; input.title = 'Керується ' + p.reason; }
            input.addEventListener('change', function () {
                var v = parseFloat(input.value.replace(',', '.'));
                if (!isNaN(v)) { row.paramEdits[p.idx] = v; }
            });

            line.appendChild(label);
            line.appendChild(input);
            box.appendChild(line);
        });

        return box;
    }

    function buildKeysEditor(row) {
        var wrap = document.createElement('div');
        wrap.className = 'keys-edit';

        var head = document.createElement('div');
        head.className = 'text-edit-head';
        head.textContent = row.valName + ' · ключі';
        wrap.appendChild(head);

        row.keys.forEach(function (k, i) {
            var line = document.createElement('label');
            line.className = 'key-row';

            var tc = document.createElement('span');
            tc.className = 'key-time';
            tc.textContent = timecode(k.t, row.fps);

            var from = document.createElement('span');
            from.className = 'key-from';
            from.textContent = fmt.format(k.v);

            var arrow = document.createElement('span');
            arrow.className = 'arrow';
            arrow.textContent = '→';

            var input = document.createElement('input');
            input.type = 'text';
            input.value = String(row.outKeys[i]);
            if (row.outKeys[i] !== k.v) { input.classList.add('out'); }
            input.addEventListener('change', function () {
                var v = parseFloat(input.value.replace(',', '.'));
                if (!isNaN(v)) {
                    row.outKeys[i] = v;
                    input.classList.toggle('out', v !== k.v);
                    var card = input.closest('.card');
                    if (card) { card.classList.toggle('is-changed', keysChanged(row) || row.outCode !== row.code); }
                }
            });

            line.appendChild(tc);
            line.appendChild(from);
            line.appendChild(arrow);
            line.appendChild(input);
            wrap.appendChild(line);
        });
        return wrap;
    }

    function buildTextEditor(row) {
        var wrap = document.createElement('div');
        wrap.className = 'text-edit';

        var head = document.createElement('div');
        head.className = 'text-edit-head';
        head.textContent = row.textExpr ? 'Source Text · вираз' : 'Source Text';

        var where = document.createElement('span');
        where.className = 'tag';
        var srcLabel = {
            expression: 'валюта у виразі',
            template: 'валюта в тексті шару',
            render: 'валюта лише в рендері — замінити нічим'
        };
        where.textContent = row.currency
            ? (srcLabel[row.currencySource] || 'валюта в тексті')
            : 'валюти не знайдено';
        if (row.currency && row.currencySource === 'render') { where.className = 'tag warn'; }
        head.appendChild(where);

        var area = document.createElement('textarea');
        area.rows = row.textExpr ? 4 : 2;
        area.value = row.textExpr
            ? (row.exprEdit !== undefined ? row.exprEdit : row.expr)
            : (row.textEdit !== undefined ? row.textEdit : row.rawText);
        area.spellcheck = false;

        area.addEventListener('input', function () {
            if (row.textExpr) { row.exprEdit = area.value; }
            else { row.textEdit = area.value; }
        });

        var foot = document.createElement('div');
        foot.className = 'text-edit-foot';

        var revert = document.createElement('button');
        revert.className = 'btn btn-ghost';
        revert.textContent = 'Повернути';
        revert.addEventListener('click', function () {
            delete row.exprEdit;
            delete row.textEdit;
            area.value = row.textExpr ? row.expr : row.rawText;
        });

        var hint = document.createElement('span');
        hint.textContent = row.textExpr
            ? 'Порожньо — валюта заміниться автоматично'
            : 'Порожньо — заміниться тільки токен валюти';
        foot.appendChild(hint);
        foot.appendChild(revert);

        wrap.appendChild(head);
        wrap.appendChild(area);
        wrap.appendChild(foot);
        return wrap;
    }

    function mkInput(value, cls) {
        var el = document.createElement('input');
        el.type = 'text';
        el.value = value;
        if (cls) { el.className = cls; }
        return el;
    }

    // ---------------------------------------------------------------- scan

    async function scan() {
        setStatus('Сканую…');
        try {
            var res = await CEP.call('CF_scan', {
                scope: $('scope').value,
                anyEffect: $('anyEffect').checked,
                match: $('matchName').value.split(',').map(function (s) { return s.trim(); })
            });
            if (!res.ok) { setStatus(res.error, 'warn'); return; }

            state.rows = res.rows.map(function (r) {
                r.checked = true;
                r.code = codeFromToken(r.currency);
                r.outValue = r.value;
                r.keys = r.keys || [];
                r.outKeys = r.keys.map(function (k) { return k.v; });
                r.outCurrency = r.currency;
                r.outCode = r.code;
                return r;
            });

            renderRows();
            renderBoard();
            setStatus('Знайдено ' + state.rows.length + ' показник(ів)', 'ok');
        } catch (e) {
            setStatus(e.message, 'warn');
        }
    }

    // ----------------------------------------------------------- conversion

    function convert() {
        var to = $('toCur').value;
        var fromSel = $('fromCur').value;
        var cfg = readRoundCfg();
        var done = 0, missing = 0;

        state.rows.forEach(function (row) {
            if (!row.checked) { return; }
            var from = fromSel === 'AUTO' ? row.code : fromSel;
            if (!from) { missing++; return; }
            var rate = rateBetween(from, to);
            if (rate === null) { missing++; return; }
            row.outValue = roundValue(row.value * rate, cfg);
            if (hasKeys(row)) {
                row.outKeys = row.keys.map(function (k) { return roundValue(k.v * rate, cfg); });
            }
            row.outCode = to;
            row.outCurrency = tokenFromCode(to, row.currency);
            done++;
        });

        renderRows();
        renderBoard();
        setStatus(
            'Перераховано ' + done + (missing ? ' · без курсу: ' + missing : ''),
            missing ? 'warn' : 'ok'
        );
    }

    function resetValues() {
        state.rows.forEach(function (row) {
            row.outValue = row.value;
            if (hasKeys(row)) { row.outKeys = row.keys.map(function (k) { return k.v; }); }
            row.outCurrency = row.currency;
            row.outCode = row.code;
        });
        renderRows();
        setStatus('Скинуто до вихідних значень');
    }

    // ---------------------------------------------------------------- apply

    async function apply() {
        var cfg = readRoundCfg();
        var items = state.rows.filter(function (r) { return r.checked; }).map(function (r) {
            var item = {
                compIdx: r.compIdx, comp: r.comp,
                layerIdx: r.layerIdx, layer: r.layer,
                fxIdx: r.fxIdx, valIdx: r.valIdx,
                value: r.outValue,
                currency: r.currency,
                currencyPos: r.currencyPos || 'prefix',
                newCurrency: (r.outCurrency && r.outCurrency !== r.currency) ? r.outCurrency : null,
                decIdx: r.decIdx,
                decimals: null
            };
            var dd = $('displayDecimals').value;
            if (dd !== 'off' && r.decIdx > 0) {
                // Independent of the rounding mode: 35000 with 2 here renders 35000,00.
                var autoDec = hasKeys(r)
                    ? r.outKeys.reduce(function (m, v) { return Math.max(m, decimalsOf(v)); }, 0)
                    : decimalsOf(r.outValue);
                item.decimals = (dd === 'auto') ? autoDec : parseInt(dd, 10);
            }
            item.allowAppend = $('allowAppend').checked;
            if (hasKeys(r)) {
                // Animated value: write per key, never the playhead value.
                item.value = null;
                item.keys = keysChanged(r) ? r.outKeys.slice() : null;
            }
            if (r.paramEdits) {
                item.params = Object.keys(r.paramEdits).map(function (k) {
                    return { idx: parseInt(k, 10), value: r.paramEdits[k] };
                });
            }
            if (r.textExpr && r.exprEdit !== undefined && r.exprEdit !== r.expr) {
                item.newExpr = r.exprEdit;
            }
            if (!r.textExpr && r.textEdit !== undefined && r.textEdit !== r.rawText) {
                item.newText = r.textEdit;
            }
            return item;
        });

        if (!items.length) { return; }
        setStatus('Застосовую…');
        try {
            var res = await CEP.call('CF_apply', { items: items });
            if (!res.ok) { setStatus(res.error, 'warn'); return; }

            state.rows.forEach(function (r) {
                if (!r.checked) { return; }
                r.value = r.outValue;
                if (hasKeys(r)) {
                    r.keys.forEach(function (k, i) { k.v = r.outKeys[i]; });
                }
                if (r.outCurrency) { r.currency = r.outCurrency; r.code = r.outCode; }
                if (r.exprEdit !== undefined) { r.expr = r.exprEdit; delete r.exprEdit; }
                if (r.textEdit !== undefined) { r.rawText = r.textEdit; delete r.textEdit; }
            });
            renderRows();

            var msg = 'Змінено ' + res.applied + (res.skipped ? ' · пропущено ' + res.skipped : '');
            if (res.notes && res.notes.length) { msg += ' · ' + res.notes[0]; }
            setStatus(msg, res.skipped ? 'warn' : 'ok');
        } catch (e) {
            setStatus(e.message, 'warn');
        }
    }

    // ---------------------------------------------------------------- rates

    async function fetchRates() {
        var url = $('ratesUrl').value.trim();
        if (!url) { setStatus('Вкажи адресу джерела курсів у налаштуваннях', 'warn'); return; }
        setStatus('Завантажую курси…');
        try {
            var resp = await fetch(url);
            if (!resp.ok) { throw new Error('HTTP ' + resp.status); }
            var data = await resp.json();
            var rates = data.rates || data.conversion_rates || (data.data && data.data.rates);
            if (!rates) { throw new Error('У відповіді немає поля rates'); }

            var added = 0;
            Object.keys(rates).forEach(function (code) {
                if (!/^[A-Z]{3}$/.test(code)) { return; }
                if (typeof rates[code] !== 'number' || rates[code] <= 0) { return; }
                if (state.rates[code] === undefined) { added++; }
                state.rates[code] = rates[code];
            });
            state.rates.USD = 1;
            state.ratesLabel = 'курси оновлено ' + new Date().toLocaleString('uk-UA');
            savePrefs();
            fillCurrencySelects(true);
            renderBoard();
            setStatus(
                'Курси оновлено · валют: ' + Object.keys(state.rates).length +
                (added ? ' (нових ' + added + ')' : ''),
                'ok'
            );
        } catch (e) {
            setStatus('Не вдалося оновити курси: ' + e.message + '. Введи вручну.', 'warn');
        }
    }

    function openRatesEditor() {
        var lines = Object.keys(state.rates).sort().map(function (c) {
            return c + '=' + state.rates[c];
        });
        $('ratesText').value = lines.join('\n');
        $('ratesEditor').hidden = false;
    }

    function saveRates() {
        var next = {};
        $('ratesText').value.split('\n').forEach(function (line) {
            var m = line.split('=');
            if (m.length !== 2) { return; }
            var code = m[0].trim().toUpperCase();
            var v = parseFloat(m[1].replace(',', '.'));
            if (code && !isNaN(v) && v > 0) { next[code] = v; }
        });
        if (!Object.keys(next).length) { setStatus('Не розпізнано жодного курсу', 'warn'); return; }
        state.rates = next;
        state.rates.USD = state.rates.USD || 1;
        state.ratesLabel = 'курси введено вручну';
        savePrefs();
        $('ratesEditor').hidden = true;
        fillCurrencySelects(true);
        renderBoard();
        setStatus('Курси збережено', 'ok');
    }

    // ------------------------------------------------------------------ ui

    function syncRoundingRows() {
        var m = $('roundMode').value;
        $('rowDecimals').hidden = m !== 'decimals';
        $('rowSig').hidden = m !== 'sig';
        $('rowStep').hidden = m !== 'step';
        $('rowCharm').hidden = m !== 'charm';
        $('rowDir').hidden = (m === 'none' || m === 'charm');
    }

    function init() {
        loadPrefs();
        fillCurrencySelects(false);
        if (state.savedTo) { $('toCur').value = state.savedTo; }
        syncRoundingRows();
        renderBoard();

        $('scan').addEventListener('click', scan);
        $('convert').addEventListener('click', convert);
        $('reset').addEventListener('click', resetValues);
        $('apply').addEventListener('click', apply);
        $('fetchRates').addEventListener('click', fetchRates);
        $('editRates').addEventListener('click', openRatesEditor);
        $('ratesSave').addEventListener('click', saveRates);
        $('ratesCancel').addEventListener('click', function () { $('ratesEditor').hidden = true; });
        $('roundMode').addEventListener('change', syncRoundingRows);
        [['decimals', 'decimals'], ['sig', 'sig'], ['step', 'step'], ['charm', 'charm']]
            .forEach(function (pair) {
                $(pair[0]).addEventListener('input', function () {
                    if ($('roundMode').value !== pair[1]) {
                        $('roundMode').value = pair[1];
                        syncRoundingRows();
                    }
                });
            });
        $('toggleSettings').addEventListener('click', function () {
            $('settings').hidden = !$('settings').hidden;
        });
        $('fromCur').addEventListener('change', renderBoard);
        $('toCur').addEventListener('change', function () { renderBoard(); savePrefs(); });
        $('checkAll').addEventListener('change', function () {
            var on = $('checkAll').checked;
            state.rows.forEach(function (r) { r.checked = on; });
            renderRows();
        });

        if (!CEP.available()) {
            setStatus('Панель запущена поза After Effects — доступний лише інтерфейс', 'warn');
        }
    }

    document.addEventListener('DOMContentLoaded', init);
}());
