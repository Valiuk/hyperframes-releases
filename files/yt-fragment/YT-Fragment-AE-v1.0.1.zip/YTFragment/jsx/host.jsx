/* YT Fragment — ExtendScript для After Effects і Premiere Pro.
   Логіка AE побудована на панелі FaceCut: час джерела -> час композиції, один Undo. */

function ytf_str(v) {
    if (v === null || v === undefined) return "null";
    var t = typeof v;
    if (t === "number") return isFinite(v) ? String(v) : "null";
    if (t === "boolean") return v ? "true" : "false";
    if (t === "string") return '"' + encodeURIComponent(v) + '"';   // розкодовується в панелі
    if (v instanceof Array) {
        var a = [];
        for (var i = 0; i < v.length; i++) a.push(ytf_str(v[i]));
        return "[" + a.join(",") + "]";
    }
    var p = [];
    for (var k in v) if (v.hasOwnProperty(k)) p.push('"' + k + '":' + ytf_str(v[k]));
    return "{" + p.join(",") + "}";
}

function ytf_parse(s) {
    s = decodeURIComponent(s);
    if (typeof JSON !== "undefined" && JSON.parse) return JSON.parse(s);
    return eval("(" + s + ")");
}

function ytf_err(msg) { return ytf_str({ error: msg }); }

function ytf_isPremiere() {
    try { return BridgeTalk.appName === "premierepro"; } catch (e) { return false; }
}

function ytf_round(t, fd) { return Math.round(t / fd) * fd; }

/* Перетворює фрагменти (у часі джерела) на шматки в часі хоста.
   lo/hi — межі шару/кліпу в часі хоста, shift — зсув (час хоста = час джерела + shift).
   mode "remove" повертає доповнення. Результат відсортовано, кожен шматок не коротший за кадр. */
function ytf_parts(segs, shift, lo, hi, fd, mode) {
    var cut = [], i;
    for (i = 0; i < segs.length; i++) {
        var a = ytf_round(segs[i].a + shift, fd), b = ytf_round(segs[i].b + shift, fd);
        a = Math.max(a, lo); b = Math.min(b, hi);
        if (b - a >= fd - 1e-6) cut.push({ a: a, b: b, name: segs[i].name || "" });
    }
    cut.sort(function (x, y) { return x.a - y.a; });
    // зливаємо перекриття
    var merged = [];
    for (i = 0; i < cut.length; i++) {
        var L = merged.length ? merged[merged.length - 1] : null;
        if (L && cut[i].a <= L.b + 1e-6) { L.b = Math.max(L.b, cut[i].b); }
        else merged.push({ a: cut[i].a, b: cut[i].b, name: cut[i].name });
    }
    if (mode !== "remove") return merged;
    var out = [], cur = lo;
    for (i = 0; i < merged.length; i++) {
        if (merged[i].a - cur >= fd - 1e-6) out.push({ a: cur, b: merged[i].a, name: "" });
        cur = Math.max(cur, merged[i].b);
    }
    if (hi - cur >= fd - 1e-6) out.push({ a: cur, b: hi, name: "" });
    return out;
}

function ytf_label(base, part, n) {
    return base + " · " + (part.name ? part.name : "фр. " + n);
}

/* ================================================================ виділення */
function ytf_selection() {
    try { return ytf_isPremiere() ? ytf_selPP() : ytf_selAE(); }
    catch (e) { return ytf_err(e.toString()); }
}

function ytf_selAE() {
    var comp = app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) return ytf_err("Відкрий композицію й виділи шар з відео.");
    var sel = comp.selectedLayers;
    if (!sel.length) return ytf_err("Виділи шар з відео.");
    var why = [];
    for (var i = 0; i < sel.length; i++) {
        var L = sel[i], src = L.source;
        if (!(L instanceof AVLayer) || !src || !(src instanceof FootageItem) || !src.file ||
            src.mainSource.isStill || !src.hasVideo) { why.push(L.name + ": не відео"); continue; }
        if (L.timeRemapEnabled) { why.push(L.name + ": увімкнено Time Remap"); continue; }
        if (Math.abs(L.stretch - 100) > 0.001) { why.push(L.name + ": Stretch " + L.stretch + "%"); continue; }
        var s0 = Math.max(0, L.inPoint - L.startTime);
        var s1 = Math.min(src.duration, L.outPoint - L.startTime);
        if (s1 - s0 < comp.frameDuration) { why.push(L.name + ": порожній"); continue; }
        return ytf_str({
            ok: true, host: "ae", name: L.name, file: src.file.fsName, "in": s0, out: s1, fps: comp.frameRate,
            where: comp.name,
            target: { compId: comp.id, index: L.index, name: L.name }
        });
    }
    return ytf_err("Цей шар не підходить. " + why.join("; "));
}

function ytf_ppFps(seq) {
    try { var f = seq.getSettings().videoFrameRate.seconds; if (f > 0) return 1 / f; } catch (e) {}
    try { return 254016000000 / parseFloat(seq.timebase); } catch (e2) {}
    return 25;
}

function ytf_ppTrackOf(seq, ti) {
    for (var i = 0; i < seq.videoTracks.numTracks; i++) {
        var cl = seq.videoTracks[i].clips;
        for (var j = 0; j < cl.numItems; j++) if (cl[j].nodeId === ti.nodeId) return i;
    }
    return -1;
}

function ytf_selPP() {
    var seq = app.project.activeSequence;
    if (!seq) return ytf_err("Відкрий секвенцію й виділи кліп з відео.");
    var sel = seq.getSelection();
    if (!sel || !sel.length) return ytf_err("Виділи кліп з відео на таймлайні.");
    var why = [];
    for (var i = 0; i < sel.length; i++) {
        var ti = sel[i];
        if (ti.mediaType !== "Video") continue;
        var pi = ti.projectItem;
        if (!pi) { why.push(ti.name + ": не кліп"); continue; }
        try { if (pi.isSequence()) { why.push(ti.name + ": вкладена секвенція"); continue; } } catch (e) {}
        var path = "";
        try { path = pi.getMediaPath(); } catch (e2) {}
        if (!path) { why.push(ti.name + ": немає файлу"); continue; }
        try { if (Math.abs(ti.getSpeed() - 1) > 0.0001) { why.push(ti.name + ": змінено швидкість"); continue; } } catch (e3) {}
        try { if (ti.isSpeedReversed()) { why.push(ti.name + ": реверс"); continue; } } catch (e4) {}
        var track = ytf_ppTrackOf(seq, ti);
        if (track < 0) { why.push(ti.name + ": не знайдено доріжку"); continue; }
        return ytf_str({
            ok: true, host: "ppro", name: ti.name, file: path,
            "in": ti.inPoint.seconds, out: ti.outPoint.seconds, fps: ytf_ppFps(seq), where: seq.name,
            target: { seqId: seq.sequenceID, track: track, nodeId: ti.nodeId, name: ti.name }
        });
    }
    return ytf_err(why.length ? "Цей кліп не підходить. " + why.join("; ") : "Виділи відеокліп, а не лише аудіо.");
}

/* ================================================================ застосування */
function ytf_apply(encoded) {
    var P;
    try { P = ytf_parse(encoded); } catch (e) { return ytf_err("Пошкоджений запит: " + e); }
    try { return ytf_isPremiere() ? ytf_applyPP(P) : ytf_applyAE(P); }
    catch (e2) { return ytf_err("Помилка: " + e2.toString() + (e2.line ? " (рядок " + e2.line + ")" : "")); }
}

function ytf_findComp(id) {
    for (var i = 1; i <= app.project.numItems; i++) {
        var it = app.project.item(i);
        if (it instanceof CompItem && it.id === id) return it;
    }
    return null;
}

function ytf_applyAE(P) {
    var T = P.target, comp = ytf_findComp(T.compId);
    if (!comp) return ytf_err("Композицію не знайдено.");
    if (T.index > comp.numLayers || comp.layer(T.index).name !== T.name)
        return ytf_err("Шар змінився або його вже розрізано. Виділи шар і відкрий його з панелі заново.");
    var L = comp.layer(T.index), fd = comp.frameDuration;
    if (L.locked && P.mode !== "newcomp" && P.mode !== "markers") return ytf_err("Шар заблоковано: " + L.name);
    var parts = ytf_parts(P.segments, L.startTime, L.inPoint, L.outPoint, fd, P.mode);
    if (!parts.length) return ytf_err("У межах шару немає жодного фрагмента.");

    var made = 0, note = "", j;
    app.beginUndoGroup("YT Fragment");
    try {
        if (P.mode === "markers") {
            var mk = L.property("ADBE Marker");
            for (j = 0; j < P.segments.length; j++) {
                var s = P.segments[j];
                var a = Math.max(ytf_round(s.a + L.startTime, fd), L.inPoint);
                var b = Math.min(ytf_round(s.b + L.startTime, fd), L.outPoint);
                if (b - a < fd - 1e-6) continue;
                var mv = new MarkerValue(s.name ? s.name : "Фрагмент " + (j + 1));
                mv.duration = b - a;
                mk.setValueAtTime(a, mv);
                made++;
            }
        } else if (P.mode === "keep" || P.mode === "remove") {
            var base = L.name;
            for (j = 0; j < parts.length; j++) {
                var D = L.duplicate();
                D.inPoint = parts[j].a;
                D.outPoint = parts[j].b;
                D.name = ytf_label(base, parts[j], j + 1);
                made++;
            }
            L.remove();
            note = "Шар розрізано. Щоб застосувати ще раз, відкрий новий шар з панелі";
        } else if (P.mode === "newcomp") {
            var total = 0;
            for (j = 0; j < parts.length; j++) total += parts[j].b - parts[j].a;
            var NC = app.project.items.addComp(comp.name + " — " + L.name + " фрагменти", comp.width, comp.height,
                comp.pixelAspect, Math.max(fd, ytf_round(total, fd)), comp.frameRate);
            var cursor = 0;
            for (j = 0; j < parts.length; j++) {
                var p = parts[j];
                L.copyToComp(NC);
                var X = NC.layer(1);
                X.startTime = L.startTime + (cursor - p.a);
                X.inPoint = cursor;
                X.outPoint = cursor + (p.b - p.a);
                X.name = ytf_label(L.name, p, j + 1);
                X.moveToEnd();
                cursor = X.outPoint;
                made++;
            }
            NC.openInViewer();
        } else {
            app.endUndoGroup();
            return ytf_err("Невідомий режим: " + P.mode);
        }
    } catch (e) {
        app.endUndoGroup();
        return ytf_err("Помилка: " + e.toString() + " (рядок " + e.line + ")");
    }
    app.endUndoGroup();
    return ytf_str({ ok: true, made: made, note: note });
}

/* ---------------- Premiere Pro */
function ytf_ppFindSeq(id) {
    var s = app.project.sequences;
    for (var i = 0; i < s.numSequences; i++) if (s[i].sequenceID === id) return s[i];
    return null;
}

function ytf_ppFindClip(track, nodeId) {
    var cl = track.clips;
    for (var j = 0; j < cl.numItems; j++) if (cl[j].nodeId === nodeId) return cl[j];
    return null;
}

function ytf_ppTC(seq, sec) {
    var t = new Time();
    t.seconds = sec;
    var st = seq.getSettings();
    return t.getFormatted(st.videoFrameRate, st.videoDisplayFormat);
}

function ytf_qeRazor(qTrack, tc) {
    try { qTrack.razor(tc); } catch (e) { qTrack.razor(tc, true, true); }
}

/* Кліпи тієї самої медіа на інших доріжках, що збігаються в часі (пов'язане аудіо). */
function ytf_ppLinkedAudio(seq, clip, fd) {
    var res = [], node = clip.projectItem.nodeId, S = clip.start.seconds, E = clip.end.seconds;
    for (var i = 0; i < seq.audioTracks.numTracks; i++) {
        var cl = seq.audioTracks[i].clips;
        for (var j = 0; j < cl.numItems; j++) {
            var c = cl[j];
            if (c.projectItem && c.projectItem.nodeId === node &&
                Math.abs(c.start.seconds - S) < fd / 2 && Math.abs(c.end.seconds - E) < fd / 2) { res.push(i); break; }
        }
    }
    return res;
}

function ytf_applyPP(P) {
    var T = P.target, seq = ytf_ppFindSeq(T.seqId);
    if (!seq) return ytf_err("Секвенцію не знайдено.");
    if (T.track >= seq.videoTracks.numTracks) return ytf_err("Доріжку не знайдено.");
    var clip = ytf_ppFindClip(seq.videoTracks[T.track], T.nodeId);
    if (!clip) return ytf_err("Кліп змінився або його вже розрізано. Виділи кліп і відкрий його з панелі заново.");
    var fd = 1 / ytf_ppFps(seq);
    var S = clip.start.seconds, E = clip.end.seconds, shift = S - clip.inPoint.seconds;
    var parts = ytf_parts(P.segments, shift, S, E, fd, P.mode === "newseq" ? "keep" : P.mode);
    if (!parts.length) return ytf_err("У межах кліпу немає жодного фрагмента.");
    var made = 0, j;

    if (P.mode === "markers") {
        for (j = 0; j < P.segments.length; j++) {
            var s = P.segments[j];
            var a = Math.max(ytf_round(s.a + shift, fd), S), b = Math.min(ytf_round(s.b + shift, fd), E);
            if (b - a < fd - 1e-6) continue;
            var m = seq.markers.createMarker(a);
            m.name = s.name ? s.name : "Фрагмент " + (j + 1);
            try { m.comments = "YT Fragment"; } catch (e0) {}
            try { m.end = b; } catch (e1) { var te = new Time(); te.seconds = b; m.end = te; }
            made++;
        }
        return ytf_str({ ok: true, made: made });
    }

    if (P.mode === "keep" || P.mode === "remove") {
        var keep = P.mode === "keep" ? parts : ytf_parts(P.segments, shift, S, E, fd, "remove");
        // межі розрізів строго всередині кліпу
        var cuts = [], i;
        for (i = 0; i < keep.length; i++) { cuts.push(keep[i].a); cuts.push(keep[i].b); }
        cuts.sort(function (x, y) { return x - y; });
        var uniq = [];
        for (i = 0; i < cuts.length; i++) {
            if (cuts[i] <= S + fd / 2 || cuts[i] >= E - fd / 2) continue;
            if (uniq.length && Math.abs(uniq[uniq.length - 1] - cuts[i]) < fd / 2) continue;
            uniq.push(cuts[i]);
        }
        var audio = ytf_ppLinkedAudio(seq, clip, fd);
        var node = clip.projectItem.nodeId;
        if (app.project.activeSequence.sequenceID !== seq.sequenceID) app.project.openSequence(seq.sequenceID);
        app.enableQE();
        var qseq = qe.project.getActiveSequence();
        for (i = 0; i < uniq.length; i++) {
            var tc = ytf_ppTC(seq, uniq[i]);
            ytf_qeRazor(qseq.getVideoTrackAt(T.track), tc);
            for (j = 0; j < audio.length; j++) ytf_qeRazor(qseq.getAudioTrackAt(audio[j]), tc);
        }
        // видаляємо шматки поза тим, що лишаємо
        var tracks = [seq.videoTracks[T.track]];
        for (j = 0; j < audio.length; j++) tracks.push(seq.audioTracks[audio[j]]);
        var drop = [];
        for (var k = 0; k < tracks.length; k++) {
            var cl = tracks[k].clips;
            for (j = 0; j < cl.numItems; j++) {
                var c = cl[j];
                if (!c.projectItem || c.projectItem.nodeId !== node) continue;
                var cs = c.start.seconds, ce = c.end.seconds;
                if (cs < S - fd / 2 || ce > E + fd / 2) continue;
                var mid = (cs + ce) / 2, inside = false;
                for (i = 0; i < keep.length; i++) if (mid > keep[i].a && mid < keep[i].b) { inside = true; break; }
                if (!inside) drop.push(c);
            }
        }
        for (j = 0; j < drop.length; j++) drop[j].remove(false, true);
        return ytf_str({ ok: true, made: keep.length,
                         note: "Кліп розрізано. Скасовувати в Premiere треба кількома Ctrl+Z" });
    }

    if (P.mode === "newseq") {
        var pi = clip.projectItem;
        var NS = app.project.createNewSequenceFromClips(seq.name + " — " + clip.name + " фрагменти", [pi],
                                                        app.project.getInsertionBin());
        if (!NS) return ytf_err("Не вдалося створити секвенцію.");
        // прибираємо кліп, який Premiere поставив сам
        var groups = [NS.videoTracks, NS.audioTracks];
        for (var g = 0; g < groups.length; g++)
            for (i = 0; i < groups[g].numTracks; i++) {
                var cc = groups[g][i].clips, rm = [];
                for (j = 0; j < cc.numItems; j++) rm.push(cc[j]);
                for (j = 0; j < rm.length; j++) rm[j].remove(false, false);
            }
        var cursor = 0;
        try {
            for (j = 0; j < parts.length; j++) {
                var srcA = parts[j].a - shift, srcB = parts[j].b - shift;
                pi.setInPoint(srcA, 4);
                pi.setOutPoint(srcB, 4);
                NS.videoTracks[0].overwriteClip(pi, cursor);
                cursor += parts[j].b - parts[j].a;
                made++;
            }
        } finally {
            try { pi.clearInPoint(); pi.clearOutPoint(); } catch (e2) {}
        }
        app.project.openSequence(NS.sequenceID);
        return ytf_str({ ok: true, made: made });
    }
    return ytf_err("Невідомий режим: " + P.mode);
}

/* ================================================================ імпорт файлів */
function ytf_import(encoded) {
    var files;
    try { files = ytf_parse(encoded); } catch (e) { return ytf_err("Пошкоджений запит: " + e); }
    try {
        var made = 0, i;
        if (ytf_isPremiere()) {
            var bin = null, root = app.project.rootItem;
            for (i = 0; i < root.children.numItems; i++)
                if (root.children[i].name === "YT Fragment" && root.children[i].type === 2) { bin = root.children[i]; break; }
            if (!bin) { try { bin = root.createBin("YT Fragment"); } catch (e1) {} }
            if (!bin) bin = app.project.getInsertionBin();
            app.project.importFiles(files, true, bin, false);
            made = files.length;
        } else {
            var folder = null;
            for (i = 1; i <= app.project.numItems; i++) {
                var it = app.project.item(i);
                if (it instanceof FolderItem && it.name === "YT Fragment") { folder = it; break; }
            }
            app.beginUndoGroup("YT Fragment: імпорт");
            if (!folder) folder = app.project.items.addFolder("YT Fragment");
            for (i = 0; i < files.length; i++) {
                var f = new File(files[i]);
                if (!f.exists) continue;
                var item = app.project.importFile(new ImportOptions(f));
                item.parentFolder = folder;
                made++;
            }
            app.endUndoGroup();
        }
        return ytf_str({ ok: true, made: made });
    } catch (e2) {
        return ytf_err("Імпорт: " + e2.toString());
    }
}
