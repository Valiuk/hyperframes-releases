/* YT Fragment — панель для After Effects і Premiere Pro.
   Відкриває програму YT Fragment окремим вікном на весь екран (як Mocha) і виконує її запити:
   програма кладе req_N.json у папку сесії, панель застосовує його через ExtendScript і пише res_N.json. */
(function () {
  "use strict";
  var cp = require("child_process"), fs = require("fs"), path = require("path"), os = require("os");
  var $ = function (id) { return document.getElementById(id); };

  var hostEnv = {};
  try { hostEnv = JSON.parse(window.__adobe_cep__.getHostEnvironment()); } catch (e) {}
  var HOST = hostEnv.appId === "PPRO" ? "ppro" : "ae";
  var HOST_NAME = HOST === "ppro" ? "Premiere Pro" : "After Effects";
  $("hostLbl").textContent = HOST_NAME;
  if (HOST === "ppro") $("selName").textContent = "Виділи кліп з відео на таймлайні";

  var extDir = (function () {
    var p = decodeURIComponent(location.pathname);
    if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
    return path.dirname(p);
  })();

  // ------------------------------------------------ ExtendScript
  function decodeDeep(v) {
    if (typeof v === "string") return decodeURIComponent(v);
    if (Array.isArray(v)) return v.map(decodeDeep);
    if (v && typeof v === "object") { var o = {}; for (var k in v) o[k] = decodeDeep(v[k]); return o; }
    return v;
  }
  function jsx(code) {
    return new Promise(function (resolve) {
      window.__adobe_cep__.evalScript(code, function (res) {
        var out;
        try { out = decodeDeep(JSON.parse(res)); } catch (e) { out = { error: HOST_NAME + ": " + res }; }
        resolve(out);
      });
    });
  }
  function enc(obj) { return encodeURIComponent(JSON.stringify(obj)).replace(/'/g, "%27"); }

  // ------------------------------------------------ ui
  function status(msg, kind) { var s = $("status"); s.textContent = msg || ""; s.className = kind || ""; }
  function fmt(t) {
    t = Math.max(0, t || 0);
    var h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = (t % 60).toFixed(2);
    if (s.length < 5) s = "0" + s;
    return (h ? h + ":" + (m < 10 ? "0" : "") : "") + m + ":" + s;
  }

  // ------------------------------------------------ шлях до програми
  function exeCandidates() {
    var list = [];
    try { var saved = localStorage.getItem("ytf_exe"); if (saved) list.push(saved); } catch (e) {}
    var la = process.env.LOCALAPPDATA || path.join(os.homedir(), "AppData", "Local");
    list.push(path.join(la, "Programs", "YT Fragment", "YT Fragment.exe"));
    list.push(path.join(extDir, "app", "YT Fragment.exe"));
    return list;
  }
  function findExe() {
    var c = exeCandidates();
    for (var i = 0; i < c.length; i++) { try { if (fs.existsSync(c[i])) return c[i]; } catch (e) {} }
    return null;
  }
  $("exePath").value = findExe() || "";
  $("exePath").addEventListener("change", function () {
    try { localStorage.setItem("ytf_exe", $("exePath").value.trim()); } catch (e) {}
  });
  $("bPick").onclick = function () {
    try {
      var r = window.cep.fs.showOpenDialogEx(false, false, "YT Fragment.exe", "", ["exe"]);
      if (r && r.data && r.data.length) {
        $("exePath").value = r.data[0];
        localStorage.setItem("ytf_exe", r.data[0]);
      }
    } catch (e) { status("Не вдалося відкрити вікно вибору: " + e.message, "e"); }
  };

  // ------------------------------------------------ виділення
  var current = null, selBusy = false;
  function showSel(r) {
    var box = $("sel");
    current = r && r.ok ? r : null;
    box.className = current ? "sel" : "sel bad";
    $("selWhat").textContent = current ? (HOST === "ae" ? "Шар у «" + r.where + "»" : "Кліп у «" + r.where + "»") : "Виділення";
    $("selName").textContent = current ? r.name : ((r && r.error) || "Виділи шар з відео");
    $("selRange").textContent = current ? fmt(r["in"]) + " – " + fmt(r.out) + "  ·  " + path.basename(r.file) : "";
    $("bOpen").disabled = !current;
  }
  function refreshSel() {
    if (selBusy) return;
    selBusy = true;
    jsx("ytf_selection()").then(function (r) { selBusy = false; showSel(r); });
  }
  setInterval(refreshSel, 1000);
  refreshSel();

  // ------------------------------------------------ сесії
  var sessions = [];
  function renderSessions() {
    $("sessions").innerHTML = sessions.map(function (s) {
      return '<div class="sess"><i></i><span>Відкрито: ' + s.label.replace(/</g, "&lt;") + "</span></div>";
    }).join("");
  }

  function launch(kind, sel) {
    var exe = $("exePath").value.trim() || findExe();
    if (!exe || !fs.existsSync(exe)) {
      status("Не знайдено YT Fragment.exe. Вкажи шлях у налаштуваннях внизу.", "e");
      return;
    }
    var dir = path.join(os.tmpdir(), "ytf_session_" + Date.now());
    fs.mkdirSync(dir);
    var session = { host: HOST, kind: kind };
    if (sel) {
      session.file = sel.file; session.name = sel.name; session["in"] = sel["in"]; session.out = sel.out;
      session.fps = sel.fps; session.target = sel.target;
    }
    fs.writeFileSync(path.join(dir, "session.json"), JSON.stringify(session), "utf8");
    try {
      // середовище без змінних вбудованого Chromium і Node з AE/Premiere, щоб вони не потрапили у WebView2 вікна
      var env = {};
      Object.keys(process.env).forEach(function (k) {
        if (!/^(CEF|CHROME|ELECTRON|NODE|WEBVIEW2|ADOBE_CEP|CEP_)/i.test(k)) env[k] = process.env[k];
      });
      var child = cp.spawn(exe, ["--session", dir], { cwd: path.dirname(exe), detached: true, stdio: "ignore", env: env });
      child.unref();
    } catch (e) {
      status("Не вдалося запустити програму: " + e.message, "e");
      return;
    }
    var s = { dir: dir, session: session, busy: false, label: sel ? sel.name : "YouTube", started: Date.now() };
    s.timer = setInterval(function () { pollSession(s); }, 250);
    sessions.push(s);
    renderSessions();
    status("Вікно відкривається…");
  }

  function closeSession(s) {
    clearInterval(s.timer);
    sessions = sessions.filter(function (x) { return x !== s; });
    renderSessions();
    setTimeout(function () { try { fs.rmSync ? fs.rmSync(s.dir, { recursive: true, force: true }) : rmdir(s.dir); } catch (e) {} }, 500);
  }
  function rmdir(d) {
    fs.readdirSync(d).forEach(function (f) { try { fs.unlinkSync(path.join(d, f)); } catch (e) {} });
    fs.rmdirSync(d);
  }

  function pollSession(s) {
    if (s.busy) return;
    var files;
    try { files = fs.readdirSync(s.dir); } catch (e) { return closeSession(s); }
    if (files.indexOf("closed") >= 0) return closeSession(s);
    var reqs = files.filter(function (f) { return /^req_\d+\.json$/.test(f); }).sort();
    if (!reqs.length) return;
    var name = reqs[0], req;
    try {
      req = JSON.parse(fs.readFileSync(path.join(s.dir, name), "utf8"));
      fs.unlinkSync(path.join(s.dir, name));
    } catch (e) { return; }
    s.busy = true;
    handle(s, req).then(function (res) {
      var out = path.join(s.dir, name.replace("req_", "res_"));
      try {
        fs.writeFileSync(out + ".tmp", JSON.stringify(res), "utf8");
        fs.renameSync(out + ".tmp", out);
      } catch (e) {}
      s.busy = false;
    });
  }

  function handle(s, req) {
    if (req.action === "apply") {
      status("Застосовую фрагменти…");
      var payload = { target: s.session.target, mode: req.mode, segments: req.segments };
      return jsx("ytf_apply('" + enc(payload) + "')").then(function (r) {
        if (r.error) { status(r.error, "e"); return { ok: false, error: r.error }; }
        status("Готово: " + r.made + (req.mode === "markers" ? " маркерів" : " фрагментів"), "ok");
        return { ok: true, made: r.made, note: r.note || "" };
      });
    }
    if (req.action === "import") {
      status("Імпортую файли…");
      return jsx("ytf_import('" + enc(req.files || []) + "')").then(function (r) {
        if (r.error) { status(r.error, "e"); return { ok: false, error: r.error }; }
        status("Імпортовано: " + r.made, "ok");
        return { ok: true, made: r.made };
      });
    }
    return Promise.resolve({ ok: false, error: "Невідомий запит" });
  }

  // ------------------------------------------------ кнопки
  $("bOpen").onclick = function () {
    jsx("ytf_selection()").then(function (r) {
      showSel(r);
      if (!r.ok) { status(r.error, "e"); return; }
      launch("layer", r);
    });
  };
  $("bYT").onclick = function () { launch("youtube", null); };
})();
