@echo off
setlocal
set "HERE=%~dp0"
set "EXT=%APPDATA%\Adobe\CEP\extensions\YTFragment"
set "APPDIR=%LOCALAPPDATA%\Programs\YT Fragment"
echo [1/2] Installing YT Fragment panel for After Effects and Premiere Pro...
if not exist "%APPDATA%\Adobe\CEP\extensions" mkdir "%APPDATA%\Adobe\CEP\extensions"
if exist "%EXT%" rmdir /s /q "%EXT%"
xcopy "%HERE%YTFragment" "%EXT%\" /e /i /y /q >nul
for %%v in (9 10 11 12 13) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
echo [2/2] Looking for the YT Fragment program...
if exist "%APPDIR%\YT Fragment.exe" (echo     Program already installed: %APPDIR% & goto :done)
if exist "%HERE%YT Fragment\YT Fragment.exe" (
  echo     Copying program to %APPDIR% ...
  xcopy "%HERE%YT Fragment" "%APPDIR%\" /e /i /y /q >nul
  goto :done
)
echo.
echo     !!! Program not found. The panel needs "YT Fragment.exe" to work.
echo     Download "Programa dlya Windows" (YT.Fragment.zip) from the site,
echo     unpack it so the "YT Fragment" folder is next to this install.bat, and run install.bat again.
echo     (Or set the path to YT Fragment.exe in the panel settings.)
:done
echo.
echo Done. Restart After Effects / Premiere Pro: Window ^> Extensions ^> YT Fragment
pause
